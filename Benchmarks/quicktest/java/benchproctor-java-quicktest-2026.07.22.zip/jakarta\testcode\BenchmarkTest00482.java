// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class BenchmarkTest00482 {

    record FormData(String payload) {}

    @GET
    @Path("/BenchmarkTest00482")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00482(@HeaderParam("Referer") String referer, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String refererValue = referer != null ? referer : "";
        FormData payload = new FormData(refererValue);
        String data = payload.payload();
        byte[] buf = new byte[Integer.parseInt(data)];
        response.setHeader("X-Alloc-Bytes", String.valueOf(buf.length));
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
