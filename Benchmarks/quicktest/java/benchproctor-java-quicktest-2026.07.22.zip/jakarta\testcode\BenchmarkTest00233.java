// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class BenchmarkTest00233 {

    private static String squeezeSpaces(String v) { return v.replaceAll(" {2,}", " "); }

    @GET
    @Path("/BenchmarkTest00233")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00233(@Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String envValue = java.util.Optional.ofNullable(System.getenv("USER_INPUT")).orElse("");
        String data = squeezeSpaces(envValue);
        byte[] buf = new byte[Integer.parseInt(data)];
        response.setHeader("X-Alloc-Bytes", String.valueOf(buf.length));
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
