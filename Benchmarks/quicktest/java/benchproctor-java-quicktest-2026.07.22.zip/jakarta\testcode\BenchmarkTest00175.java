// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.*;

@Path("/")
public class BenchmarkTest00175 {

    @GET
    @Path("/BenchmarkTest00175")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00175(@Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String configValue = java.util.Optional.ofNullable(new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("/etc/app/config.json")))).orElse("");
        request.setAttribute("carrier", configValue);
        String data = String.valueOf(request.getAttribute("carrier"));
        if (!data.matches("^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$")) {
            return Response.status(400).entity("forbidden").build();
        }
        try (java.io.FileWriter fw = new java.io.FileWriter("/var/data/secrets.txt")) {
            fw.write(data);
        }
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
