// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class BenchmarkTest00142 {

    @GET
    @Path("/BenchmarkTest00142")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00142(@HeaderParam("Host") String host, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String hostValue = host != null ? host : "";
        java.util.function.Function<String, String> firstStage = s -> s.replaceAll("[ ]{2,}", " ");
        java.util.function.Function<String, String> composed = firstStage.andThen(String::strip);
        String data = composed.apply(hostValue);
        java.util.Map<String, String> records = java.util.Map.of(
            "1001", "alice profile", "1002", "bob profile", "1003", "carol profile");
        String record = records.get(data);
        if (record != null) {
            return Response.ok("{\"resource\":\"" + record + "\"}", MediaType.APPLICATION_JSON).build();
        }
        return Response.status(404).entity("not found").build();
    }
}
