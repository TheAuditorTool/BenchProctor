// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class BenchmarkTest00330 {

    @GET
    @Path("/BenchmarkTest00330")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00330(@Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String dotenvValue = java.util.Optional.ofNullable(System.getenv("DOTENV_VAR")).orElse("");
        java.util.Map.Entry<String,String> pair = java.util.Map.entry(dotenvValue, "form");
        response.setHeader("X-Tuple-Context", pair.getValue());
        String data = pair.getKey();
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
        byte[] presentedHash = md.digest(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] storedHash = java.util.Base64.getDecoder().decode(java.util.Optional.ofNullable((String) request.getSession().getAttribute("credHash")).orElse(""));
        if (!java.security.MessageDigest.isEqual(presentedHash, storedHash)) { return Response.status(401).build(); }
        return Response.ok("{\"auth\":\"ok\"}", MediaType.APPLICATION_JSON).build();
    }
}
