// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class BenchmarkTest00307 {

    @GET
    @Path("/BenchmarkTest00307")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00307(@CookieParam("session_token") String sessionToken, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String cookieValue = sessionToken != null ? sessionToken : "";
        java.util.concurrent.CompletableFuture<String> fut = java.util.concurrent.CompletableFuture
            .supplyAsync(() -> cookieValue)
            .thenApply(v -> java.text.Normalizer.normalize(v, java.text.Normalizer.Form.NFC).strip());
        String data = fut.get(5, java.util.concurrent.TimeUnit.SECONDS);
        if (data.length() > 2048) { return Response.status(400).entity("schema invalid").build(); }
        response.sendRedirect(data);
        return Response.ok().build();
    }
}
