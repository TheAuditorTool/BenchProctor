// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.net.*;

@Path("/")
public class BenchmarkTest00435 {

    private static String collapseSpaces(String v) { return v.replaceAll("[ \\t]+", " "); }

    @GET
    @Path("/BenchmarkTest00435")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00435(@QueryParam("id") String id, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String userId = id != null ? id : "";
        String data = collapseSpaces(userId);
        if (data.length() > 2048) { return Response.status(400).entity("schema invalid").build(); }
        String socketRaw = String.valueOf(data);
        String socketHost = socketRaw.contains("://") ? java.net.URI.create(socketRaw).getHost() : socketRaw;
        new Socket(socketHost, 80).close();
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
