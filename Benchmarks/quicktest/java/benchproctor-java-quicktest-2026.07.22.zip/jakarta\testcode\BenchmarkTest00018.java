// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.*;
import java.net.*;

@Path("/")
public class BenchmarkTest00018 {

    @GET
    @Path("/BenchmarkTest00018")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00018(@CookieParam("session_token") String sessionToken, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String cookieValue = sessionToken != null ? sessionToken : "";
        String data = cookieValue.isEmpty() ? "default" : cookieValue;
        java.net.URI imdsParsed = java.net.URI.create(data.contains("://") ? data : "https://" + data);
        java.net.InetAddress imdsAddr = java.net.InetAddress.getByName(imdsParsed.getHost());
        if (imdsAddr.isAnyLocalAddress() || imdsAddr.isLoopbackAddress() || imdsAddr.isSiteLocalAddress() || imdsAddr.isLinkLocalAddress()) {
            return Response.status(403).build();
        }
        String targetUrl = imdsParsed.getScheme() + "://" + imdsParsed.getHost() + (imdsParsed.getPort() == -1 ? "" : ":" + imdsParsed.getPort());
        try {
            java.net.http.HttpRequest httpReq = java.net.http.HttpRequest.newBuilder(java.net.URI.create(targetUrl)).GET().build();
            java.net.http.HttpResponse<String> httpResp = java.net.http.HttpClient.newHttpClient().send(httpReq, java.net.http.HttpResponse.BodyHandlers.ofString());
            response.setHeader("X-Fetch-Status", String.valueOf(httpResp.statusCode()));
        } catch (Exception e) { return Response.status(502).build(); }
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
