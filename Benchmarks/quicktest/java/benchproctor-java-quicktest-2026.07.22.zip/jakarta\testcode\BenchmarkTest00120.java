// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.*;

@Path("/")
public class BenchmarkTest00120 {

    private static java.sql.Connection connection;
    static {
        try {
            connection = java.sql.DriverManager.getConnection("jdbc:h2:mem:bench;DB_CLOSE_DELAY=-1", "sa", "");
            try (var stmt = connection.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS users (id INT, name VARCHAR(64))");
                stmt.execute("INSERT INTO users (id, name) VALUES (1, 'alice')");
            }
        } catch (java.sql.SQLException ignored) {}
    }

    @GET
    @Path("/BenchmarkTest00120")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00120(@Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String secretValue = "default_setting_value";
        String data = String.format("%s", secretValue);
        if (data.isEmpty()) { return Response.status(400).entity("request required").build(); }
        java.util.Properties props = new java.util.Properties();
        try (java.io.InputStream propsStream = new java.io.FileInputStream("/etc/app/credentials.properties")) {
            props.load(propsStream);
        }
        String storeCred = props.getProperty("api.key", "");
        String dbPass = System.getenv("DB_PASSWORD");
        DriverManager.getConnection("jdbc:postgresql://db/prod", "app", dbPass);
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
