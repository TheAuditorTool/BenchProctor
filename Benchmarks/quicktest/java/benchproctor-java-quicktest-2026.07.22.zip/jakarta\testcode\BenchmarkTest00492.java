// SPDX-License-Identifier: Apache-2.0
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.security.*;

@Path("/")
public class BenchmarkTest00492 {

    @GET
    @Path("/BenchmarkTest00492")
    @Produces(MediaType.APPLICATION_JSON)
    public Response BenchmarkTest00492(@HeaderParam("Authorization") String authorization, @Context HttpServletRequest request, @Context HttpServletResponse response) throws Exception {
        String authHeader = authorization != null ? authorization : "";
        request.setAttribute("bundle", authHeader);
        String data = String.valueOf(request.getAttribute("bundle"));
        if (!data.matches("^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$")) {
            return Response.status(400).entity("forbidden").build();
        }
        byte[] digest = MessageDigest.getInstance("MD5").digest(data.getBytes());
        response.setHeader("X-Hash", java.util.Base64.getEncoder().encodeToString(digest));
        return Response.ok("{\"ready\":true}", MediaType.APPLICATION_JSON).build();
    }
}
