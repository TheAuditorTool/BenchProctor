#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00201() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  set -- "$user_input" "http"
  data="$1"
  ulimit -v 524288
  if [[ "$data" =~ ^[0-9]+$ ]]; then _req="$data"; else _req=0; fi
  (( _req > 1024 )) && _req=1024
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$_req" 2>/dev/null
}

benchmark_test_00201 "$@"
