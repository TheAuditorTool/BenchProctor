#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00027() {
  user_input="$HTTP_X_FORWARDED_FOR"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00027 "$@"
