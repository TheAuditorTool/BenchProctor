#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00314() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  xmllint --xpath "//user[name='$processed']" /var/data/users.xml
}

benchmark_test_00314 "$@"
