#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00271() {
  user_input="k7Qm2Rv9Lp4Tw8Nj3Zc"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00271 "$@"
