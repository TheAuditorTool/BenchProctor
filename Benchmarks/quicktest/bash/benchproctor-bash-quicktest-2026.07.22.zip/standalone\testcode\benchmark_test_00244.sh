#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00244() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00244 "$@"
