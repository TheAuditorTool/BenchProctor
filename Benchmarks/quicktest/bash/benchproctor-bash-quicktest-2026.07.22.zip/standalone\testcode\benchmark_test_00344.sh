#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00344() {
  user_input="$HTTP_COOKIE"
  data=$(printf "%b" "${user_input//%/\\x}")
  sudo -u nobody echo "$data"
}

benchmark_test_00344 "$@"
