#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00324() {
  user_input="$(cat /dev/stdin)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  ulimit -v 524288
  if [[ "$data" =~ ^[0-9]+$ ]]; then _req="$data"; else _req=0; fi
  (( _req > 1024 )) && _req=1024
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$_req" 2>/dev/null
}

benchmark_test_00324 "$@"
