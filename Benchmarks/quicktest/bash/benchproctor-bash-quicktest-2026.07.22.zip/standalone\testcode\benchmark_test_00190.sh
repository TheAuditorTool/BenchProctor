#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00190() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  echo "$data" | openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00190 "$@"
