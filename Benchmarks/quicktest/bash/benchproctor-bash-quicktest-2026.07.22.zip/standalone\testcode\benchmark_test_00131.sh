#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00131() {
  user_input="$DOTENV_VAR"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  echo "$processed" > /var/data/secrets.txt
}

benchmark_test_00131 "$@"
