#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00123() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(printf "%s" "$user_input")
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00123 "$@"
