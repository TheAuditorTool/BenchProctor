#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00067() {
  user_input="$APP_INPUT"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  curl -sk "$data"
}

benchmark_test_00067 "$@"
