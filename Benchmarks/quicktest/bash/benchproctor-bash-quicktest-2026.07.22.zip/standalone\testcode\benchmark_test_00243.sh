#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00243() {
  user_input="$HTTP_COOKIE"
  data="${user_input:-default}"
  echo -n "$data" | md5sum
}

benchmark_test_00243 "$@"
