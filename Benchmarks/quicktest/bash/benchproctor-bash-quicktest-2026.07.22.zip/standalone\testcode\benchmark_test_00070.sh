#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00070() {
  user_input="$QUERY_STRING"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "invalid"; exit 1; fi
  parsed_id="$data"
  mysql -e "SELECT * FROM users WHERE id = $parsed_id"
}

benchmark_test_00070 "$@"
