#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00205() {
  user_input="$HTTP_COOKIE"
  data="${user_input:-default}"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  echo "$processed,data,row" >> /var/data/output.csv
}

benchmark_test_00205 "$@"
