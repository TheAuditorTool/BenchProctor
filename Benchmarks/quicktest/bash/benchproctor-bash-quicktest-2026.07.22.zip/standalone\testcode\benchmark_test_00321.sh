#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00321() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=$(printf "%s" "$user_input")
  tar -czf /tmp/archive.tgz $data
}

benchmark_test_00321 "$@"
