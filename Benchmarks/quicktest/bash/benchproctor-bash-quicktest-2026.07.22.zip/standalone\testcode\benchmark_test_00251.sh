#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00251() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00251 "$@"
