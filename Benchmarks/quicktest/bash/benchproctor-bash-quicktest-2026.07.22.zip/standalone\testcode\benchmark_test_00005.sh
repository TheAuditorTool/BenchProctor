#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00005() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=$(printf "%b" "${user_input//%/\\x}")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00005 "$@"
