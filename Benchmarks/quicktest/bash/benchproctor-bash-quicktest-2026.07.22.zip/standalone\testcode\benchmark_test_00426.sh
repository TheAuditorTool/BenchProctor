#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00426() {
  user_input="$HTTP_X_FORWARDED_FOR"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  local -a _cmd=("echo" "$data")
  "${_cmd[@]}"
}

benchmark_test_00426 "$@"
