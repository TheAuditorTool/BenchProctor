#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00285() {
  user_input="$HTTP_COOKIE"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  processed=$(echo "$data" | tr -d '\r\n' | sed "s/[a-zA-Z0-9]\{4,\}/****/g")
  logger "Action: $processed"
}

benchmark_test_00285 "$@"
