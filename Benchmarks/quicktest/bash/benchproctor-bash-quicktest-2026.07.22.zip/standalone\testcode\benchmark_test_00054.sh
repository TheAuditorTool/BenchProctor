#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00054() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(printf "%s" "$user_input")
  redis-cli -s /var/run/redis.sock DEL "account:$data" >/dev/null 2>&1
}

benchmark_test_00054 "$@"
