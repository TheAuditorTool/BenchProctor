#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00289() {
  user_input="$UPLOAD_NAME"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  case $data in config.json|index.html|readme.md) checked_path="/var/app/data/$data";; *) echo "forbidden"; exit 1;; esac
  cat "$checked_path"
}

benchmark_test_00289 "$@"
