#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00432() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  eval "echo $data"
}

benchmark_test_00432 "$@"
