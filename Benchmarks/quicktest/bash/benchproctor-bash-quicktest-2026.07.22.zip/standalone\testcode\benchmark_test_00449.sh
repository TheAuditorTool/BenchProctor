#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00449() {
  user_input="$QUERY_STRING"
  printf -v data "%s" "${user_input}"
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00449 "$@"
