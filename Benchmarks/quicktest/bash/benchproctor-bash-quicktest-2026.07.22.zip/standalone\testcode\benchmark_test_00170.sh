#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00170() {
  user_input="$PATH_INFO"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  rm -f "/var/app/data/$data"
}

benchmark_test_00170 "$@"
