#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00425() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  printf -v data "%s" "${user_input}"
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  logger "Action: $parsed_bool"
}

benchmark_test_00425 "$@"
