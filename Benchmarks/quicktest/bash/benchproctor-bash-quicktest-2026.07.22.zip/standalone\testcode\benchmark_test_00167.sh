#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00167() {
  user_input="q9Cb4Ad2Fg8Ht3Vk6Mp"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00167 "$@"
