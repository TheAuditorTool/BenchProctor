#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00353() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  mysql -u app -p"$data" -e "SELECT 1"
}

benchmark_test_00353 "$@"
