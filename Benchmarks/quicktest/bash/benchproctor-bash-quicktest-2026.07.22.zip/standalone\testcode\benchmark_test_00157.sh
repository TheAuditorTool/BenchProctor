#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00157() {
  user_input="$HTTP_USER_AGENT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00157 "$@"
