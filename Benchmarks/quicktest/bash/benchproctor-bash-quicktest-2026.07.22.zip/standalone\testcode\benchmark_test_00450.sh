#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00450() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  curl -sk "$data"
}

benchmark_test_00450 "$@"
