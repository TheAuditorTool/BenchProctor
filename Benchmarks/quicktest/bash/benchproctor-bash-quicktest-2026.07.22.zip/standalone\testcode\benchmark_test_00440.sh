#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00440() {
  user_input="$HTTP_COOKIE"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00440 "$@"
