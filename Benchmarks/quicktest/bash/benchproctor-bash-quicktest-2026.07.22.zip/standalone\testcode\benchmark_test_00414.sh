#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00414() {
  user_input="$HTTP_COOKIE"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  eval "echo $data"
}

benchmark_test_00414 "$@"
