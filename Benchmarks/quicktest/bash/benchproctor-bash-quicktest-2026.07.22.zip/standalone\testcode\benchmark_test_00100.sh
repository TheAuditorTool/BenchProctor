#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00100() {
  user_input="$PATH_INFO"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  logger "Action: $parsed_bool"
}

benchmark_test_00100 "$@"
