#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00431() {
  user_input="$HTTP_ORIGIN"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  case "$data" in
    https://app.shcdn.net|https://cdn.shcdn.net) allowed_origin="$data";;
    *) echo "forbidden origin" >&2; exit 1;;
  esac
  printf '%s\r\n' "Access-Control-Allow-Origin: $allowed_origin"
}

benchmark_test_00431 "$@"
