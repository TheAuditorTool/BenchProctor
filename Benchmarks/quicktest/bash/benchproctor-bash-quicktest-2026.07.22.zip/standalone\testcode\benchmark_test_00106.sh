#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00106() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  input_value="$processed"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00106 "$@"
