#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00269() {
  user_input="$USER_COMMENT"
  data="${user_input//$'\x00'/}"
  echo "$data" | xmllint --nonet - > /dev/null 2>&1
}

benchmark_test_00269 "$@"
