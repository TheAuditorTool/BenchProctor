#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00477() {
  user_input="$DOTENV_VAR"
  printf -v data "%s" "${user_input}"
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00477 "$@"
