#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00469() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
}

benchmark_test_00469 "$@"
