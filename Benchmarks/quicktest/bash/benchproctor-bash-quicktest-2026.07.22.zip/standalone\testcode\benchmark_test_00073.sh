#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00073() {
  user_input="$PATH_INFO"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "$data" | openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00073 "$@"
