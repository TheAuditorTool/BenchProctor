#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00424() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  trusted_claim="$parsed_bool"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00424 "$@"
