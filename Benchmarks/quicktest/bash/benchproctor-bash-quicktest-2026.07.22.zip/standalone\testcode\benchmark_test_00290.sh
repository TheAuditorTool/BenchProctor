#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00290() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00290 "$@"
