#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00259() {
  user_input="$HTTP_X_FORWARDED_FOR"
  set -- "$user_input" "http"
  data="$1"
  ldapsearch -x -b "dc=example,dc=com" "uid=$data"
}

benchmark_test_00259 "$@"
