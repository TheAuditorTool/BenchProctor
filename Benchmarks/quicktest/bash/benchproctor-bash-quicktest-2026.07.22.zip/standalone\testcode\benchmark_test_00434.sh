#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00434() {
  user_input="$HTTP_AUTHORIZATION"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00434 "$@"
