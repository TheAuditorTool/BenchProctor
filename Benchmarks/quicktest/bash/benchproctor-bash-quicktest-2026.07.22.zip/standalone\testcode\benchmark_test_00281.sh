#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00281() {
  user_input="$HTTP_USER_AGENT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  tar -czf /tmp/archive.tgz $data
}

benchmark_test_00281 "$@"
