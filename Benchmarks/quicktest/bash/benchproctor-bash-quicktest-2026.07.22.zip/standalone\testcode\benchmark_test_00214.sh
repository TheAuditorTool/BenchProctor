#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00214() {
  user_input="$HTTP_AUTHORIZATION"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00214 "$@"
