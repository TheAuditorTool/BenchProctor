#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00316() {
  user_input="$HTTP_REFERER"
  set -- "$user_input" "http"
  data="$1"
  curl -sk "$data"
}

benchmark_test_00316 "$@"
