#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00331() {
  user_input="$PATH_INFO"
  curl -sk "$user_input"
}

benchmark_test_00331 "$@"
