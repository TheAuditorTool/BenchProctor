#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00046() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00046 "$@"
