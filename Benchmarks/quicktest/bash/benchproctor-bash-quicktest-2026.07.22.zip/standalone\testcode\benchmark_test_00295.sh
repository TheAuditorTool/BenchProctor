#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00295() {
  user_input="$PATH_INFO"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "Error: $data" >&2
}

benchmark_test_00295 "$@"
