#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00063() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  eval "echo $data"
}

benchmark_test_00063 "$@"
