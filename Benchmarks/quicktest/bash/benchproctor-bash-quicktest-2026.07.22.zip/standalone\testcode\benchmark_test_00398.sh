#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00398() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  curl -s -H "Authorization: Bearer $data" http://api.internal/data > /dev/null
}

benchmark_test_00398 "$@"
