#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00351() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  curl -s -H "Authorization: Bearer $data" http://api.internal/data > /dev/null
}

benchmark_test_00351 "$@"
