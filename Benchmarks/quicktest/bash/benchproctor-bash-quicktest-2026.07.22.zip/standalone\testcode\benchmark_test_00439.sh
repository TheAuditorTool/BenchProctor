#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00439() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  printf '%s\r\n' "Access-Control-Allow-Origin: $data"
}

benchmark_test_00439 "$@"
