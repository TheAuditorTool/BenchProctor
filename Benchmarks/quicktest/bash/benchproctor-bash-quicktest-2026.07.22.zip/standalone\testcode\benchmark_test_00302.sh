#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00302() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  echo -n "$data" | md5sum
}

benchmark_test_00302 "$@"
