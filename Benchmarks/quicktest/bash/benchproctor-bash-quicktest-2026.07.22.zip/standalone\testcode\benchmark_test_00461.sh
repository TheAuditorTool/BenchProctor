#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00461() {
  user_input="$HTTP_USER_AGENT"
  printf -v data "%s" "${user_input}"
  case "$data" in
    https://app.shcdn.net|https://cdn.shcdn.net) allowed_origin="$data";;
    *) echo "forbidden origin" >&2; exit 1;;
  esac
  printf '%s\r\n' "Access-Control-Allow-Origin: $allowed_origin"
}

benchmark_test_00461 "$@"
