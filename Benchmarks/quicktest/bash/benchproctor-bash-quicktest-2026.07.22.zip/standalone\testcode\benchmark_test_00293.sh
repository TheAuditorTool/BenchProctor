#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00293() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  eval "echo $processed"
}

benchmark_test_00293 "$@"
