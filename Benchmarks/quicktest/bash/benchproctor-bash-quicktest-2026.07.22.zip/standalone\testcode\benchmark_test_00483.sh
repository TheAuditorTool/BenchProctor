#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00483() {
  user_input="$QUERY_STRING"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  redis-cli -s /var/run/redis.sock DEL "account:$data" >/dev/null 2>&1
}

benchmark_test_00483 "$@"
