#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00139() {
  user_input="$QUERY_STRING"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00139 "$@"
