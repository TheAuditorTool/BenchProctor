#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00218() {
  user_input="$(cat /dev/stdin)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  logger "Action: $processed"
}

benchmark_test_00218 "$@"
