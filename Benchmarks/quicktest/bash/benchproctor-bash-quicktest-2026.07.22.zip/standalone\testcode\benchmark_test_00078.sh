#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00078() {
  user_input="$QUERY_STRING"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo -n "$data" | md5sum
}

benchmark_test_00078 "$@"
