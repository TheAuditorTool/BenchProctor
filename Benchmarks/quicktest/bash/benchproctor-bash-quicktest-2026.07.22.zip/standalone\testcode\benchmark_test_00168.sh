#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00168() {
  user_input="$APP_INPUT"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  logger "Action: $processed"
}

benchmark_test_00168 "$@"
