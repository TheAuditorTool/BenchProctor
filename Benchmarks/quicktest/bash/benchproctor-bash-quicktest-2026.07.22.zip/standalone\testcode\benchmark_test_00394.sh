#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00394() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  tar -czf /tmp/archive.tgz $processed
}

benchmark_test_00394 "$@"
