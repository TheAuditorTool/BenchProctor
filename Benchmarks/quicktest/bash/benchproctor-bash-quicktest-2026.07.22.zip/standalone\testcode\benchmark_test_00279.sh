#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00279() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _host=$(echo "$data" | awk -F[/:] '{print $4}')
  if [[ ! "$_host" =~ \.(internal\.corp|example\.com)$ ]]; then echo "forbidden host"; exit 1; fi
  target_url="$data"
  _body=$(curl -s "$target_url")
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00279 "$@"
