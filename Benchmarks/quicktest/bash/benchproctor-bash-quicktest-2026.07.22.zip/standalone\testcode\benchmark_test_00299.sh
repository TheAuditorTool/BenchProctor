#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00299() {
  user_input="$HTTP_USER_AGENT"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo "Error: $data" >&2
}

benchmark_test_00299 "$@"
