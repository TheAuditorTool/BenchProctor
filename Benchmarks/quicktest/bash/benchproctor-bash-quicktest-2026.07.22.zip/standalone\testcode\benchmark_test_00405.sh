#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00405() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  eval "echo $data"
}

benchmark_test_00405 "$@"
