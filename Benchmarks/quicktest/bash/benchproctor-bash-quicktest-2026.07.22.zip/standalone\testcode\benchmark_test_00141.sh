#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00141() {
  user_input="$QUERY_STRING"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  printf "X-Custom: %s\r\n" "$parsed_bool"
}

benchmark_test_00141 "$@"
