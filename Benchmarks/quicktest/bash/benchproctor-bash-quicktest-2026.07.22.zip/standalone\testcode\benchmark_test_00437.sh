#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00437() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  _fname=$(basename -- "$user_input")
  case "$_fname" in *.jpg|*.png|*.gif|*.pdf) entry_file="$_fname";; *) echo "invalid file type"; exit 1;; esac
  echo "uploaded" > "/var/uploads/$entry_file"
}

benchmark_test_00437 "$@"
