#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00066() {
  user_input="$(cat /dev/stdin)"
  set -- "$user_input" "http"
  data="$1"
  echo "$data" | xmllint --nonet - > /dev/null 2>&1
}

benchmark_test_00066 "$@"
