#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00347() {
  user_input="$HTTP_HOST"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00347 "$@"
