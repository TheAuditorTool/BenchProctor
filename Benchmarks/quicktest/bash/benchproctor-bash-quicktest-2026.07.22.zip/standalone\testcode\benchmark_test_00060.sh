#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00060() {
  user_input="$HTTP_HOST"
  set -- "$user_input" "http"
  data="$1"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  xmllint --xpath "//user[name='$processed']" /var/data/users.xml
}

benchmark_test_00060 "$@"
