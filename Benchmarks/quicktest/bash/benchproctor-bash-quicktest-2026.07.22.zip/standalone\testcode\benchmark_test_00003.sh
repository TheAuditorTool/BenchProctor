#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00003() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%b" "$user_input")
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00003 "$@"
