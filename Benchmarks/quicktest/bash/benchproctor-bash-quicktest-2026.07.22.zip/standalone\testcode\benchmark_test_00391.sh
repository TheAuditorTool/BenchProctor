#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00391() {
  user_input="$QUERY_STRING"
  data="${user_input:-default}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  mysql -e "SELECT * FROM users WHERE id = '$processed'"
}

benchmark_test_00391 "$@"
