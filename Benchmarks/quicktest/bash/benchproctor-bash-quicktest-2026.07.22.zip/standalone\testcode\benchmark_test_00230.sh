#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00230() {
  user_input="$PATH_INFO"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  input_value="$data"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00230 "$@"
