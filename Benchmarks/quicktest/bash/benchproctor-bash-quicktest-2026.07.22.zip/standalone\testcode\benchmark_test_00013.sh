#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00013() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  curl -s "$data"
}

benchmark_test_00013 "$@"
