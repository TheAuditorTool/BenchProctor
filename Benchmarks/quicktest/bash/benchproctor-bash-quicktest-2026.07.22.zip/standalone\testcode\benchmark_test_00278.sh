#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00278() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  echo "Error: $data" >&2
}

benchmark_test_00278 "$@"
