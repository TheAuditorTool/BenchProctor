#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00403() {
  user_input="$HTTP_AUTHORIZATION"
  data="${user_input:-default}"
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00403 "$@"
