#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00210() {
  user_input="$HTTP_REFERER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  _body=$(curl -s "$data")
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00210 "$@"
