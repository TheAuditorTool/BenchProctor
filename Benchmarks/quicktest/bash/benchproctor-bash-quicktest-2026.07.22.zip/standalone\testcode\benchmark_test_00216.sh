#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00216() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  rm -f "$checked_path"
}

benchmark_test_00216 "$@"
