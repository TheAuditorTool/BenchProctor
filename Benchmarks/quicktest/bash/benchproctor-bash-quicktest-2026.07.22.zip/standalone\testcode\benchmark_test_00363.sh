#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00363() {
  user_input="$QUERY_STRING"
  data="${user_input:-default}"
  echo "Error: $data" >&2
}

benchmark_test_00363 "$@"
