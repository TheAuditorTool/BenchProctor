#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00004() {
  user_input="$PATH_INFO"
  data=$(printf "%b" "${user_input//%/\\x}")
  echo "Error: $data" >&2
}

benchmark_test_00004 "$@"
