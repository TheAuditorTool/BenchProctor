#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00435() {
  user_input="$HTTP_AUTHORIZATION"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  curl -sk "$data"
}

benchmark_test_00435 "$@"
