#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00417() {
  user_input="k7Qm2Rv9Lp4Tw8Nj3Zc"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00417 "$@"
