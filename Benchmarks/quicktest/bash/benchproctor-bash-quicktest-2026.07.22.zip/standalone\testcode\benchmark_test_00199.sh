#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00199() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data="${user_input:-default}"
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00199 "$@"
