#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00444() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  local -a _cmd=("echo" "$data")
  "${_cmd[@]}"
}

benchmark_test_00444 "$@"
