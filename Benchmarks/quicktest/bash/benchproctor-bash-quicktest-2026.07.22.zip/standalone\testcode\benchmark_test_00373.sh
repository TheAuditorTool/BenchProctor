#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00373() {
  user_input="q9Cb4Ad2Fg8Ht3Vk6Mp"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo '{"sub":"1"}' | openssl dgst -sha256 -hmac "$data" > /dev/null
}

benchmark_test_00373 "$@"
