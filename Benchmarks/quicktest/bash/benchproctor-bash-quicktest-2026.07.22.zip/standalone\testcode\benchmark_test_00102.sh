#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00102() {
  user_input="$QUERY_STRING"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  printf '%s\r\n' "Access-Control-Allow-Origin: $data"
}

benchmark_test_00102 "$@"
