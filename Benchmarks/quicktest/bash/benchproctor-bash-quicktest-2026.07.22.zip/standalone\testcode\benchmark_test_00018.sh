#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00018() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  printf -v data "%s" "${user_input}"
  echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
}

benchmark_test_00018 "$@"
