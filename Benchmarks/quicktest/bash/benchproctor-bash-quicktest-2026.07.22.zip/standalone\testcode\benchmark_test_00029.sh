#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00029() {
  user_input="$HTTP_HOST"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  case "$data" in *DROP*|*DELETE*) echo "invalid schema" >&2; exit 1;; esac
  processed="$data"
  if [[ "$processed" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $processed" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00029 "$@"
