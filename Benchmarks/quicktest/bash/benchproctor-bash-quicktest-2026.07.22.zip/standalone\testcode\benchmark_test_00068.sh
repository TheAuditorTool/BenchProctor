#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00068() {
  user_input="$(cat /dev/stdin)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  processed=$(echo "$data" | tr -d '\r\n' | sed "s/[a-zA-Z0-9]\{4,\}/****/g")
  logger "Action: $processed"
}

benchmark_test_00068 "$@"
