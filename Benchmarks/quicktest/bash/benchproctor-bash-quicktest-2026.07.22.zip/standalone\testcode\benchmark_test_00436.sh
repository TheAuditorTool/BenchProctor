#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00436() {
  user_input="$APP_INPUT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  _body=$(curl -s "$data")
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00436 "$@"
