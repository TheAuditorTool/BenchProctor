#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00183() {
  user_input="$HTTP_X_FORWARDED_FOR"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _bypass_re='^[a-zA-Z0-9 _.,;:/=()|+@-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  if [[ ! "$processed" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  requested=$processed
  alloc_size=$((requested + 1))
  echo "alloc:$alloc_size"
}

benchmark_test_00183 "$@"
