#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00071() {
  user_input="$APP_INPUT"
  data=$(printf "%s" "$user_input")
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00071 "$@"
