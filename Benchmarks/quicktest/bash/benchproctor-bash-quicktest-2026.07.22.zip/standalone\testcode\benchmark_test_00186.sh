#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00186() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(printf "%s" "$user_input")
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00186 "$@"
