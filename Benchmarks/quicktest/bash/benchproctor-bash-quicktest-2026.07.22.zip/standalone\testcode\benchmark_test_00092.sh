#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00092() {
  user_input="$HTTP_COOKIE"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00092 "$@"
