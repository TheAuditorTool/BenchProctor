#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00107() {
  user_input="$(cat /dev/stdin)"
  printf -v data "%s" "${user_input}"
  cat "/var/app/data/$data"
}

benchmark_test_00107 "$@"
