#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00413() {
  user_input="$HTTP_USER_AGENT"
  data="${user_input:-default}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  eval "echo $processed"
}

benchmark_test_00413 "$@"
