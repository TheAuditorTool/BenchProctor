#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00256() {
  user_input="$QUERY_STRING"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00256 "$@"
