#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00138() {
  user_input="$APP_INPUT"
  set -- "$user_input" "http"
  data="$1"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00138 "$@"
