#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00114() {
  user_input="$HTTP_AUTHORIZATION"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  echo -n "$data" | md5sum
}

benchmark_test_00114 "$@"
