#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00096() {
  user_input="$(cat /dev/stdin)"
  set -- "$user_input" "http"
  data="$1"
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00096 "$@"
