#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00156() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(printf "%s" "$user_input")
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  input_value="$parsed_bool"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00156 "$@"
