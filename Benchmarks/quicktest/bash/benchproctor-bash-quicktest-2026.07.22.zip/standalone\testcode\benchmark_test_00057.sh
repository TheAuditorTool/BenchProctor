#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00057() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo -n "$data" | md5sum
}

benchmark_test_00057 "$@"
