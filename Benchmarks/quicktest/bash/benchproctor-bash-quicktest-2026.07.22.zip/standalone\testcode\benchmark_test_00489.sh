#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00489() {
  user_input="$HTTP_HOST"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  local -a _cmd=("echo" "$data")
  "${_cmd[@]}"
}

benchmark_test_00489 "$@"
