#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00174() {
  user_input="$APP_INPUT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  logger "Action: $data"
}

benchmark_test_00174 "$@"
