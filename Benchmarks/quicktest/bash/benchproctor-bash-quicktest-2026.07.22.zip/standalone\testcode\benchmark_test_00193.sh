#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00193() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00193 "$@"
