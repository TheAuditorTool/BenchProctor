#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00262() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  printf -v data "%s" "${user_input}"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  curl -s "$target_url"
}

benchmark_test_00262 "$@"
