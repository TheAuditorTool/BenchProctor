#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00127() {
  user_input="$HTTP_ORIGIN"
  data="${user_input:-default}"
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00127 "$@"
