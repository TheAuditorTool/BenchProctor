#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00341() {
  user_input="$HTTP_COOKIE"
  ls -la -- "$user_input" 2>&1
}

benchmark_test_00341 "$@"
