#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00468() {
  user_input="$(cat /dev/stdin)"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  _bypass_re='^[^<>]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00468 "$@"
