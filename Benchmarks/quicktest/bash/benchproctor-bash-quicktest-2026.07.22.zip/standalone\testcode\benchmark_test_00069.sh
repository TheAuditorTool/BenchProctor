#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00069() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(printf "%s" "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00069 "$@"
