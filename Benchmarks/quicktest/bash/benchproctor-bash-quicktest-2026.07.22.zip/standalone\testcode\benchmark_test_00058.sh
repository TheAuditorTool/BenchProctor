#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00058() {
  user_input="$(cat /dev/stdin)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  requested=$data
  alloc_size=$((requested + 1))
  echo "alloc:$alloc_size"
}

benchmark_test_00058 "$@"
