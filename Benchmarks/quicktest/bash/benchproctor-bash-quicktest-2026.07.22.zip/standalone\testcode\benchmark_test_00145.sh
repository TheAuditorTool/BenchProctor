#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00145() {
  user_input="$HTTP_ORIGIN"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00145 "$@"
