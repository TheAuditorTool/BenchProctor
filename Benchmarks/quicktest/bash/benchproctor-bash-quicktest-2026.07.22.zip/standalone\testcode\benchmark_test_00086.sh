#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00086() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  curl -s "$user_input"
}

benchmark_test_00086 "$@"
