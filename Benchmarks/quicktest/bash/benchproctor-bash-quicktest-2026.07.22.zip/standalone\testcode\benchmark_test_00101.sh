#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00101() {
  user_input="$HTTP_HOST"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _fname=$(basename -- "$data")
  case "$_fname" in *.jpg|*.png|*.gif|*.pdf) entry_file="$_fname";; *) echo "invalid file type"; exit 1;; esac
  echo "uploaded" > "/var/uploads/$entry_file"
}

benchmark_test_00101 "$@"
