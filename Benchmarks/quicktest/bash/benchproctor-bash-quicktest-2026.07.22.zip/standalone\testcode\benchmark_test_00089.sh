#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00089() {
  user_input="$QUERY_STRING"
  data=$(printf "%b" "${user_input//%/\\x}")
  checked_path="/var/app/data/$(basename -- "$data")"
  rm -f "$checked_path"
}

benchmark_test_00089 "$@"
