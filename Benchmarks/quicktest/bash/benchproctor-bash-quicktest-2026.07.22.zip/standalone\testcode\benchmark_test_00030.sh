#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00030() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00030 "$@"
