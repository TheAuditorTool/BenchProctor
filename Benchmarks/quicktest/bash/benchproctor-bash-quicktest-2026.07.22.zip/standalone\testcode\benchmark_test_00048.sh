#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00048() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00048 "$@"
