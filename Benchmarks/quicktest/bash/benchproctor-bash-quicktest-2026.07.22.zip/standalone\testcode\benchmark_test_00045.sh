#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00045() {
  user_input="$HTTP_HOST"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  echo "$processed,data,row" >> /var/data/output.csv
}

benchmark_test_00045 "$@"
