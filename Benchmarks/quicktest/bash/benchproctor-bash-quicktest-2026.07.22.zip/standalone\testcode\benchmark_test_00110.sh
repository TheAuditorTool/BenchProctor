#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00110() {
  user_input="$HTTP_ORIGIN"
  data="${user_input:-default}"
  echo -n "$data" | md5sum
}

benchmark_test_00110 "$@"
