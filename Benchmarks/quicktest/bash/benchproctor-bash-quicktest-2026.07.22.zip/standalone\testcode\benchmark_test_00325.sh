#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00325() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  echo "Error: $data" >&2
}

benchmark_test_00325 "$@"
