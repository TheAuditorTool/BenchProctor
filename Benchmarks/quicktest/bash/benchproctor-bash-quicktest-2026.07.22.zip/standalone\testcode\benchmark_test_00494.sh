#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00494() {
  store_cred=$(vault kv get -field=secret secret/app 2>/dev/null || echo "")
  mysql -u app -p"$store_cred" -e "SELECT 1"
}

benchmark_test_00494 "$@"
