#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00473() {
  user_input="$HTTP_X_FORWARDED_FOR"
  set -- "$user_input" "http"
  data="$1"
  printf "X-Custom: %s\r\n" "$data"
}

benchmark_test_00473 "$@"
