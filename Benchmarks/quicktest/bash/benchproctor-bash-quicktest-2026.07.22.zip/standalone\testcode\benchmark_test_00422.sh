#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00422() {
  user_input="$PATH_INFO"
  data="${user_input//$'\x00'/}"
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00422 "$@"
