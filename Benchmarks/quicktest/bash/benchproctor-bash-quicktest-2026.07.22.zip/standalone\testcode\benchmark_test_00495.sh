#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00495() {
  user_input="$(cat /dev/stdin)"
  echo -n "$user_input" | md5sum
}

benchmark_test_00495 "$@"
