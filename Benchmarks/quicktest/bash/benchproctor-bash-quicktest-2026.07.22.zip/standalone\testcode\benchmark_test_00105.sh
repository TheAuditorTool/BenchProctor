#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00105() {
  user_input="$APP_INPUT"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  echo -n "$data" | sha256sum
}

benchmark_test_00105 "$@"
