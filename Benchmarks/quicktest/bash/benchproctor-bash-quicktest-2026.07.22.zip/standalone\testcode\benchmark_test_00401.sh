#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00401() {
  user_input="$HTTP_AUTHORIZATION"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _bypass_re='^[a-zA-Z0-9 _.,;:/=()|+@-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  echo "$processed" > /var/data/secrets.txt
}

benchmark_test_00401 "$@"
