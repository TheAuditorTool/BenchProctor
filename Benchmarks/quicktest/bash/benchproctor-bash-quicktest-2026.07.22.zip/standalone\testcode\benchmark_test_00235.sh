#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00235() {
  user_input="$(cat /dev/stdin)"
  set -- "$user_input" "http"
  data="$1"
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00235 "$@"
