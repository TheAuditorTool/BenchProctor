#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00222() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  curl -s "$data"
}

benchmark_test_00222 "$@"
