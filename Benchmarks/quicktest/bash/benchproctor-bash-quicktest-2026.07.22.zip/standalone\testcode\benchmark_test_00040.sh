#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00040() {
  user_input="$(mysql -N -e 'SELECT bio FROM profiles LIMIT 1')"
  set -- "$user_input" "http"
  data="$1"
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00040 "$@"
