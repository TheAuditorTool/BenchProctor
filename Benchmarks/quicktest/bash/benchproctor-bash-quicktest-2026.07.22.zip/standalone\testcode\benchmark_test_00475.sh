#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00475() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  set -- "$user_input" "http"
  data="$1"
  echo "Error: $data" >&2
}

benchmark_test_00475 "$@"
