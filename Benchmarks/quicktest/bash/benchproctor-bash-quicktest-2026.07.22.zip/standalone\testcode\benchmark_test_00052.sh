#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00052() {
  user_input="$HTTP_USER_AGENT"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  input_value="$parsed_bool"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00052 "$@"
