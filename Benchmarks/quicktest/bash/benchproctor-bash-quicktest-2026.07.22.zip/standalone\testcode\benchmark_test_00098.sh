#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00098() {
  user_input="$QUERY_STRING"
  curl -s "$user_input"
}

benchmark_test_00098 "$@"
