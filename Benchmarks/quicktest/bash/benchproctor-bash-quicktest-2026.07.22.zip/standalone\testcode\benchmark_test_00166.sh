#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00166() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  printf "Location: %s\r\n\r\n" "$processed"
}

benchmark_test_00166 "$@"
