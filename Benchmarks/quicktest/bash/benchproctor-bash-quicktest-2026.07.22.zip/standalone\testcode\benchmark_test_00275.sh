#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00275() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00275 "$@"
