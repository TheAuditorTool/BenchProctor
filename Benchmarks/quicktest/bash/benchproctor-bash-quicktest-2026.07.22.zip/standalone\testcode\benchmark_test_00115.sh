#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00115() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data="${user_input//$'\x00'/}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  echo "$processed,data,row" >> /var/data/output.csv
}

benchmark_test_00115 "$@"
