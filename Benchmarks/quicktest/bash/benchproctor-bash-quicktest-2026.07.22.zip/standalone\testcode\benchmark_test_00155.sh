#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00155() {
  user_input="$(cat /dev/stdin)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  curl -sk "$data"
}

benchmark_test_00155 "$@"
