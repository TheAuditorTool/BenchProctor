#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00080() {
  user_input="$(cat /dev/stdin)"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  printf "Location: %s\r\n\r\n" "$target_url"
}

benchmark_test_00080 "$@"
