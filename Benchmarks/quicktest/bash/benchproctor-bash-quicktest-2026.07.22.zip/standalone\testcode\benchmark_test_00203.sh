#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00203() {
  user_input="$(cat /dev/stdin)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  eval "echo $processed"
}

benchmark_test_00203 "$@"
