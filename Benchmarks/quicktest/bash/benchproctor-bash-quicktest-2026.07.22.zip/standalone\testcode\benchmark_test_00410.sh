#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00410() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%b" "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  echo "$processed,data,row" >> /var/data/output.csv
}

benchmark_test_00410 "$@"
