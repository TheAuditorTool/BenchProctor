#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00447() {
  user_input="$HTTP_AUTHORIZATION"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00447 "$@"
