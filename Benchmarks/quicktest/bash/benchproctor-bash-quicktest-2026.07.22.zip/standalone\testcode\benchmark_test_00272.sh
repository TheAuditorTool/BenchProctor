#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00272() {
  user_input="$HTTP_HOST"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  ls -la -- "$data" 2>&1
}

benchmark_test_00272 "$@"
