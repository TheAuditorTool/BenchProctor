#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00035() {
  user_input="$HTTP_X_FORWARDED_FOR"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  requested=$data
  alloc_size=$((requested + 1))
  echo "alloc:$alloc_size"
}

benchmark_test_00035 "$@"
