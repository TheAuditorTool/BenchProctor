#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00121() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  ldapsearch -x -b "dc=example,dc=com" "uid=$data"
}

benchmark_test_00121 "$@"
