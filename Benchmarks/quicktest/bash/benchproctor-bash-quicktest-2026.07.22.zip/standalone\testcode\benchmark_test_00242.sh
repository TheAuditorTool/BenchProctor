#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00242() {
  user_input="$HTTP_REFERER"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  sudo bash -c "echo $processed"
}

benchmark_test_00242 "$@"
