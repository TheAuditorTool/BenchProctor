#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00250() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00250 "$@"
