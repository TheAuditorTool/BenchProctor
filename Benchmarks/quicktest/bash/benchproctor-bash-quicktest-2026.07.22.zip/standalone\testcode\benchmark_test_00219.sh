#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00219() {
  user_input="$HTTP_USER_AGENT"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  curl -sk "$data"
}

benchmark_test_00219 "$@"
