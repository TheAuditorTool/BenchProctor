#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00462() {
  user_input="$PATH_INFO"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  echo "Error: $data" >&2
}

benchmark_test_00462 "$@"
