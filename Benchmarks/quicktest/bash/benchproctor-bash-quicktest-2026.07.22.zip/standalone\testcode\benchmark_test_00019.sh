#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00019() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  if [[ "$user_input" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $user_input" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00019 "$@"
