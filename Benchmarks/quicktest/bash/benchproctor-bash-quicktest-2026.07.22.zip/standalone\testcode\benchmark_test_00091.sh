#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00091() {
  user_input="$(cat /dev/stdin)"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  case "$data" in
    https://app.shcdn.net|https://cdn.shcdn.net) allowed_origin="$data";;
    *) echo "forbidden origin" >&2; exit 1;;
  esac
  printf '%s\r\n' "Access-Control-Allow-Origin: $allowed_origin"
}

benchmark_test_00091 "$@"
