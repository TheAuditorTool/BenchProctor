#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00362() {
  user_input="$USER_COMMENT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  eval "tar -czf /tmp/archive.tgz $data"
}

benchmark_test_00362 "$@"
