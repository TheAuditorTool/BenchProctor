#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00464() {
  user_input="$HTTP_USER_AGENT"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  case "$data" in *DROP*|*DELETE*) echo "invalid schema" >&2; exit 1;; esac
  processed="$data"
  redis-cli -s /var/run/redis.sock DEL "account:$processed" >/dev/null 2>&1
}

benchmark_test_00464 "$@"
