#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00456() {
  user_input="$QUERY_STRING"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$user_input" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$user_input"
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00456 "$@"
