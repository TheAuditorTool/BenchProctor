#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00142() {
  store_cred="$APP_SECRET"
  if [ -z "$store_cred" ]; then echo "missing credential" >&2; exit 1; fi
  echo "granted" >> /var/log/auth.audit
}

benchmark_test_00142 "$@"
