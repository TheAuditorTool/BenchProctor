#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00176() {
  user_input="$HTTP_X_FORWARDED_FOR"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  echo "data" > "/var/uploads/$processed"
}

benchmark_test_00176 "$@"
