#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00254() {
  user_input="$USER_COMMENT"
  data="${user_input//$'\x00'/}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00254 "$@"
