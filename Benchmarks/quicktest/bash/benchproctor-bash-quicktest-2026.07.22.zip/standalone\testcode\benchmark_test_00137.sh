#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00137() {
  user_input="$HTTP_REFERER"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  _bypass_re='^[a-zA-Z0-9 _.,;:/=[:space:]-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00137 "$@"
