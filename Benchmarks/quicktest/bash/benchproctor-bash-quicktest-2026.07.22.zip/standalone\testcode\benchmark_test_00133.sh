#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00133() {
  user_input="$(cat /dev/stdin)"
  printf -v data "%s" "${user_input}"
  printf '%s\r\n' "Access-Control-Allow-Origin: $data"
}

benchmark_test_00133 "$@"
