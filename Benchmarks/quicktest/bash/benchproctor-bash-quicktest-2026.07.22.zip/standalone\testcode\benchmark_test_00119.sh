#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00119() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data="${user_input:-default}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  input_value="$processed"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00119 "$@"
