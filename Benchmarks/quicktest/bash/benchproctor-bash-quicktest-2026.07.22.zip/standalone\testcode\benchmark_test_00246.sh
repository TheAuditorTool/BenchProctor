#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00246() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  printf -v data "%s" "${user_input}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00246 "$@"
