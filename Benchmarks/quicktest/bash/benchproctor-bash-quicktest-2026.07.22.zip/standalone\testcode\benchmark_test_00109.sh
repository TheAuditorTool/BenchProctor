#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00109() {
  user_input="$HTTP_COOKIE"
  data=$(printf "%b" "${user_input//%/\\x}")
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00109 "$@"
