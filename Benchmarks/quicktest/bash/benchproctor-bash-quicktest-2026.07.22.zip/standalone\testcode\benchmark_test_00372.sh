#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00372() {
  user_input="$HTTP_HOST"
  if [[ ! $user_input =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$user_input"
  logger "Action: $processed"
}

benchmark_test_00372 "$@"
