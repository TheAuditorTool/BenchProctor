#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00221() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00221 "$@"
