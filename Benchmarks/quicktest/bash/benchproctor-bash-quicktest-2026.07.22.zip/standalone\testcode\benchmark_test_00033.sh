#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00033() {
  user_input="$HTTP_X_FORWARDED_FOR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  eval "echo $processed"
}

benchmark_test_00033 "$@"
