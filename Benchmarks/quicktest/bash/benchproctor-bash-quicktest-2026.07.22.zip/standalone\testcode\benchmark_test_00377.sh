#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00377() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(printf "%s" "$user_input")
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00377 "$@"
