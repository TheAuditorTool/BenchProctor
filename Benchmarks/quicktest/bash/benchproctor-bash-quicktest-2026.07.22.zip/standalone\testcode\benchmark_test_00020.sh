#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00020() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00020 "$@"
