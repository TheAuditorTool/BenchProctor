#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00134() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  eval "echo $processed"
}

benchmark_test_00134 "$@"
