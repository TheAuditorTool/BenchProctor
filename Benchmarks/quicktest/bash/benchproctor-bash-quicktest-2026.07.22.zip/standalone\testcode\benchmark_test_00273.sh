#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00273() {
  user_input="$HTTP_X_FORWARDED_FOR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  if [[ "$processed" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $processed" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00273 "$@"
