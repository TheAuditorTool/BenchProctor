#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00490() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00490 "$@"
