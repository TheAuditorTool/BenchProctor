#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00112() {
  user_input="$(cat /etc/app/config)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo -n "$data" | sha256sum
}

benchmark_test_00112 "$@"
