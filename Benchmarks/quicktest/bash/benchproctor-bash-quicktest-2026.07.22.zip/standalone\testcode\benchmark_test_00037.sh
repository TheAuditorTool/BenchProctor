#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00037() {
  user_input="$QUERY_STRING"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00037 "$@"
