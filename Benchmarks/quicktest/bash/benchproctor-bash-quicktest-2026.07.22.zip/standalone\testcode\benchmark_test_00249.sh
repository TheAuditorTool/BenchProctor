#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00249() {
  user_input="$HTTP_HOST"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  mongosh --eval "db.users.find({name: '$processed'})"
}

benchmark_test_00249 "$@"
