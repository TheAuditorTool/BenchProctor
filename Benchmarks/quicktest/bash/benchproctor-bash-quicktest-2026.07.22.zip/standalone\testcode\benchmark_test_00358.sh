#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00358() {
  user_input="$QUERY_STRING"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  printf "Location: %s\r\n\r\n" "$data"
}

benchmark_test_00358 "$@"
