#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00095() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00095 "$@"
