#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00207() {
  user_input="$HTTP_COOKIE"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  printf "X-Custom: %s\r\n" "$data"
}

benchmark_test_00207 "$@"
