#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00097() {
  user_input="$USER_COMMENT"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  echo "Error: $data" >&2
}

benchmark_test_00097 "$@"
