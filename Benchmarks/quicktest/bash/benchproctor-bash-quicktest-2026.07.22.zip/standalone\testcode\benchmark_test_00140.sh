#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00140() {
  user_input="$HTTP_ORIGIN"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  printf "X-Custom: %s\r\n" "$parsed_bool"
}

benchmark_test_00140 "$@"
