#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00407() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data="${user_input:-default}"
  _h=$(printf '%s' "$data" | sha256sum | cut -d" " -f1)
  if grep -qxF -- "$_h" /etc/app/passwd.sha256; then echo "auth ok"; else echo "auth failed" >&2; exit 1; fi
}

benchmark_test_00407 "$@"
