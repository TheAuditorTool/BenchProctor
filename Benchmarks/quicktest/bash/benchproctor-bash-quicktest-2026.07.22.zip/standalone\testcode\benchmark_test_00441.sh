#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00441() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  eval "xmllint --xpath \"//user[name='$data']\" /var/data/users.xml"
}

benchmark_test_00441 "$@"
