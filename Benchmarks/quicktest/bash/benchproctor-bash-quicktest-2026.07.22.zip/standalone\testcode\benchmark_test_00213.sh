#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00213() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  (
    echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
  ) &
  wait $!
}

benchmark_test_00213 "$@"
