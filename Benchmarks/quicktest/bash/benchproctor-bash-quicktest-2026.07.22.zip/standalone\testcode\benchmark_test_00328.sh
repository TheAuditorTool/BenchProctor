#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00328() {
  user_input="$HTTP_ORIGIN"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00328 "$@"
