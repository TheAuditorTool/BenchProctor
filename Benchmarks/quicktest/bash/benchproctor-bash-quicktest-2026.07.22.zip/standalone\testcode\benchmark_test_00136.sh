#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00136() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  printf -v data "%s" "${user_input}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  cat "/var/app/data/$processed"
}

benchmark_test_00136 "$@"
