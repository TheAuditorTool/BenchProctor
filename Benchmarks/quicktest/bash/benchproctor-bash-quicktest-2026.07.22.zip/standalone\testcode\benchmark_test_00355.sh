#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00355() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  sudo bash -c "echo $data"
}

benchmark_test_00355 "$@"
