#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00128() {
  user_input="$USER_COMMENT"
  printf -v data "%s" "${user_input}"
  printf "X-Custom: %s\r\n" "$data"
}

benchmark_test_00128 "$@"
