#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00402() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00402 "$@"
