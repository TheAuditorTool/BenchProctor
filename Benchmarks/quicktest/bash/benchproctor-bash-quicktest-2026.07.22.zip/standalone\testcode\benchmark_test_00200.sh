#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00200() {
  user_input="d1Fg7Ht3Vk8Mq2Pn6Ws"
  data="${user_input:-default}"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00200 "$@"
