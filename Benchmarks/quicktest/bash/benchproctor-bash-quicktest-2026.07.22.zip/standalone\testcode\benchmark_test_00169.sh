#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00169() {
  user_input="$HTTP_USER_AGENT"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00169 "$@"
