#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00311() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  if [[ "$user_input" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $user_input" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00311 "$@"
