#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00298() {
  echo "Internal error" >&2
}

benchmark_test_00298 "$@"
