#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00182() {
  user_input="$HTTP_AUTHORIZATION"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  eval "echo $processed"
}

benchmark_test_00182 "$@"
