#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00303() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  printf '%s\r\n' "Access-Control-Allow-Origin: $data"
}

benchmark_test_00303 "$@"
