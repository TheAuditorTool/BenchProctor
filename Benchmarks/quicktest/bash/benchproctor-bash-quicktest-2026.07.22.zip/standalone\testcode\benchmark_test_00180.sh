#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00180() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00180 "$@"
