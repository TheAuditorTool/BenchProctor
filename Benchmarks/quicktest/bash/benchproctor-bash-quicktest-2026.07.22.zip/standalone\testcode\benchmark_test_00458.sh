#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00458() {
  user_input="$APP_INPUT"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  input_value="$data"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00458 "$@"
