#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00211() {
  user_input="$HTTP_REFERER"
  data="${user_input:-default}"
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00211 "$@"
