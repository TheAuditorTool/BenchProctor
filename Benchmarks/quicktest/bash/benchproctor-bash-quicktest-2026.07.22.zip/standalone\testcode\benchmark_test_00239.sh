#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00239() {
  user_input="$APP_INPUT"
  set -- "$user_input" "http"
  data="$1"
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00239 "$@"
