#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00395() {
  user_input="q9Cb4Ad2Fg8Ht3Vk6Mp"
  set -- "$user_input" "http"
  data="$1"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00395 "$@"
