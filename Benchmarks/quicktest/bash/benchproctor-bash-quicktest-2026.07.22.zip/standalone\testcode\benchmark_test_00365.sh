#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00365() {
  user_input="$(cat /dev/stdin)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo -n "$data" | sha256sum
}

benchmark_test_00365 "$@"
