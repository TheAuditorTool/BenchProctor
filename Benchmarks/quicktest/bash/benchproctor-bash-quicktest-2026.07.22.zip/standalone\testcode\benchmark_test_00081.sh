#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00081() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  input_value="$data"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00081 "$@"
