#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00093() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  ls -la -- "$data" 2>&1
}

benchmark_test_00093 "$@"
