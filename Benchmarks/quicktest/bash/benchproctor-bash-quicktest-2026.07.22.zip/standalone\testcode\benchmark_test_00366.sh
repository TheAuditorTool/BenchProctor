#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00366() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _bypass_re='^[a-zA-Z0-9 _.,;:/=[:space:]-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00366 "$@"
