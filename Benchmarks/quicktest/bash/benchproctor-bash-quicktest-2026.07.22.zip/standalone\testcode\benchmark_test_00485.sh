#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00485() {
  user_input="$HTTP_USER_AGENT"
  data=$(printf "%s" "$user_input")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00485 "$@"
