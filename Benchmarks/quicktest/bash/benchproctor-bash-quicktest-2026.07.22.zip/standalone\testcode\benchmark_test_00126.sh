#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00126() {
  user_input="$HTTP_HOST"
  printf -v data "%s" "${user_input}"
  curl -s "$data"
}

benchmark_test_00126 "$@"
