#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00253() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  printf "Location: %s\r\n\r\n" "$target_url"
}

benchmark_test_00253 "$@"
