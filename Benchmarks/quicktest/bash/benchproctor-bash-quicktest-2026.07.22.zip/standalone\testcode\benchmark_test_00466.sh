#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00466() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  curl -s "$target_url"
}

benchmark_test_00466 "$@"
