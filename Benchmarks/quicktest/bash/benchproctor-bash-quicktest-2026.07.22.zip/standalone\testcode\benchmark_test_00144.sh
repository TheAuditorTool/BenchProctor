#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00144() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "Error: $data" >&2
}

benchmark_test_00144 "$@"
