#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00427() {
  user_input="$(cat /etc/app/config)"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00427 "$@"
