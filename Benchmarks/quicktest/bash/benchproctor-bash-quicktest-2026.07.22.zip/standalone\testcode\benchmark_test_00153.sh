#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00153() {
  user_input="$(mysql -N -e 'SELECT bio FROM profiles LIMIT 1')"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00153 "$@"
