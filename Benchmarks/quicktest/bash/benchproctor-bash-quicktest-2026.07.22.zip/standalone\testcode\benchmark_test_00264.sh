#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00264() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data="${user_input//$'\x00'/}"
  redis-cli -s /var/run/redis.sock DEL "account:$data" >/dev/null 2>&1
}

benchmark_test_00264 "$@"
