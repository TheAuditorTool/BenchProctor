#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00322() {
  user_input="$USER_COMMENT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
}

benchmark_test_00322 "$@"
