#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00467() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  mysql -e "SELECT * FROM users WHERE id = '$data'"
}

benchmark_test_00467 "$@"
