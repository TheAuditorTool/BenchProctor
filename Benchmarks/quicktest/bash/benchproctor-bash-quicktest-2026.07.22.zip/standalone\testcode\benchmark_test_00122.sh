#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00122() {
  user_input="$HTTP_COOKIE"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  sudo -u nobody echo "$data"
}

benchmark_test_00122 "$@"
