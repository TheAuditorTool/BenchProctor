#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00247() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  if [ "$(date +%Y)" -ge 2020 ]; then
    echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
  fi
}

benchmark_test_00247 "$@"
