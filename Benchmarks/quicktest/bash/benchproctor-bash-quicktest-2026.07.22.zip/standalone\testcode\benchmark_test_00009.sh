#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00009() {
  user_input="$HTTP_ORIGIN"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00009 "$@"
