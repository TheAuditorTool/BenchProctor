#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00471() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  set -- "$user_input" "http"
  data="$1"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00471 "$@"
