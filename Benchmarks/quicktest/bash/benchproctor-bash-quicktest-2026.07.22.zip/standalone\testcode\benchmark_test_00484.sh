#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00484() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data="${user_input:-default}"
  echo -n "$data" | sha256sum
}

benchmark_test_00484 "$@"
