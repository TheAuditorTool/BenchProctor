#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00118() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  case $data in true|false|0|1) parsed_bool="$data";; *) echo "invalid bool" >&2; exit 1;; esac
  xmllint --xpath "//user[name='$parsed_bool']" /var/data/users.xml
}

benchmark_test_00118 "$@"
