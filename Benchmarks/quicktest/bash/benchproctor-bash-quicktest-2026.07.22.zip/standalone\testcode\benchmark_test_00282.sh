#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00282() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00282 "$@"
