#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00476() {
  user_input="$HTTP_REFERER"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  eval "echo $processed"
}

benchmark_test_00476 "$@"
