#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00047() {
  user_input="$(cat /dev/stdin)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00047 "$@"
