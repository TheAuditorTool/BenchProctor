#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00194() {
  user_input="$HTTP_HOST"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  curl -s "$data"
}

benchmark_test_00194 "$@"
