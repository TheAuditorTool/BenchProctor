#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00411() {
  user_input="$(cat /dev/stdin)"
  echo "$user_input" > /var/data/secrets.txt
}

benchmark_test_00411 "$@"
