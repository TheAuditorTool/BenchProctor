#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00420() {
  user_input="$HTTP_COOKIE"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  eval "echo $data"
}

benchmark_test_00420 "$@"
