#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00233() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  _fname=$(basename -- "$data")
  case "$_fname" in *.jpg|*.png|*.gif|*.pdf) entry_file="$_fname";; *) echo "invalid file type"; exit 1;; esac
  echo "uploaded" > "/var/uploads/$entry_file"
}

benchmark_test_00233 "$@"
