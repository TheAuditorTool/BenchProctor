#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00406() {
  user_input="$(cat /dev/stdin)"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00406 "$@"
