#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00150() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$user_input" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$user_input"
  printf "Location: %s\r\n\r\n" "$target_url"
}

benchmark_test_00150 "$@"
