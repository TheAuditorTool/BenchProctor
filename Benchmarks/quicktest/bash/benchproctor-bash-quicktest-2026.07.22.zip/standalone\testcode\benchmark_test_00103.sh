#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00103() {
  user_input="$HTTP_ORIGIN"
  set -- "$user_input" "http"
  data="$1"
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00103 "$@"
