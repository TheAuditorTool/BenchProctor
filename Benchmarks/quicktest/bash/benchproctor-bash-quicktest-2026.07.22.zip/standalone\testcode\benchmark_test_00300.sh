#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00300() {
  user_input="$(mysql -N -e 'SELECT bio FROM profiles LIMIT 1')"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  curl -s http://api.lan.local/ingest --data "$data"
}

benchmark_test_00300 "$@"
