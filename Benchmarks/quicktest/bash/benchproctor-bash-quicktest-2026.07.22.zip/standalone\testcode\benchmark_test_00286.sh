#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00286() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00286 "$@"
