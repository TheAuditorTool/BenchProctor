#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00129() {
  user_input="$USER_COMMENT"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  curl -sk "$data"
}

benchmark_test_00129 "$@"
