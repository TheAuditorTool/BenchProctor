#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00023() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if [ "$(date +%Y)" -ge 2020 ]; then
    eval "echo $data"
  fi
}

benchmark_test_00023 "$@"
