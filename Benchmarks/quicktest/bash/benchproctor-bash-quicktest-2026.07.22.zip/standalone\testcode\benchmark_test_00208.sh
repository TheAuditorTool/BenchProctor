#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00208() {
  user_input="$QUERY_STRING"
  printf -v data "%s" "${user_input}"
  curl -sk "$data"
}

benchmark_test_00208 "$@"
