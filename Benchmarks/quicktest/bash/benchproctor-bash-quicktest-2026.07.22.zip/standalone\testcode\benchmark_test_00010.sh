#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00010() {
  user_input="$HTTP_REFERER"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00010 "$@"
