#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00474() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  logger "Action: $processed"
}

benchmark_test_00474 "$@"
