#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00028() {
  user_input="$APP_INPUT"
  data=$(printf "%s" "$user_input")
  eval "echo $data"
}

benchmark_test_00028 "$@"
