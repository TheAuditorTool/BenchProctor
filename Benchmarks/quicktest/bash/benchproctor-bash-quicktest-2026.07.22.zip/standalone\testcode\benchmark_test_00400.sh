#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00400() {
  user_input="$HTTP_USER_AGENT"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$processed" 2>/dev/null
}

benchmark_test_00400 "$@"
