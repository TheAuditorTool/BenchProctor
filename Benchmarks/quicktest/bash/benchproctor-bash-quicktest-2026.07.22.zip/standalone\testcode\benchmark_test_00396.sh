#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00396() {
  user_input="$APP_INPUT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  input_value="$processed"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00396 "$@"
