#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00181() {
  user_input="$HTTP_X_FORWARDED_FOR"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  redis-cli -s /var/run/redis.sock DEL "account:$data" >/dev/null 2>&1
}

benchmark_test_00181 "$@"
