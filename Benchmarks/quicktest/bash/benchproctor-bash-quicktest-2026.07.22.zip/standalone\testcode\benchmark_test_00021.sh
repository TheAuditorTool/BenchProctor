#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00021() {
  user_input="$HTTP_HOST"
  printf -v data "%s" "${user_input}"
  logger "Action: $data"
}

benchmark_test_00021 "$@"
