#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00381() {
  user_input="$HTTP_COOKIE"
  printf -v data "%s" "${user_input}"
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "invalid"; exit 1; fi
  parsed_id="$data"
  mysql -e "SELECT * FROM users WHERE id = $parsed_id"
}

benchmark_test_00381 "$@"
