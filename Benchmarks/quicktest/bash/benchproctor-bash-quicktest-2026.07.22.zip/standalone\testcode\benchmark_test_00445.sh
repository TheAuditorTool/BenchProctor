#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00445() {
  user_input="$HTTP_REFERER"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  redis-cli -s /var/run/redis.sock DEL "account:$data" >/dev/null 2>&1
}

benchmark_test_00445 "$@"
