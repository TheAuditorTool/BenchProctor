#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00158() {
  user_input="$(cat /dev/stdin)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  curl -s "$data"
}

benchmark_test_00158 "$@"
