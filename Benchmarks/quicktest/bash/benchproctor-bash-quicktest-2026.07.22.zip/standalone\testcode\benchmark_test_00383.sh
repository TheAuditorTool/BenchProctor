#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00383() {
  user_input="$HTTP_USER_AGENT"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  eval "echo $processed"
}

benchmark_test_00383 "$@"
