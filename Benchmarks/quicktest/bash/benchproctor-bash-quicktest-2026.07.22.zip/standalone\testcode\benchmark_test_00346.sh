#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00346() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00346 "$@"
