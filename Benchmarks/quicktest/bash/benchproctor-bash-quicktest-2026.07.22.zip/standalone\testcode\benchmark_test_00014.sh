#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00014() {
  user_input="$HTTP_USER_AGENT"
  data="${user_input//$'\x00'/}"
  cell="$data"
  case "$cell" in [=+@-]*) cell="'$cell";; esac
  printf '"%s","data"\n' "$cell" >> /var/data/output.csv
}

benchmark_test_00014 "$@"
