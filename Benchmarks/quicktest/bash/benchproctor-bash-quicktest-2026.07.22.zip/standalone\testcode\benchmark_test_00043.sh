#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00043() {
  user_input="$HTTP_X_FORWARDED_FOR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  ls -la -- "$data" 2>&1
}

benchmark_test_00043 "$@"
