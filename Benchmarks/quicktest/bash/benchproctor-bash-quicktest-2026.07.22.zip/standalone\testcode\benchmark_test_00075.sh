#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00075() {
  user_input="$QUERY_STRING"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00075 "$@"
