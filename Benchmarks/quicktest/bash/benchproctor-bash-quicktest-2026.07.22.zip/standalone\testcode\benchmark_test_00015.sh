#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00015() {
  user_input="$HTTP_HOST"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00015 "$@"
