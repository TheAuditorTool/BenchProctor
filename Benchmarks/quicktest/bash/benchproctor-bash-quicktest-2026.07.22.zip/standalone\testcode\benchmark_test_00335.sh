#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00335() {
  user_input="$DOTENV_VAR"
  data=$(printf "%s" "$user_input")
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00335 "$@"
