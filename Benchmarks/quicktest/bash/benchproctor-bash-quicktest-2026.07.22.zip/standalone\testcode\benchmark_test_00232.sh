#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00232() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$user_input" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$user_input"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00232 "$@"
