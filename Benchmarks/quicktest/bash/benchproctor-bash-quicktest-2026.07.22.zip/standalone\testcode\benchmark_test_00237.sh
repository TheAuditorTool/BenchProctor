#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00237() {
  user_input="$HTTP_AUTHORIZATION"
  data="${user_input:-default}"
  processed=$(echo "$data" | tr -d '\r\n' | sed "s/[a-zA-Z0-9]\{4,\}/****/g")
  logger "Action: $processed"
}

benchmark_test_00237 "$@"
