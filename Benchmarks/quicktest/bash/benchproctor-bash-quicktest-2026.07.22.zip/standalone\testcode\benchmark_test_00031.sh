#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00031() {
  user_input="$(cat /dev/stdin)"
  set -- "$user_input" "http"
  data="$1"
  curl -sk "$data"
}

benchmark_test_00031 "$@"
