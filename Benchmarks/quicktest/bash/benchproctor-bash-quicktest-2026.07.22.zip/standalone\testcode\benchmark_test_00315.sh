#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00315() {
  user_input="$HTTP_AUTHORIZATION"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/data/secrets.enc
}

benchmark_test_00315 "$@"
