#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00231() {
  user_input="$APP_INPUT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  requested=$data
  alloc_size=$((requested + 1))
  echo "alloc:$alloc_size"
}

benchmark_test_00231 "$@"
