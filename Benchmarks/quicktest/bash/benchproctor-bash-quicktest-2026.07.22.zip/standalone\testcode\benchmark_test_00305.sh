#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00305() {
  user_input="$HTTP_ORIGIN"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00305 "$@"
