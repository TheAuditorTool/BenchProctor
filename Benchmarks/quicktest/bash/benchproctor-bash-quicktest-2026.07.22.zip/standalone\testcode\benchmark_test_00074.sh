#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00074() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00074 "$@"
