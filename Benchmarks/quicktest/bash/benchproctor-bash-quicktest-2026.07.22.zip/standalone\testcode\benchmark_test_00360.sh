#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00360() {
  user_input="$APP_INPUT"
  data=$(printf "%s" "$user_input")
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00360 "$@"
