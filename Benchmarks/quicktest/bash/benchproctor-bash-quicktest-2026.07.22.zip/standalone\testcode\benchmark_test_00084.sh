#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00084() {
  user_input="$(cat /dev/stdin)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  curl -s http://api.lan.local/ingest --data "$data"
}

benchmark_test_00084 "$@"
