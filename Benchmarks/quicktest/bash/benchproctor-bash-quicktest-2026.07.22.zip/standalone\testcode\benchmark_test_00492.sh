#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00492() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data="${user_input//$'\x00'/}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00492 "$@"
