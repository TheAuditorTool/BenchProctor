#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00124() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  trusted_claim="$user_input"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00124 "$@"
