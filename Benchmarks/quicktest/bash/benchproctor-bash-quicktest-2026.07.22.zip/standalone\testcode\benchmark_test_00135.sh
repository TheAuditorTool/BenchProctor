#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00135() {
  store_cred="$APP_SECRET"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$store_cred" -in /dev/null -out /dev/null
}

benchmark_test_00135 "$@"
