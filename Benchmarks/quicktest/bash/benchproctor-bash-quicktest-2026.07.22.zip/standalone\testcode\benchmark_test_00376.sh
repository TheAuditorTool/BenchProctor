#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00376() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  curl -sk "$data"
}

benchmark_test_00376 "$@"
