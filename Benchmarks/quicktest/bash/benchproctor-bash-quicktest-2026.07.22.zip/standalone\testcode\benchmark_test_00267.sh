#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00267() {
  user_input="$DOTENV_VAR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _bypass_re='^[a-zA-Z0-9 _.,;:/=()|+@-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  curl -s http://api.lan.local/ingest --data "$processed"
}

benchmark_test_00267 "$@"
