#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00491() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  echo "Error: $data" >&2
}

benchmark_test_00491 "$@"
