#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00038() {
  user_input="$HTTP_HOST"
  echo "$user_input" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00038 "$@"
