#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00371() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00371 "$@"
