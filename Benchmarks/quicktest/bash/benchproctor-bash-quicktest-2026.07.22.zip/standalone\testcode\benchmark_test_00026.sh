#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00026() {
  user_input="k7Qm2Rv9Lp4Tw8Nj3Zc"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  mysql -u app -p"$data" -e "SELECT 1"
}

benchmark_test_00026 "$@"
