#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00175() {
  user_input="$HTTP_USER_AGENT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00175 "$@"
