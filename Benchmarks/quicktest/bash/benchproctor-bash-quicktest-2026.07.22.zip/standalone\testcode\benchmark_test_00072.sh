#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00072() {
  user_input="$HTTP_USER_AGENT"
  data="${user_input:-default}"
  echo -n "$data" | sha256sum
}

benchmark_test_00072 "$@"
