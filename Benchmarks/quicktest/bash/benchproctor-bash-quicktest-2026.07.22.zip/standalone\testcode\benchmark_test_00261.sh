#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00261() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  _attempts=$(( ${_attempts:-0} + 1 ))
  logger "login attempt #$_attempts"
  if grep -qF -- "$data" /etc/app/passwd; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00261 "$@"
