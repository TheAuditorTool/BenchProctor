#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00165() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  logger "Action: $data"
}

benchmark_test_00165 "$@"
