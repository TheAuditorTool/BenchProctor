#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00082() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  input_value="$processed"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00082 "$@"
