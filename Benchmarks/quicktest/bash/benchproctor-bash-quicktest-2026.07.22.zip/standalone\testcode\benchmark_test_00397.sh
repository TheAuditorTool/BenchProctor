#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00397() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  case "$data" in asc*|desc*|name*|created*) processed="$data";; *) echo "invalid" >&2; exit 1;; esac
  echo "$processed" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00397 "$@"
