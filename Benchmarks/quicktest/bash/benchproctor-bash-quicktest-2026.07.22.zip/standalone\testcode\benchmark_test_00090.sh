#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00090() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  set -- "$user_input" "http"
  data="$1"
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00090 "$@"
