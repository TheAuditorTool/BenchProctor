#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00334() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  case $data in /bin/echo|/bin/cat|/usr/bin/id) allowed_bin=$data;; *) echo "forbidden binary" >&2; exit 1;; esac
  eval "$allowed_bin"
}

benchmark_test_00334 "$@"
