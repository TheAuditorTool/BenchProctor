#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00368() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00368 "$@"
