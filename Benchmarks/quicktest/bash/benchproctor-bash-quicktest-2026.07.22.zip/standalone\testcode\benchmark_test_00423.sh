#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00423() {
  user_input="$(cat /dev/stdin)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  curl -s "$data"
}

benchmark_test_00423 "$@"
