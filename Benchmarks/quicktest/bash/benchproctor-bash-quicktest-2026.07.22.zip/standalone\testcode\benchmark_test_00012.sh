#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00012() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  eval "echo $data"
}

benchmark_test_00012 "$@"
