#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00409() {
  user_input="$(cat /dev/stdin)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "$data,data,row" >> /var/data/output.csv
}

benchmark_test_00409 "$@"
