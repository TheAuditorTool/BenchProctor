#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00319() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00319 "$@"
