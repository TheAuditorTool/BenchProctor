#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00163() {
  user_input="$HTTP_USER_AGENT"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00163 "$@"
