#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00041() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00041 "$@"
