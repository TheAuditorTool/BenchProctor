#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00404() {
  user_input="$(cat /dev/stdin)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _bypass_re='^[a-zA-Z0-9 _./\\:_-]+$'
  if [[ ! "$data" =~ $_bypass_re ]]; then echo "forbidden"; exit 1; fi
  processed="$data"
  echo "uploaded" > "/var/uploads/$processed"
}

benchmark_test_00404 "$@"
