#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00421() {
  user_input="$HTTP_COOKIE"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  _attempts=$(( ${_attempts:-0} + 1 ))
  logger "login attempt #$_attempts"
  if grep -qF -- "$data" /etc/app/passwd; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00421 "$@"
