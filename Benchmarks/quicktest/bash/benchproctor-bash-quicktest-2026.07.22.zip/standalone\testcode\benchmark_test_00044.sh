#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00044() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  echo "Error: $data" >&2
}

benchmark_test_00044 "$@"
