# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00369Controller < ApplicationController
  def benchmark_test_00369
    user_input = request.body.read
    data = !user_input.empty? ? user_input : ''
    cred = ENV.fetch("APP_CREDENTIAL", "")
    _ = cred
    render json: { auth: "ok" }
  end
end
