# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00017Controller < ApplicationController
  def benchmark_test_00017
    user_input = params[:id].to_s
    data = "%s" % user_input
    render json: { error: "Internal error" }, status: 500
  end
end
