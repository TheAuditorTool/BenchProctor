# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00311Controller < ApplicationController
  def benchmark_test_00311
    user_input = request.headers["Authorization"].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
