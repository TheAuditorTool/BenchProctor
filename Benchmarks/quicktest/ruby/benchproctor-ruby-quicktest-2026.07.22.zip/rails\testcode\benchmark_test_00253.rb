# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00253Controller < ApplicationController
  def benchmark_test_00253
    user_input = request.headers["Origin"].to_s
    data = String(user_input).strip
    if ENV.fetch("APP_ENV", "production") != "test"
      File.delete("/var/app/data/" + data)
    end
    render json: { status: "ok" }
  end
end
