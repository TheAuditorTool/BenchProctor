# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00254Controller < ApplicationController
  def benchmark_test_00254
    user_input = params[:id].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    render json: { error: "Internal error" }, status: 500
  end
end
