# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00281Controller < ApplicationController
  def benchmark_test_00281
    user_input = cookies[:session_token].to_s
    data = !user_input.empty? ? user_input : ''
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
