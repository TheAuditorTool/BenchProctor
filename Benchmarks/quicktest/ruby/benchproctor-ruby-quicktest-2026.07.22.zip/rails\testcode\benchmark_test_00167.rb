# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00167Controller < ApplicationController
  def benchmark_test_00167
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
