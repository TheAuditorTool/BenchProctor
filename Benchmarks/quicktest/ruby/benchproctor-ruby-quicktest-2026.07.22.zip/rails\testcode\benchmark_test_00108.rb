# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00108Controller < ApplicationController
  def benchmark_test_00108
    user_input = request.headers["X-Custom-Header"].to_s
    data = format('%s', user_input)
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
