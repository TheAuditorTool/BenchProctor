# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00292Controller < ApplicationController
  def benchmark_test_00292
    user_input = ENV["USER_INPUT"] || ""
    data = "" + user_input
    if data.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: data.to_s }
    end
  end
end
