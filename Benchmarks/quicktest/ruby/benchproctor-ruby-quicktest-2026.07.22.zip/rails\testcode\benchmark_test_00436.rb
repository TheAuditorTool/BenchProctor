# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00436Controller < ApplicationController
  def benchmark_test_00436
    user_input = (params[:variables] || {})[:input].to_s
    _body = URI.open(user_input).read
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
