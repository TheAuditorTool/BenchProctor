# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00405Controller < ApplicationController
  def benchmark_test_00405
    user_input = request.headers["Origin"].to_s
    data = sprintf("%s", user_input)
    system("echo", data)
    render json: { status: "ok" }
  end
end
