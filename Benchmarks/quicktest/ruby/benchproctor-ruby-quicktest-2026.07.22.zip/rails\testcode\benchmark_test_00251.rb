# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00251Controller < ApplicationController
  def benchmark_test_00251
    user_input = User.first&.name.to_s
    data = format('%s', user_input)
    render html: ("<div>" + data + "</div>").html_safe
  end
end
