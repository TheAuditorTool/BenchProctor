# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00116Controller < ApplicationController
  def benchmark_test_00116
    user_input = request.host.to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    eval('require "mongo"; Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => data}).first')
    render json: { status: "ok" }
  end
end
