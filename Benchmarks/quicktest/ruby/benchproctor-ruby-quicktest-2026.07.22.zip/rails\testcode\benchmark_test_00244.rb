# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00244Controller < ApplicationController
  def benchmark_test_00244
    user_input = User.first&.name.to_s
    data = user_input.split.join(" ")
    render json: { error: data }, status: 500
  end
end
