# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00448Controller < ApplicationController
  def benchmark_test_00448
    user_input = request.headers["X-Custom-Header"].to_s
    data = user_input ? user_input : ''
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
