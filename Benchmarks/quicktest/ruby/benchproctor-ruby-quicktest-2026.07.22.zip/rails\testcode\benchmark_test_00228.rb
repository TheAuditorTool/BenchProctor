# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00228Controller < ApplicationController
  def benchmark_test_00228
    user_input = ENV["USER_INPUT"] || ""
    data = "" + user_input
    eval(data)
    render json: { status: "ok" }
  end
end
