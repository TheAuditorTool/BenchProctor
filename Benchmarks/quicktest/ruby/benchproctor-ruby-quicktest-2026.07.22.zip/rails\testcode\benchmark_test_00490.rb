# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00490Controller < ApplicationController
  def benchmark_test_00490
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    _body = URI.open(data).read
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
