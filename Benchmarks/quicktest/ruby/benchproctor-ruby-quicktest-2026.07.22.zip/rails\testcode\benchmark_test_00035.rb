# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00035Controller < ApplicationController
  def benchmark_test_00035
    user_input = (params[:variables] || {})[:input].to_s
    data = String(user_input).strip
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
