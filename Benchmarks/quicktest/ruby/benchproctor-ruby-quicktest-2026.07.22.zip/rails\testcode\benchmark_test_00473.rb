# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00473Controller < ApplicationController
  def benchmark_test_00473
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = user_input.split.join(" ")
    cred = ENV.fetch("APP_CREDENTIAL", "")
    _ = cred
    render json: { auth: "ok" }
  end
end
