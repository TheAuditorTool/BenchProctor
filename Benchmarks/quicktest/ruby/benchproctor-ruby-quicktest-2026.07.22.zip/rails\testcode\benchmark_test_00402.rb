# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00402Controller < ApplicationController
  def benchmark_test_00402
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = user_input.split.join(" ")
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
