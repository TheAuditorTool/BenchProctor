# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00135Controller < ApplicationController
  def benchmark_test_00135
    user_input = User.first&.name.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    render json: { error: data }, status: 500
  end
end
