# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00117Controller < ApplicationController
  def benchmark_test_00117
    user_input = ["s3cr3t_key_test_xyz"][0]
    data = String(user_input).strip
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = data.to_s.ljust(32)[0, 32]
    _cipher.update("data")
    render json: { encrypted: "ok" }
  end
end
