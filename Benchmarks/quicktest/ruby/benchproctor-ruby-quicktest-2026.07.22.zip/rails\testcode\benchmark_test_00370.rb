# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00370Controller < ApplicationController
  def benchmark_test_00370
    user_input = request.user_agent.to_s
    payload, _origin = user_input, 'http'
    data = payload
    render html: ("<div>" + data + "</div>").html_safe
  end
end
