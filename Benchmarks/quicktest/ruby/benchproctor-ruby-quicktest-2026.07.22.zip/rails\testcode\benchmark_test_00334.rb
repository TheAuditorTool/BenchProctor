# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00334Controller < ApplicationController
  def benchmark_test_00334
    user_input = request.query_parameters[:q].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    render html: ("<div>" + data + "</div>").html_safe
  end
end
