# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "base64"
require "csv"

class BenchmarkTest00126Controller < ApplicationController
  def benchmark_test_00126
    user_input = cookies[:session_token].to_s
    data = Base64.decode64(user_input)
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [processed, "data"] }
    render json: { status: "ok" }
  end
end
