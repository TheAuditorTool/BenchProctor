# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00076Controller < ApplicationController
  def benchmark_test_00076
    user_input = (params[:variables] || {})[:input].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    trusted_claim = processed.to_s
    render json: { trusted: trusted_claim }
  end
end
