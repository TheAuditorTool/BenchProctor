# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "resolv"
require "ipaddr"
require "open-uri"

class BenchmarkTest00177Controller < ApplicationController
  def benchmark_test_00177
    user_input = request.headers["Origin"].to_s
    @user_input = user_input
    data = @user_input
    _host = (URI.parse(data).host rescue nil)
    _ip_str = _host ? (Resolv.getaddress(_host) rescue nil) : nil
    _addr = _ip_str ? (IPAddr.new(_ip_str) rescue nil) : nil
    unless _addr && !_addr.private? && !_addr.loopback? && !_addr.link_local?
      render json: { error: "private range blocked" }, status: 403
      return
    end
    target_url = data
    URI.open(target_url).read
    render json: { status: "ok" }
  end
end
