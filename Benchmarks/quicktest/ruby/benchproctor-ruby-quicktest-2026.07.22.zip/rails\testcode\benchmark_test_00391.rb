# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"
require "net/http"

class BenchmarkTest00391Controller < ApplicationController
  def benchmark_test_00391
    user_input = ENV["DOTENV_VAR"] || ""
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    Net::HTTP.post(URI("http://api.intra.net/data"), processed.to_s)
    render json: { status: "ok" }
  end
end
