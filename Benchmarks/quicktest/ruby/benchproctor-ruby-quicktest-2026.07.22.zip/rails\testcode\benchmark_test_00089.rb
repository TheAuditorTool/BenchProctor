# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00089Controller < ApplicationController
  def benchmark_test_00089
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    Nokogiri::XML(data) { |config| config.dtdload.noent.nonet }
    render json: { status: "ok" }
  end
end
