# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00047Controller < ApplicationController
  def benchmark_test_00047
    user_input = request.headers["Authorization"].to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
