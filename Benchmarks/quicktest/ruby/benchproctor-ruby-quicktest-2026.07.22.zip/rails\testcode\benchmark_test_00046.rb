# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00046Controller < ApplicationController
  def benchmark_test_00046
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
