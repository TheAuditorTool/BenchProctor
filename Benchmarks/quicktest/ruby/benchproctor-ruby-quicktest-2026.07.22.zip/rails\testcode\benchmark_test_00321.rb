# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00321Controller < ApplicationController
  def benchmark_test_00321
    user_input = params.require(:user).permit(:name)[:name].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    session[:data] = data.to_s
    render json: { status: "ok" }
  end
end
