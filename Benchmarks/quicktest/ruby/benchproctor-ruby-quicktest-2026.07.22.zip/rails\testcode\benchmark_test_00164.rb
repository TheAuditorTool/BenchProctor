# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00164Controller < ApplicationController
  def benchmark_test_00164
    user_input = cookies[:session_token].to_s
    data = user_input.gsub("\u0000", "")
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
