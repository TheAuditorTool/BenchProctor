# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00215Controller < ApplicationController
  def benchmark_test_00215
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = !user_input.empty? ? user_input : ''
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    Rails.logger.info("Action: " + parsed_bool)
    render json: { status: "ok" }
  end
end
