# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "base64"

class BenchmarkTest00336Controller < ApplicationController
  def benchmark_test_00336
    user_input = request.headers["Authorization"].to_s
    data = Base64.decode64(user_input)
    unless session[:user]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    Rails.logger.info("error: " + data.to_s)
  end
end
