# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00246Controller < ApplicationController
  def benchmark_test_00246
    user_input = cookies[:session_token].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
