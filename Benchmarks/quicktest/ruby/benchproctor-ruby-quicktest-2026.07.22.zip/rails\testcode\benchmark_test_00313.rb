# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00313Controller < ApplicationController
  def benchmark_test_00313
    user_input = request.referer.to_s
    data = String(user_input).strip
    unless data.to_s =~ /\.(jpg|png|gif|pdf)\z/i
      render json: { error: "invalid type" }, status: 400
      return
    end
    entry_file = data
    File.write("/var/uploads/" + File.basename(entry_file.to_s), "data")
    render json: { status: "ok" }
  end
end
