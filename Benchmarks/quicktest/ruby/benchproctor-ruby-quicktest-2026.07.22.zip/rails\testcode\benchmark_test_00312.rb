# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00312Controller < ApplicationController
  def benchmark_test_00312
    user_input = request.query_parameters[:q].to_s
    data = user_input ? user_input : ''
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
