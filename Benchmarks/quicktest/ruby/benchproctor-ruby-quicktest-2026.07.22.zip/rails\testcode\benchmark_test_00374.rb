# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00374Controller < ApplicationController
  def benchmark_test_00374
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = !user_input.empty? ? user_input : ''
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => processed}).first
    render json: { status: "ok" }
  end
end
