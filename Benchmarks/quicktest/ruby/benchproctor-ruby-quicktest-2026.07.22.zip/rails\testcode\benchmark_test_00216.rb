# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00216Controller < ApplicationController
  def benchmark_test_00216
    user_input = Comment.first&.text.to_s
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => user_input}).first
    render json: { status: "ok" }
  end
end
