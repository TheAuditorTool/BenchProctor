# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00118Controller < ApplicationController
  def benchmark_test_00118
    user_input = cookies[:session_token].to_s
    @user_input = user_input
    data = @user_input
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
