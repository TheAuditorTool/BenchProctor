# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00392Controller < ApplicationController
  def benchmark_test_00392
    user_input = cookies[:session_token].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
