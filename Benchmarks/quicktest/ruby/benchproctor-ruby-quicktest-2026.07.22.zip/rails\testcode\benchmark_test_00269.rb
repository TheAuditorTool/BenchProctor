# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00269Controller < ApplicationController
  def benchmark_test_00269
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = !user_input.empty? ? user_input : ''
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
