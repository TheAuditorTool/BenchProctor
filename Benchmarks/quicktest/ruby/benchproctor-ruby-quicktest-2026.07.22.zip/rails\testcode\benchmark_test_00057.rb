# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00057Controller < ApplicationController
  def benchmark_test_00057
    user_input = ENV["DOTENV_VAR"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
