# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00454Controller < ApplicationController
  def benchmark_test_00454
    user_input = params.require(:user).permit(:name)[:name].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    trusted_claim = processed.to_s
    render json: { trusted: trusted_claim }
  end
end
