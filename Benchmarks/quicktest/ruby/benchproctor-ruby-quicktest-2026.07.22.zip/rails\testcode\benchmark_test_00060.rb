# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00060Controller < ApplicationController
  def benchmark_test_00060
    user_input = request.referer.to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
