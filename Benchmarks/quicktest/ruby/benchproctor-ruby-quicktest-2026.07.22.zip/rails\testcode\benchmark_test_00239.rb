# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00239Controller < ApplicationController
  def benchmark_test_00239
    user_input = request.headers["X-Forwarded-For"].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
