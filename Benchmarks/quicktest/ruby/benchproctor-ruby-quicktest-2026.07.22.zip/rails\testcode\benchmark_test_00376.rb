# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00376Controller < ApplicationController
  def benchmark_test_00376
    user_input = params[:id].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    result = User.find_by(name: data)
    value = result.name
    render json: { status: "ok" }
  end
end
