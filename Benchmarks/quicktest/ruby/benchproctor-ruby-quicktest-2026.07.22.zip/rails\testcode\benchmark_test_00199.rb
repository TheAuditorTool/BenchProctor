# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00199Controller < ApplicationController
  def benchmark_test_00199
    user_input = Comment.first&.text.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    system("echo " + data)
    render json: { status: "ok" }
  end
end
