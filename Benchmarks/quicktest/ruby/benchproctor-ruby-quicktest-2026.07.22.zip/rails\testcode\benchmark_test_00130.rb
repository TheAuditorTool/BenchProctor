# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00130Controller < ApplicationController
  def benchmark_test_00130
    user_input = request.query_parameters[:q].to_s
    data = user_input ? user_input : ''
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
