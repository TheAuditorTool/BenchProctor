# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00028Controller < ApplicationController
  def benchmark_test_00028
    user_input = "app_display_name"
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = ENV.fetch("DATA_ENC_KEY", "").ljust(32)[0, 32]
    _cipher.update("data")
    render json: { encrypted: "ok" }
  end
end
