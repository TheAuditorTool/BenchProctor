# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"
require "net/http"

class BenchmarkTest00193Controller < ApplicationController
  def benchmark_test_00193
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = CGI.unescape(user_input)
    Net::HTTP.post(URI("http://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
