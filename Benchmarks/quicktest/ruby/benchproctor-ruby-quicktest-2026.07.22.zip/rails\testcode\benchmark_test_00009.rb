# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00009Controller < ApplicationController
  def benchmark_test_00009
    user_input = request.body.read
    data = Thread.new { user_input.to_s.strip }.value
    unless session[:user]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    Rails.logger.info("error: " + data.to_s)
  end
end
