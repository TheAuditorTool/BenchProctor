# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00345Controller < ApplicationController
  def benchmark_test_00345
    user_input = request.headers["Authorization"].to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    unless session[:auth_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:auth_token].to_s)
      render json: { error: "unauthorized" }, status: 401
      return
    end
  end
end
