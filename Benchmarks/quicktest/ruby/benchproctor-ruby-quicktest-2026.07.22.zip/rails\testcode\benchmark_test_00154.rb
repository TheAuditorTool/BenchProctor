# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00154Controller < ApplicationController
  def benchmark_test_00154
    user_input = request.headers["X-Forwarded-For"].to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    session[:data] = data.to_s
    render json: { status: "ok" }
  end
end
