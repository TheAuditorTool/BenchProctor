# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00144Controller < ApplicationController
  def benchmark_test_00144
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = user_input ? user_input : ''
    JSON.parse(data)
    render json: { status: "ok" }
  end
end
