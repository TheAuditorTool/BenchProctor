# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00090Controller < ApplicationController
  def benchmark_test_00090
    user_input = request.headers["Authorization"].to_s
    @user_input = user_input
    data = @user_input
    Thread.new {
      render html: ("<div>" + data + "</div>").html_safe
    }.join
  end
end
