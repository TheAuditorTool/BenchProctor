# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00295Controller < ApplicationController
  def benchmark_test_00295
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    on_input = proc { |v| v.to_s.tr("\r\n", "  ") }
    data = on_input.call(user_input)
    _doc = Nokogiri::XML(data) { |config| config.nonet.nodtdload }
    _ = _doc
    render json: { status: "ok" }
  end
end
