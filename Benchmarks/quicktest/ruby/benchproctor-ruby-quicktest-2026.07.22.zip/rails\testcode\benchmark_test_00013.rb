# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "base64"

class BenchmarkTest00013Controller < ApplicationController
  def benchmark_test_00013
    user_input = cookies[:session_token].to_s
    data = Base64.decode64(user_input)
    entries = Dir.entries(data.to_s) rescue []
    render json: { listing: entries }
  end
end
