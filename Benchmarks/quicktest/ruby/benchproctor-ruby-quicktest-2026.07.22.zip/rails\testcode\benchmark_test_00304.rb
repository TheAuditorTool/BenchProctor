# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00304Controller < ApplicationController
  def benchmark_test_00304
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    render html: ("<div>" + user_input + "</div>").html_safe
  end
end
