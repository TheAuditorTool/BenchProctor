# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00072Controller < ApplicationController
  def benchmark_test_00072
    user_input = request.headers["X-Forwarded-For"].to_s
    data = "#{user_input}"
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    Rails.logger.info("Action: " + parsed_bool)
    render json: { status: "ok" }
  end
end
