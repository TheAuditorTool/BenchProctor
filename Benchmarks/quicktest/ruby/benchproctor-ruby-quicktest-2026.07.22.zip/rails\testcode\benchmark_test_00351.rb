# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00351Controller < ApplicationController
  def benchmark_test_00351
    user_input = request.headers["Origin"].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
