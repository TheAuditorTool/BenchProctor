# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00058Controller < ApplicationController
  def benchmark_test_00058
    user_input = request.headers["Authorization"].to_s
    data = user_input ? user_input : ''
    checked_path = "/var/app/data/" + File.basename(data)
    File.delete(checked_path)
    render json: { status: "ok" }
  end
end
