# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "resolv"
require "ipaddr"
require "socket"

class BenchmarkTest00296Controller < ApplicationController
  def benchmark_test_00296
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = user_input.gsub("\u0000", "")
    _host = (URI.parse(data).host rescue nil)
    _ip_str = _host ? (Resolv.getaddress(_host) rescue nil) : nil
    _addr = _ip_str ? (IPAddr.new(_ip_str) rescue nil) : nil
    unless _addr && !_addr.private? && !_addr.loopback? && !_addr.link_local?
      render json: { error: "private range blocked" }, status: 403
      return
    end
    target_url = data
    TCPSocket.new(target_url, 80).close
    render json: { status: "ok" }
  end
end
