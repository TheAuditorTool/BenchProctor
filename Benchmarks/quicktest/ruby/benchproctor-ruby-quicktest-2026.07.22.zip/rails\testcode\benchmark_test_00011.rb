# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00011Controller < ApplicationController
  def benchmark_test_00011
    user_input = params.require(:user).permit(:name)[:name].to_s
    @user_input = user_input
    data = @user_input
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
