# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"
require "securerandom"

class BenchmarkTest00066Controller < ApplicationController
  def benchmark_test_00066
    user_input = params.require(:user).permit(:name)[:name].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    _salt = SecureRandom.hex(16)
    digest = Digest::SHA256.hexdigest(_salt + data.to_s)
    render json: { status: "ok" }
  end
end
