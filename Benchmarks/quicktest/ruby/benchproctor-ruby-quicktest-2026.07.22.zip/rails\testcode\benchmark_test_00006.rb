# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00006Controller < ApplicationController
  def benchmark_test_00006
    user_input = params.require(:user).permit(:name)[:name].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    cred = Digest::SHA256.hexdigest(data.to_s)
    _ = cred
    render json: { auth: "ok" }
  end
end
