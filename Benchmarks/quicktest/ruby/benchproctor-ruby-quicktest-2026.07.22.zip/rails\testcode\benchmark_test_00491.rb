# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00491Controller < ApplicationController
  def benchmark_test_00491
    user_input = request.body.read
    data = Thread.new { user_input.to_s.strip }.value
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
