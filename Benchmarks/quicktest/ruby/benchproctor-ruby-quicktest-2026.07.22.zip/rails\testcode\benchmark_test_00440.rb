# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00440Controller < ApplicationController
  def benchmark_test_00440
    user_input = params[:id].to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
