# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00110Controller < ApplicationController
  def benchmark_test_00110
    user_input = params.require(:user).permit(:name)[:name].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    host = URI.parse(data).host rescue ""
    unless ["api.intra.net", "cdn.railscdn.org"].include?(host)
      render json: { error: "forbidden host" }, status: 403
      return
    end
    target_url = data
    redirect_to target_url
  end
end
