# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00390Controller < ApplicationController
  def benchmark_test_00390
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    host = URI.parse(data).host rescue ""
    unless ["api.intra.net", "cdn.railscdn.org"].include?(host)
      render json: { error: "forbidden host" }, status: 403
      return
    end
    target_url = data
    URI.open(target_url).read
    render json: { status: "ok" }
  end
end
