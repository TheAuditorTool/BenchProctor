# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00461Controller < ApplicationController
  def benchmark_test_00461
    user_input = (params[:variables] || {})[:input].to_s
    data = format('%s', user_input)
    File.write("/var/uploads/" + File.basename(data.to_s), "data")
    render json: { status: "ok" }
  end
end
