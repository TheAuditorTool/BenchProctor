# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00220Controller < ApplicationController
  def benchmark_test_00220
    user_input = (params[:variables] || {})[:input].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
