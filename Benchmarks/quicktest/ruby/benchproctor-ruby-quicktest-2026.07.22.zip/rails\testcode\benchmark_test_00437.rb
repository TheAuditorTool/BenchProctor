# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"
require "securerandom"

class BenchmarkTest00437Controller < ApplicationController
  def benchmark_test_00437
    user_input = request.host.to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    _salt = SecureRandom.hex(16)
    digest = Digest::SHA256.hexdigest(_salt + data.to_s)
    render json: { status: "ok" }
  end
end
