# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00263Controller < ApplicationController
  def benchmark_test_00263
    user_input = request.referer.to_s
    payload, _origin = user_input, 'http'
    data = payload
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
