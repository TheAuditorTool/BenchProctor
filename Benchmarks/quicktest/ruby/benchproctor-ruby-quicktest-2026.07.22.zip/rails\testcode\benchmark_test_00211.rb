# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00211Controller < ApplicationController
  def benchmark_test_00211
    user_input = ENV["USER_INPUT"] || ""
    data = !user_input.empty? ? user_input : ''
    result = User.find_by(name: data)
    value = result.name
    render json: { status: "ok" }
  end
end
