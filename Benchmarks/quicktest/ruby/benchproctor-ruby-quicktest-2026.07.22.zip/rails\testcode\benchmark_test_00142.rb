# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00142Controller < ApplicationController
  def benchmark_test_00142
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    File.write("/var/uploads/" + File.basename(data.to_s), "data")
    render json: { status: "ok" }
  end
end
