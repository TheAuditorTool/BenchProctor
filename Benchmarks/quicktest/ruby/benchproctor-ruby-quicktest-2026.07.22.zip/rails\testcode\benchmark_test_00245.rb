# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00245Controller < ApplicationController
  def benchmark_test_00245
    user_input = ENV["USER_INPUT"] || ""
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    render json: { error: "Internal error" }, status: 500
  end
end
