# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00355Controller < ApplicationController
  def benchmark_test_00355
    user_input = request.referer.to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
