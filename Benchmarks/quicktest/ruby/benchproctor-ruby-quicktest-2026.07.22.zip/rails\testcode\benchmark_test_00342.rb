# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00342Controller < ApplicationController
  def benchmark_test_00342
    user_input = User.first&.name.to_s
    payload, _origin = user_input, 'http'
    data = payload
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    ActiveRecord::Base.connection.execute("SELECT * FROM users ORDER BY #{processed}")
    render json: { status: "ok" }
  end
end
