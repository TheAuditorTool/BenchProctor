# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"
require "digest"

class BenchmarkTest00152Controller < ApplicationController
  def benchmark_test_00152
    user_input = request.body.read
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    _resp = URI.open(data)
    _body = _resp.read
    _expected = ENV.fetch("FEED_SHA256", "")
    raise "integrity check failed" unless Digest::SHA256.hexdigest(_body) == _expected
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
