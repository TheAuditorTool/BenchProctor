# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"
require "securerandom"

class BenchmarkTest00223Controller < ApplicationController
  def benchmark_test_00223
    user_input = request.body.read
    data = format('%s', user_input)
    _salt = SecureRandom.hex(16)
    digest = Digest::SHA256.hexdigest(_salt + data.to_s)
    render json: { status: "ok" }
  end
end
