# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00088Controller < ApplicationController
  def benchmark_test_00088
    user_input = request.headers["X-Forwarded-For"].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    trusted_claim = data.to_s
    render json: { trusted: trusted_claim }
  end
end
