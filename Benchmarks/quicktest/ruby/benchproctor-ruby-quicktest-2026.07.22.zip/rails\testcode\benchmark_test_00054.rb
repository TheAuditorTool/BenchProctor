# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00054Controller < ApplicationController
  def benchmark_test_00054
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
