# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00184Controller < ApplicationController
  def benchmark_test_00184
    user_input = params[:id].to_s
    data = user_input.gsub("\u0000", "")
    if data.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: data.to_s }
    end
  end
end
