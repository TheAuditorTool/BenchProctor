# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00063Controller < ApplicationController
  def benchmark_test_00063
    user_input = request.headers["Authorization"].to_s
    data = format('%s', user_input)
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
