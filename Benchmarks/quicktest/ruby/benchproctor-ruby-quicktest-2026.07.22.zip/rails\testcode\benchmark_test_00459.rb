# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00459Controller < ApplicationController
  def benchmark_test_00459
    user_input = request.body.read
    data = user_input ? user_input : ''
    Nokogiri::XML(data) { |config| config.dtdload.noent.nonet }
    render json: { status: "ok" }
  end
end
