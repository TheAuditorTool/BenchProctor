# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00349Controller < ApplicationController
  def benchmark_test_00349
    user_input = request.body.read
    data = user_input.split.join(" ")
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
