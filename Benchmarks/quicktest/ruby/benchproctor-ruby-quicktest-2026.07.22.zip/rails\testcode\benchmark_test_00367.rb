# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00367Controller < ApplicationController
  def benchmark_test_00367
    user_input = request.user_agent.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    ActiveRecord::Base.connection.exec_query("SELECT * FROM users WHERE id = ?", "SQL", [[nil, data]])
    render json: { status: "ok" }
  end
end
