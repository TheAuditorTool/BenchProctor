# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00372Controller < ApplicationController
  def benchmark_test_00372
    user_input = request.user_agent.to_s
    data = user_input.split.join(" ")
    eval(data)
    render json: { status: "ok" }
  end
end
