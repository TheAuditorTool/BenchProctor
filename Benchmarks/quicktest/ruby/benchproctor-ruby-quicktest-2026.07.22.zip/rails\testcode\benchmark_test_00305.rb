# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00305Controller < ApplicationController
  def benchmark_test_00305
    user_input = User.first&.name.to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    Net::HTTP.post(URI("https://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
