# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00285Controller < ApplicationController
  def benchmark_test_00285
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = !user_input.empty? ? user_input : ''
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    eval(processed)
    render json: { status: "ok" }
  end
end
