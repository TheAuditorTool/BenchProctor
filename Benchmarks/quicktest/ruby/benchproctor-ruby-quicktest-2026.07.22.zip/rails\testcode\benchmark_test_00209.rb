# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00209Controller < ApplicationController
  def benchmark_test_00209
    user_input = request.headers["Origin"].to_s
    @user_input = user_input
    data = @user_input
    host = URI.parse(data).host rescue ""
    unless ["api.intra.net", "cdn.railscdn.org"].include?(host)
      render json: { error: "forbidden host" }, status: 403
      return
    end
    target_url = data
    redirect_to target_url
  end
end
