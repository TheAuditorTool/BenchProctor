# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00044Controller < ApplicationController
  def benchmark_test_00044
    user_input = request.user_agent.to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    cred = ENV.fetch("APP_CREDENTIAL", "")
    _ = cred
    render json: { auth: "ok" }
  end
end
