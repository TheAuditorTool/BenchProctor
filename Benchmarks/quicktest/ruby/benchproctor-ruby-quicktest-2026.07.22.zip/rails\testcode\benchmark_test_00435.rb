# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00435Controller < ApplicationController
  def benchmark_test_00435
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = String(user_input).strip
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
