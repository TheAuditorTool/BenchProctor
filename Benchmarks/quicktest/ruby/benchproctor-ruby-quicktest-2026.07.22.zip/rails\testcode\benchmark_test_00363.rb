# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00363Controller < ApplicationController
  def benchmark_test_00363
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = Thread.new { user_input.to_s.strip }.value
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
