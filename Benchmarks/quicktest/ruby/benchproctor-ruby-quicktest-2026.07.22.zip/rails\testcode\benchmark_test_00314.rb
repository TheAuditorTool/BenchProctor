# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00314Controller < ApplicationController
  def benchmark_test_00314
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = sprintf("%s", user_input)
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
