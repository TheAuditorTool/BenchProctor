# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00018Controller < ApplicationController
  def benchmark_test_00018
    user_input = request.body.read
    data = ''
    user_input.split(',').each { |token| data = token }
    render json: { error: data }, status: 500
  end
end
