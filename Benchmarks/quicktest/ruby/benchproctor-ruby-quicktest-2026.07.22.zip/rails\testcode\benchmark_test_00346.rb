# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00346Controller < ApplicationController
  def benchmark_test_00346
    user_input = request.headers["X-Custom-Header"].to_s
    data = [user_input].pack("H*").force_encoding("UTF-8") rescue user_input
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + data + "']")
    render json: { status: "ok" }
  end
end
