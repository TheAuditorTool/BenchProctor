# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "shellwords"

class BenchmarkTest00386Controller < ApplicationController
  def benchmark_test_00386
    user_input = request.headers["X-Custom-Header"].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    processed = Shellwords.escape(data)
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
