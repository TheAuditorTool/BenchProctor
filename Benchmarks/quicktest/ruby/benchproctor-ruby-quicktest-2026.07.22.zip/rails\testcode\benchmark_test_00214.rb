# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00214Controller < ApplicationController
  def benchmark_test_00214
    user_input = request.body.read
    data = sprintf("%s", user_input)
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
