# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00171Controller < ApplicationController
  def benchmark_test_00171
    user_input = request.headers["Origin"].to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    unless session[:auth_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:auth_token].to_s)
      render json: { error: "unauthorized" }, status: 401
      return
    end
  end
end
