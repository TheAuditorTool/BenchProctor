# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00274Controller < ApplicationController
  def benchmark_test_00274
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
