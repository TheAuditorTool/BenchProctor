# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/ldap"

class BenchmarkTest00069Controller < ApplicationController
  def benchmark_test_00069
    user_input = ENV["USER_INPUT"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    ldap = Net::LDAP.new(host: "localhost")
    ldap.search(base: "dc=example,dc=com", filter: Net::LDAP::Filter.eq("cn", processed))
    render json: { status: "ok" }
  end
end
