# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00075Controller < ApplicationController
  def benchmark_test_00075
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    unless session[:csrf_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:csrf_token].to_s)
      render json: { error: "csrf mismatch" }, status: 403
      return
    end
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
  end
end
