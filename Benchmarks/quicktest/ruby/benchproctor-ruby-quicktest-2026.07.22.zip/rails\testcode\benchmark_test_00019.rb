# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00019Controller < ApplicationController
  def benchmark_test_00019
    user_input = request.body.read
    payload, _origin = user_input, 'http'
    data = payload
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
