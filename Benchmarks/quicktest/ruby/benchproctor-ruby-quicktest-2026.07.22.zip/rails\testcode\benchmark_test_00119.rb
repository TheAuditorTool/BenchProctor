# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00119Controller < ApplicationController
  def benchmark_test_00119
    user_input = request.query_parameters[:q].to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    Thread.new {
      render html: ("<div>" + data + "</div>").html_safe
    }.join
  end
end
