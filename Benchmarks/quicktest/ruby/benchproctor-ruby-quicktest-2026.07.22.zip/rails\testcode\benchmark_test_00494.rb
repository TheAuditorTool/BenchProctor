# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00494Controller < ApplicationController
  def benchmark_test_00494
    user_input = cookies[:session_token].to_s
    data = "#{user_input}"
    _hashed = Digest::SHA256.hexdigest(data.to_s)
    File.write("/var/data/output", _hashed)
    render json: { status: "ok" }
  end
end
