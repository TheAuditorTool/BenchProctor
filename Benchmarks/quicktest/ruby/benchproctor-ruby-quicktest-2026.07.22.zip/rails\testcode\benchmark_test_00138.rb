# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00138Controller < ApplicationController
  def benchmark_test_00138
    user_input = params.require(:user).permit(:name)[:name].to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    if Time.now.year >= 2020
    Nokogiri::XML(data) { |config| config.dtdload.noent.nonet }
    end
    render json: { status: "ok" }
  end
end
