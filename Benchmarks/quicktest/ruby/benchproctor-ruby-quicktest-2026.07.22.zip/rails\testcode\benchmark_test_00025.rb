# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00025Controller < ApplicationController
  def benchmark_test_00025
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    redirect_to user_input
  end
end
