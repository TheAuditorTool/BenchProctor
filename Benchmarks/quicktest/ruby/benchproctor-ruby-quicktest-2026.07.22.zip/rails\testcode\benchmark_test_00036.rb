# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00036Controller < ApplicationController
  def benchmark_test_00036
    user_input = ENV["USER_INPUT"] || ""
    tokens = user_input.split(',')
    data = tokens.join(',')
    ActiveRecord::Base.connection.execute("SELECT * FROM users WHERE id = '" + data + "'")
    render json: { status: "ok" }
  end
end
