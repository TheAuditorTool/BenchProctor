# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00457Controller < ApplicationController
  def benchmark_test_00457
    user_input = request.headers["X-Forwarded-For"].to_s
    data = user_input.gsub("\u0000", "")
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
