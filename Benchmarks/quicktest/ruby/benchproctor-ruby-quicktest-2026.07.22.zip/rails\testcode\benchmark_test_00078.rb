# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00078Controller < ApplicationController
  def benchmark_test_00078
    user_input = (params[:variables] || {})[:input].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    Process::Sys.setuid(65534)
    render json: { result: "ok" }
  end
end
