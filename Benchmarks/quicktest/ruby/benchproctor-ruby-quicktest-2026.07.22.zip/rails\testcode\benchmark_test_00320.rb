# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "yaml"

class BenchmarkTest00320Controller < ApplicationController
  def benchmark_test_00320
    user_input = ENV["USER_INPUT"] || ""
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    YAML.unsafe_load(data)
    render json: { status: "ok" }
  end
end
