# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00417Controller < ApplicationController
  def benchmark_test_00417
    user_input = request.host.to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
