# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00145Controller < ApplicationController
  def benchmark_test_00145
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = "%s" % user_input
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [processed, "data"] }
    render json: { status: "ok" }
  end
end
