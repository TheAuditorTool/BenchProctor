# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00297Controller < ApplicationController
  def benchmark_test_00297
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = !user_input.empty? ? user_input : ''
    render json: { error: data }, status: 500
  end
end
