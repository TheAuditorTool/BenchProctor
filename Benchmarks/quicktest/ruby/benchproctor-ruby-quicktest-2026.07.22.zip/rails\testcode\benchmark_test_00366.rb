# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00366Controller < ApplicationController
  def benchmark_test_00366
    user_input = Comment.first&.text.to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    render html: ("<html><body>" + data.to_s + "</body></html>").html_safe
  end
end
