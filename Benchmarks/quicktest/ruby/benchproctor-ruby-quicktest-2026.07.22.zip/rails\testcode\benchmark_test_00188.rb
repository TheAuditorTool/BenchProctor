# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00188Controller < ApplicationController
  def benchmark_test_00188
    user_input = ENV["USER_INPUT"] || ""
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
