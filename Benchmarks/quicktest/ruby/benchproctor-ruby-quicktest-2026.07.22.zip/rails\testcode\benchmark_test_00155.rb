# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00155Controller < ApplicationController
  def benchmark_test_00155
    user_input = request.body.read
    data = "#{user_input}"
    URI.open(data).read
    render json: { status: "ok" }
  end
end
