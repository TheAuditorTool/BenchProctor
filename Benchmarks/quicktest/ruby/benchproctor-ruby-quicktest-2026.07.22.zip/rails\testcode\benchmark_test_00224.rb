# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00224Controller < ApplicationController
  def benchmark_test_00224
    user_input = request.referer.to_s
    data = String(user_input).strip
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
