# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00064Controller < ApplicationController
  def benchmark_test_00064
    user_input = ENV["USER_INPUT"] || ""
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    processed = data.length > 64 ? data[0, 64] : data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
