# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00004Controller < ApplicationController
  def benchmark_test_00004
    user_input = request.headers["Authorization"].to_s
    data = Thread.new { user_input.to_s.strip }.value
    Process::Sys.setuid(data.to_i)
    render json: { result: "ok" }
  end
end
