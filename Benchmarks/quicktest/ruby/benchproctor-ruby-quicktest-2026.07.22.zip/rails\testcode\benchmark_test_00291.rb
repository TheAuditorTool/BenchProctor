# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00291Controller < ApplicationController
  def benchmark_test_00291
    user_input = (params[:variables] || {})[:input].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + data + "']")
    render json: { status: "ok" }
  end
end
