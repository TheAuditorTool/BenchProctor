# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00316Controller < ApplicationController
  def benchmark_test_00316
    user_input = params[:id].to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    unless %w[config.json index.html readme.md].include?(data.to_s)
      render json: { error: "forbidden" }, status: 403
      return
    end
    checked_path = data
    content = File.read(checked_path)
    render json: { status: "ok" }
  end
end
