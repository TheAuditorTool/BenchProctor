# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00248Controller < ApplicationController
  def benchmark_test_00248
    user_input = (params[:variables] || {})[:input].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    Marshal.load(processed)
    render json: { status: "ok" }
  end
end
