# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00200Controller < ApplicationController
  def benchmark_test_00200
    user_input = request.query_parameters[:q].to_s
    data = !user_input.empty? ? user_input : ''
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
