# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00250Controller < ApplicationController
  def benchmark_test_00250
    user_input = ENV["DOTENV_VAR"] || ""
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
