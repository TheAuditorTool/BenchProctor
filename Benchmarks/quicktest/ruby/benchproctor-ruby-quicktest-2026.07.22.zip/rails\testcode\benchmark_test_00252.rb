# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00252Controller < ApplicationController
  def benchmark_test_00252
    user_input = request.body.read
    data = "#{user_input}"
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
