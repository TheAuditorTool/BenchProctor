# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00465Controller < ApplicationController
  def benchmark_test_00465
    user_input = request.user_agent.to_s
    data = !user_input.empty? ? user_input : ''
    eval(data)
    render json: { status: "ok" }
  end
end
