# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00122Controller < ApplicationController
  def benchmark_test_00122
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    render html: (ERB.new(processed.to_s).result).html_safe
  end
end
