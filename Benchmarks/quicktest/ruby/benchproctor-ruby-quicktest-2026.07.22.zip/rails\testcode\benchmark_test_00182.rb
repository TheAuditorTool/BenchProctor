# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00182Controller < ApplicationController
  def benchmark_test_00182
    user_input = ENV["USER_INPUT"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
