# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00375Controller < ApplicationController
  def benchmark_test_00375
    user_input = (params[:variables] || {})[:input].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    _body = URI.open(data).read
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
