# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00016Controller < ApplicationController
  def benchmark_test_00016
    user_input = request.headers["Authorization"].to_s
    data = "%s" % user_input
    Net::HTTP.post(URI("https://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
