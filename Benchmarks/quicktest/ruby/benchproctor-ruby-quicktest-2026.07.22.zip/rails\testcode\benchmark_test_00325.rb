# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00325Controller < ApplicationController
  def benchmark_test_00325
    user_input = request.host.to_s
    data = user_input.split.join(" ")
    trusted_claim = data.to_s
    render json: { trusted: trusted_claim }
  end
end
