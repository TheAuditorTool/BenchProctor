# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00190Controller < ApplicationController
  def benchmark_test_00190
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
