# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00147Controller < ApplicationController
  def benchmark_test_00147
    user_input = request.headers["X-Custom-Header"].to_s
    on_input = proc { |v| v.to_s.tr("\r\n", "  ") }
    data = on_input.call(user_input)
    unless session[:csrf_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:csrf_token].to_s)
      render json: { error: "csrf mismatch" }, status: 403
      return
    end
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
  end
end
