# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00409Controller < ApplicationController
  def benchmark_test_00409
    user_input = params.require(:user).permit(:name)[:name].to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    processed = data.length > 64 ? data[0, 64] : data
    Nokogiri::XML(processed) { |config| config.dtdload.noent.nonet }
    render json: { status: "ok" }
  end
end
