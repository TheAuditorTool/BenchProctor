# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00012Controller < ApplicationController
  def benchmark_test_00012
    user_input = request.headers["X-Forwarded-For"].to_s
    data = String(user_input).strip
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    render html: (ERB.new(processed.to_s).result).html_safe
  end
end
