# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"
require "securerandom"

class BenchmarkTest00124Controller < ApplicationController
  def benchmark_test_00124
    user_input = User.first&.name.to_s
    data = String(user_input).strip
    _salt = SecureRandom.hex(16)
    digest = Digest::SHA256.hexdigest(_salt + data.to_s)
    render json: { status: "ok" }
  end
end
