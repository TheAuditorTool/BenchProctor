# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00030Controller < ApplicationController
  def benchmark_test_00030
    user_input = request.body.read
    data = ''
    user_input.split(',').each { |token| data = token }
    processed = CGI.escapeHTML(data)
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
