# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00134Controller < ApplicationController
  def benchmark_test_00134
    user_input = ENV["USER_INPUT"] || ""
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
