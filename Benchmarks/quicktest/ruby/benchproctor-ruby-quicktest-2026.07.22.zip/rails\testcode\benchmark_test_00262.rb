# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00262Controller < ApplicationController
  def benchmark_test_00262
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = !user_input.empty? ? user_input : ''
    Nokogiri::XML(data) { |config| config.dtdload.noent.nonet }
    render json: { status: "ok" }
  end
end
