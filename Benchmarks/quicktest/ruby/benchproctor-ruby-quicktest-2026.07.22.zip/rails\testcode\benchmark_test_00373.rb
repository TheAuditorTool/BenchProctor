# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00373Controller < ApplicationController
  def benchmark_test_00373
    user_input = Comment.first&.text.to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    render json: { error: "Internal error" }, status: 500
  end
end
