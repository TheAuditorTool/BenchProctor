# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00442Controller < ApplicationController
  def benchmark_test_00442
    user_input = request.query_parameters[:q].to_s
    data = !user_input.empty? ? user_input : ''
    Rails.logger.info("Action: " + data)
    render json: { status: "ok" }
  end
end
