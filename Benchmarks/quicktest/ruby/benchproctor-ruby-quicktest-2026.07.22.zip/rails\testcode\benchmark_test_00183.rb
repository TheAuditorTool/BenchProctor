# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00183Controller < ApplicationController
  def benchmark_test_00183
    user_input = cookies[:session_token].to_s
    data = "#{user_input}"
    cred = ENV.fetch("APP_CREDENTIAL", "")
    _ = cred
    render json: { auth: "ok" }
  end
end
