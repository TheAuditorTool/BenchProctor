# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00087Controller < ApplicationController
  def benchmark_test_00087
    user_input = request.headers["X-Custom-Header"].to_s
    data = user_input.split.join(" ")
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    response.set_header("X-Custom", parsed_bool)
    render json: { status: "ok" }
  end
end
