# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00236Controller < ApplicationController
  def benchmark_test_00236
    user_input = "config_secret_test_abc123"
    data = "" + user_input
    _token = OpenSSL::HMAC.hexdigest("SHA256", data.to_s, "header.payload")
    _ = _token
    render json: { jwt: "signed" }
  end
end
