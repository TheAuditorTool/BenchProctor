# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00270Controller < ApplicationController
  def benchmark_test_00270
    user_input = (params[:variables] || {})[:input].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    render json: { error: "Internal error" }, status: 500
  end
end
