# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00306Controller < ApplicationController
  def benchmark_test_00306
    user_input = request.host.to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    response.set_header("X-Custom", processed)
    render json: { status: "ok" }
  end
end
