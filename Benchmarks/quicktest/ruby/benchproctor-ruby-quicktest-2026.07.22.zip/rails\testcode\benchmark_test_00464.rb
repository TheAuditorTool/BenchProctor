# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00464Controller < ApplicationController
  def benchmark_test_00464
    user_input = request.headers["Authorization"].to_s
    data = "" + user_input
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    if processed.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: processed.to_s }
    end
  end
end
