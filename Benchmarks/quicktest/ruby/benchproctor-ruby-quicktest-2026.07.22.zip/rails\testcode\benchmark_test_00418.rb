# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"
require "digest"

class BenchmarkTest00418Controller < ApplicationController
  def benchmark_test_00418
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    _resp = URI.open(data)
    _body = _resp.read
    _expected = ENV.fetch("FEED_SHA256", "")
    raise "integrity check failed" unless Digest::SHA256.hexdigest(_body) == _expected
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
