# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00423Controller < ApplicationController
  def benchmark_test_00423
    user_input = request.host.to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    render html: ("<div>" + data + "</div>").html_safe
  end
end
