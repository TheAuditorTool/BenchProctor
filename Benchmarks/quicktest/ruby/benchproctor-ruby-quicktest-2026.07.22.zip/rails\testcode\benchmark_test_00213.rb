# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00213Controller < ApplicationController
  def benchmark_test_00213
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    @user_input = user_input
    data = @user_input
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
