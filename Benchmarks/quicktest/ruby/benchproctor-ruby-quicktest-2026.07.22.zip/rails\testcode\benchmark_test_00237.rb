# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00237Controller < ApplicationController
  def benchmark_test_00237
    user_input = ENV["USER_INPUT"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
