# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00120Controller < ApplicationController
  def benchmark_test_00120
    user_input = request.headers["Authorization"].to_s
    data = [user_input].pack("H*").force_encoding("UTF-8") rescue user_input
    render json: { error: "Internal error" }, status: 500
  end
end
