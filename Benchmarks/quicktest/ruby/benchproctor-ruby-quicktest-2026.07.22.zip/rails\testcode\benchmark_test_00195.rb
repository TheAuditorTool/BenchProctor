# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00195Controller < ApplicationController
  def benchmark_test_00195
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    @user_input = user_input
    data = @user_input
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
