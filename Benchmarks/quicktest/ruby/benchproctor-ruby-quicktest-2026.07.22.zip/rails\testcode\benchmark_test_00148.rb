# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00148Controller < ApplicationController
  def benchmark_test_00148
    user_input = ENV["USER_INPUT"] || ""
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    render json: { error: "Internal error" }, status: 500
  end
end
