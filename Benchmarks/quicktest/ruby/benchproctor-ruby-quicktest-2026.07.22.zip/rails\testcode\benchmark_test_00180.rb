# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00180Controller < ApplicationController
  def benchmark_test_00180
    user_input = Comment.first&.text.to_s
    data = user_input.split.join(" ")
    _doc = Nokogiri::XML(data) { |config| config.nonet.nodtdload }
    _ = _doc
    render json: { status: "ok" }
  end
end
