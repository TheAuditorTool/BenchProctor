# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00477Controller < ApplicationController
  def benchmark_test_00477
    user_input = request.body.read
    tokens = user_input.split(',')
    data = tokens.join(',')
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
