# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00020Controller < ApplicationController
  def benchmark_test_00020
    user_input = request.body.read
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    token = rand(1000000)
    render json: { status: "ok" }
  end
end
