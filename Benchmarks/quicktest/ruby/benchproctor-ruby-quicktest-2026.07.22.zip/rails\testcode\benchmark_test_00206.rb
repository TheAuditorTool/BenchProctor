# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/ldap"

class BenchmarkTest00206Controller < ApplicationController
  def benchmark_test_00206
    user_input = cookies[:session_token].to_s
    data = !user_input.empty? ? user_input : ''
    ldap = Net::LDAP.new(host: "localhost")
    ldap.search(base: "dc=example,dc=com", filter: Net::LDAP::Filter.eq("cn", data))
    render json: { status: "ok" }
  end
end
