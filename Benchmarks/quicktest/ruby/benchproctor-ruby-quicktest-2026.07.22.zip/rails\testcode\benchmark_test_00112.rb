# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00112Controller < ApplicationController
  def benchmark_test_00112
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
