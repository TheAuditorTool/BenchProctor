# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00194Controller < ApplicationController
  def benchmark_test_00194
    user_input = request.user_agent.to_s
    data = !user_input.empty? ? user_input : ''
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + data + "']")
    render json: { status: "ok" }
  end
end
