# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00240Controller < ApplicationController
  def benchmark_test_00240
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    render html: ("<html><body>" + data.to_s + "</body></html>").html_safe
  end
end
