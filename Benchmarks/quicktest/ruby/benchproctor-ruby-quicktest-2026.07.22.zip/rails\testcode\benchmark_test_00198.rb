# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00198Controller < ApplicationController
  def benchmark_test_00198
    user_input = request.user_agent.to_s
    payload, _origin = user_input, 'http'
    data = payload
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
