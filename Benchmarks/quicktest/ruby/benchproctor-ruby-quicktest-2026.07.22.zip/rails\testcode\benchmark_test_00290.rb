# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00290Controller < ApplicationController
  def benchmark_test_00290
    user_input = request.user_agent.to_s
    data = "%s" % user_input
    render json: { error: data }, status: 500
  end
end
