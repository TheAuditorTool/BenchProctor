# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00460Controller < ApplicationController
  def benchmark_test_00460
    user_input = request.host.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
