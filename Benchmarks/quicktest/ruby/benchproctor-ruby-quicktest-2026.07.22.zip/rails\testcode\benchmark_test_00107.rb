# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00107Controller < ApplicationController
  def benchmark_test_00107
    user_input = request.host.to_s
    payload, _origin = user_input, 'http'
    data = payload
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
