# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00343Controller < ApplicationController
  def benchmark_test_00343
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
