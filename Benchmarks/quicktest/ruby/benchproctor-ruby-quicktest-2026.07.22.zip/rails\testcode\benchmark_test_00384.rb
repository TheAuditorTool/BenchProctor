# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00384Controller < ApplicationController
  def benchmark_test_00384
    user_input = params.require(:user).permit(:name)[:name].to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    processed = data.length > 64 ? data[0, 64] : data
    render html: (ERB.new(processed.to_s).result).html_safe
  end
end
