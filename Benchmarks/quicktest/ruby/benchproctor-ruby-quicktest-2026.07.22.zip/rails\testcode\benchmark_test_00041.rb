# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00041Controller < ApplicationController
  def benchmark_test_00041
    user_input = Comment.first&.text.to_s
    data = String(user_input).strip
    eval('system("echo " + data)')
    render json: { status: "ok" }
  end
end
