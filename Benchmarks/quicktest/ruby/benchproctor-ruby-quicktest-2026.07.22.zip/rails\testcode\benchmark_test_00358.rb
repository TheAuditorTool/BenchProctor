# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00358Controller < ApplicationController
  def benchmark_test_00358
    user_input = request.body.read
    data = user_input ? user_input : ''
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => data}).first
    render json: { status: "ok" }
  end
end
