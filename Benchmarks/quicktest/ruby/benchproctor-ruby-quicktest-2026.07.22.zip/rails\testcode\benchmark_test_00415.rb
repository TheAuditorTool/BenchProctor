# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00415Controller < ApplicationController
  def benchmark_test_00415
    user_input = ENV["APP_ARGV"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
