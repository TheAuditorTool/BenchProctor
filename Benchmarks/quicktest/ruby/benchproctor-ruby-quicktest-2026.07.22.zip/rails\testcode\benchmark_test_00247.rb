# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"
require "net/http"

class BenchmarkTest00247Controller < ApplicationController
  def benchmark_test_00247
    user_input = ENV["USER_INPUT"] || ""
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
