# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"
require "nokogiri"

class BenchmarkTest00258Controller < ApplicationController
  def benchmark_test_00258
    user_input = request.headers["X-Forwarded-For"].to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    if ENV.fetch("APP_ENV", "production") != "test"
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + data + "']")
    end
    render json: { status: "ok" }
  end
end
