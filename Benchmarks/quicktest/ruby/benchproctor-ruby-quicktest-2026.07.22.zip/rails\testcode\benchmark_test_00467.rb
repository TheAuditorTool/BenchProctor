# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00467Controller < ApplicationController
  def benchmark_test_00467
    user_input = ENV["USER_INPUT"] || ""
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    if parsed_bool.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: parsed_bool.to_s }
    end
  end
end
