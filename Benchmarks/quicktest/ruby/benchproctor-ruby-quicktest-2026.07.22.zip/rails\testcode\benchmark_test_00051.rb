# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00051Controller < ApplicationController
  def benchmark_test_00051
    user_input = request.body.read
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    Thread.new {
      _body = URI.open(data).read
      ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    }.join
    render json: { status: "ok" }
  end
end
