# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00400Controller < ApplicationController
  def benchmark_test_00400
    user_input = cookies[:session_token].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    http = Net::HTTP.new(URI(data).host, 443)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    http.start { |h| h.get('/') }
    render json: { status: "ok" }
  end
end
