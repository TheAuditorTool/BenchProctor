# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00024Controller < ApplicationController
  def benchmark_test_00024
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = CGI.unescape(user_input)
    processed = CGI.escapeHTML(data)
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
