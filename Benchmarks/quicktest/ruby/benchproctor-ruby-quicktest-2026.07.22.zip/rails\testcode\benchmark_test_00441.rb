# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00441Controller < ApplicationController
  def benchmark_test_00441
    user_input = params.require(:user).permit(:name)[:name].to_s
    cookies[:session] = { value: user_input, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
