# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00286Controller < ApplicationController
  def benchmark_test_00286
    user_input = request.query_parameters[:q].to_s
    @user_input = user_input
    data = @user_input
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    Process::Sys.setuid(processed.to_i)
    render json: { result: "ok" }
  end
end
