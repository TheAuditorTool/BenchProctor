# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00496Controller < ApplicationController
  def benchmark_test_00496
    user_input = request.headers["X-Custom-Header"].to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    processed = data.length > 64 ? data[0, 64] : data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
