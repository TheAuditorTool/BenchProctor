# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00434Controller < ApplicationController
  def benchmark_test_00434
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
