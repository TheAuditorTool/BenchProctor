# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00235Controller < ApplicationController
  def benchmark_test_00235
    user_input = request.user_agent.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
