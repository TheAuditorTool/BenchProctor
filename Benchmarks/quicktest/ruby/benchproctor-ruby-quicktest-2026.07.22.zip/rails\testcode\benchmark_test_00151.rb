# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00151Controller < ApplicationController
  def benchmark_test_00151
    user_input = "ghp_EXAMPLEonly0123456789abcdefABCDEF0"
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = data.to_s.ljust(32)[0, 32]
    _cipher.update("data")
    render json: { encrypted: "ok" }
  end
end
