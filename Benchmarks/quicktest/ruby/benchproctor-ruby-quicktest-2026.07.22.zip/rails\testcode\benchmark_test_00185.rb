# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00185Controller < ApplicationController
  def benchmark_test_00185
    user_input = request.body.read
    data = user_input.split.join(" ")
    render html: ("<div>" + data + "</div>").html_safe
  end
end
