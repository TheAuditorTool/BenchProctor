# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00176Controller < ApplicationController
  def benchmark_test_00176
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    result = User.find_by(name: data)
    value = result.name
    render json: { status: "ok" }
  end
end
