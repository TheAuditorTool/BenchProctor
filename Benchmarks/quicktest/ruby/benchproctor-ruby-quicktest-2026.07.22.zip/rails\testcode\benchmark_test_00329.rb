# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00329Controller < ApplicationController
  def benchmark_test_00329
    user_input = Comment.first&.text.to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
