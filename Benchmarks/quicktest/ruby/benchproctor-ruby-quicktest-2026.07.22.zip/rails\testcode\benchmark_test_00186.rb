# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00186Controller < ApplicationController
  def benchmark_test_00186
    user_input = request.body.read
    data = "" + user_input
    requested = data.to_i
    wrapped = [requested + 1].pack('l').unpack('l').first
    render json: { wrapped: wrapped }
  end
end
