# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00161Controller < ApplicationController
  def benchmark_test_00161
    user_input = request.query_parameters[:q].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    render json: { error: data }, status: 500
  end
end
