# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00388Controller < ApplicationController
  def benchmark_test_00388
    user_input = request.headers["X-Custom-Header"].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    Rails.logger.info("Action: " + data)
    render json: { status: "ok" }
  end
end
