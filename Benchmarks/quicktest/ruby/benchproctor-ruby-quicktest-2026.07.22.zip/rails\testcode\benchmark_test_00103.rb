# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00103Controller < ApplicationController
  def benchmark_test_00103
    user_input = request.headers["Origin"].to_s
    if %w[read write admin].include?(user_input.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
