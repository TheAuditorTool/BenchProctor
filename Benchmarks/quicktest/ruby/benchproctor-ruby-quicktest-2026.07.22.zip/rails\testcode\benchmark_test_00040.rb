# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00040Controller < ApplicationController
  def benchmark_test_00040
    user_input = User.first&.name.to_s
    data = !user_input.empty? ? user_input : ''
    http = Net::HTTP.new(URI(data).host, 443)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    http.start { |h| h.get('/') }
    render json: { status: "ok" }
  end
end
