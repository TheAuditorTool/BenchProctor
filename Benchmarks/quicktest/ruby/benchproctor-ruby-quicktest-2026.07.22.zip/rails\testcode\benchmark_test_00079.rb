# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00079Controller < ApplicationController
  def benchmark_test_00079
    user_input = request.referer.to_s
    data = user_input.split.join(" ")
    Rails.logger.info("Action: " + data)
    render json: { status: "ok" }
  end
end
