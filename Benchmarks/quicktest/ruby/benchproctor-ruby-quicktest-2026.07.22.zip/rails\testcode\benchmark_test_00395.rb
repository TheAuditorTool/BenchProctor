# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00395Controller < ApplicationController
  def benchmark_test_00395
    user_input = User.first&.name.to_s
    data = user_input.gsub("\u0000", "")
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
