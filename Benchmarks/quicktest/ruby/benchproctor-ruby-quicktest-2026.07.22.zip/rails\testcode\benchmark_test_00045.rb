# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00045Controller < ApplicationController
  def benchmark_test_00045
    user_input = request.referer.to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
