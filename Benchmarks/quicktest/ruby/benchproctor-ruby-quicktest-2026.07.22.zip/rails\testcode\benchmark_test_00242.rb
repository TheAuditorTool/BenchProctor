# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00242Controller < ApplicationController
  def benchmark_test_00242
    user_input = User.first&.name.to_s
    payload, _origin = user_input, 'http'
    data = payload
    content = File.read("/var/app/data/" + data)
    render json: { status: "ok" }
  end
end
