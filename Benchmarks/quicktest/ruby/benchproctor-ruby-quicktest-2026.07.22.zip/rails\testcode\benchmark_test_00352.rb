# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00352Controller < ApplicationController
  def benchmark_test_00352
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    unless session[:csrf_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:csrf_token].to_s)
      render json: { error: "csrf mismatch" }, status: 403
      return
    end
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
  end
end
