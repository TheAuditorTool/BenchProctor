# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "redcarpet"

class BenchmarkTest00396Controller < ApplicationController
  def benchmark_test_00396
    user_input = params[:id].to_s
    data = "#{user_input}"
    processed = Redcarpet::Markdown.new(Redcarpet::Render::SafeHTML).render(data)
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
