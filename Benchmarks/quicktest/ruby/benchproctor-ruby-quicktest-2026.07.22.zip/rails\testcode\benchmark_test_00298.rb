# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00298Controller < ApplicationController
  def benchmark_test_00298
    user_input = request.headers["X-Forwarded-For"].to_s
    data = "#{user_input}"
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
