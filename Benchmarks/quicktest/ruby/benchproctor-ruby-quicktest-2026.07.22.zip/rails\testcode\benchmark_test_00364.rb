# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00364Controller < ApplicationController
  def benchmark_test_00364
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = CGI.unescape(user_input)
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
