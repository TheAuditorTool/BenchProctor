# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00081Controller < ApplicationController
  def benchmark_test_00081
    user_input = request.referer.to_s
    data = user_input.split.join(" ")
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
