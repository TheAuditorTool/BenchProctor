# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00201Controller < ApplicationController
  def benchmark_test_00201
    user_input = request.headers["Authorization"].to_s
    data = [user_input].pack("H*").force_encoding("UTF-8") rescue user_input
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
