# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00114Controller < ApplicationController
  def benchmark_test_00114
    user_input = ENV["USER_INPUT"] || ""
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    render html: (ERB.new(data.to_s).result).html_safe
  end
end
