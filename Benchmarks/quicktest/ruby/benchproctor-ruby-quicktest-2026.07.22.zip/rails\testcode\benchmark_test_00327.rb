# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00327Controller < ApplicationController
  def benchmark_test_00327
    user_input = request.headers["X-Custom-Header"].to_s
    data = [user_input].pack("H*").force_encoding("UTF-8") rescue user_input
    URI.open(data).read
    render json: { status: "ok" }
  end
end
