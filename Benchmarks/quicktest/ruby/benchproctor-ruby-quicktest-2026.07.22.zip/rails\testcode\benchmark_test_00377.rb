# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00377Controller < ApplicationController
  def benchmark_test_00377
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = "" + user_input
    cell = data.to_s
    cell = "'" + cell if cell.start_with?("=", "+", "-", "@")
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [cell, "data"] }
    render json: { status: "ok" }
  end
end
