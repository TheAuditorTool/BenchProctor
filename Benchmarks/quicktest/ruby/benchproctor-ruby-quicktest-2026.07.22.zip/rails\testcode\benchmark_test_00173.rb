# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00173Controller < ApplicationController
  def benchmark_test_00173
    user_input = request.referer.to_s
    data = "#{user_input}"
    cred = data.to_s
    authenticated = !cred.empty?
    unless authenticated
      render json: { error: "unauthorized" }, status: 401
      return
    end
    render json: { auth: "ok" }
  end
end
