# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00429Controller < ApplicationController
  def benchmark_test_00429
    user_input = request.body.read
    data = ''
    user_input.split(',').each { |token| data = token }
    unless data.to_s =~ /\.(jpg|png|gif|pdf)\z/i
      render json: { error: "invalid type" }, status: 400
      return
    end
    entry_file = data
    File.write("/var/uploads/" + File.basename(entry_file.to_s), "data")
    render json: { status: "ok" }
  end
end
