# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00260Controller < ApplicationController
  def benchmark_test_00260
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = user_input.gsub("\u0000", "")
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
