# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00067Controller < ApplicationController
  def benchmark_test_00067
    user_input = request.headers["X-Custom-Header"].to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    Digest::MD5.hexdigest(data)
    render json: { status: "ok" }
  end
end
