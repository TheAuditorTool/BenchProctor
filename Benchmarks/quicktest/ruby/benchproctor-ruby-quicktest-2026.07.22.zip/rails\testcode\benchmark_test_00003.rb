# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "shellwords"

class BenchmarkTest00003Controller < ApplicationController
  def benchmark_test_00003
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = sprintf("%s", user_input)
    processed = Shellwords.escape(data)
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
