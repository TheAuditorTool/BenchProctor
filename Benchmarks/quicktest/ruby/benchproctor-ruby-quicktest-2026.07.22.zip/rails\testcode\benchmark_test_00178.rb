# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00178Controller < ApplicationController
  def benchmark_test_00178
    user_input = request.headers["X-Custom-Header"].to_s
    data = user_input ? user_input : ''
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + data + "']")
    render json: { status: "ok" }
  end
end
