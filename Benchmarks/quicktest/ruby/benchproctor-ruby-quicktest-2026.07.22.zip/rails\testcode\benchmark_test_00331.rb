# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00331Controller < ApplicationController
  def benchmark_test_00331
    user_input = request.headers["X-Forwarded-For"].to_s
    data = user_input ? user_input : ''
    render json: { error: data }, status: 500
  end
end
