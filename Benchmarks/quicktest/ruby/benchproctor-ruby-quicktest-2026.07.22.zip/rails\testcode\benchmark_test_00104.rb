# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00104Controller < ApplicationController
  def benchmark_test_00104
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    data = String(user_input).strip
    if Time.now.year >= 2020
      render html: (ERB.new(data.to_s).result).html_safe
    end
  end
end
