# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00139Controller < ApplicationController
  def benchmark_test_00139
    user_input = request.query_parameters[:q].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    requested = data.to_i
    wrapped = [requested + 1].pack('l').unpack('l').first
    render json: { wrapped: wrapped }
  end
end
