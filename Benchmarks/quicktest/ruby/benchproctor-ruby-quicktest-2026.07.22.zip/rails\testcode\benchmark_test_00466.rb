# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00466Controller < ApplicationController
  def benchmark_test_00466
    user_input = request.headers["Authorization"].to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    if %w[read write admin].include?(processed.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
