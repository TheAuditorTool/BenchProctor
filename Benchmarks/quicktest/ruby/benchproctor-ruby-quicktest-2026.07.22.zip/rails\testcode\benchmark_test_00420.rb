# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00420Controller < ApplicationController
  def benchmark_test_00420
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    system("echo", data)
    render json: { status: "ok" }
  end
end
