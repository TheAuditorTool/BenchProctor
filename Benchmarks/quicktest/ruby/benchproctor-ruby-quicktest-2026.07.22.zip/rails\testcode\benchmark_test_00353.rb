# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00353Controller < ApplicationController
  def benchmark_test_00353
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = format('%s', user_input)
    unless %w[ls cat date whoami].include?(data.to_s)
      render json: { error: "forbidden" }, status: 400
      return
    end
    system(data.to_s)
  end
end
