# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00361Controller < ApplicationController
  def benchmark_test_00361
    user_input = request.host.to_s
    data = sprintf("%s", user_input)
    response.set_header("Access-Control-Allow-Origin", data)
    render json: { status: "ok" }
  end
end
