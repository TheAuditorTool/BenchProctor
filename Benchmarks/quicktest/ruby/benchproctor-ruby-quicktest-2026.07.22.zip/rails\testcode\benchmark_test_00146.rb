# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"

class BenchmarkTest00146Controller < ApplicationController
  def benchmark_test_00146
    user_input = request.referer.to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    host = URI.parse(data).host rescue ""
    unless ["api.intra.net", "cdn.railscdn.org"].include?(host)
      render json: { error: "forbidden host" }, status: 403
      return
    end
    target_url = data
    URI.open(target_url).read
    render json: { status: "ok" }
  end
end
