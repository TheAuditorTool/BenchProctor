# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00202Controller < ApplicationController
  def benchmark_test_00202
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = user_input.gsub("\u0000", "")
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
    render json: { status: "ok" }
  end
end
