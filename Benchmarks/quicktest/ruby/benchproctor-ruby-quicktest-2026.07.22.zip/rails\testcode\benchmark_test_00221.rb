# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00221Controller < ApplicationController
  def benchmark_test_00221
    user_input = request.headers["X-Forwarded-For"].to_s
    data = !user_input.empty? ? user_input : ''
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
