# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00005Controller < ApplicationController
  def benchmark_test_00005
    user_input = Comment.first&.text.to_s
    data = !user_input.empty? ? user_input : ''
    unless session[:user]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    Rails.logger.info("error: " + data.to_s)
  end
end
