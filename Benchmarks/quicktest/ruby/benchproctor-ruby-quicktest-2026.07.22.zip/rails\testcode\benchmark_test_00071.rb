# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00071Controller < ApplicationController
  def benchmark_test_00071
    user_input = User.first&.name.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    eval(data)
    render json: { status: "ok" }
  end
end
