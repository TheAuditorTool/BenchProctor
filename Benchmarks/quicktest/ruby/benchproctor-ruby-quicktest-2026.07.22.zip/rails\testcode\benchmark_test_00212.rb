# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00212Controller < ApplicationController
  def benchmark_test_00212
    user_input = request.headers["X-Custom-Header"].to_s
    data = String(user_input).strip
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
