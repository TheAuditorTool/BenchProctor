# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00231Controller < ApplicationController
  def benchmark_test_00231
    user_input = request.user_agent.to_s
    @user_input = user_input
    data = @user_input
    render json: { error: "Internal error" }, status: 500
  end
end
