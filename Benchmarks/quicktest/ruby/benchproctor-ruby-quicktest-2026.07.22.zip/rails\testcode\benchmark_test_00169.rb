# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00169Controller < ApplicationController
  def benchmark_test_00169
    user_input = request.query_parameters[:q].to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    system("echo " + data)
    render json: { status: "ok" }
  end
end
