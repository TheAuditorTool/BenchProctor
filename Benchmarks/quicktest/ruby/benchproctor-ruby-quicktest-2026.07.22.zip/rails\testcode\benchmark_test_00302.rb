# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00302Controller < ApplicationController
  def benchmark_test_00302
    user_input = ENV["USER_INPUT"] || ""
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [processed, "data"] }
    render json: { status: "ok" }
  end
end
