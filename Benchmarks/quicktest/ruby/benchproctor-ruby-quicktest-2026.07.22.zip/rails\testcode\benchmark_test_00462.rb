# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00462Controller < ApplicationController
  def benchmark_test_00462
    user_input = params[:id].to_s
    data = format('%s', user_input)
    render json: { error: data }, status: 500
  end
end
