# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00127Controller < ApplicationController
  def benchmark_test_00127
    user_input = Comment.first&.text.to_s
    data = "%s" % user_input
    File.delete("/var/app/data/" + data)
    render json: { status: "ok" }
  end
end
