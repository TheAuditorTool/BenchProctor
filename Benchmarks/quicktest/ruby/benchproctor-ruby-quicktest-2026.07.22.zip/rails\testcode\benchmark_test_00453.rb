# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00453Controller < ApplicationController
  def benchmark_test_00453
    user_input = cookies[:session_token].to_s
    data = Thread.new { user_input.to_s.strip }.value
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
