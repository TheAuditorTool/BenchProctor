# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00287Controller < ApplicationController
  def benchmark_test_00287
    user_input = Comment.first&.text.to_s
    data = !user_input.empty? ? user_input : ''
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
