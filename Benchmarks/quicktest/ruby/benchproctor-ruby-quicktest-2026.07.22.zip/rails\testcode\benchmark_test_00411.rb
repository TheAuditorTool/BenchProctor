# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00411Controller < ApplicationController
  def benchmark_test_00411
    user_input = params.require(:user).permit(:name)[:name].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    redirect_to data
  end
end
