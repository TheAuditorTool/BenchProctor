# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00181Controller < ApplicationController
  def benchmark_test_00181
    user_input = request.host.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    eval(processed)
    render json: { status: "ok" }
  end
end
