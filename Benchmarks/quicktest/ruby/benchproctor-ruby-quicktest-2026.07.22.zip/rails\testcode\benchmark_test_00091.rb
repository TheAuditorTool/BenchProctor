# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "base64"

class BenchmarkTest00091Controller < ApplicationController
  def benchmark_test_00091
    user_input = request.headers["Authorization"].to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = ENV.fetch("DATA_ENC_KEY", "").ljust(32)[0, 32]
    _cipher.random_iv
    _enc = Base64.strict_encode64(_cipher.update(data.to_s) + _cipher.final)
    File.write("/var/data/output", _enc)
    render json: { status: "ok" }
  end
end
