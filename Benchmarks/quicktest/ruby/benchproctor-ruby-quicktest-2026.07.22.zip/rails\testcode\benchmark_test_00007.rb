# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "base64"

class BenchmarkTest00007Controller < ApplicationController
  def benchmark_test_00007
    user_input = request.body.read
    data = Base64.decode64(user_input)
    system("echo " + data)
    render json: { status: "ok" }
  end
end
