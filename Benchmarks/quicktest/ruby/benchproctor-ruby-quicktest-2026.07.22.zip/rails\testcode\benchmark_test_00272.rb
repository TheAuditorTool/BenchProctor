# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00272Controller < ApplicationController
  def benchmark_test_00272
    user_input = request.host.to_s
    render json: { error: "Internal error" }, status: 500
  end
end
