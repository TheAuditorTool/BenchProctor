# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00433Controller < ApplicationController
  def benchmark_test_00433
    user_input = request.headers["Authorization"].to_s
    data = String(user_input).strip
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [processed, "data"] }
    render json: { status: "ok" }
  end
end
