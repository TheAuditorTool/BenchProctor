# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "socket"

class BenchmarkTest00485Controller < ApplicationController
  def benchmark_test_00485
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    TCPSocket.new(data, 80).close
    render json: { status: "ok" }
  end
end
