# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00449Controller < ApplicationController
  def benchmark_test_00449
    user_input = params.require(:user).permit(:name)[:name].to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
