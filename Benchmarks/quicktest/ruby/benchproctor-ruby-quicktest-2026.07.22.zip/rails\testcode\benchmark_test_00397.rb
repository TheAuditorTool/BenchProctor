# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00397Controller < ApplicationController
  def benchmark_test_00397
    user_input = request.headers["X-Forwarded-For"].to_s
    data = !user_input.empty? ? user_input : ''
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
