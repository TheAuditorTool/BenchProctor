# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00481Controller < ApplicationController
  def benchmark_test_00481
    user_input = Comment.first&.text.to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    cred = ENV.fetch("APP_CREDENTIAL", "")
    _ = cred
    render json: { auth: "ok" }
  end
end
