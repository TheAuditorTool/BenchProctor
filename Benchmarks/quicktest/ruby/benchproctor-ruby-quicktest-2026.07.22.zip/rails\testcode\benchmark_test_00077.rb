# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"
require "digest"

class BenchmarkTest00077Controller < ApplicationController
  def benchmark_test_00077
    user_input = (params[:variables] || {})[:input].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    _resp = URI.open(data)
    _body = _resp.read
    _expected = ENV.fetch("FEED_SHA256", "")
    raise "integrity check failed" unless Digest::SHA256.hexdigest(_body) == _expected
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
