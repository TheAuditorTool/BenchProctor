# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00149Controller < ApplicationController
  def benchmark_test_00149
    user_input = User.first&.name.to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    Net::HTTP.post(URI("http://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
