# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "yaml"

class BenchmarkTest00406Controller < ApplicationController
  def benchmark_test_00406
    user_input = request.body.read
    data = user_input.split.join(" ")
    YAML.unsafe_load(data)
    render json: { status: "ok" }
  end
end
