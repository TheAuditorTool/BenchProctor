# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00027Controller < ApplicationController
  def benchmark_test_00027
    user_input = "default_config_label"
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    _key = ENV.fetch("API_KEY", "")
    _req = Net::HTTP::Get.new(URI("https://api.railscdn.org/v1/data"))
    _req["Authorization"] = "Bearer " + _key
    _ = _req
    render json: { data: "ok" }
  end
end
