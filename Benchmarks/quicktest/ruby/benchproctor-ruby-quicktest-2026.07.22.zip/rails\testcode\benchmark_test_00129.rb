# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00129Controller < ApplicationController
  def benchmark_test_00129
    user_input = request.body.read
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    eval(parsed_bool)
    render json: { status: "ok" }
  end
end
