# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00451Controller < ApplicationController
  def benchmark_test_00451
    user_input = request.body.read
    data = "" + user_input
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [data, "data"] }
    render json: { status: "ok" }
  end
end
