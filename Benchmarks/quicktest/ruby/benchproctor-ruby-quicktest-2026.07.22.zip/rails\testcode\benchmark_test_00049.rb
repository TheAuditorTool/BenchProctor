# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00049Controller < ApplicationController
  def benchmark_test_00049
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = JSON.parse(user_input)["value"] rescue ""
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
