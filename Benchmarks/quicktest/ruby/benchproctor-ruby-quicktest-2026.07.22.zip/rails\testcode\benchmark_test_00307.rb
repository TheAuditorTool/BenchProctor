# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00307Controller < ApplicationController
  def benchmark_test_00307
    user_input = params[:id].to_s
    data = Thread.new { user_input.to_s.strip }.value
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    ActiveRecord::Base.connection.execute("SELECT * FROM users WHERE id = '" + processed + "'")
    render json: { status: "ok" }
  end
end
