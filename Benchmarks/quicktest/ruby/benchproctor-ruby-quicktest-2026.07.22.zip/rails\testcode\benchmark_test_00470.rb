# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00470Controller < ApplicationController
  def benchmark_test_00470
    user_input = ENV["USER_INPUT"] || ""
    data = user_input.gsub("\u0000", "")
    system("echo", data)
    render json: { status: "ok" }
  end
end
