# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00299Controller < ApplicationController
  def benchmark_test_00299
    user_input = request.headers["Authorization"].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
