# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00168Controller < ApplicationController
  def benchmark_test_00168
    user_input = request.body.read
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
