# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00203Controller < ApplicationController
  def benchmark_test_00203
    user_input = User.first&.name.to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    render html: ("<div>" + data + "</div>").html_safe
  end
end
