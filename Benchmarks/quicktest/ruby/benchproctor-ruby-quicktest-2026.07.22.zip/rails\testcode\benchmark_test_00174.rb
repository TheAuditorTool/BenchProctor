# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00174Controller < ApplicationController
  def benchmark_test_00174
    user_input = request.host.to_s
    data = Thread.new { user_input.to_s.strip }.value
    entries = Dir.entries(data.to_s) rescue []
    render json: { listing: entries }
  end
end
