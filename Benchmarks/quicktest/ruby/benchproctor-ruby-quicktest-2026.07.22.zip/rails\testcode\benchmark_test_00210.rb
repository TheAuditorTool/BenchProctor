# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00210Controller < ApplicationController
  def benchmark_test_00210
    user_input = ENV["USER_INPUT"] || ""
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    render json: { error: data }, status: 500
  end
end
