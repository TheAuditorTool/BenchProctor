# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00111Controller < ApplicationController
  def benchmark_test_00111
    user_input = request.user_agent.to_s
    data = sprintf("%s", user_input)
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => processed}).first
    render json: { status: "ok" }
  end
end
