# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00456Controller < ApplicationController
  def benchmark_test_00456
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = CGI.unescape(user_input)
    host = URI.parse(data).host rescue ""
    unless ["api.intra.net", "cdn.railscdn.org"].include?(host)
      render json: { error: "forbidden host" }, status: 403
      return
    end
    target_url = data
    redirect_to target_url
  end
end
