# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00080Controller < ApplicationController
  def benchmark_test_00080
    user_input = Comment.first&.text.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
