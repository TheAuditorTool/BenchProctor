# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00196Controller < ApplicationController
  def benchmark_test_00196
    user_input = request.headers["X-Custom-Header"].to_s
    data = user_input.split.join(" ")
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    trusted_claim = processed.to_s
    render json: { trusted: trusted_claim }
  end
end
