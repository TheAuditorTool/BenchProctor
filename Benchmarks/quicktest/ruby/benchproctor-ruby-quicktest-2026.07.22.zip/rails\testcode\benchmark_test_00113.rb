# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00113Controller < ApplicationController
  def benchmark_test_00113
    user_input = request.query_parameters[:q].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    File.write("/var/uploads/" + File.basename(data.to_s), "data")
    render json: { status: "ok" }
  end
end
