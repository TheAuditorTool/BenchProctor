# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00132Controller < ApplicationController
  def benchmark_test_00132
    user_input = User.first&.name.to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
