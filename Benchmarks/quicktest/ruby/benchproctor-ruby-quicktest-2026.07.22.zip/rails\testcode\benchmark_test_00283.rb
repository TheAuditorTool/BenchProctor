# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00283Controller < ApplicationController
  def benchmark_test_00283
    user_input = params[:id].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    requested = data.to_i
    allocated = requested + 1
    render json: { allocated: allocated }
  end
end
