# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00330Controller < ApplicationController
  def benchmark_test_00330
    user_input = request.host.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    render json: { error: "Internal error" }, status: 500
  end
end
