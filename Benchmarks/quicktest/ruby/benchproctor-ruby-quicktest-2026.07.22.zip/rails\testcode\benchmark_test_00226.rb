# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00226Controller < ApplicationController
  def benchmark_test_00226
    user_input = request.referer.to_s
    data = user_input ? user_input : ''
    render html: ERB::Util.html_escape(data)
  end
end
