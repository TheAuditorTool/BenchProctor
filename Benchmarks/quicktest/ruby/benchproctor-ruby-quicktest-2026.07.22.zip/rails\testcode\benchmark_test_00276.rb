# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00276Controller < ApplicationController
  def benchmark_test_00276
    user_input = "ghp_EXAMPLEonly0123456789abcdefABCDEF0"
    data = user_input ? user_input : ''
    _dsn = "postgres://app:" + data.to_s + "@db/prod"
    _ = _dsn
    render json: { auth: "ok" }
  end
end
