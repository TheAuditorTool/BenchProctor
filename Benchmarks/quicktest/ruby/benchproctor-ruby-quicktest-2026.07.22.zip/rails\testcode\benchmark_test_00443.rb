# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00443Controller < ApplicationController
  def benchmark_test_00443
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    system("echo " + data)
    render json: { status: "ok" }
  end
end
