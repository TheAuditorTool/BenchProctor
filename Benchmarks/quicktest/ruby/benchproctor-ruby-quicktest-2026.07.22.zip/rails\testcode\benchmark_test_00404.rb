# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00404Controller < ApplicationController
  def benchmark_test_00404
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = "" + user_input
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
