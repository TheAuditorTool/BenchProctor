# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00052Controller < ApplicationController
  def benchmark_test_00052
    user_input = Profile.first&.bio.to_s
    data = user_input ? user_input : ''
    resolved = File.realpath(File.join("/var/app/data", data)) rescue nil
    unless resolved && (resolved == "/var/app/data" || resolved.start_with?("/var/app/data/"))
      render json: { error: "forbidden" }, status: 403
      return
    end
    checked_path = resolved
    File.delete(checked_path)
    render json: { status: "ok" }
  end
end
