# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00163Controller < ApplicationController
  def benchmark_test_00163
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
