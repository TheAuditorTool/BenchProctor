# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00159Controller < ApplicationController
  def benchmark_test_00159
    user_input = User.first&.name.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    unless data.to_s =~ /\.(jpg|png|gif|pdf)\z/i
      render json: { error: "invalid type" }, status: 400
      return
    end
    entry_file = data
    File.write("/var/uploads/" + File.basename(entry_file.to_s), "data")
    render json: { status: "ok" }
  end
end
