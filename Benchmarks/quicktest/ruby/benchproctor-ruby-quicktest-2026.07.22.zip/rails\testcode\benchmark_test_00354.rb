# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00354Controller < ApplicationController
  def benchmark_test_00354
    user_input = "default_config_label"
    tokens = user_input.split(',')
    data = tokens.join(',')
    _secret = ENV.fetch("JWT_SECRET", "")
    _token = OpenSSL::HMAC.hexdigest("SHA256", _secret, "header.payload")
    _ = _token
    render json: { jwt: "signed" }
  end
end
