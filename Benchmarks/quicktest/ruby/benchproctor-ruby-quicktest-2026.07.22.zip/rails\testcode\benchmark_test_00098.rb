# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00098Controller < ApplicationController
  def benchmark_test_00098
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = format('%s', user_input)
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
