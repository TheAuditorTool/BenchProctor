# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00031Controller < ApplicationController
  def benchmark_test_00031
    user_input = ENV["USER_INPUT"] || ""
    data = "%s" % user_input
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
