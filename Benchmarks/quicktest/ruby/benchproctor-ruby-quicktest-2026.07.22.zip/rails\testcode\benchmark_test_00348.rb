# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00348Controller < ApplicationController
  def benchmark_test_00348
    user_input = request.query_parameters[:q].to_s
    data = "" + user_input
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
