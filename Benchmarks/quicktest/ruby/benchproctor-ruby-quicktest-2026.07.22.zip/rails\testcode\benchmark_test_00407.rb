# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00407Controller < ApplicationController
  def benchmark_test_00407
    user_input = request.body.read
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    trusted_claim = data.to_s
    render json: { trusted: trusted_claim }
  end
end
