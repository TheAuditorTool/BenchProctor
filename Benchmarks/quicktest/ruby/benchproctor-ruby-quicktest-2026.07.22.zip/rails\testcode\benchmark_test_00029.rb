# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00029Controller < ApplicationController
  def benchmark_test_00029
    user_input = params[:id].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    response.set_header("X-Custom", parsed_bool)
    render json: { status: "ok" }
  end
end
