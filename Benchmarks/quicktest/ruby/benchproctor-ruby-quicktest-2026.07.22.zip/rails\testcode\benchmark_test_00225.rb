# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00225Controller < ApplicationController
  def benchmark_test_00225
    user_input = request.headers["Origin"].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    render html: ("<html><body>" + data.to_s + "</body></html>").html_safe
  end
end
