# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00160Controller < ApplicationController
  def benchmark_test_00160
    user_input = params.require(:user).permit(:name)[:name].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    unless session[:csrf_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:csrf_token].to_s)
      render json: { error: "csrf mismatch" }, status: 403
      return
    end
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
  end
end
