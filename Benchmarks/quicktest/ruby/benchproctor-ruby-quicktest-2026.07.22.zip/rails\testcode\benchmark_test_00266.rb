# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00266Controller < ApplicationController
  def benchmark_test_00266
    user_input = request.referer.to_s
    data = sprintf("%s", user_input)
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
