# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00010Controller < ApplicationController
  def benchmark_test_00010
    user_input = request.query_parameters[:q].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    token = rand(1000000)
    render json: { status: "ok" }
  end
end
