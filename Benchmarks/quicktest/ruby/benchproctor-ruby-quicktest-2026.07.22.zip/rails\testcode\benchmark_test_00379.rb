# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/ldap"

class BenchmarkTest00379Controller < ApplicationController
  def benchmark_test_00379
    user_input = ENV["USER_INPUT"] || ""
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    ldap = Net::LDAP.new(host: "localhost")
    ldap.search(base: "dc=example,dc=com", filter: Net::LDAP::Filter.eq("cn", processed))
    render json: { status: "ok" }
  end
end
