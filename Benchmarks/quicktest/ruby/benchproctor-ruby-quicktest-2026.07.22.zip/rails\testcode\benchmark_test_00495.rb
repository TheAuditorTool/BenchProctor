# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00495Controller < ApplicationController
  def benchmark_test_00495
    user_input = "app_display_name"
    payload, _origin = user_input, 'http'
    data = payload
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = ENV.fetch("DATA_ENC_KEY", "").ljust(32)[0, 32]
    _cipher.update("data")
    render json: { encrypted: "ok" }
  end
end
