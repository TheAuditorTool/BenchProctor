# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00480Controller < ApplicationController
  def benchmark_test_00480
    user_input = (params[:variables] || {})[:input].to_s
    data = Thread.new { user_input.to_s.strip }.value
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    eval(processed)
    render json: { status: "ok" }
  end
end
