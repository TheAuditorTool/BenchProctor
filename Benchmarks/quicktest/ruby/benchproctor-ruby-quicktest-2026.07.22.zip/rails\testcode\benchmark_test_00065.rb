# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00065Controller < ApplicationController
  def benchmark_test_00065
    user_input = request.query_parameters[:q].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    processed = CGI.escapeHTML(data)
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
