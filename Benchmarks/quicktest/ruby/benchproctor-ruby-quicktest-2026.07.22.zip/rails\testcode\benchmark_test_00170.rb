# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00170Controller < ApplicationController
  def benchmark_test_00170
    user_input = ENV["USER_INPUT"] || ""
    payload, _origin = user_input, 'http'
    data = payload
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    ActiveRecord::Base.connection.execute("SELECT * FROM users WHERE id = '" + processed + "'")
    render json: { status: "ok" }
  end
end
