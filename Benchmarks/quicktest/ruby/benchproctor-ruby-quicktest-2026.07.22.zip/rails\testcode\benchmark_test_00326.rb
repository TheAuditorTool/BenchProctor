# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00326Controller < ApplicationController
  def benchmark_test_00326
    user_input = params.require(:user).permit(:name)[:name].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    requested = data.to_i
    allocated = requested + 1
    render json: { allocated: allocated }
  end
end
