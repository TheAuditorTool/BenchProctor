# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00234Controller < ApplicationController
  def benchmark_test_00234
    user_input = request.headers["X-Custom-Header"].to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    render json: { error: "Internal error" }, status: 500
  end
end
