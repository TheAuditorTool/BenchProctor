# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00410Controller < ApplicationController
  def benchmark_test_00410
    user_input = request.user_agent.to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + processed + "']")
    render json: { status: "ok" }
  end
end
