# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00095Controller < ApplicationController
  def benchmark_test_00095
    user_input = (params[:variables] || {})[:input].to_s
    data = sprintf("%s", user_input)
    unless session[:auth_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:auth_token].to_s)
      render json: { error: "unauthorized" }, status: 401
      return
    end
  end
end
