# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"
require "nokogiri"

class BenchmarkTest00317Controller < ApplicationController
  def benchmark_test_00317
    user_input = params.require(:user).permit(:name)[:name].to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    Nokogiri::XML("<root/>").xpath("/root/item[@id='" + parsed_bool + "']")
    render json: { status: "ok" }
  end
end
