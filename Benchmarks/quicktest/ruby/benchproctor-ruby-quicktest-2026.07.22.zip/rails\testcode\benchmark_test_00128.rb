# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00128Controller < ApplicationController
  def benchmark_test_00128
    user_input = request.referer.to_s
    data = sprintf("%s", user_input)
    if ["https://app.railscdn.org"].include?(data)
      response.set_header("Access-Control-Allow-Origin", data)
    end
    render json: { status: "ok" }
  end
end
