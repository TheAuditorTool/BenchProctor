# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00421Controller < ApplicationController
  def benchmark_test_00421
    user_input = request.headers["Authorization"].to_s
    data = format('%s', user_input)
    cred = data.to_s
    authenticated = !cred.empty?
    unless authenticated
      render json: { error: "unauthorized" }, status: 401
      return
    end
    render json: { auth: "ok" }
  end
end
