# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00232Controller < ApplicationController
  def benchmark_test_00232
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
