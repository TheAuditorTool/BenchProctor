# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00243Controller < ApplicationController
  def benchmark_test_00243
    user_input = cookies[:session_token].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
