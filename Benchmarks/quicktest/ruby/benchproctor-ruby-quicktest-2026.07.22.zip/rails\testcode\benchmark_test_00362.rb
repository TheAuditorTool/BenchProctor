# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00362Controller < ApplicationController
  def benchmark_test_00362
    user_input = (params[:variables] || {})[:input].to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
