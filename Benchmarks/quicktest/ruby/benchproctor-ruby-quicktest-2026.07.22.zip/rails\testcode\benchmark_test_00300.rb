# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00300Controller < ApplicationController
  def benchmark_test_00300
    user_input = params.require(:user).permit(:name)[:name].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
