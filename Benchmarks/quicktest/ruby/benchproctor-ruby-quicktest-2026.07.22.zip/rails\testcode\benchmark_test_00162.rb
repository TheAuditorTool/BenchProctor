# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00162Controller < ApplicationController
  def benchmark_test_00162
    user_input = Comment.first&.text.to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    _buf = "x" * 1024
    _ = _buf
    render json: { result: "ok" }
  end
end
