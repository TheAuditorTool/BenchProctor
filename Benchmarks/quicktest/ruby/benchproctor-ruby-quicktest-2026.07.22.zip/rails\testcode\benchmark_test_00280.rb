# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00280Controller < ApplicationController
  def benchmark_test_00280
    user_input = request.headers["Authorization"].to_s
    _buf = "x" * 1024
    _ = _buf
    render json: { result: "ok" }
  end
end
