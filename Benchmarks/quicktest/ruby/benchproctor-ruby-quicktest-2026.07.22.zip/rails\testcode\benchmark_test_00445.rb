# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00445Controller < ApplicationController
  def benchmark_test_00445
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    redirect_to data
  end
end
