# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00422Controller < ApplicationController
  def benchmark_test_00422
    user_input = params.require(:user).permit(:name)[:name].to_s
    on_input = proc { |v| v.to_s.tr("\r\n", "  ") }
    data = on_input.call(user_input)
    render json: { error: data }, status: 500
  end
end
