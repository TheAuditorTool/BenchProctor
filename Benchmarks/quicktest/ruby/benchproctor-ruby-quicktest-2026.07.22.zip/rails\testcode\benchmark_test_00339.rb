# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00339Controller < ApplicationController
  def benchmark_test_00339
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = "%s" % user_input
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
