# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00230Controller < ApplicationController
  def benchmark_test_00230
    user_input = cookies[:session_token].to_s
    data = "%s" % user_input
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
  end
end
