# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00022Controller < ApplicationController
  def benchmark_test_00022
    user_input = request.headers["X-Custom-Header"].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    unless session[:csrf_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:csrf_token].to_s)
      render json: { error: "csrf mismatch" }, status: 403
      return
    end
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
  end
end
