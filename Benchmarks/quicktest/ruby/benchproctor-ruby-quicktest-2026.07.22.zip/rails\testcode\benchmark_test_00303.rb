# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00303Controller < ApplicationController
  def benchmark_test_00303
    user_input = request.headers["Origin"].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
