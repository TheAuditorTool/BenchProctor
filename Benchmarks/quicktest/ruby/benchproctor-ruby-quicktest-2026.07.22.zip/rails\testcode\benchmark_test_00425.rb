# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00425Controller < ApplicationController
  def benchmark_test_00425
    user_input = Rails.application.config.app_value.to_s
    data = "" + user_input
    Net::HTTP.post(URI("https://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
