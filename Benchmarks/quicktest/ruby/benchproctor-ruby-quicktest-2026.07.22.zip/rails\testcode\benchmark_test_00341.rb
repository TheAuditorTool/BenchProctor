# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00341Controller < ApplicationController
  def benchmark_test_00341
    user_input = request.headers["Authorization"].to_s
    data = "%s" % user_input
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
