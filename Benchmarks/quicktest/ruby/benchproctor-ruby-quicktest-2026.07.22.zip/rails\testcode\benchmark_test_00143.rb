# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00143Controller < ApplicationController
  def benchmark_test_00143
    user_input = request.body.read
    data = Thread.new { user_input.to_s.strip }.value
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
