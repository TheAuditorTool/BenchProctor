# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00399Controller < ApplicationController
  def benchmark_test_00399
    user_input = params[:id].to_s
    data = user_input ? user_input : ''
    render json: { error: data }, status: 500
  end
end
