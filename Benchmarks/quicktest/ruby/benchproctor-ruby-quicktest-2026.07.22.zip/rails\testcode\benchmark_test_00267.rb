# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "erb"

class BenchmarkTest00267Controller < ApplicationController
  def benchmark_test_00267
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = "%s" % user_input
    render html: (ERB.new(data.to_s).result).html_safe
  end
end
