# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "shellwords"

class BenchmarkTest00487Controller < ApplicationController
  def benchmark_test_00487
    user_input = request.headers["Origin"].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    processed = Shellwords.escape(data)
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
