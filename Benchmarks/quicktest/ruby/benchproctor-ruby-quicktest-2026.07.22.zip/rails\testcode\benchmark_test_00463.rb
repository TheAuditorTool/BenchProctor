# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00463Controller < ApplicationController
  def benchmark_test_00463
    user_input = request.headers["X-Forwarded-For"].to_s
    data = !user_input.empty? ? user_input : ''
    resolved = File.realpath(File.join("/var/app/data", data)) rescue nil
    unless resolved && (resolved == "/var/app/data" || resolved.start_with?("/var/app/data/"))
      render json: { error: "forbidden" }, status: 403
      return
    end
    checked_path = resolved
    File.write(checked_path, "data")
    render json: { status: "ok" }
  end
end
