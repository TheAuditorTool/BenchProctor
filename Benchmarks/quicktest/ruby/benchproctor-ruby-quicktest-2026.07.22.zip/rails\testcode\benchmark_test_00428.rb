# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00428Controller < ApplicationController
  def benchmark_test_00428
    user_input = request.referer.to_s
    data = !user_input.empty? ? user_input : ''
    processed = CGI.escapeHTML(data)
    render html: ("<div>" + processed + "</div>").html_safe
  end
end
