# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00497Controller < ApplicationController
  def benchmark_test_00497
    user_input = User.first&.name.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    cred = data.to_s
    authenticated = !cred.empty?
    unless authenticated
      render json: { error: "unauthorized" }, status: 401
      return
    end
    render json: { auth: "ok" }
  end
end
