# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00393Controller < ApplicationController
  def benchmark_test_00393
    user_input = Comment.first&.text.to_s
    data = user_input ? user_input : ''
    JSON.parse(data)
    render json: { status: "ok" }
  end
end
