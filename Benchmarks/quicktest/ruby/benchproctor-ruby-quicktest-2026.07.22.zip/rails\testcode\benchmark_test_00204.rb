# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00204Controller < ApplicationController
  def benchmark_test_00204
    user_input = request.referer.to_s
    payload, _origin = user_input, 'http'
    data = payload
    render json: { error: "Internal error" }, status: 500
  end
end
