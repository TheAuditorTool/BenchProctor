# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00323Controller < ApplicationController
  def benchmark_test_00323
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    Net::HTTP.get(URI(data))
    render json: { status: "ok" }
  end
end
