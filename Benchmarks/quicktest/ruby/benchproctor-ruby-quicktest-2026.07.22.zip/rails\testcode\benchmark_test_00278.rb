# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00278Controller < ApplicationController
  def benchmark_test_00278
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = !user_input.empty? ? user_input : ''
    render json: { error: data }, status: 500
  end
end
