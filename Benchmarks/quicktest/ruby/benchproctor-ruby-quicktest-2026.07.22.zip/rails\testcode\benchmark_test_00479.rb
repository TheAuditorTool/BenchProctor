# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00479Controller < ApplicationController
  def benchmark_test_00479
    user_input = (params[:variables] || {})[:input].to_s
    data = String(user_input).strip
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
