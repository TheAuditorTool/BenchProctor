# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00401Controller < ApplicationController
  def benchmark_test_00401
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
