# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00360Controller < ApplicationController
  def benchmark_test_00360
    user_input = (params[:variables] || {})[:input].to_s
    data = "" + user_input
    render json: { error: "Internal error" }, status: 500
  end
end
