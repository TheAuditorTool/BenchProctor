# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00431Controller < ApplicationController
  def benchmark_test_00431
    user_input = request.headers["X-Custom-Header"].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    render html: ("<div>" + data + "</div>").html_safe
  end
end
