# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00277Controller < ApplicationController
  def benchmark_test_00277
    user_input = request.headers["X-Forwarded-For"].to_s
    begin
      data = JSON.parse(user_input)['value'] || user_input
    rescue JSON::ParserError
      data = user_input
    end
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
