# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00382Controller < ApplicationController
  def benchmark_test_00382
    user_input = request.headers["X-Custom-Header"].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
