# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00268Controller < ApplicationController
  def benchmark_test_00268
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    system("echo", data)
    render json: { status: "ok" }
  end
end
