# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00033Controller < ApplicationController
  def benchmark_test_00033
    user_input = request.user_agent.to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => processed}).first
    render json: { status: "ok" }
  end
end
