# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00074Controller < ApplicationController
  def benchmark_test_00074
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = user_input ? user_input : ''
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
