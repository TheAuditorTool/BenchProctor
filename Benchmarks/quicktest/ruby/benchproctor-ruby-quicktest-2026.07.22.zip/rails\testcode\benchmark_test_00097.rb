# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00097Controller < ApplicationController
  def benchmark_test_00097
    user_input = request.user_agent.to_s
    data = user_input ? user_input : ''
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    eval(parsed_bool)
    render json: { status: "ok" }
  end
end
