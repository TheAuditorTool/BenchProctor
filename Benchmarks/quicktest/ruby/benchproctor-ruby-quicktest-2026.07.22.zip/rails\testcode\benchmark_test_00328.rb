# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00328Controller < ApplicationController
  def benchmark_test_00328
    user_input = request.headers["Origin"].to_s
    payload, _origin = user_input, 'http'
    data = payload
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    eval(processed)
    render json: { status: "ok" }
  end
end
