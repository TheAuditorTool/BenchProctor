# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00264Controller < ApplicationController
  def benchmark_test_00264
    user_input = request.headers["Origin"].to_s
    data = user_input.gsub("\u0000", "")
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
