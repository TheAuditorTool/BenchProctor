# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00309Controller < ApplicationController
  def benchmark_test_00309
    user_input = request.body.read
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    requested = data.to_i
    wrapped = [requested + 1].pack('l').unpack('l').first
    render json: { wrapped: wrapped }
  end
end
