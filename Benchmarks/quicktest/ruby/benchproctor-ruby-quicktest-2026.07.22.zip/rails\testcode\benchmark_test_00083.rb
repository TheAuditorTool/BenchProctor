# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00083Controller < ApplicationController
  def benchmark_test_00083
    user_input = cookies[:session_token].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
