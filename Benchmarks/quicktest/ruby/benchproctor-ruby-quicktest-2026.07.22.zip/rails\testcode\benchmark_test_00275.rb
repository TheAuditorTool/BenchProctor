# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "nokogiri"

class BenchmarkTest00275Controller < ApplicationController
  def benchmark_test_00275
    user_input = params.require(:user).permit(:name)[:name].to_s
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    if ENV.fetch("APP_ENV", "production") != "test"
    Nokogiri::XML(data) { |config| config.dtdload.noent.nonet }
    end
    render json: { status: "ok" }
  end
end
