# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00053Controller < ApplicationController
  def benchmark_test_00053
    user_input = params[:id].to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    Thread.new {
      redirect_to data
    }.join
  end
end
