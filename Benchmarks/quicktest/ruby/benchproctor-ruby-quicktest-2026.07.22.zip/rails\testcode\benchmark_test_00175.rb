# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"
require "open-uri"

class BenchmarkTest00175Controller < ApplicationController
  def benchmark_test_00175
    user_input = request.query_parameters[:q].to_s
    data = CGI.unescape(user_input)
    _body = URI.open(data).read
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
