# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00483Controller < ApplicationController
  def benchmark_test_00483
    user_input = params[:id].to_s
    data = String(user_input).strip
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    ActiveRecord::Base.connection.execute("SELECT * FROM users WHERE id = '" + processed + "'")
    render json: { status: "ok" }
  end
end
