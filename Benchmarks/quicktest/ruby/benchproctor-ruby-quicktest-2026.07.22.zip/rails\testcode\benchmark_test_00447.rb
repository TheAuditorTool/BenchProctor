# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00447Controller < ApplicationController
  def benchmark_test_00447
    user_input = Comment.first&.text.to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
