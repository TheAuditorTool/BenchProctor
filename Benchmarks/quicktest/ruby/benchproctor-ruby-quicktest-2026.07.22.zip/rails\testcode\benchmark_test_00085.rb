# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00085Controller < ApplicationController
  def benchmark_test_00085
    user_input = request.user_agent.to_s
    @user_input = user_input
    data = @user_input
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
