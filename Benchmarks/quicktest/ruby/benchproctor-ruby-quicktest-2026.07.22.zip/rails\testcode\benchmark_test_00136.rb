# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00136Controller < ApplicationController
  def benchmark_test_00136
    user_input = cookies[:session_token].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    File.delete("/var/app/data/" + data)
    render json: { status: "ok" }
  end
end
