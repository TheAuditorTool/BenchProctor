# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00282Controller < ApplicationController
  def benchmark_test_00282
    user_input = User.first&.name.to_s
    data = format('%s', user_input)
    requested = data.to_i
    wrapped = [requested + 1].pack('l').unpack('l').first
    render json: { wrapped: wrapped }
  end
end
