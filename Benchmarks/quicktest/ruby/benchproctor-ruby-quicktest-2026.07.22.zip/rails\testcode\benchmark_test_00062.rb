# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00062Controller < ApplicationController
  def benchmark_test_00062
    user_input = (params[:variables] || {})[:input].to_s
    data = JSON.parse(user_input)["value"] rescue ""
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
