# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00394Controller < ApplicationController
  def benchmark_test_00394
    user_input = request.headers["Authorization"].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
