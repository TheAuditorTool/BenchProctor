# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00233Controller < ApplicationController
  def benchmark_test_00233
    user_input = request.body.read
    data = format('%s', user_input)
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
