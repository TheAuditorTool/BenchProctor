# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00034Controller < ApplicationController
  def benchmark_test_00034
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = user_input.split.join(" ")
    Net::HTTP.post(URI("https://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
