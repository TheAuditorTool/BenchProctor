# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00039Controller < ApplicationController
  def benchmark_test_00039
    user_input = cookies[:session_token].to_s
    @user_input = user_input
    data = @user_input
    processed = data.length > 64 ? data[0, 64] : data
    role = processed.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
