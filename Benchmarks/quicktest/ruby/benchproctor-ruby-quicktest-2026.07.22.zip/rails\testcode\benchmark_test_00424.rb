# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00424Controller < ApplicationController
  def benchmark_test_00424
    user_input = params.require(:user).permit(:name)[:name].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    unless %w[true false 1 0].include?(data.to_s)
      render json: { error: "invalid bool" }, status: 400
      return
    end
    parsed_bool = data
    if parsed_bool.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: parsed_bool.to_s }
    end
  end
end
