# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00219Controller < ApplicationController
  def benchmark_test_00219
    user_input = params.require(:upload_form).permit(:upload)[:upload].original_filename.to_s
    render json: { error: user_input }, status: 500
  end
end
