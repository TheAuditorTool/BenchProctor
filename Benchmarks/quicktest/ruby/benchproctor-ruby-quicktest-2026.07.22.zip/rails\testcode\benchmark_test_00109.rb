# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00109Controller < ApplicationController
  def benchmark_test_00109
    user_input = params[:id].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    response.set_header("Access-Control-Allow-Origin", data)
    render json: { status: "ok" }
  end
end
