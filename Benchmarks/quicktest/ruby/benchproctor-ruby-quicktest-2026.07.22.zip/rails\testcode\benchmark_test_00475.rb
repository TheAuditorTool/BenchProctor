# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00475Controller < ApplicationController
  def benchmark_test_00475
    user_input = request.headers["X-Forwarded-For"].to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    response.set_header("Access-Control-Allow-Origin", data)
    render json: { status: "ok" }
  end
end
