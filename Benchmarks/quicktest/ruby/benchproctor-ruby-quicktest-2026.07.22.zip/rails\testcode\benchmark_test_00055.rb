# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00055Controller < ApplicationController
  def benchmark_test_00055
    user_input = request.referer.to_s
    on_input = proc { |v| v.to_s.tr("\r\n", "  ") }
    data = on_input.call(user_input)
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => processed}).first
    render json: { status: "ok" }
  end
end
