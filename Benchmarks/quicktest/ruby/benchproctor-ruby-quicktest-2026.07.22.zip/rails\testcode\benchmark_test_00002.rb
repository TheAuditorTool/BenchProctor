# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "open-uri"
require "digest"

class BenchmarkTest00002Controller < ApplicationController
  def benchmark_test_00002
    user_input = request.host.to_s
    data = user_input.gsub("\u0000", "")
    _resp = URI.open(data)
    _body = _resp.read
    _expected = ENV.fetch("FEED_SHA256", "")
    raise "integrity check failed" unless Digest::SHA256.hexdigest(_body) == _expected
    ActiveRecord::Base.connection.exec_query("INSERT INTO feed (data) VALUES (?)", "SQL", [[nil, _body]])
    render json: { status: "ok" }
  end
end
