# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00383Controller < ApplicationController
  def benchmark_test_00383
    user_input = User.first&.name.to_s
    data = !user_input.empty? ? user_input : ''
    requested = data.to_i
    allocated = requested + 1
    render json: { allocated: allocated }
  end
end
