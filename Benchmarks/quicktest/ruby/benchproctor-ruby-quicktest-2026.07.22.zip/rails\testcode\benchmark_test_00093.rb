# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00093Controller < ApplicationController
  def benchmark_test_00093
    user_input = User.first&.name.to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    _buf = "x" * data.to_i
    _ = _buf
    render json: { result: "ok" }
  end
end
