# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00179Controller < ApplicationController
  def benchmark_test_00179
    user_input = request.headers["Authorization"].to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
