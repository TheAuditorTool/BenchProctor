# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00256Controller < ApplicationController
  def benchmark_test_00256
    user_input = cookies[:session_token].to_s
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    eval(data)
    render json: { status: "ok" }
  end
end
