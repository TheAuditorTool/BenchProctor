# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00100Controller < ApplicationController
  def benchmark_test_00100
    user_input = request.host.to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    system("echo " + data)
    render json: { status: "ok" }
  end
end
