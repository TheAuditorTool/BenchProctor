# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00432Controller < ApplicationController
  def benchmark_test_00432
    user_input = ENV["DOTENV_VAR"] || ""
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    File.write("/var/data/output", data)
    render json: { status: "ok" }
  end
end
