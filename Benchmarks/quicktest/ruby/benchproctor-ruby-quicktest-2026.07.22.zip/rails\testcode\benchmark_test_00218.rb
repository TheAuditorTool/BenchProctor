# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00218Controller < ApplicationController
  def benchmark_test_00218
    user_input = request.headers["X-Custom-Header"].to_s
    data = format('%s', user_input)
    render json: { error: "Internal error" }, status: 500
  end
end
