# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00318Controller < ApplicationController
  def benchmark_test_00318
    user_input = request.headers["Origin"].to_s
    data = user_input ? user_input : ''
    response.set_header("X-Custom", data)
    render json: { status: "ok" }
  end
end
