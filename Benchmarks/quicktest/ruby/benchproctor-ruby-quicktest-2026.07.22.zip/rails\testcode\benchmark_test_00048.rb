# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00048Controller < ApplicationController
  def benchmark_test_00048
    user_input = (params[:variables] || {})[:input].to_s
    data = "#{user_input}"
    Process::Sys.setuid(65534)
    render json: { result: "ok" }
  end
end
