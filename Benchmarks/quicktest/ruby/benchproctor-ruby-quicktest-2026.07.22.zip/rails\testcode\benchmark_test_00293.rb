# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00293Controller < ApplicationController
  def benchmark_test_00293
    user_input = request.headers["X-Custom-Header"].to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => processed}).first
    render json: { status: "ok" }
  end
end
