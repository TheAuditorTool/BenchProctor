# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00340Controller < ApplicationController
  def benchmark_test_00340
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = CGI.unescape(user_input)
    redirect_to data
  end
end
