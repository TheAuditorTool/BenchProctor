# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00387Controller < ApplicationController
  def benchmark_test_00387
    user_input = params[:id].to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    Process::Sys.setuid(65534)
    render json: { result: "ok" }
  end
end
