# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00187Controller < ApplicationController
  def benchmark_test_00187
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    data = String(user_input).strip
    ActiveRecord::Base.connection.exec_query("UPDATE users SET name = ?", "SQL", [[nil, data]])
    render json: { status: "ok" }
  end
end
