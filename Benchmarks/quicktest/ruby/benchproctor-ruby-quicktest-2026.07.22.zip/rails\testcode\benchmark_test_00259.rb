# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00259Controller < ApplicationController
  def benchmark_test_00259
    user_input = request.headers["Origin"].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
