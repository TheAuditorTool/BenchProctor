# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00096Controller < ApplicationController
  def benchmark_test_00096
    user_input = request.query_parameters[:q].to_s
    _accessor = :to_s
    data = user_input.public_send(_accessor)
    Thread.new {
      File.write("/var/uploads/" + File.basename(data.to_s), "data")
    }.join
    render json: { status: "ok" }
  end
end
