# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00289Controller < ApplicationController
  def benchmark_test_00289
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    data = Thread.new { user_input.to_s.strip }.value
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
