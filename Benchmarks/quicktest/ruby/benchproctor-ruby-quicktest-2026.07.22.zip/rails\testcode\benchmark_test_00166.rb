# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "csv"

class BenchmarkTest00166Controller < ApplicationController
  def benchmark_test_00166
    user_input = params[:id].to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    CSV.open("/var/data/output.csv", "a") { |csv| csv << [processed, "data"] }
    render json: { status: "ok" }
  end
end
