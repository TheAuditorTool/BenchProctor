# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00279Controller < ApplicationController
  def benchmark_test_00279
    user_input = request.body.read
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    http = Net::HTTP.new(URI(data).host, 443)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    http.start { |h| h.get('/') }
    render json: { status: "ok" }
  end
end
