# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00157Controller < ApplicationController
  def benchmark_test_00157
    user_input = ENV["DOTENV_VAR"] || ""
    data = user_input.gsub("\u0000", "")
    Net::HTTP.post(URI("https://api.intra.net/data"), data.to_s)
    render json: { status: "ok" }
  end
end
