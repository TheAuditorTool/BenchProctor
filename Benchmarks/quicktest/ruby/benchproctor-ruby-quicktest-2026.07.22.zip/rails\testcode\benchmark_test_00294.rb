# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00294Controller < ApplicationController
  def benchmark_test_00294
    user_input = request.host.to_s
    data = Thread.new { user_input.to_s.strip }.value
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    render json: { error: processed }, status: 500
  end
end
