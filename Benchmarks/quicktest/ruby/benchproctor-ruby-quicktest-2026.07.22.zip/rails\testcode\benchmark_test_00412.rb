# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/http"

class BenchmarkTest00412Controller < ApplicationController
  def benchmark_test_00412
    user_input = "app_display_name"
    instance_variable_set(:@exec_val, user_input)
    data = instance_variable_get(:@exec_val)
    _key = ENV.fetch("API_KEY", "")
    _req = Net::HTTP::Get.new(URI("https://api.railscdn.org/v1/data"))
    _req["Authorization"] = "Bearer " + _key
    _ = _req
    render json: { data: "ok" }
  end
end
