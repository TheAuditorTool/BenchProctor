# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "bunny"

class BenchmarkTest00105Controller < ApplicationController
  def benchmark_test_00105
    user_input = Bunny.new.start.create_channel.queue("taint_q").pop[2].to_s
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    JSON.parse(data)
    render json: { status: "ok" }
  end
end
