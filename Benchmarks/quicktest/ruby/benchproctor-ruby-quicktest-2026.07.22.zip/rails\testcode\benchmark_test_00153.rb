# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00153Controller < ApplicationController
  def benchmark_test_00153
    user_input = Comment.first&.text.to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
