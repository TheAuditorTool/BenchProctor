# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00165Controller < ApplicationController
  def benchmark_test_00165
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    on_input = proc { |v| v.to_s.tr("\r\n", "  ") }
    data = on_input.call(user_input)
    entries = Dir.entries(data.to_s) rescue []
    render json: { listing: entries }
  end
end
