# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00322Controller < ApplicationController
  def benchmark_test_00322
    user_input = Comment.first&.text.to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    unless %w[asc desc name created].include?(data)
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    response.set_header("X-Custom", processed)
    render json: { status: "ok" }
  end
end
