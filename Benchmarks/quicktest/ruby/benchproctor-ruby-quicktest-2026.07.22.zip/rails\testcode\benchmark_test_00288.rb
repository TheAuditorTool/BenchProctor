# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00288Controller < ApplicationController
  def benchmark_test_00288
    user_input = request.headers["Origin"].to_s
    data = user_input ? user_input : ''
    system("echo " + data)
    render json: { status: "ok" }
  end
end
