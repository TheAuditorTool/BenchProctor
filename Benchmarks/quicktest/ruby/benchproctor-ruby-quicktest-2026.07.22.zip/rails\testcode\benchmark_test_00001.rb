# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00001Controller < ApplicationController
  def benchmark_test_00001
    user_input = request.user_agent.to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => data}).first
    render json: { status: "ok" }
  end
end
