# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00125Controller < ApplicationController
  def benchmark_test_00125
    user_input = request.body.read
    @user_input = user_input
    data = @user_input
    response.set_header("X-Frame-Options", "DENY")
    response.set_header("Content-Security-Policy", "frame-ancestors 'none'")
    render json: { status: "ok" }
  end
end
