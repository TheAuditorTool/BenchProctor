# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00092Controller < ApplicationController
  def benchmark_test_00092
    user_input = params[:id].to_s
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
