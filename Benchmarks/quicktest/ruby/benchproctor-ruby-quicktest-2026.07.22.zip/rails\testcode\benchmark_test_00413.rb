# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "mongo"

class BenchmarkTest00413Controller < ApplicationController
  def benchmark_test_00413
    user_input = request.headers["Authorization"].to_s
    transform = ->(v) { v.to_s.unicode_normalize(:nfc) }
    data = transform.call(user_input)
    Mongo::Client.new(["localhost:27017"])[:users].find(name: {"$regex" => data}).first
    render json: { status: "ok" }
  end
end
