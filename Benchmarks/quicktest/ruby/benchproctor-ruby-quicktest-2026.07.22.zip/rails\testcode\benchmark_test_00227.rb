# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00227Controller < ApplicationController
  def benchmark_test_00227
    user_input = request.headers["X-Custom-Header"].to_s
    data = user_input.gsub("\u0000", "")
    render json: { error: "Internal error" }, status: 500
  end
end
