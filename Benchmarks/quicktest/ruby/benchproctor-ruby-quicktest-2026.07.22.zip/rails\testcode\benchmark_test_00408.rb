# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "cgi"

class BenchmarkTest00408Controller < ApplicationController
  def benchmark_test_00408
    user_input = request.query_parameters[:q].to_s
    data = CGI.unescape(user_input)
    trusted_claim = data.to_s
    render json: { trusted: trusted_claim }
  end
end
