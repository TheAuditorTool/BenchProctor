# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "digest"

class BenchmarkTest00335Controller < ApplicationController
  def benchmark_test_00335
    user_input = params.require(:multipart_data).permit(:multipart_field)[:multipart_field].to_s
    q = Queue.new
    producer = Thread.new { q.push(user_input.to_s.strip) }
    data = q.pop
    producer.join
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    Digest::MD5.hexdigest(processed)
    render json: { status: "ok" }
  end
end
