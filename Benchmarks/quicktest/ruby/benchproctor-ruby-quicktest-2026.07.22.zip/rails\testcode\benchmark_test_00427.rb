# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "securerandom"

class BenchmarkTest00427Controller < ApplicationController
  def benchmark_test_00427
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    payload, _origin = user_input, 'http'
    data = payload
    token = SecureRandom.hex(32)
    render json: { status: "ok" }
  end
end
