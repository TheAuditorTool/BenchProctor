# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00082Controller < ApplicationController
  def benchmark_test_00082
    user_input = request.user_agent.to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    unless session[:user_id]
      render json: { error: "unauthorized" }, status: 401
      return
    end
    session[:data] = data.to_s
  end
end
