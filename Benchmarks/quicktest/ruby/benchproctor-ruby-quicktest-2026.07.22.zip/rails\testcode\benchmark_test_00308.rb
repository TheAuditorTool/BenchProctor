# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00308Controller < ApplicationController
  def benchmark_test_00308
    user_input = request.body.read
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    processed = data.length > 64 ? data[0, 64] : data
    if processed.to_s =~ /[a-zA-Z0-9_-]+/
      render json: { validated: processed.to_s }
    end
  end
end
