# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00365Controller < ApplicationController
  def benchmark_test_00365
    user_input = request.headers["X-Forwarded-For"].to_s
    data = ''
    user_input.split(',').each { |token| data = token }
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
