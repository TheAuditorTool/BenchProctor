# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00050Controller < ApplicationController
  def benchmark_test_00050
    user_input = request.headers["Authorization"].to_s
    data = user_input.gsub("\u0000", "")
    token = rand(1000000)
    render json: { status: "ok" }
  end
end
