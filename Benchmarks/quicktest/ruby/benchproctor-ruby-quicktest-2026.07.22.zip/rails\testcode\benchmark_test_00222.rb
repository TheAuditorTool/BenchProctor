# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00222Controller < ApplicationController
  def benchmark_test_00222
    user_input = (params[:variables] || {})[:input].to_s
    payload, _origin = user_input, 'http'
    data = payload
    requested = data.to_i
    wrapped = [requested + 1].pack('l').unpack('l').first
    render json: { wrapped: wrapped }
  end
end
