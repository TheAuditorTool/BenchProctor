# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00444Controller < ApplicationController
  def benchmark_test_00444
    user_input = ENV["STDIN_DATA"] || ""
    normalize = ->(v) { v.to_s.strip }
    data = normalize.call(user_input)
    unless data =~ /\A[a-zA-Z0-9_.-]+\z/
      render json: { error: "invalid" }, status: 400
      return
    end
    processed = data
    system("echo " + processed)
    render json: { status: "ok" }
  end
end
