# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00419Controller < ApplicationController
  def benchmark_test_00419
    user_input = params.require(:request_data).permit(:payload)[:payload].to_s
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    if %w[read write admin].include?(data.to_s)
      render json: { access: "granted", role: "admin" }, status: 200
    end
  end
end
