# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00338Controller < ApplicationController
  def benchmark_test_00338
    user_input = request.body.read
    rec = Data.define(:payload).new(payload: user_input.to_s)
    data = rec.payload
    render json: { error: "Internal error" }, status: 500
  end
end
