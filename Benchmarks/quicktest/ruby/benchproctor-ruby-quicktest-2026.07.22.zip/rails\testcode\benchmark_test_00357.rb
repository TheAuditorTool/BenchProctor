# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00357Controller < ApplicationController
  def benchmark_test_00357
    user_input = "app_display_name"
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    _pw = ENV.fetch("DB_PASSWORD", "")
    _dsn = "postgres://app:" + _pw + "@db/prod"
    _ = _dsn
    render json: { auth: "ok" }
  end
end
