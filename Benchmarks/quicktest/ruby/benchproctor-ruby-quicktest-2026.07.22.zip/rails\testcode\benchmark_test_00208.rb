# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "net/ldap"

class BenchmarkTest00208Controller < ApplicationController
  def benchmark_test_00208
    user_input = request.referer.to_s
    _prefix = user_input[0,1].downcase
    data = case _prefix
           when 'h' then user_input.downcase
           when 'f' then user_input.upcase
           else user_input.strip
           end
    ldap = Net::LDAP.new(host: "localhost")
    ldap.search(base: "dc=example,dc=com", filter: Net::LDAP::Filter.eq("cn", data))
    render json: { status: "ok" }
  end
end
