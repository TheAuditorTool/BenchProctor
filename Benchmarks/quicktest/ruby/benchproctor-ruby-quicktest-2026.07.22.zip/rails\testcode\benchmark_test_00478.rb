# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00478Controller < ApplicationController
  def benchmark_test_00478
    user_input = request.body.read
    _limit = 4096
    reader = -> { user_input.to_s[0, _limit] }
    data = reader.call
    result = User.find_by(name: data)
    return render json: { error: "not found" }, status: 404 if result.nil?
    value = result.name
    render json: { status: "ok" }
  end
end
