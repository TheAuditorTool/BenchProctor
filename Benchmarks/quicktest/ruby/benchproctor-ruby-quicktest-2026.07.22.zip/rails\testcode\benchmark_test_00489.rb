# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00489Controller < ApplicationController
  def benchmark_test_00489
    user_input = request.headers["X-Forwarded-For"].to_s
    holder = Struct.new(:value).new(user_input.to_s)
    data = holder.value
    unless session[:auth_token] && ActiveSupport::SecurityUtils.secure_compare(data.to_s, session[:auth_token].to_s)
      render json: { error: "unauthorized" }, status: 401
      return
    end
  end
end
