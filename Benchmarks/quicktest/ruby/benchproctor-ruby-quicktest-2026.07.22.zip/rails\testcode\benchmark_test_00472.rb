# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"
require "ostruct"

class BenchmarkTest00472Controller < ApplicationController
  def benchmark_test_00472
    user_input = request.referer.to_s
    ctx = OpenStruct.new(payload: user_input)
    data = ctx.payload
    return render json: { error: 'forbidden' }, status: 400 unless data =~ Regexp.new("\\A[^\\x00-\\x08\\x0e-\\x1f\\x7f]+\\z")
    processed = data
    Rails.logger.info("Action: " + processed)
    render json: { status: "ok" }
  end
end
