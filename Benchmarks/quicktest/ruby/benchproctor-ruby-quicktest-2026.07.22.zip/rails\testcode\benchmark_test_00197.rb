# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00197Controller < ApplicationController
  def benchmark_test_00197
    user_input = User.first&.name.to_s
    data = user_input ? user_input : ''
    cookies[:session] = { value: data, secure: true, httponly: true, same_site: :strict }
    render json: { status: "ok" }
  end
end
