# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00344Controller < ApplicationController
  def benchmark_test_00344
    user_input = request.body.read
    tokens = user_input.split(',')
    data = tokens.join(',')
    cookies[:session] = data
    render json: { status: "ok" }
  end
end
