# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00141Controller < ApplicationController
  def benchmark_test_00141
    user_input = "app_display_name"
    pending = user_input.split(',')
    data = ''
    data = pending.shift until pending.empty?
    _cipher = OpenSSL::Cipher.new("aes-256-gcm")
    _cipher.encrypt
    _cipher.key = ENV.fetch("DATA_ENC_KEY", "").ljust(32)[0, 32]
    _cipher.update("data")
    render json: { encrypted: "ok" }
  end
end
