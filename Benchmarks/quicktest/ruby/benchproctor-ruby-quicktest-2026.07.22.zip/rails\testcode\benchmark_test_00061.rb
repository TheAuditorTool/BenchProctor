# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00061Controller < ApplicationController
  def benchmark_test_00061
    user_input = cookies[:session_token].to_s
    tokens = user_input.split(',')
    data = tokens.join(',')
    role = data.to_s
    if role == "admin"
      render json: { role: "admin" }, status: 200
    end
  end
end
