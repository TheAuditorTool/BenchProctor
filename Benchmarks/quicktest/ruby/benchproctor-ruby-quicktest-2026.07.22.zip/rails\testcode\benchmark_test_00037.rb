# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00037Controller < ApplicationController
  def benchmark_test_00037
    user_input = request.host.to_s
    $request_state = { last_input: user_input }
    data = $request_state[:last_input]
    unless session[:role] == "admin"
      render json: { error: "forbidden" }, status: 403
      return
    end
    _decision = data.to_s
  end
end
