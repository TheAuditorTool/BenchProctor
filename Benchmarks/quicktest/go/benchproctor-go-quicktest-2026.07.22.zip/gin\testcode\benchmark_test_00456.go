// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00456(c *gin.Context) {
	fieldValue := c.PostForm("field")
	form := FormData{Payload: fieldValue}
	data := form.Payload
	resp, err := http.Post("http://api.svc.cluster/data", "text/plain", strings.NewReader(data))
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
