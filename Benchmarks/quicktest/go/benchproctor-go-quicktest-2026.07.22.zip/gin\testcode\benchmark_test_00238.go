// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00238(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	_prefix := ""
	if len(dbValue) > 0 {
		_prefix = strings.ToLower(dbValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = dbValue
	case "f":
		data = dbValue
	default:
		data = dbValue
	}
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
