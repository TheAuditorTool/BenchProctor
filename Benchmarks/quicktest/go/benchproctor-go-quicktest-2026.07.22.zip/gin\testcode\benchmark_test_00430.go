// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00430(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	capture := func() string { return uploadName }
	data := capture()
	conn, err := net.Dial("tcp", data)
	if err == nil {
		defer conn.Close()
	}
	c.JSON(200, gin.H{"code": "OK"})
}
