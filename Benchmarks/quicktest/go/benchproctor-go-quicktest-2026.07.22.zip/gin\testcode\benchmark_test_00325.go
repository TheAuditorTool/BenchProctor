// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00325(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	_prefix := ""
	if len(commentText) > 0 {
		_prefix = strings.ToLower(commentText[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = commentText
	case "f":
		data = commentText
	default:
		data = commentText
	}
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
