// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"net/http"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00175(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(uploadName) {
		data = normalizer(uploadName)
	}
	validPattern := regexp.MustCompile(`^[^\x00-\x08\x0e-\x1f\x7f]+$`)
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "forbidden")
		return
	}
	processed := data
	var mongoFilter bson.M
	json.Unmarshal([]byte(processed), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
