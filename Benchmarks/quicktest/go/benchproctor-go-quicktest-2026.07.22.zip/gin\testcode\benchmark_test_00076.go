// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00076(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	data := strings.Join(strings.Fields(headerValue), " ")
	c.Set("data", data)
}
