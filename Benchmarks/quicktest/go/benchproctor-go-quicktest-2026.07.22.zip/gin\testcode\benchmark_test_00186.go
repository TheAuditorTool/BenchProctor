// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00186(c *gin.Context) {
	secretValue := "s3cr3tP4ssw0rd_test_credential01"
	lastRequestValue.Store(secretValue)
	data, _ := lastRequestValue.Load().(string)
	validPattern := regexp.MustCompile(`^[^\x00-\x08\x0e-\x1f\x7f]+$`)
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "forbidden")
		return
	}
	processed := data
	block, _ := aes.NewCipher([]byte(processed))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
