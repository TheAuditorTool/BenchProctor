// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00037(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	_prefix := ""
	if len(cookieValue) > 0 {
		_prefix = strings.ToLower(cookieValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = cookieValue
	case "f":
		data = cookieValue
	default:
		data = cookieValue
	}
	authVerify("user", data)
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
