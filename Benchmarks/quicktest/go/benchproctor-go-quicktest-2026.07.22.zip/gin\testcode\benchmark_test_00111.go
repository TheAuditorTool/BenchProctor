// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00111(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	lastRequestValue.Store(originValue)
	data, _ := lastRequestValue.Load().(string)
	if os.Getenv("APP_ENV") != "test" {
		cmd := exec.Command("sh", "-c", "echo "+data)
		output, err := cmd.CombinedOutput()
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		c.Data(200, "text/plain", output)
	}
}
