// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00017(c *gin.Context) {
	configSecret := "config_secret_test_abc123_key007"
	segments := strings.Split(configSecret, ",")
	data := strings.Join(segments, " ")
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
