// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00314(c *gin.Context) {
	storeCred := os.Getenv("KEYRING_SECRET")
	req, _ := http.NewRequest("GET", "https://api.gocdn.net/v1/data", nil)
	req.Header.Set("Authorization", "Bearer "+storeCred)
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	c.Data(200, "text/plain", body)
}
