// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00462(c *gin.Context) {
	fieldValue := c.PostForm("field")
	var data string
	if len(fieldValue) > 0 {
		data = fieldValue
	} else {
		data = "default"
	}
	for _, a := range []string{"read", "write", "delete", "admin"} {
		if a == data {
			c.JSON(http.StatusOK, map[string]string{"access": "granted", "role": "admin"})
			return
		}
	}
	c.JSON(200, gin.H{"code": "OK"})
}
