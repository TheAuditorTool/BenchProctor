// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00059(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	data := strings.ReplaceAll(forwardedIP, "\x00", "")
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
