// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00184(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", multipartValue)
	data := _sb.String()
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
