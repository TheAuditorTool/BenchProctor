// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00010(c *gin.Context) {
	pathValue := c.Param("id")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", pathValue)
	data := _sb.String()
	DB.Exec("DELETE FROM accounts WHERE id = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
