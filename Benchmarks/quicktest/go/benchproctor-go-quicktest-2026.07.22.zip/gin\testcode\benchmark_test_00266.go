// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00266(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	data := jsonValue
	if _, after, ok := strings.Cut(jsonValue, ","); ok {
		data = after
	}
	allowed := map[string]bool{"https://app.gocdn.net": true}
	if allowed[data] {
		c.Header("Access-Control-Allow-Origin", data)
	}
	c.JSON(200, gin.H{"code": "OK"})
}
