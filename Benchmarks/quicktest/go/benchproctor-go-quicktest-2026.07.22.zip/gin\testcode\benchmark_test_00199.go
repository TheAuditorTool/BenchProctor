// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00199(c *gin.Context) {
	if !verifyBearer(c.GetHeader("Authorization")) {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.JSON(http.StatusOK, map[string]string{"status": "ok"})
}
