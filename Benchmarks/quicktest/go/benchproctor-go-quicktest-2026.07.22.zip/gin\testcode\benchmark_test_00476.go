// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00476(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	var mongoFilter bson.M
	json.Unmarshal([]byte(cookieValue), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
