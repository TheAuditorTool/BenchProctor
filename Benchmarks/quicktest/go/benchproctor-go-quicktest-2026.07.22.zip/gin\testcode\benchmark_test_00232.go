// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00232(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(uaValue)
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", data).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
