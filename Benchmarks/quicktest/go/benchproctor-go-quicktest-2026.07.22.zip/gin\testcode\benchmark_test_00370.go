// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"database/sql"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00370(c *gin.Context) {
	secretValue := "s3cr3tP4ssw0rd_test_credential01"
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(secretValue) {
		data = normalizer(secretValue)
	}
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	dsn := "host=db user=app password=" + processed + " dbname=prod"
	db, _ := sql.Open("postgres", dsn)
	defer db.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
