// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00356(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", jsonValue)
	data := _sb.String()
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
