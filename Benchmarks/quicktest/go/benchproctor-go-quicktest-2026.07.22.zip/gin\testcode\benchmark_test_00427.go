// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00427(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", uaValue)
	data := _sb.String()
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	os.Remove("/var/app/data/" + processed)
	c.JSON(200, gin.H{"code": "OK"})
}
