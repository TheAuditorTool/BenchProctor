// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00239(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := fmt.Sprintf("%s", originValue)
	c.Set("data", data)
}
