// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00322(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	var _b strings.Builder
	_b.WriteString(cookieValue)
	data := _b.String()
	if !strings.HasSuffix(strings.ToLower(data), ".jpg") && !strings.HasSuffix(strings.ToLower(data), ".png") {
		c.String(http.StatusBadRequest, "invalid file type")
		return
	}
	entryFile := data
	os.WriteFile("/var/uploads/"+entryFile, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
