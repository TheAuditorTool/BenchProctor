// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00417(c *gin.Context) {
	userID := c.Query("id")
	form := FormData{Payload: userID}
	data := form.Payload
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
