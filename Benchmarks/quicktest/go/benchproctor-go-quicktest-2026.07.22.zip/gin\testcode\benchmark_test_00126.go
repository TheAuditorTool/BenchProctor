// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00126(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	data := func(v string) string { return strings.TrimSpace(v) }(commentText)
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
