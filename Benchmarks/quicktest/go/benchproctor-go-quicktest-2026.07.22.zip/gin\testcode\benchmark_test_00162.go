// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"encoding/json"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00162(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	var _b strings.Builder
	_b.WriteString(graphqlVar)
	data := _b.String()
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{data, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
