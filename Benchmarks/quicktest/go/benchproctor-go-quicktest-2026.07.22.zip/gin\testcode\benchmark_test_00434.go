// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00434(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	hexBytes, _ := hex.DecodeString(authHeader)
	data := string(hexBytes)
	hashed := sha256.Sum256([]byte(data))
	os.WriteFile("/var/data/secrets.txt", []byte(fmt.Sprintf("%x", hashed)), 0644)
}
