// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00333(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	capture := func() string { return multipartValue }
	data := capture()
	var docName string
	DB.QueryRow("SELECT name FROM documents WHERE id = ?", data).Scan(&docName)
	c.Header("X-Record", docName)
	c.JSON(200, gin.H{"code": "OK"})
}
