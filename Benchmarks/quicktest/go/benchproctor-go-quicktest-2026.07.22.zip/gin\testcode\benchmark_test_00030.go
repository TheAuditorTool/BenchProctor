// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"io"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00030(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	lastRequestValue.Store(rawBody)
	data, _ := lastRequestValue.Load().(string)
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{processed, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
