// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/antchfx/xmlquery"
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00485(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	lastRequestValue.Store(authHeader)
	data, _ := lastRequestValue.Load().(string)
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	xmlDoc, xmlErr := xmlquery.Parse(strings.NewReader("<root><user/></root>"))
	if xmlErr != nil {
		c.String(http.StatusInternalServerError, xmlErr.Error())
		return
	}
	xmlquery.FindOne(xmlDoc, "//user[@name='"+processed+"']")
	c.JSON(200, gin.H{"code": "OK"})
}
