// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00419(c *gin.Context) {
	userID := c.Query("id")
	data := strings.Join(strings.Fields(userID), " ")
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
