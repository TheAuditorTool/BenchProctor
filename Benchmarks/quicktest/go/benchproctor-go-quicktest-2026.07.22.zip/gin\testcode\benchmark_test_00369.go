// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00369(c *gin.Context) {
	userID := c.Query("id")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(userID)
	}()
	data := <-resultCh
	validPattern := regexp.MustCompile("[a-zA-Z0-9_.-]+")
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	loginAttempts.Add(1)
	if authVerify("user", processed) {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
