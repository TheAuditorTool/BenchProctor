// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"math/rand"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00413(c *gin.Context) {
	fieldValue := c.PostForm("field")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(fieldValue) {
		data = normalizer(fieldValue)
	}
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	val := rand.Intn(1000000)
	c.JSON(http.StatusOK, map[string]string{"token": fmt.Sprintf("%d", val)})
}
