// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00303(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	segments := strings.Split(cookieValue, ",")
	data := strings.Join(segments, " ")
	crlfStripped := crlfPat.ReplaceAllString(data, "")
	processed := redactPat.ReplaceAllString(crlfStripped, "****")
	log.Printf("User action: %s", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
