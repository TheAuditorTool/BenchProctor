// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00045(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(uploadName) {
		data = normalizer(uploadName)
	}
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
