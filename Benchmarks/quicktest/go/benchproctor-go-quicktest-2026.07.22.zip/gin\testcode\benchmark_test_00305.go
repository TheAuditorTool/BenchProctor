// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00305(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	pending := strings.Split(dbValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{processed, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
