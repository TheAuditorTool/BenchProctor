// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00474(c *gin.Context) {
	secrets := map[string]string{"key": "p4ssw0rd_test_dict_secret_key012"}
	dictSecret := secrets["key"]
	lastRequestValue.Store(dictSecret)
	data, _ := lastRequestValue.Load().(string)
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
