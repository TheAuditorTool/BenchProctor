// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00203(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	if !strings.HasSuffix(strings.ToLower(originValue), ".jpg") && !strings.HasSuffix(strings.ToLower(originValue), ".png") {
		c.String(http.StatusBadRequest, "invalid file type")
		return
	}
	entryFile := originValue
	os.WriteFile("/var/uploads/"+entryFile, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
