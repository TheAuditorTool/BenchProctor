// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00343(c *gin.Context) {
	pathValue := c.Param("id")
	c.Set("data", pathValue)
}
