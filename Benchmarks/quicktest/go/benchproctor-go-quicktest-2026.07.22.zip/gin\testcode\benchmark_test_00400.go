// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net"
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00400(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", originValue)
	data := _sb.String()
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	ip := net.ParseIP(parsedURL.Hostname())
	if ip == nil {
		addrs, lookupErr := net.LookupHost(parsedURL.Hostname())
		if lookupErr != nil || len(addrs) == 0 {
			c.String(http.StatusForbidden, "unresolvable host")
			return
		}
		ip = net.ParseIP(addrs[0])
		if ip == nil {
			c.String(http.StatusForbidden, "unresolvable host")
			return
		}
	}
	if ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() {
		c.String(http.StatusForbidden, "private range blocked")
		return
	}
	targetUrl := data
	conn, err := net.Dial("tcp", targetUrl)
	if err == nil {
		defer conn.Close()
	}
	c.JSON(200, gin.H{"code": "OK"})
}
