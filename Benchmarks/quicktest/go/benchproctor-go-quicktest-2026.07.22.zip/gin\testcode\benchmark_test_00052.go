// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00052(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	if !aclCheck(c.GetString("user"), authHeader) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
