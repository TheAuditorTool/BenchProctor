// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00424(c *gin.Context) {
	pathValue := c.Param("id")
	pending := strings.Split(pathValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	allowedHosts := map[string]bool{"api.svc.cluster": true, "cdn.gocdn.net": true}
	if !allowedHosts[parsedURL.Hostname()] {
		c.String(http.StatusForbidden, "forbidden host")
		return
	}
	targetUrl := data
	c.Redirect(http.StatusFound, targetUrl)
}
