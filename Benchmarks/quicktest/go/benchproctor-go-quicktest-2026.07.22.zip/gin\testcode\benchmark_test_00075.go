// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"fmt"
	"log"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00075(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", graphqlVar)
	data := _sb.String()
	log.Printf("User action: %s", data)
	c.JSON(200, gin.H{"code": "OK"})
}
