// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00029(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	data := func(v string) string { return strings.TrimSpace(v) }(headerValue)
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
