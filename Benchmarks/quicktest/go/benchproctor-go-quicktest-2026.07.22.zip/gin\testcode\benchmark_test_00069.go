// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00069(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	_prefix := ""
	if len(originValue) > 0 {
		_prefix = strings.ToLower(originValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = originValue
	case "f":
		data = originValue
	default:
		data = originValue
	}
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
