// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00204(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	form := FormData{Payload: multipartValue}
	data := form.Payload
	salt := make([]byte, 16)
	rand.Read(salt)
	sum := sha256.Sum256(append(salt, []byte(data)...))
	hashStr := fmt.Sprintf("%x:%x", salt, sum)
	c.JSON(http.StatusOK, map[string]string{"hash": hashStr})
}
