// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00108(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	var mongoFilter bson.M
	json.Unmarshal([]byte(refererValue), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
