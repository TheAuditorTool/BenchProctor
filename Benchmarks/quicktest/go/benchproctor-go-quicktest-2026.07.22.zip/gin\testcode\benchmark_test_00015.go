// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00015(c *gin.Context) {
	dotenvValue := os.Getenv("DOTENV_VAR")
	os.WriteFile("/var/data/secrets.txt", []byte(dotenvValue), 0644)
}
