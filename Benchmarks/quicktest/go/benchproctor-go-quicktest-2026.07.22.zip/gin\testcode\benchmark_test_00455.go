// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00455(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	data := commentText
	if _, after, ok := strings.Cut(commentText, ","); ok {
		data = after
	}
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	allowedHosts := map[string]bool{"api.svc.cluster": true, "cdn.gocdn.net": true}
	if !allowedHosts[parsedURL.Hostname()] {
		c.String(http.StatusForbidden, "forbidden host")
		return
	}
	targetUrl := data
	c.Redirect(http.StatusFound, targetUrl)
}
