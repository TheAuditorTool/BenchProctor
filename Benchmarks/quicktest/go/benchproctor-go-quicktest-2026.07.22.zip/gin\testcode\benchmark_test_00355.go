// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00355(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	lastRequestValue.Store(headerValue)
	data, _ := lastRequestValue.Load().(string)
	DB.Exec("UPDATE users SET name = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
