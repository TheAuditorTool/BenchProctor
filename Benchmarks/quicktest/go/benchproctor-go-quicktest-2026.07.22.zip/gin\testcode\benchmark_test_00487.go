// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os/exec"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00487(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	var data string
	for _, token := range strings.Split(refererValue, ",") {
		data = token
	}
	cmd := exec.Command("python3", "-c", data)
	output, _ := cmd.CombinedOutput()
	c.Data(200, "text/plain", output)
}
