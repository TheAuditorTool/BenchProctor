// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"html"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00064(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	data := BenchSvcPassthrough(rawBody)
	processed := html.EscapeString(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
