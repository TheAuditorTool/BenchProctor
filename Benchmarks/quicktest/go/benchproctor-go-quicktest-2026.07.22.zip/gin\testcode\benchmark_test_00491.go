// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os/exec"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00491(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- originValue
	close(_jobs)
	data := <-_out
	_handlers := map[string]func(){"primary": func() {
		cmd := exec.Command("sh", "-c", "echo "+data)
		output, err := cmd.CombinedOutput()
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		c.Data(200, "text/plain", output)
	}}
	_handlers["primary"]()
}
