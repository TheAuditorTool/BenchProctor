// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00380(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	xmlBody := string(rawBytes)
	form := FormData{Payload: xmlBody}
	data := form.Payload
	var mongoFilter bson.M
	json.Unmarshal([]byte(data), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
