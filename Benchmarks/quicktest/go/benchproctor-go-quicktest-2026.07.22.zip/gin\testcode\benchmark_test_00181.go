// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00181(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	form := FormData{Payload: refererValue}
	data := form.Payload
	htmlOut := "<div>" + data + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
