// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"path/filepath"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00004(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(refererValue)
	}()
	data := <-resultCh
	checkedPath := filepath.Clean(data)
	os.WriteFile("/var/uploads/"+checkedPath, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
