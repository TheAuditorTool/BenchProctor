// SPDX-License-Identifier: Apache-2.0
//go:build unix

package testcode

import (
	"io"
	"log"
	"net/http"
	"strconv"
	"syscall"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00177(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	xmlBody := string(rawBytes)
	capture := func() string { return xmlBody }
	data := capture()
	reqUID, _ := strconv.Atoi(data)
	log.Printf("drop-privilege request for uid=%d", reqUID)
	syscall.Setuid(65534)
	c.JSON(http.StatusOK, map[string]string{"priv": "dropped"})
}
