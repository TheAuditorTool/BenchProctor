// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/md5"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00368(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	lastRequestValue.Store(authHeader)
	data, _ := lastRequestValue.Load().(string)
	hash := md5.Sum([]byte(data))
	hashStr := fmt.Sprintf("%x", hash)
	c.JSON(http.StatusOK, map[string]string{"hash": hashStr})
}
