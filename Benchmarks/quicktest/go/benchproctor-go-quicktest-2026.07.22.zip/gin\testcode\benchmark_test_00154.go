// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00154(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := uaValue
	if _, after, ok := strings.Cut(uaValue, ","); ok {
		data = after
	}
	trustedClaim := data
	c.Header("X-Claim-Trusted", trustedClaim)
}
