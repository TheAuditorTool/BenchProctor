// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00442(c *gin.Context) {
	_cfgBytes, _ := os.ReadFile("/etc/app/config.json")
	configValue := string(_cfgBytes)
	lastRequestValue.Store(configValue)
	data, _ := lastRequestValue.Load().(string)
	os.WriteFile("/var/data/secrets.txt", []byte(data), 0644)
}
