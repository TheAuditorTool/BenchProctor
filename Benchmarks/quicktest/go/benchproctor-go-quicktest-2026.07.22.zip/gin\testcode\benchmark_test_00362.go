// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00362(c *gin.Context) {
	dotenvValue := os.Getenv("DOTENV_VAR")
	pending := strings.Split(dotenvValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	os.WriteFile("/var/data/secrets.txt", []byte(data), 0644)
}
