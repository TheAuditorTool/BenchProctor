// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00444(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	xmlBody := string(rawBytes)
	var data string
	for _, token := range strings.Split(xmlBody, ",") {
		data = token
	}
	authVerify("user", data)
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
