// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00099(c *gin.Context) {
	storeCred := os.Getenv("VAULT_SECRET")
	if storeCred == "" {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
