// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"html/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00465(c *gin.Context) {
	userID := c.Query("id")
	var data string
	if len(userID) > 0 {
		data = userID
	} else {
		data = "default"
	}
	tmpl, _ := template.New("view").Parse("{{.}}")
	var buf bytes.Buffer
	tmpl.Execute(&buf, data)
	c.Data(200, "text/html", buf.Bytes())
}
