// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00435(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	var _b strings.Builder
	_b.WriteString(originValue)
	data := _b.String()
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{data, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
