// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00135(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(originValue)
	os.WriteFile("/var/uploads/"+data, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
