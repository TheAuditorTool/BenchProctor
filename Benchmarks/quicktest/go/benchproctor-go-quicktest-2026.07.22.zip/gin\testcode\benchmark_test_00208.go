// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00208(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := strings.ReplaceAll(originValue, "\x00", "")
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
