// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00372(c *gin.Context) {
	pathValue := c.Param("id")
	data := strings.Join(strings.Fields(pathValue), " ")
	c.Header("Access-Control-Allow-Origin", data)
	c.JSON(200, gin.H{"code": "OK"})
}
