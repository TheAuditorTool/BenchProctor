// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/des"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00364(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", uaValue)
	data := _sb.String()
	cipherBlock, _ := des.NewCipher([]byte("legacyk8"))
	cipherOut := make([]byte, des.BlockSize)
	cipherBlock.Encrypt(cipherOut, []byte(fmt.Sprintf("%-8.8s", data)))
	c.JSON(http.StatusOK, map[string]string{"alg": "des-ecb", "out": fmt.Sprintf("%x", cipherOut)})
}
