// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00089(c *gin.Context) {
	pathValue := c.Param("id")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(pathValue) {
		data = normalizer(pathValue)
	}
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	allocSize, _ := strconv.Atoi(processed)
	buf := make([]byte, allocSize)
	copy(buf, []byte(processed))
	c.JSON(200, gin.H{"code": "OK"})
}
