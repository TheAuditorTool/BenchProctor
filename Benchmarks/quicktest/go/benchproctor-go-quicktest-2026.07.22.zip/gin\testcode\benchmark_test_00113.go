// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"fmt"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00113(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := fmt.Sprintf("%s", uaValue)
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{processed, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
