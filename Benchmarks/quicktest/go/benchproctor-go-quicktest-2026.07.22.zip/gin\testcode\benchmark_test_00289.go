// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bufio"
	"net/http"
	"os"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00289(c *gin.Context) {
	_scanner := bufio.NewScanner(os.Stdin)
	_scanner.Scan()
	stdinValue := _scanner.Text()
	data := BenchSvcPassthrough(stdinValue)
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	cmd := exec.Command("sh", "-c", "echo "+processed)
	output, err := cmd.CombinedOutput()
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	c.Data(200, "text/plain", output)
}
