// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"html"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00218(c *gin.Context) {
	hostValue := c.Request.Host
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(hostValue)
	processed := html.EscapeString(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
