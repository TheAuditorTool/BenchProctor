// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00005(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(uaValue)
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data, Secure: true, HttpOnly: true, SameSite: http.SameSiteStrictMode})
	c.JSON(200, gin.H{"code": "OK"})
}
