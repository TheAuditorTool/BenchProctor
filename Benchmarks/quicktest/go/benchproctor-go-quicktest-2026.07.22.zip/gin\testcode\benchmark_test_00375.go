// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os/exec"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00375(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(forwardedIP) {
		data = normalizer(forwardedIP)
	}
	done := make(chan struct{})
	go func() {
		defer close(done)
		cmd := exec.Command("sh", "-c", "echo "+data)
		output, err := cmd.CombinedOutput()
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		c.Data(200, "text/plain", output)
	}()
	<-done
}
