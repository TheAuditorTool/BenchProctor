// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00207(c *gin.Context) {
	hostValue := c.Request.Host
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(hostValue)
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
