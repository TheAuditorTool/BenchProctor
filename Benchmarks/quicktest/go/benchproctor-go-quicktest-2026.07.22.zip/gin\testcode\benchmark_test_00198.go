// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00198(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	var data string
	for _, token := range strings.Split(originValue, ",") {
		data = token
	}
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
