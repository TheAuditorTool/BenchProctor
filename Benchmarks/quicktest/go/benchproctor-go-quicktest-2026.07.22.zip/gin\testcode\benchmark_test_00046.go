// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"fmt"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00046(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", refererValue)
	data := _sb.String()
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{data, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
