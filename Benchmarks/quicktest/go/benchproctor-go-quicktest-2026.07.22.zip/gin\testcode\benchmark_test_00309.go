// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/go-ldap/ldap/v3"
)

func BenchmarkTest00309(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(uaValue)
	}()
	data := <-resultCh
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	ldapConn, ldapErr := ldap.DialURL("ldap://localhost:389")
	if ldapErr != nil {
		c.String(http.StatusInternalServerError, ldapErr.Error())
		return
	}
	defer ldapConn.Close()
	searchReq := ldap.NewSearchRequest("ou=people,dc=example,dc=com", ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 0, 0, false, "(uid="+processed+")", []string{"cn"}, nil)
	sr, _ := ldapConn.Search(searchReq)
	if sr != nil {
		c.Header("X-LDAP-Count", strconv.Itoa(len(sr.Entries)))
	}
	c.JSON(200, gin.H{"code": "OK"})
}
