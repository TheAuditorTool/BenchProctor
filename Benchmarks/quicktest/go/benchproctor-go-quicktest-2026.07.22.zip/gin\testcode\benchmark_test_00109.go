// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00109(c *gin.Context) {
	pathValue := c.Param("id")
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(pathValue)
	parsedInt, err := strconv.Atoi(data)
	if err != nil || parsedInt < 0 || parsedInt > 2147483647 {
		c.String(http.StatusBadRequest, "invalid integer")
		return
	}
	boundedVal := strconv.Itoa(parsedInt)
	requested, _ := strconv.Atoi(boundedVal)
	allocated := requested + 1
	c.Header("X-Alloc-Size", strconv.Itoa(allocated))
}
