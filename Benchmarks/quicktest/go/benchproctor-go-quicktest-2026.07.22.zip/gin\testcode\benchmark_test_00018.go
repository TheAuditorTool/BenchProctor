// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00018(c *gin.Context) {
	pathValue := c.Param("id")
	data := BenchSvcPassthrough(pathValue)
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	cmd := exec.Command("sh", "-c", "echo "+processed)
	output, err := cmd.CombinedOutput()
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	c.Data(200, "text/plain", output)
}
