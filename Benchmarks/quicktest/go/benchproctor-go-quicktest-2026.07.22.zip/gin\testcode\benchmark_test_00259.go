// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00259(c *gin.Context) {
	dotenvValue := os.Getenv("DOTENV_VAR")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", dotenvValue)
	data := _sb.String()
	authVerify("user", data)
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
