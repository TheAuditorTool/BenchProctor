// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/des"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00016(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	capture := func() string { return forwardedIP }
	data := capture()
	cipherBlock, _ := des.NewCipher([]byte("legacyk8"))
	cipherOut := make([]byte, des.BlockSize)
	cipherBlock.Encrypt(cipherOut, []byte(fmt.Sprintf("%-8.8s", data)))
	c.JSON(http.StatusOK, map[string]string{"alg": "des-ecb", "out": fmt.Sprintf("%x", cipherOut)})
}
