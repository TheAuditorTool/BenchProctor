// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/des"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00429(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := strings.ReplaceAll(uaValue, "\x00", "")
	cipherBlock, _ := des.NewCipher([]byte("legacyk8"))
	cipherOut := make([]byte, des.BlockSize)
	cipherBlock.Encrypt(cipherOut, []byte(fmt.Sprintf("%-8.8s", data)))
	c.JSON(http.StatusOK, map[string]string{"alg": "des-ecb", "out": fmt.Sprintf("%x", cipherOut)})
}
