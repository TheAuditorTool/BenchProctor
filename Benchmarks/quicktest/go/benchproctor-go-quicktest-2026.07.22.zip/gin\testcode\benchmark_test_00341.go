// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00341(c *gin.Context) {
	secretValue := "s3cr3tP4ssw0rd_test_credential01"
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", secretValue)
	data := _sb.String()
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
