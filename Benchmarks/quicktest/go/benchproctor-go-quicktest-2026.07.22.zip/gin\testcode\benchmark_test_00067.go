// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00067(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(cookieValue)
	encrypted := encryptForStorage(data)
	os.WriteFile("/var/data/secrets.enc", []byte(encrypted), 0600)
	c.JSON(http.StatusOK, map[string]string{"stored": "encrypted"})
}
