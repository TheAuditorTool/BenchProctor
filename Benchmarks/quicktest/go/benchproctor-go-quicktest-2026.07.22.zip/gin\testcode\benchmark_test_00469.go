// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00469(c *gin.Context) {
	userID := c.Query("id")
	pending := strings.Split(userID, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	DB.Exec("UPDATE users SET role = ? WHERE id = 1", data)
	c.JSON(200, gin.H{"code": "OK"})
}
