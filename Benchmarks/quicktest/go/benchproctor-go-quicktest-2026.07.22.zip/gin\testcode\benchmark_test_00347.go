// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"path/filepath"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00347(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(authHeader) {
		data = normalizer(authHeader)
	}
	checkedPath := filepath.Join("/var/app/data", filepath.Base(data))
	os.WriteFile(checkedPath, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
