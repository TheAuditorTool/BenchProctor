// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00290(c *gin.Context) {
	hostValue := c.Request.Host
	var _b strings.Builder
	_b.WriteString(hostValue)
	data := _b.String()
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), bson.D{{Key: "status", Value: processed}})
	c.JSON(200, gin.H{"code": "OK"})
}
