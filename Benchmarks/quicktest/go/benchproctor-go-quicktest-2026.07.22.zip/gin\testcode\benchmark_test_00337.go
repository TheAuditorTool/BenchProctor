// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"database/sql"
	"fmt"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00337(c *gin.Context) {
	storeCred := os.Getenv("VAULT_SECRET")
	dsn := fmt.Sprintf("host=db user=app password=%s dbname=prod", storeCred)
	db, _ := sql.Open("postgres", dsn)
	defer db.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
