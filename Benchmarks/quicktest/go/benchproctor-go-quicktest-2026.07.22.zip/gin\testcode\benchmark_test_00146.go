// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"os"
	"text/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00146(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := BenchSvcPassthrough(originValue)
	if os.Getenv("APP_ENV") != "test" {
		tmpl, _ := template.New("unsafe").Parse(data)
		var buf bytes.Buffer
		tmpl.Execute(&buf, nil)
		c.Data(200, "text/html", buf.Bytes())
	}
}
