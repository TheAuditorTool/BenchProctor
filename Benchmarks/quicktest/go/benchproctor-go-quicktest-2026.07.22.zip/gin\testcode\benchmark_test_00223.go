// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"time"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00223(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	data := BenchSvcPassthrough(dbValue)
	if time.Now().Year() >= 2020 {
		htmlOut := "<div>" + data + "</div>"
		c.Data(200, "text/html", []byte(htmlOut))
	}
}
