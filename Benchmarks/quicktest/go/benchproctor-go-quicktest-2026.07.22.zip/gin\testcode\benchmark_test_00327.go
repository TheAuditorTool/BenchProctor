// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00327(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(multipartValue)
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
