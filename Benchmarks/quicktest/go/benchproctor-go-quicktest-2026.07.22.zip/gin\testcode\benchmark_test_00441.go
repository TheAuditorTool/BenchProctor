// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00441(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	var data string
	if len(uploadName) > 0 {
		data = uploadName
	} else {
		data = "default"
	}
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), bson.D{{Key: "status", Value: processed}})
	c.JSON(200, gin.H{"code": "OK"})
}
