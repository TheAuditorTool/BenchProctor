// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00136(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	_prefix := ""
	if len(uaValue) > 0 {
		_prefix = strings.ToLower(uaValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = uaValue
	case "f":
		data = uaValue
	default:
		data = uaValue
	}
	c.Set("data", data)
}
