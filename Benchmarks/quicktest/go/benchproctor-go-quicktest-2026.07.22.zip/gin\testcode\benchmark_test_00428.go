// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/hex"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00428(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	hexBytes, _ := hex.DecodeString(cookieValue)
	data := string(hexBytes)
	loginAttempts.Add(1)
	if authVerify("user", data) {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
