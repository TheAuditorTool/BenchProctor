// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/tls"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00283(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	holder := InputCarrier{UserInput: multipartValue}
	data := holder.UserInput
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	resp, err := client.Get(data)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	c.Data(200, "text/plain", body)
}
