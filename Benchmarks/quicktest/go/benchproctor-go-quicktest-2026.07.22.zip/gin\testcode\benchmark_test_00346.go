// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00346(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := strings.ReplaceAll(uaValue, "\x00", "")
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{data, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
