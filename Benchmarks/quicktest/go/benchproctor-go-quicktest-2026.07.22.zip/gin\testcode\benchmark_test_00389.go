// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"text/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00389(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := BenchSvcPassthrough(originValue)
	_handlers := map[string]func(){"primary": func() {
		tmpl, _ := template.New("unsafe").Parse(data)
		var buf bytes.Buffer
		tmpl.Execute(&buf, nil)
		c.Data(200, "text/html", buf.Bytes())
	}}
	_handlers["primary"]()
}
