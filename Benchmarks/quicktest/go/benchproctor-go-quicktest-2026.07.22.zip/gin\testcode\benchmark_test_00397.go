// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00397(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	form := FormData{Payload: rawBody}
	data := form.Payload
	allowed := map[string]bool{"https://app.gocdn.net": true}
	if allowed[data] {
		c.Header("Access-Control-Allow-Origin", data)
	}
	c.JSON(200, gin.H{"code": "OK"})
}
