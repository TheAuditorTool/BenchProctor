// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"fmt"
	"strings"
	"text/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00013(c *gin.Context) {
	hostValue := c.Request.Host
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", hostValue)
	data := _sb.String()
	tmpl, _ := template.New("unsafe").Parse(data)
	var buf bytes.Buffer
	tmpl.Execute(&buf, nil)
	c.Data(200, "text/html", buf.Bytes())
}
