// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"strings"
	"text/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00001(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := func(v string) string { return strings.TrimSpace(v) }(refererValue)
	tmpl, _ := template.New("unsafe").Parse(data)
	var buf bytes.Buffer
	tmpl.Execute(&buf, nil)
	c.Data(200, "text/html", buf.Bytes())
}
