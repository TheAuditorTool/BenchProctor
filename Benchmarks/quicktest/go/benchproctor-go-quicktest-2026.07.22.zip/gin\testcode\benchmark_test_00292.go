// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00292(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	var _b strings.Builder
	_b.WriteString(refererValue)
	data := _b.String()
	if !validSchemaPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	trustedClaim := processed
	c.Header("X-Claim-Trusted", trustedClaim)
}
