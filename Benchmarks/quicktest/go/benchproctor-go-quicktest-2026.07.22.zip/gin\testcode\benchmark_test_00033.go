// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00033(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	segments := strings.Split(uploadName, ",")
	data := strings.Join(segments, " ")
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	_host := parsedURL.Hostname()
	if _host == "metadata.google.internal" || _host == "metadata" {
		c.String(http.StatusForbidden, "metadata endpoint blocked")
		return
	}
	_ip := net.ParseIP(_host)
	if _ip == nil {
		if _addrs, _lookupErr := net.LookupHost(_host); _lookupErr == nil && len(_addrs) > 0 {
			_ip = net.ParseIP(_addrs[0])
		}
	}
	if _ip != nil && (_ip.IsLinkLocalUnicast() || _ip.Equal(net.ParseIP("fd00:ec2::254"))) {
		c.String(http.StatusForbidden, "metadata endpoint blocked")
		return
	}
	targetURL := data
	resp, err := http.Get(targetURL)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	c.Data(200, "text/plain", body)
}
