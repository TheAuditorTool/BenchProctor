// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00373(c *gin.Context) {
	secrets := map[string]string{"key": "p4ssw0rd_test_dict_secret_key012"}
	dictSecret := secrets["key"]
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- dictSecret
	close(_jobs)
	data := <-_out
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
