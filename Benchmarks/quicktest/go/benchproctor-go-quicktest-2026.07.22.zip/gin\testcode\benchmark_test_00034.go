// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00034(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	data := rawBody
	if _, after, ok := strings.Cut(rawBody, ","); ok {
		data = after
	}
	var docName string
	DB.QueryRow("SELECT name FROM documents WHERE id = ?", data).Scan(&docName)
	c.Header("X-Record", docName)
	c.JSON(200, gin.H{"code": "OK"})
}
