// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00423(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	lastRequestValue.Store(authHeader)
	data, _ := lastRequestValue.Load().(string)
	allowed := map[string]bool{"https://app.gocdn.net": true}
	if allowed[data] {
		c.Header("Access-Control-Allow-Origin", data)
	}
	c.JSON(200, gin.H{"code": "OK"})
}
