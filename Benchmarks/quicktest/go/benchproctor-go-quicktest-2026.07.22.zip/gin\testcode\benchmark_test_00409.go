// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00409(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	pending := strings.Split(authHeader, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	if data != "true" && data != "false" {
		c.String(http.StatusBadRequest, "invalid boolean")
		return
	}
	parsedBool := data
	log.Printf("User action: %s", parsedBool)
	c.JSON(200, gin.H{"code": "OK"})
}
