// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/tls"
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00008(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	segments := strings.Split(authHeader, ",")
	data := strings.Join(segments, " ")
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	resp, err := client.Get(data)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	c.Data(200, "text/plain", body)
}
