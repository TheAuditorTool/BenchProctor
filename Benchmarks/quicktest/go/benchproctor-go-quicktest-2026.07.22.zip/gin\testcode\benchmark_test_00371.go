// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00371(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	holder := InputCarrier{UserInput: authHeader}
	data := holder.UserInput
	if os.Getenv("APP_ENV") != "test" {
		query := fmt.Sprintf("SELECT * FROM users WHERE id = '%s'", data)
		rows, err := DB.Query(query)
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		defer rows.Close()
	}
	c.JSON(200, gin.H{"code": "OK"})
}
