// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"net/url"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00145(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	form := FormData{Payload: headerValue}
	data := form.Payload
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	allowedHosts := map[string]bool{"api.svc.cluster": true, "cdn.gocdn.net": true}
	if !allowedHosts[parsedURL.Hostname()] {
		c.String(http.StatusForbidden, "forbidden host")
		return
	}
	targetUrl := data
	c.Redirect(http.StatusFound, targetUrl)
}
