// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00020(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	lastRequestValue.Store(cookieValue)
	data, _ := lastRequestValue.Load().(string)
	validPattern := regexp.MustCompile(`^[^\x00-\x08\x0e-\x1f\x7f]+$`)
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "forbidden")
		return
	}
	processed := data
	if processed == "S3cr3tToken" {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
