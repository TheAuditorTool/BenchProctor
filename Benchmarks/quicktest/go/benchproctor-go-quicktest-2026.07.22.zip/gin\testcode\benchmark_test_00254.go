// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00254(c *gin.Context) {
	hostValue := c.Request.Host
	data := BenchSvcPassthrough(hostValue)
	for _, a := range []string{"read", "write", "delete", "admin"} {
		if a == data {
			c.JSON(http.StatusOK, map[string]string{"access": "granted", "role": "admin"})
			return
		}
	}
	c.JSON(200, gin.H{"code": "OK"})
}
