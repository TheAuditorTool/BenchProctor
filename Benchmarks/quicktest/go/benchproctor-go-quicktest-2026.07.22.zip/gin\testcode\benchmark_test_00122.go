// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func BenchmarkTest00122(c *gin.Context) {
	fieldValue := c.PostForm("field")
	lastRequestValue.Store(fieldValue)
	data, _ := lastRequestValue.Load().(string)
	hashedPw, _ := bcrypt.GenerateFromPassword([]byte(data), bcrypt.DefaultCost)
	c.JSON(http.StatusOK, map[string]string{"hash": string(hashedPw)})
}
