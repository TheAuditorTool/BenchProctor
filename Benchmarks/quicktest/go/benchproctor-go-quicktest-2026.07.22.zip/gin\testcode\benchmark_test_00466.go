// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00466(c *gin.Context) {
	pathValue := c.Param("id")
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(pathValue)
	content, err := os.ReadFile("/var/app/data/" + data)
	if err != nil {
		c.String(http.StatusNotFound, "not found")
		return
	}
	c.Data(200, "text/plain", content)
}
