// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00221(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	data := func(v string) string { return strings.TrimSpace(v) }(jsonValue)
	encrypted := encryptForStorage(data)
	os.WriteFile("/var/data/secrets.enc", []byte(encrypted), 0600)
	c.JSON(http.StatusOK, map[string]string{"stored": "encrypted"})
}
