// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00451(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	segments := strings.Split(uaValue, ",")
	data := strings.Join(segments, " ")
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
