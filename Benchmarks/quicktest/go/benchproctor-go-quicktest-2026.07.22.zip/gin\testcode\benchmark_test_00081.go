// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00081(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	segments := strings.Split(rawBody, ",")
	data := strings.Join(segments, " ")
	if !verifyBearer(c.GetHeader("Authorization")) {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.Set("data", data)
}
