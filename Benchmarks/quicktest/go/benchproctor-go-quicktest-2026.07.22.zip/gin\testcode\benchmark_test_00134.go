// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00134(c *gin.Context) {
	_cfgBytes, _ := os.ReadFile("/etc/app/config.json")
	configValue := string(_cfgBytes)
	pending := strings.Split(configValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	os.WriteFile("/var/data/secrets.txt", []byte(data), 0644)
}
