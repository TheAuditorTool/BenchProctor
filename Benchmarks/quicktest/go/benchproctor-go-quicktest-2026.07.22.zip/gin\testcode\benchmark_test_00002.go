// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00002(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	capture := func() string { return headerValue }
	data := capture()
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
