// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00110(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	var _b strings.Builder
	_b.WriteString(jsonValue)
	data := _b.String()
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", data).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
