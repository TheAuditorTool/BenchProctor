// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00224(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(uaValue) {
		data = normalizer(uaValue)
	}
	authVerify("user", data)
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
