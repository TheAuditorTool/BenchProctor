// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00197(c *gin.Context) {
	fieldValue := c.PostForm("field")
	data := fieldValue
	if _, after, ok := strings.Cut(fieldValue, ","); ok {
		data = after
	}
	if data != c.GetHeader("X-CSRF-Token") {
		c.String(http.StatusForbidden, "csrf mismatch")
		return
	}
	DB.Exec("UPDATE users SET name = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
