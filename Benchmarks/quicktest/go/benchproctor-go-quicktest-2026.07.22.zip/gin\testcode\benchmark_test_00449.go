// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"fmt"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00449(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(authHeader) {
		data = normalizer(authHeader)
	}
	hashed := sha256.Sum256([]byte(data))
	os.WriteFile("/var/data/secrets.txt", []byte(fmt.Sprintf("%x", hashed)), 0644)
}
