// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00007(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	data := func(v string) string { return strings.TrimSpace(v) }(commentText)
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
