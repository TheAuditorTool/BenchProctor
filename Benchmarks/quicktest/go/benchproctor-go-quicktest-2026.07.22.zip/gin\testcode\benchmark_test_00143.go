// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00143(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- originValue
	close(_jobs)
	data := <-_out
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
