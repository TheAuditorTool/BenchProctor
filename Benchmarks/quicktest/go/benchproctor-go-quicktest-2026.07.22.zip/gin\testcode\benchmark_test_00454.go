// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00454(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	pending := strings.Split(dbValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	allocSize, _ := strconv.Atoi(data)
	buf := make([]byte, allocSize)
	copy(buf, []byte(data))
	c.JSON(200, gin.H{"code": "OK"})
}
