// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00003(c *gin.Context) {
	_cfgBytes, _ := os.ReadFile("/etc/app/config.json")
	configValue := string(_cfgBytes)
	var _b strings.Builder
	_b.WriteString(configValue)
	data := _b.String()
	resp, err := http.Post("http://api.svc.cluster/data", "text/plain", strings.NewReader(data))
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
