// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00211(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	xmlBody := string(rawBytes)
	segments := strings.Split(xmlBody, ",")
	data := strings.Join(segments, " ")
	salt := make([]byte, 16)
	rand.Read(salt)
	sum := sha256.Sum256(append(salt, []byte(data)...))
	hashStr := fmt.Sprintf("%x:%x", salt, sum)
	c.JSON(http.StatusOK, map[string]string{"hash": hashStr})
}
