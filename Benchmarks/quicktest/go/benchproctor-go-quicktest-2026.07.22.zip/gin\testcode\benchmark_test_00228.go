// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00228(c *gin.Context) {
	pathValue := c.Param("id")
	data := strings.Join(strings.Fields(pathValue), " ")
	log.Printf("User action: %s", data)
	c.JSON(200, gin.H{"code": "OK"})
}
