// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00092(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	lastRequestValue.Store(jsonValue)
	data, _ := lastRequestValue.Load().(string)
	resp, err := http.Get(data)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	actualHash := fmt.Sprintf("%x", sha256.Sum256(body))
	expectedHash := os.Getenv("TRUSTED_FEED_SHA256")
	if actualHash != expectedHash {
		c.String(http.StatusBadGateway, "integrity check failed")
		return
	}
	DB.Exec("INSERT INTO feed (data) VALUES (?)", string(body))
}
