// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00019(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	data := cookieValue
	if _, after, ok := strings.Cut(cookieValue, ","); ok {
		data = after
	}
	allocSize, _ := strconv.Atoi(data)
	buf := make([]byte, allocSize)
	copy(buf, []byte(data))
	c.JSON(200, gin.H{"code": "OK"})
}
