// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00231(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	_prefix := ""
	if len(forwardedIP) > 0 {
		_prefix = strings.ToLower(forwardedIP[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = forwardedIP
	case "f":
		data = forwardedIP
	default:
		data = forwardedIP
	}
	trustedClaim := data
	c.Header("X-Claim-Trusted", trustedClaim)
}
