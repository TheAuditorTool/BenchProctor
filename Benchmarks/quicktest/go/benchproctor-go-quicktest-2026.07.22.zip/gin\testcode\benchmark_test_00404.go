// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"log"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00404(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	data := fmt.Sprintf("%s", dbValue)
	log.Printf("User action: %s", data)
	c.JSON(200, gin.H{"code": "OK"})
}
