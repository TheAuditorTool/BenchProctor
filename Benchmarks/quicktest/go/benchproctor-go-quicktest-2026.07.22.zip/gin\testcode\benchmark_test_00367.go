// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/hex"

	"github.com/gin-gonic/gin"
	"github.com/microcosm-cc/bluemonday"
)

func BenchmarkTest00367(c *gin.Context) {
	userID := c.Query("id")
	hexBytes, _ := hex.DecodeString(userID)
	data := string(hexBytes)
	processed := bluemonday.UGCPolicy().Sanitize(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
