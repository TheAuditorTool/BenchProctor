// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00265(c *gin.Context) {
	_cfgBytes, _ := os.ReadFile("/etc/app/config.json")
	configValue := string(_cfgBytes)
	data := fmt.Sprintf("%s", configValue)
	encrypted := encryptForStorage(data)
	os.WriteFile("/var/data/secrets.enc", []byte(encrypted), 0600)
	c.JSON(http.StatusOK, map[string]string{"stored": "encrypted"})
}
