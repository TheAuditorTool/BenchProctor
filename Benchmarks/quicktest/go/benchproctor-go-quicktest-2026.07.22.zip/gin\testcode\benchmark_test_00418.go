// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"strings"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00418(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := strings.ReplaceAll(refererValue, "\x00", "")
	var mongoFilter bson.M
	json.Unmarshal([]byte(data), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
