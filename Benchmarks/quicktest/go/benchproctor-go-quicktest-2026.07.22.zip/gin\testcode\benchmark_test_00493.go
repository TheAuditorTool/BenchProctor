// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00493(c *gin.Context) {
	userID := c.Query("id")
	data := userID
	if _, after, ok := strings.Cut(userID, ","); ok {
		data = after
	}
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(data) {
		c.Header("X-Validated", data)
	}
}
