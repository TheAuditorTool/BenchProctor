// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00293(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", forwardedIP)
	data := _sb.String()
	c.Header("X-Frame-Options", "DENY")
	c.Header("Content-Security-Policy", "frame-ancestors 'none'")
	c.JSON(http.StatusOK, map[string]string{"status": "ok", "view": data})
}
