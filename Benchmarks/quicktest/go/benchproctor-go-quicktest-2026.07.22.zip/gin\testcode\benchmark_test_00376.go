// SPDX-License-Identifier: Apache-2.0
//go:build unix

package testcode

import (
	"log"
	"net/http"
	"strconv"
	"syscall"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00376(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	reqUID, _ := strconv.Atoi(headerValue)
	log.Printf("drop-privilege request for uid=%d", reqUID)
	syscall.Setuid(65534)
	c.JSON(http.StatusOK, map[string]string{"priv": "dropped"})
}
