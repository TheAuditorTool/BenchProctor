// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00237(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	capture := func() string { return uploadName }
	data := capture()
	DB.Exec("DELETE FROM accounts WHERE id = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
