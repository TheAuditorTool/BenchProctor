// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00114(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	data := func(v string) string { return strings.TrimSpace(v) }(uploadName)
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	log.Printf("User action: %s", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
