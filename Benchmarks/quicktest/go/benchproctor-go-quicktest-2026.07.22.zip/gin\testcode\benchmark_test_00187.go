// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00187(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	data := func(v string) string { return strings.TrimSpace(v) }(cookieValue)
	if data == "S3cr3tToken" {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
