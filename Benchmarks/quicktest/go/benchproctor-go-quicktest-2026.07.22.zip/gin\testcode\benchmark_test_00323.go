// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00323(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(commentText)
	}()
	data := <-resultCh
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", processed).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
