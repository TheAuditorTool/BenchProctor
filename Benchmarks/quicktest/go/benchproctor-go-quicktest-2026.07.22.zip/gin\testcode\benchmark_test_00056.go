// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00056(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	_prefix := ""
	if len(uploadName) > 0 {
		_prefix = strings.ToLower(uploadName[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = uploadName
	case "f":
		data = uploadName
	default:
		data = uploadName
	}
	parsedURL, err := url.Parse(data)
	if err != nil {
		c.String(http.StatusBadRequest, "invalid url")
		return
	}
	ip := net.ParseIP(parsedURL.Hostname())
	if ip == nil {
		addrs, lookupErr := net.LookupHost(parsedURL.Hostname())
		if lookupErr != nil || len(addrs) == 0 {
			c.String(http.StatusForbidden, "unresolvable host")
			return
		}
		ip = net.ParseIP(addrs[0])
		if ip == nil {
			c.String(http.StatusForbidden, "unresolvable host")
			return
		}
	}
	if ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() {
		c.String(http.StatusForbidden, "private range blocked")
		return
	}
	targetUrl := data
	resp, err := http.Get(targetUrl)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	c.Data(200, "text/plain", body)
}
