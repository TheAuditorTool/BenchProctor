// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00366(c *gin.Context) {
	pathValue := c.Param("id")
	var data string
	for _, token := range strings.Split(pathValue, ",") {
		data = token
	}
	if !verifyBearer(c.GetHeader("Authorization")) {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.Set("data", data)
}
