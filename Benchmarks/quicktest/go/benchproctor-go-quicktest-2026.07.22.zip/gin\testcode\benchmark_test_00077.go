// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00077(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	holder := InputCarrier{UserInput: refererValue}
	data := holder.UserInput
	processed := strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;").Replace(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
