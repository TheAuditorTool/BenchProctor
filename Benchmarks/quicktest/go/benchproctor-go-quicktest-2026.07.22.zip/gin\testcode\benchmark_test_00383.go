// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00383(c *gin.Context) {
	fieldValue := c.PostForm("field")
	pending := strings.Split(fieldValue, ",")
	var data string
	for len(pending) > 0 {
		data = pending[0]
		pending = pending[1:]
	}
	if data != c.GetHeader("X-CSRF-Token") {
		c.String(http.StatusForbidden, "csrf mismatch")
		return
	}
	DB.Exec("UPDATE users SET name = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
