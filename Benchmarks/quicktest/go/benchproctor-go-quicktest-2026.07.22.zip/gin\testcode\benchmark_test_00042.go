// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00042(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := BenchSvcPassthrough(originValue)
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(data) {
		c.Header("X-Validated", data)
	}
}
