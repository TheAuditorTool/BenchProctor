// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00340(c *gin.Context) {
	hostValue := c.Request.Host
	_prefix := ""
	if len(hostValue) > 0 {
		_prefix = strings.ToLower(hostValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = hostValue
	case "f":
		data = hostValue
	default:
		data = hostValue
	}
	resp, err := http.Get(data)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	actualHash := fmt.Sprintf("%x", sha256.Sum256(body))
	expectedHash := os.Getenv("TRUSTED_FEED_SHA256")
	if actualHash != expectedHash {
		c.String(http.StatusBadGateway, "integrity check failed")
		return
	}
	DB.Exec("INSERT INTO feed (data) VALUES (?)", string(body))
}
