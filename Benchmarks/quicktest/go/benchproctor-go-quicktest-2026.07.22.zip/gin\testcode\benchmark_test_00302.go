// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00302(c *gin.Context) {
	var argValue string
	if len(os.Args) > 1 {
		argValue = os.Args[1]
	}
	var data string
	if argValue != "" {
		data = argValue
	}
	if !validSchemaPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	cmd := exec.Command("sh", "-c", "echo "+processed)
	output, err := cmd.CombinedOutput()
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	c.Data(200, "text/plain", output)
}
