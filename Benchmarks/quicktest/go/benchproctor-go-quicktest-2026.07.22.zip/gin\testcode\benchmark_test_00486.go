// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/url"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00486(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data, _ := url.QueryUnescape(refererValue)
	log.Printf("User action: %s", data)
	c.JSON(200, gin.H{"code": "OK"})
}
