// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00414(c *gin.Context) {
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
