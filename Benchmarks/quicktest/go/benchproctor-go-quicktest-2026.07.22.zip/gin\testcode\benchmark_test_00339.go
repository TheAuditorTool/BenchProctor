// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00339(c *gin.Context) {
	keys := []string{"s3cr3t_list_key_test_secret_0123"}
	listSecret := keys[0]
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(listSecret) {
		data = normalizer(listSecret)
	}
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
