// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00235(c *gin.Context) {
	fieldValue := c.PostForm("field")
	var data string
	if fieldValue != "" {
		data = fieldValue
	}
	if data == "S3cr3tToken" {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
