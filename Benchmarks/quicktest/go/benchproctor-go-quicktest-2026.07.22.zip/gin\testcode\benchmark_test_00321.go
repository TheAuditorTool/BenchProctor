// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00321(c *gin.Context) {
	userID := c.Query("id")
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", userID)
	data := _sb.String()
	htmlOut := "<div>" + data + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
