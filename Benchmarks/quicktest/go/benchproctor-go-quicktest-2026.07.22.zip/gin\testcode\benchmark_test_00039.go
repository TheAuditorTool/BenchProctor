// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"fmt"
	"html/template"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00039(c *gin.Context) {
	hostValue := c.Request.Host
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", hostValue)
	data := _sb.String()
	tmpl, _ := template.New("view").Parse("{{.}}")
	var buf bytes.Buffer
	tmpl.Execute(&buf, data)
	c.Data(200, "text/html", buf.Bytes())
}
