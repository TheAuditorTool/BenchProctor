// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"net/http"
	"text/template"
	"time"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00386(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	data := BenchSvcPassthrough(uploadName)
	if time.Now().Year() >= 2020 {
		tmpl, _ := template.New("unsafe").Parse(data)
		var buf bytes.Buffer
		tmpl.Execute(&buf, nil)
		c.Data(200, "text/html", buf.Bytes())
	}
}
