// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00152(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	data := string(bytes.TrimSpace([]byte(rawBody)))
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
