// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00130(c *gin.Context) {
	fieldValue := c.PostForm("field")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(fieldValue)
	}()
	data := <-resultCh
	os.WriteFile("/var/data/secrets.txt", []byte(data), 0644)
}
