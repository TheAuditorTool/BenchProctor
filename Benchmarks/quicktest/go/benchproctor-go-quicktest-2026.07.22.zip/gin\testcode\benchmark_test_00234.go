// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00234(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- graphqlVar
	close(_jobs)
	data := <-_out
	if !validSchemaPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	trustedClaim := processed
	c.Header("X-Claim-Trusted", trustedClaim)
}
