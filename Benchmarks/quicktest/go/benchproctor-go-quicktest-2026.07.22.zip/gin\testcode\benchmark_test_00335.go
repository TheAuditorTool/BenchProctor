// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00335(c *gin.Context) {
	var commentText string
	DB.QueryRow("SELECT text FROM comments LIMIT 1").Scan(&commentText)
	var _b strings.Builder
	_b.WriteString(commentText)
	data := _b.String()
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", data).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
