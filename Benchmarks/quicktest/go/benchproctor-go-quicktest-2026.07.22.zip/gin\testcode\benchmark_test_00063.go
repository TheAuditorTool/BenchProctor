// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00063(c *gin.Context) {
	fieldValue := c.PostForm("field")
	data := strings.Join(strings.Fields(fieldValue), " ")
	trustedClaim := data
	c.Header("X-Claim-Trusted", trustedClaim)
}
