// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00102(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	data := strings.Join(strings.Fields(multipartValue), " ")
	if !strings.HasSuffix(strings.ToLower(data), ".jpg") && !strings.HasSuffix(strings.ToLower(data), ".png") {
		c.String(http.StatusBadRequest, "invalid file type")
		return
	}
	entryFile := data
	os.WriteFile("/var/uploads/"+entryFile, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
