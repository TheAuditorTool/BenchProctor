// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"fmt"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00281(c *gin.Context) {
	fieldValue := c.PostForm("field")
	form := FormData{Payload: fieldValue}
	data := form.Payload
	hashed := sha256.Sum256([]byte(data))
	os.WriteFile("/var/data/secrets.txt", []byte(fmt.Sprintf("%x", hashed)), 0644)
}
