// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00217(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	segments := strings.Split(headerValue, ",")
	data := strings.Join(segments, " ")
	cell := data
	if len(cell) > 0 && strings.ContainsRune("=+-@\t\r", rune(cell[0])) {
		cell = "'" + cell
	}
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{cell, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
