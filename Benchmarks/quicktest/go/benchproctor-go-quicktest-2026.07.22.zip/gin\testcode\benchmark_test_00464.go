// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00464(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	data := rawBody
	if _, after, ok := strings.Cut(rawBody, ","); ok {
		data = after
	}
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", data).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
