// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00445(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(refererValue)
	}()
	data := <-resultCh
	if !verifyBearer(c.GetHeader("Authorization")) {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.Set("data", data)
}
