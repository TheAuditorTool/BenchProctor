// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00087(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := strings.ReplaceAll(refererValue, "\x00", "")
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(data) {
		c.Header("X-Validated", data)
	}
}
