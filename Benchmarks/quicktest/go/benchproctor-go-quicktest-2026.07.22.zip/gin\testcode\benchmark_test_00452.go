// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"bytes"
	"net/http"
	"strings"
	"text/template"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00452(c *gin.Context) {
	hostValue := c.Request.Host
	var _b strings.Builder
	_b.WriteString(hostValue)
	data := _b.String()
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	tmpl, _ := template.New("unsafe").Parse(processed)
	var buf bytes.Buffer
	tmpl.Execute(&buf, nil)
	c.Data(200, "text/html", buf.Bytes())
}
