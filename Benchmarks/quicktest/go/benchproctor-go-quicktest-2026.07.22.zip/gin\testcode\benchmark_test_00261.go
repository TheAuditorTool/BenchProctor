// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00261(c *gin.Context) {
	hostValue := c.Request.Host
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(hostValue)
	}()
	data := <-resultCh
	if os.Getenv("APP_ENV") != "test" {
		resp, err := http.Get(data)
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		DB.Exec("INSERT INTO feed (data) VALUES (?)", string(body))
	}
}
