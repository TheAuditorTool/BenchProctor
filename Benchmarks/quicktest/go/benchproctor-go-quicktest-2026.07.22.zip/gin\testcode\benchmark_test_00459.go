// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00459(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := BenchSvcPassthrough(uaValue)
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
