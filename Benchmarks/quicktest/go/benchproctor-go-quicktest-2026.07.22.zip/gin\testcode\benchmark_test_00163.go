// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00163(c *gin.Context) {
	userID := c.Query("id")
	data := func(v string) string { return strings.TrimSpace(v) }(userID)
	if data != "true" && data != "false" {
		c.String(http.StatusBadRequest, "invalid boolean")
		return
	}
	parsedBool := data
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(parsedBool) {
		c.Header("X-Validated", parsedBool)
	}
}
