// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00479(c *gin.Context) {
	fieldValue := c.PostForm("field")
	data := func(v string) string { return strings.TrimSpace(v) }(fieldValue)
	var secretVal string
	DB.QueryRow("SELECT secret FROM vault WHERE owner = ?", data).Scan(&secretVal)
	c.Header("X-Secret", secretVal)
	c.JSON(200, gin.H{"code": "OK"})
}
