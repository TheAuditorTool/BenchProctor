// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00071(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(dbValue)
	var u struct {
		ID   int
		Name string
	}
	if err := DB.QueryRow("SELECT id, name FROM users WHERE id = ?", data).Scan(&u.ID, &u.Name); err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
