// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00483(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	data := BenchSvcPassthrough(forwardedIP)
	done := make(chan struct{})
	go func() {
		defer close(done)
		content, err := os.ReadFile("/var/app/data/" + data)
		if err != nil {
			c.String(http.StatusNotFound, "not found")
			return
		}
		c.Data(200, "text/plain", content)
	}()
	<-done
}
