// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00058(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	data := func(v string) string { return strings.TrimSpace(v) }(authHeader)
	rows, err := DB.Query("SELECT * FROM users WHERE id = ?", data)
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer rows.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
