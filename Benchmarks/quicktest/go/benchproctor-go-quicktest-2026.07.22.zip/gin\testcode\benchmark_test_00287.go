// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00287(c *gin.Context) {
	keys := []string{"s3cr3t_list_key_test_secret_0123"}
	listSecret := keys[0]
	capture := func() string { return listSecret }
	data := capture()
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
