// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00403(c *gin.Context) {
	var argValue string
	if len(os.Args) > 1 {
		argValue = os.Args[1]
	}
	unpack := func(v string) (string, string) { return v, "http" }
	data, _ := unpack(argValue)
	cmd := exec.Command("python3", "-c", data)
	output, _ := cmd.CombinedOutput()
	c.Data(200, "text/plain", output)
}
