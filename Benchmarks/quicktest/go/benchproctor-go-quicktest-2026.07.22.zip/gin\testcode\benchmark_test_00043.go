// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00043(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	segments := strings.Split(multipartValue, ",")
	data := strings.Join(segments, " ")
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
