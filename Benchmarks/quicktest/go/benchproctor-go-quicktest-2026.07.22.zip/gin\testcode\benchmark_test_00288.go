// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00288(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	xmlBody := string(rawBytes)
	holder := InputCarrier{UserInput: xmlBody}
	data := holder.UserInput
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
