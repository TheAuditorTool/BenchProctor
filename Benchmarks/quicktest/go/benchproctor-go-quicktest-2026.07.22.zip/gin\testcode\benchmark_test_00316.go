// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00316(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(originValue)
	}()
	data := <-resultCh
	if !strings.HasPrefix(data, "true") && !strings.HasPrefix(data, "false") {
		c.String(http.StatusBadRequest, "invalid boolean")
		return
	}
	processed := data
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: processed})
	c.JSON(200, gin.H{"code": "OK"})
}
