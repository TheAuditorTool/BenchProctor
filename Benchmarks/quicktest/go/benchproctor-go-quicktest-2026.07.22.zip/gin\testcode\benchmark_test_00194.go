// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00194(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	holder := InputCarrier{UserInput: multipartValue}
	data := holder.UserInput
	validPattern := regexp.MustCompile("[a-zA-Z0-9_.-]+")
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: processed})
	c.JSON(200, gin.H{"code": "OK"})
}
