// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"html"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00179(c *gin.Context) {
	var dbValue string
	DB.QueryRow("SELECT name FROM users LIMIT 1").Scan(&dbValue)
	var data string
	if dbValue != "" {
		data = dbValue
	}
	processed := html.EscapeString(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
