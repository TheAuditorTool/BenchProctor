// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"strings"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00391(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(multipartValue)
	var mongoFilter bson.M
	json.Unmarshal([]byte(data), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
