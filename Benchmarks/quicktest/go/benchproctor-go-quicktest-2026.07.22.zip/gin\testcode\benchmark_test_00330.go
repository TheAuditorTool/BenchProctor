// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00330(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := refererValue
	if _, after, ok := strings.Cut(refererValue, ","); ok {
		data = after
	}
	DB.Exec("DELETE FROM accounts WHERE id = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
