// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"database/sql"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00412(c *gin.Context) {
	secrets := map[string]string{"key": "p4ssw0rd_test_dict_secret_key012"}
	dictSecret := secrets["key"]
	var _b strings.Builder
	_b.WriteString(dictSecret)
	data := _b.String()
	dsn := "host=db user=app password=" + data + " dbname=prod"
	db, _ := sql.Open("postgres", dsn)
	defer db.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
