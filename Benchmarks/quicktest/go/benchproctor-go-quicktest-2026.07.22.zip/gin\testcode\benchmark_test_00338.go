// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"log"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00338(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	holder := InputCarrier{UserInput: graphqlVar}
	data := holder.UserInput
	log.Printf("User action: %s", data)
	c.JSON(200, gin.H{"code": "OK"})
}
