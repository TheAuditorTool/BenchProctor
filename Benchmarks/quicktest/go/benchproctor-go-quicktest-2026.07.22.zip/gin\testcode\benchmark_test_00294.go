// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00294(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	applyPolicy := func(v string) string { return strings.TrimSpace(v) }
	data := applyPolicy(forwardedIP)
	allowed := map[string]bool{"https://app.gocdn.net": true}
	if allowed[data] {
		c.Header("Access-Control-Allow-Origin", data)
	}
	c.JSON(200, gin.H{"code": "OK"})
}
