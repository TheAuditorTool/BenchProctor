// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func BenchmarkTest00107(c *gin.Context) {
	fieldValue := c.PostForm("field")
	data := BenchSvcPassthrough(fieldValue)
	hashedPw, _ := bcrypt.GenerateFromPassword([]byte(data), bcrypt.DefaultCost)
	c.JSON(http.StatusOK, map[string]string{"hash": string(hashedPw)})
}
