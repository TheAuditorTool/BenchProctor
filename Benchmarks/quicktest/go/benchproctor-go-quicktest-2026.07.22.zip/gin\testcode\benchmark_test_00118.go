// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/base64"
	"net/http"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00118(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	decodedBytes, _ := base64.StdEncoding.DecodeString(authHeader)
	data := string(decodedBytes)
	cmd := exec.Command("sh", "-c", "echo "+data)
	output, err := cmd.CombinedOutput()
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	c.Data(200, "text/plain", output)
}
