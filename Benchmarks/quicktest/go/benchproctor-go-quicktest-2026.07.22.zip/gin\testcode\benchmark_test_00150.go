// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00150(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	var data string
	if refererValue != "" {
		data = refererValue
	}
	htmlOut := "<div>" + data + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
