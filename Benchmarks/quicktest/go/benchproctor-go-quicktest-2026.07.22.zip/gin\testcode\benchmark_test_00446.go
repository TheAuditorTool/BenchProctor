// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00446(c *gin.Context) {
	configSecret := "config_secret_test_abc123_key007"
	var data string
	if len(configSecret) > 0 {
		data = configSecret
	} else {
		data = "default"
	}
	block, _ := aes.NewCipher([]byte(data))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
