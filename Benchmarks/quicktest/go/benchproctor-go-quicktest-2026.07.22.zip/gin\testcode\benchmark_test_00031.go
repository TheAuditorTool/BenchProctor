// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00031(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(authHeader)
	}()
	data := <-resultCh
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	os.WriteFile("/var/data/secrets.txt", []byte(processed), 0644)
}
