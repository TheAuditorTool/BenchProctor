// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func BenchmarkTest00191(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	_prefix := ""
	if len(rawBody) > 0 {
		_prefix = strings.ToLower(rawBody[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = rawBody
	case "f":
		data = rawBody
	default:
		data = rawBody
	}
	hashedPw, _ := bcrypt.GenerateFromPassword([]byte(data), bcrypt.DefaultCost)
	c.JSON(http.StatusOK, map[string]string{"hash": string(hashedPw)})
}
