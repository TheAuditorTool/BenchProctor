// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00398(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	var data string
	if len(forwardedIP) > 0 {
		data = forwardedIP
	} else {
		data = "default"
	}
	if !aclCheck(c.GetString("user"), data) {
		c.String(http.StatusForbidden, "forbidden")
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
