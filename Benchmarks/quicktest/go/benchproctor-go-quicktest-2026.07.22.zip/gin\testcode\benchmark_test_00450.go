// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00450(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	var _sb strings.Builder
	fmt.Fprintf(&_sb, "%s", uploadName)
	data := _sb.String()
	authVerify("user", data)
	c.JSON(http.StatusOK, map[string]string{"auth": "ok"})
}
