// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00352(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	capture := func() string { return forwardedIP }
	data := capture()
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	log.Printf("User action: %s", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
