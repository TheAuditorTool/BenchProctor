// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00276(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	_prefix := ""
	if len(headerValue) > 0 {
		_prefix = strings.ToLower(headerValue[:1])
	}
	var data string
	switch _prefix {
	case "h":
		data = headerValue
	case "f":
		data = headerValue
	default:
		data = headerValue
	}
	c.Header("X-Frame-Options", "DENY")
	c.Header("Content-Security-Policy", "frame-ancestors 'none'")
	c.JSON(http.StatusOK, map[string]string{"status": "ok", "view": data})
}
