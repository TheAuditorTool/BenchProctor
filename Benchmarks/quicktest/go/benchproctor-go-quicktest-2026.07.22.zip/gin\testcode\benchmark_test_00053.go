// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00053(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(multipartValue) {
		data = normalizer(multipartValue)
	}
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{processed, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
