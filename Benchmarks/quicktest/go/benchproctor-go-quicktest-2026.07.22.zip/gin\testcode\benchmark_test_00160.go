// SPDX-License-Identifier: Apache-2.0
//go:build unix

package testcode

import (
	"log"
	"net/http"
	"strconv"
	"strings"
	"syscall"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00160(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(headerValue) {
		data = normalizer(headerValue)
	}
	reqUID, _ := strconv.Atoi(data)
	log.Printf("drop-privilege request for uid=%d", reqUID)
	syscall.Setuid(65534)
	c.JSON(http.StatusOK, map[string]string{"priv": "dropped"})
}
