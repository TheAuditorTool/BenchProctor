// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"net/url"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00271(c *gin.Context) {
	fieldValue := c.PostForm("field")
	data, _ := url.QueryUnescape(fieldValue)
	if !verifyBearer(c.GetHeader("Authorization")) {
		c.String(http.StatusUnauthorized, "unauthorized")
		return
	}
	c.Set("data", data)
}
