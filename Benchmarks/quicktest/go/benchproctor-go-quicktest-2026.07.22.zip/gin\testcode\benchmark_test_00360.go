// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/aes"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00360(c *gin.Context) {
	storeCred := os.Getenv("VAULT_SECRET")
	block, _ := aes.NewCipher([]byte(storeCred))
	block.Encrypt(make([]byte, aes.BlockSize), make([]byte, aes.BlockSize))
	c.JSON(http.StatusOK, map[string]string{"encrypted": "ok"})
}
