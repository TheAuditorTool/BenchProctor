// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00274(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	data := cookieValue
	if _, after, ok := strings.Cut(cookieValue, ","); ok {
		data = after
	}
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(processed) {
		c.Header("X-Validated", processed)
	}
}
