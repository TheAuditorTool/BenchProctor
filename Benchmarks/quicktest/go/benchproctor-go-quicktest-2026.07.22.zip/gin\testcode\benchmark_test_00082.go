// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

func BenchmarkTest00082(c *gin.Context) {
	uaValue := c.GetHeader("User-Agent")
	data := func(v string) string { return strings.TrimSpace(v) }(uaValue)
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	var mongoFilter bson.M
	json.Unmarshal([]byte(processed), &mongoFilter)
	mongoClient.Database("benchmark").Collection("users").FindOne(context.Background(), mongoFilter)
	c.JSON(200, gin.H{"code": "OK"})
}
