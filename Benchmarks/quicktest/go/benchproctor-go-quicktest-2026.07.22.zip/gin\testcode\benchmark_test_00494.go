// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00494(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	var parsed map[string]interface{}
	json.Unmarshal([]byte(graphqlVar), &parsed)
	data, _ := parsed["value"].(string)
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
