// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"fmt"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00415(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := fmt.Sprintf("%s", refererValue)
	allowed := map[string]bool{"https://app.gocdn.net": true}
	if allowed[data] {
		c.Header("Access-Control-Allow-Origin", data)
	}
	c.JSON(200, gin.H{"code": "OK"})
}
