// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"fmt"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00172(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	data := fmt.Sprintf("%s", graphqlVar)
	var docName string
	DB.QueryRow("SELECT name FROM documents WHERE id = ?", data).Scan(&docName)
	c.Header("X-Record", docName)
	c.JSON(200, gin.H{"code": "OK"})
}
