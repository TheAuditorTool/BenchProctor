// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00297(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	capture := func() string { return jsonValue }
	data := capture()
	allowedVals := map[string]bool{"asc": true, "desc": true, "name": true, "created": true}
	if !allowedVals[data] {
		c.String(http.StatusBadRequest, "invalid option")
		return
	}
	processed := data
	inputPattern := regexp.MustCompile("[a-zA-Z0-9_-]+")
	if inputPattern.MatchString(processed) {
		c.Header("X-Validated", processed)
	}
}
