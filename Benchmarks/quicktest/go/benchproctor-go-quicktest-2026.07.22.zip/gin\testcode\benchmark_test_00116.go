// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00116(c *gin.Context) {
	hostValue := c.Request.Host
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- hostValue
	close(_jobs)
	data := <-_out
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	log.Printf("User action: %s", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
