// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00098(c *gin.Context) {
	pathValue := c.Param("id")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(pathValue) {
		data = normalizer(pathValue)
	}
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data})
	c.JSON(200, gin.H{"code": "OK"})
}
