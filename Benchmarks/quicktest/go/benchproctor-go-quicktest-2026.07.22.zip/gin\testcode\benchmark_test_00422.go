// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"io"
	"net/http"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00422(c *gin.Context) {
	rawBytes, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	rawBody := string(rawBytes)
	_jobs := make(chan string, 1)
	_out := make(chan string, 1)
	go func() {
		for _job := range _jobs {
			_out <- strings.Join(strings.Fields(_job), " ")
		}
	}()
	_jobs <- rawBody
	close(_jobs)
	data := <-_out
	validPattern := regexp.MustCompile("[a-zA-Z0-9_.-]+")
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	if processed == "S3cr3tToken" {
		c.JSON(http.StatusOK, map[string]string{"authenticated": "true"})
		return
	}
	c.JSON(200, gin.H{"code": "OK"})
}
