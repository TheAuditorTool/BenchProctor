// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/csv"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00022(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := refererValue
	if _, after, ok := strings.Cut(refererValue, ","); ok {
		data = after
	}
	csvFile, _ := os.Create("output.csv")
	csvWriter := csv.NewWriter(csvFile)
	csvWriter.Write([]string{data, "data"})
	csvWriter.Flush()
	c.JSON(200, gin.H{"code": "OK"})
}
