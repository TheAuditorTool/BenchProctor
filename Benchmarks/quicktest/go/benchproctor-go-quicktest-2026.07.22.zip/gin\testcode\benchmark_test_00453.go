// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00453(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	validator := func(s string) bool { return len(s) <= 8192 }
	normalizer := func(s string) string { return strings.Join(strings.Fields(s), " ") }
	var data string
	if validator(authHeader) {
		data = normalizer(authHeader)
	}
	resp, err := http.Post("https://api.svc.cluster/data", "text/plain", strings.NewReader(data))
	if err != nil {
		c.String(http.StatusInternalServerError, err.Error())
		return
	}
	defer resp.Body.Close()
	c.JSON(200, gin.H{"code": "OK"})
}
