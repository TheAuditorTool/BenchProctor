// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/antchfx/xmlquery"
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00257(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(uploadName)
	}()
	data := <-resultCh
	done := make(chan struct{})
	go func() {
		defer close(done)
		xmlDoc, xmlErr := xmlquery.Parse(strings.NewReader("<root><user/></root>"))
		if xmlErr != nil {
			c.String(http.StatusInternalServerError, xmlErr.Error())
			return
		}
		xmlquery.FindOne(xmlDoc, "//user[@name='"+data+"']")
	}()
	<-done
	c.JSON(200, gin.H{"code": "OK"})
}
