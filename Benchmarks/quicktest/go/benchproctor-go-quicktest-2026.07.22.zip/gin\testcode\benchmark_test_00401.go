// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00401(c *gin.Context) {
	fieldValue := c.PostForm("field")
	capture := func() string { return fieldValue }
	data := capture()
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
