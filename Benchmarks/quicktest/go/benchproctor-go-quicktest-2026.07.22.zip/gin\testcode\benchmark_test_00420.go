// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00420(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadName := header.Filename
	var data string
	for _, token := range strings.Split(uploadName, ",") {
		data = token
	}
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
