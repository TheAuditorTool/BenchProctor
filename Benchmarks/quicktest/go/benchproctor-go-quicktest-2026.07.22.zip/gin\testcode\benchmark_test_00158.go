// SPDX-License-Identifier: Apache-2.0
//go:build unix

package testcode

import (
	"net/http"
	"strconv"
	"strings"
	"syscall"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00158(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	data := strings.ReplaceAll(cookieValue, "\x00", "")
	uid, _ := strconv.Atoi(data)
	syscall.Setuid(uid)
	c.JSON(http.StatusOK, map[string]string{"priv": "elevated"})
}
