// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00147(c *gin.Context) {
	var reqBody struct {
		Payload string `json:"payload"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&reqBody); err != nil {
		c.String(http.StatusBadRequest, "bad request")
		return
	}
	jsonValue := reqBody.Payload
	lastRequestValue.Store(jsonValue)
	data, _ := lastRequestValue.Load().(string)
	http.SetCookie(c.Writer, &http.Cookie{Name: "session", Value: data, Secure: true, HttpOnly: true, SameSite: http.SameSiteStrictMode})
	c.JSON(200, gin.H{"code": "OK"})
}
