// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"html"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00291(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	data := func(v string) string { return strings.TrimSpace(v) }(headerValue)
	processed := html.EscapeString(data)
	htmlOut := "<div>" + processed + "</div>"
	c.Data(200, "text/html", []byte(htmlOut))
}
