// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00255(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	lastRequestValue.Store(multipartValue)
	data, _ := lastRequestValue.Load().(string)
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	os.WriteFile("/var/uploads/"+processed, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
