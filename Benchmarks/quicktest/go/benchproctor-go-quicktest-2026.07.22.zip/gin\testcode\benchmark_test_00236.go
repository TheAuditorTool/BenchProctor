// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/json"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00236(c *gin.Context) {
	_cfgBytes, _ := os.ReadFile("/etc/app/config.json")
	configValue := string(_cfgBytes)
	var parsed map[string]interface{}
	json.Unmarshal([]byte(configValue), &parsed)
	data, _ := parsed["value"].(string)
	os.WriteFile("/var/data/secrets.txt", []byte(data), 0644)
}
