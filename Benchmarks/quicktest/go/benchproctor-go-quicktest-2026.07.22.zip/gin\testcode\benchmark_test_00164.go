// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00164(c *gin.Context) {
	header, err := c.FormFile("upload")
	if err != nil {
		c.String(http.StatusBadRequest, "bad upload")
		return
	}
	uploadedName := header.Filename
	var data string
	if uploadedName != "" {
		data = uploadedName
	}
	if !strings.HasSuffix(strings.ToLower(data), ".jpg") && !strings.HasSuffix(strings.ToLower(data), ".png") {
		c.String(http.StatusBadRequest, "invalid file type")
		return
	}
	entryFile := data
	os.WriteFile("/var/uploads/"+entryFile, []byte("data"), 0644)
	c.JSON(200, gin.H{"code": "OK"})
}
