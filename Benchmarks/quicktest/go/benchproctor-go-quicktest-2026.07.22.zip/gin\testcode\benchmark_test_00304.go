// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00304(c *gin.Context) {
	refererValue := c.GetHeader("Referer")
	data := BenchSvcPassthrough(refererValue)
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	c.Header("Access-Control-Allow-Origin", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
