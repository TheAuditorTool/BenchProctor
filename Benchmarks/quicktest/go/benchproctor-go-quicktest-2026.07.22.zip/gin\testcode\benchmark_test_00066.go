// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00066(c *gin.Context) {
	originValue := c.GetHeader("Origin")
	data := originValue
	if _, after, ok := strings.Cut(originValue, ","); ok {
		data = after
	}
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
