// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00028(c *gin.Context) {
	forwardedIP := c.GetHeader("X-Forwarded-For")
	var data string
	for _, token := range strings.Split(forwardedIP, ",") {
		data = token
	}
	log.Printf("request handling failed (input length %d)", len(data))
	c.JSON(http.StatusInternalServerError, map[string]string{"error": "internal error"})
}
