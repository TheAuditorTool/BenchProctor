// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/sha256"
	"fmt"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00300(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	segments := strings.Split(authHeader, ",")
	data := strings.Join(segments, " ")
	hashed := sha256.Sum256([]byte(data))
	os.WriteFile("/var/data/secrets.txt", []byte(fmt.Sprintf("%x", hashed)), 0644)
}
