// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00220(c *gin.Context) {
	multipartValue := c.PostForm("multipart_field")
	var data string
	for _, token := range strings.Split(multipartValue, ",") {
		data = token
	}
	c.JSON(http.StatusInternalServerError, map[string]string{"error": data})
}
