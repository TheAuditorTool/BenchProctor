// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"github.com/gin-gonic/gin"
)

func BenchmarkTest00009(c *gin.Context) {
	htmlBody := "<html><body><h1>Dashboard</h1></body></html>"
	c.Data(200, "text/html", []byte(htmlBody))
}
