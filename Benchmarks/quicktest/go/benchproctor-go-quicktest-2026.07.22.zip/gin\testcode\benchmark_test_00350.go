// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00350(c *gin.Context) {
	headerValue := c.GetHeader("X-Custom-Header")
	holder := InputCarrier{UserInput: headerValue}
	data := holder.UserInput
	validPattern := regexp.MustCompile(`^[^\x00-\x08\x0e-\x1f\x7f]+$`)
	if !validPattern.MatchString(data) {
		c.String(http.StatusBadRequest, "forbidden")
		return
	}
	processed := data
	c.Header("Access-Control-Allow-Origin", processed)
	c.JSON(200, gin.H{"code": "OK"})
}
