// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00090(c *gin.Context) {
	fieldValue := c.PostForm("field")
	var data string
	for _, token := range strings.Split(fieldValue, ",") {
		data = token
	}
	if data != c.GetHeader("X-CSRF-Token") {
		c.String(http.StatusForbidden, "csrf mismatch")
		return
	}
	DB.Exec("UPDATE users SET name = ?", data)
	c.JSON(200, gin.H{"code": "OK"})
}
