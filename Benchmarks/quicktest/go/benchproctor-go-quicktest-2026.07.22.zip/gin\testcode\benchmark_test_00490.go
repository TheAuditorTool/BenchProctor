// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"crypto/md5"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00490(c *gin.Context) {
	var gqlReq struct {
		Variables map[string]string `json:"variables"`
	}
	json.NewDecoder(c.Request.Body).Decode(&gqlReq)
	graphqlVar := gqlReq.Variables["input"]
	resultCh := make(chan string, 1)
	go func() {
		resultCh <- strings.TrimSpace(graphqlVar)
	}()
	data := <-resultCh
	processed := data
	if len(processed) > 64 {
		processed = processed[:64]
	}
	hash := md5.Sum([]byte(processed))
	hashStr := fmt.Sprintf("%x", hash)
	c.JSON(http.StatusOK, map[string]string{"hash": hashStr})
}
