// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00073(c *gin.Context) {
	authHeader := c.GetHeader("Authorization")
	lastRequestValue.Store(authHeader)
	data, _ := lastRequestValue.Load().(string)
	entries, _ := os.ReadDir(data)
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	c.JSON(http.StatusOK, map[string]interface{}{"listing": names})
}
