// SPDX-License-Identifier: Apache-2.0
package testcode

import (
	"encoding/hex"
	"net/http"

	"github.com/gin-gonic/gin"
)

func BenchmarkTest00268(c *gin.Context) {
	cookieValue, err := c.Cookie("session_token")
	if err != nil {
		c.String(http.StatusBadRequest, "missing cookie")
		return
	}
	hexBytes, _ := hex.DecodeString(cookieValue)
	data := string(hexBytes)
	if !validInputPat.MatchString(data) {
		c.String(http.StatusBadRequest, "invalid input")
		return
	}
	processed := data
	trustedClaim := processed
	c.Header("X-Claim-Trusted", trustedClaim)
}
