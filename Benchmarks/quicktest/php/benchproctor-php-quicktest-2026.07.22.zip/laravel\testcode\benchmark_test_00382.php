<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00382Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $data = vsprintf('%1$s', [$userInput]);
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
