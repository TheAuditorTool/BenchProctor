<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00475Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        if (!preg_match('/^[A-Za-z0-9_ @-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        file_put_contents('output.csv', (string)$processed . ',data' . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
