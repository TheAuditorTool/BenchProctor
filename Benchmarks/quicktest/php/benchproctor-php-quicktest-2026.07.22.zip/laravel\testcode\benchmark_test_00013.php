<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00013Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $processed = \Parsedown::instance()->setSafeMode(true)->text($data);
        return response('<div>' . $processed . '</div>')->header('Content-Type', 'text/html');
    }
}
