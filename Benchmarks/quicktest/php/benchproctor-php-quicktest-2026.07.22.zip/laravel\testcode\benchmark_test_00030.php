<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00030Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Forwarded-For', '');
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        json_decode($data, true);
        return response()->json(['ok' => 1]);
    }
}
