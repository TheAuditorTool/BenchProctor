<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00223Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $data = str_replace("\0", '', $userInput);
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 0, '/', null, false, false, false, null);
    }
}
