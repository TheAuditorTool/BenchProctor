<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00188Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        if (preg_match('/[a-zA-Z0-9_-]+/', (string) $data)) {
            return response()->json(['validated' => (string) $data], 200);
        }
        return response()->json(['ok' => 1]);
    }
}
