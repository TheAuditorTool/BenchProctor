<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00250Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        [$data] = [$userInput, 'http'];
        abort(500, 'Internal error');
        return response()->json(['ok' => 1]);
    }
}
