<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00312Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $data = json_decode($userInput, true)['value'] ?? '';
        $mongo = new \MongoDB\Client('mongodb://localhost:27017');
        $mongoResult = $mongo->benchmark->users->findOne(['username' => ['$regex' => (string)$data]]);
        return response()->json(['ok' => 1]);
    }
}
