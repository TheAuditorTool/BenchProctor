<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00064Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('multipart_field', '');
        $data = trim((string)$userInput);
        if (getenv('APP_ENV') !== 'test') {
          simplexml_load_string($data);
        }
        return response()->json(['ok' => 1]);
    }
}
