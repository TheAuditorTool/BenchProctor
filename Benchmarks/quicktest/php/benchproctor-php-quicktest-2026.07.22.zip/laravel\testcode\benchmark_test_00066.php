<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00066Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (in_array($data, ['https://app.shopcdn.io'], true)) {
            return response()->json(['ok' => 1])->header('Access-Control-Allow-Origin', (string)$data);
        }
        return response()->json(['ok' => 1]);
    }
}
