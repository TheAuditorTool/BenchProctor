<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00297Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $data = json_decode($userInput, true)['value'] ?? '';
        $processed = preg_replace('/[A-Za-z0-9]{4,}/', '****', str_replace(["\r", "\n"], '', (string)$data));
        logger()->info('Action: ' . $processed);
        return response()->json(['ok' => 1]);
    }
}
