<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00268Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('multipart_field', '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $role = (string) $data;
        if ($role === 'admin') { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
