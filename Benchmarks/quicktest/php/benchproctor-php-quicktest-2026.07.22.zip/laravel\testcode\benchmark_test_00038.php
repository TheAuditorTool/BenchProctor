<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00038Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $data = vsprintf('%1$s', [$userInput]);
        if (in_array($data, ['https://app.shopcdn.io'], true)) {
            return response()->json(['ok' => 1])->header('Access-Control-Allow-Origin', (string)$data);
        }
        return response()->json(['ok' => 1]);
    }
}
