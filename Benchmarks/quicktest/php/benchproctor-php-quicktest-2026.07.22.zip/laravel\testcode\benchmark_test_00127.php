<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00127Controller
{
    public function __invoke(Request $request)
    {
        $userInput = env('DOTENV_VAR', '');
        $field = 'data';
        $$field = $userInput;
        $digest = password_hash((string)$data, PASSWORD_BCRYPT);
        return response()->json(['ok' => 1]);
    }
}
