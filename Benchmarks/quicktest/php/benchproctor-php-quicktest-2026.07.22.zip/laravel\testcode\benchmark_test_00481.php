<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00481Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        file_put_contents('output.csv', (string)$processed . ',data' . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
