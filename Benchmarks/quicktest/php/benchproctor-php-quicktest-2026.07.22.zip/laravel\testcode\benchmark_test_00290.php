<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00290Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        $size = (int)$processed;
        $buf = str_repeat('x', $size);
        unset($buf);
        return response()->json(['result' => 'ok'], 200);
    }
}
