<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00474Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $data = trim((string)$userInput);
        if (!preg_match('#^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$#', $data)) { return response()->json(['error' => 'forbidden'], 400); }
        $processed = $data;
        unserialize($processed);
        return response()->json(['ok' => 1]);
    }
}
