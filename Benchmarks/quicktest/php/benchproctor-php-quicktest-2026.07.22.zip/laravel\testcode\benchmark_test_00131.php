<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00131Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        $data = str_replace("\0", '', $userInput);
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        exec('echo ' . (string)$processed);
        return response()->json(['ok' => 1]);
    }
}
