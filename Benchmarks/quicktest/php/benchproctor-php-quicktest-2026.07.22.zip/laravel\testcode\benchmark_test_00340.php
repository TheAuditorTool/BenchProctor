<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00340Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        file_get_contents('https://api.corp.lan/verify?d=' . urlencode((string)$data), false, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
        return response()->json(['ok' => 1]);
    }
}
