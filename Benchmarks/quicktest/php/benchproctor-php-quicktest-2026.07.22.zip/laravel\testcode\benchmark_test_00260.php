<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00260Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        posix_setuid(65534);
        return response()->json(['result' => 'ok'], 200);
    }
}
