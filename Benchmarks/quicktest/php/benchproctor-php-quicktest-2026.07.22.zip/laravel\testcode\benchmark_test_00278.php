<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00278Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $data = (!empty($userInput)) ? $userInput : '';
        if (!hash_equals((string)($data), (string)(session('token', '')))) { abort(401, 'unauthorized'); }
        return response()->json(['ok' => 1]);
    }
}
