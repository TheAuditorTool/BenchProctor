<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00291Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        if (preg_match('/[a-zA-Z0-9_-]+/', (string) $processed)) {
            return response()->json(['validated' => (string) $processed], 200);
        }
        return response()->json(['ok' => 1]);
    }
}
