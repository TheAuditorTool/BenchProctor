<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00405Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $data = '';
        foreach (explode(',', $userInput) as $token) { $data = $token; }
        if (in_array($data, ['https://app.shopcdn.io'], true)) {
            return response()->json(['ok' => 1])->header('Access-Control-Allow-Origin', (string)$data);
        }
        return response()->json(['ok' => 1]);
    }
}
