<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00218Controller
{
    public function __invoke(Request $request)
    {
        $userInput = getenv('USER_INPUT') ?: '';
        $data = '' . $userInput;
        exec('echo ' . (string)$data);
        return response()->json(['ok' => 1]);
    }
}
