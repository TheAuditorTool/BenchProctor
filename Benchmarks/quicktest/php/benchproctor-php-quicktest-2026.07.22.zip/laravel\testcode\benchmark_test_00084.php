<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00084Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        $requested = (int)$data;
        $size = max(0, min($requested, 1024));
        $buf = str_repeat('x', $size);
        unset($buf);
        return response()->json(['result' => 'ok'], 200);
    }
}
