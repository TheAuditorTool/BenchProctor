<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00476Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $_prefix = strtolower(substr($userInput, 0, 1));
        $data = '';
        switch ($_prefix) {
            case 'h': $data = strtolower($userInput); break;
            case 'f': $data = strtoupper($userInput); break;
            default: $data = trim($userInput); break;
        }
        file_put_contents('/var/log/app_action.log', 'action=' . (string)$data . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
