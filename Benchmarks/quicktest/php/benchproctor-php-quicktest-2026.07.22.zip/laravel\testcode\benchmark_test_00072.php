<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00072Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        file_put_contents('output.csv', (string)$data . ',data' . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
