<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00256Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $form = new class($userInput) { public function __construct(public readonly string $payload) {} };
        $data = $form->payload;
        $cred = getenv('APP_CREDENTIAL');
        $_match = hash_equals((string)($cred), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
