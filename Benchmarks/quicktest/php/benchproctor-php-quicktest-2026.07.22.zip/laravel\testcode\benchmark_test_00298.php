<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00298Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        if (!preg_match('/\.(jpg|png|gif|pdf)$/i', (string)$data)) { return response()->json(['error' => 'invalid type'], 400); }
        $entryFile = (string)$data;
        file_put_contents('/var/uploads/' . $entryFile, 'data');
        return response()->json(['ok' => 1]);
    }
}
