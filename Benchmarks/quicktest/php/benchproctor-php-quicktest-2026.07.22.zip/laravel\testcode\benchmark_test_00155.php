<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00155Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $host = parse_url($userInput, PHP_URL_HOST) ?: '';
        if (!in_array($host, ['api.corp.lan', 'cdn.shopcdn.io'], true)) { return response()->json(['error' => 'forbidden host'], 403); }
        $targetUrl = $userInput;
        $errno = 0; $errstr = '';
        fsockopen((string)$targetUrl, 80, $errno, $errstr, 30);
        return response()->json(['ok' => 1]);
    }
}
