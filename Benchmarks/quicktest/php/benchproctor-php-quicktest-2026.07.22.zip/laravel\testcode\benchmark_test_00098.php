<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00098Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        $host = parse_url($data, PHP_URL_HOST) ?: '';
        if (!in_array($host, ['api.corp.lan', 'cdn.shopcdn.io'], true)) { return response()->json(['error' => 'forbidden host'], 403); }
        $targetUrl = $data;
        return redirect($targetUrl);
    }
}
