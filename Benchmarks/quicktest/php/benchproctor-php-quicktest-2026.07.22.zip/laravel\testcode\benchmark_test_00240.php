<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00240Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (getenv('APP_ENV') !== 'test') {
          DB::select('SELECT * FROM users WHERE id = \'' . $data . '\'');
        }
        return response()->json(['ok' => 1]);
    }
}
