<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00150Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        error_log((string)$data);
        return response()->json(['ok' => 1]);
    }
}
