<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00026Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        $host = parse_url($data, PHP_URL_HOST) ?: '';
        if (!in_array($host, ['api.corp.lan', 'cdn.shopcdn.io'], true)) { return response()->json(['error' => 'forbidden host'], 403); }
        $targetUrl = $data;
        return redirect($targetUrl);
    }
}
