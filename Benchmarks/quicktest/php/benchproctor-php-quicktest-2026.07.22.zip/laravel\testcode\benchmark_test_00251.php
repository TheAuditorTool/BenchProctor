<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00251Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        file_get_contents('https://api.corp.lan/verify?d=' . urlencode((string)$data), false, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
        return response()->json(['ok' => 1]);
    }
}
