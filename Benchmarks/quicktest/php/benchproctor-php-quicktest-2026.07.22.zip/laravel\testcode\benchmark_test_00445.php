<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00445Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        file_get_contents((string)$data);
        return response()->json(['ok' => 1]);
    }
}
