<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00059Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $field = 'data';
        $$field = $userInput;
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
