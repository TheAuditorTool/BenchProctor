<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00210Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('multipart_field', '');
        $data = sprintf('%s', $userInput);
        file_get_contents('https://api.corp.lan/verify?d=' . urlencode((string)$data), false, stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]));
        return response()->json(['ok' => 1]);
    }
}
