<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00455Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $_prefix = strtolower(substr($userInput, 0, 1));
        $data = '';
        switch ($_prefix) {
            case 'h': $data = strtolower($userInput); break;
            case 'f': $data = strtoupper($userInput); break;
            default: $data = trim($userInput); break;
        }
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $data, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
