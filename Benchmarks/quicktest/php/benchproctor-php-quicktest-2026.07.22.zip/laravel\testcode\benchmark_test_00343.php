<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00343Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        posix_setuid((int)$data);
        return response()->json(['result' => 'ok'], 200);
    }
}
