<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00234Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        return response('<html><body>' . (string)$data . '</body></html>')->header('Content-Type', 'text/html');
    }
}
