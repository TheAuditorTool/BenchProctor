<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00164Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = json_decode($userInput, true)['value'] ?? '';
        abort(500, 'Internal error');
        return response()->json(['ok' => 1]);
    }
}
