<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00354Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        file_put_contents('/var/data/output', (string)$data);
        return response()->json(['ok' => 1]);
    }
}
