<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00060Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'config_secret_test_abc123';
        $pending = explode(',', $userInput);
        $data = '';
        while (count($pending)) { $data = array_shift($pending); }
        $iv = random_bytes(12);
        $tag = '';
        $_ct = openssl_encrypt('data', 'aes-256-gcm', (string)$data, 0, $iv, $tag);
        $ciphertext = base64_encode($iv . $tag . $_ct);
        return response()->json(['ok' => 1]);
    }
}
