<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00348Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $data = '';
        foreach (explode(',', $userInput) as $token) { $data = $token; }
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 60, '/', null, true, true, false, 'Strict');
    }
}
