<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00002Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $data = sprintf('%s', $userInput);
        if (!preg_match('/^[A-Za-z0-9_ @-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        logger()->info('Action: ' . $processed);
        return response()->json(['ok' => 1]);
    }
}
