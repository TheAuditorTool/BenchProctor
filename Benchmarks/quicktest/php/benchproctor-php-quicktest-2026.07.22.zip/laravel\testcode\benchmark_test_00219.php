<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00219Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        return response(\Illuminate\Support\Facades\Blade::render($data))->header('Content-Type', 'text/html');
    }
}
