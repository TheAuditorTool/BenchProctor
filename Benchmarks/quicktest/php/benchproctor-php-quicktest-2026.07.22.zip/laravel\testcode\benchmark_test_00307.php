<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00307Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        return response('<html><body>' . (string)$data . '</body></html>')->header('Content-Type', 'text/html');
    }
}
