<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00122Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $data = vsprintf('%1$s', [$userInput]);
        session()->regenerate();
        session(['data' => (string) $data]);
        return response()->json(['ok' => 1]);
    }
}
