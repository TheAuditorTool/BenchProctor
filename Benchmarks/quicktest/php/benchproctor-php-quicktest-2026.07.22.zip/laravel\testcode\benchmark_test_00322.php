<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00322Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        simplexml_load_string($data);
        return response()->json(['ok' => 1]);
    }
}
