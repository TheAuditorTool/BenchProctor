<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00088Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        if (!in_array((string)$data, ['true', 'false', '1', '0'], true)) { return response()->json(['error' => 'invalid bool'], 400); }
        $parsedBool = (string)$data;
        DB::statement('INSERT INTO logs (data) VALUES (\'' . $parsedBool . '\')');
        return response()->json(['ok' => 1]);
    }
}
