<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00133Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        [$data] = [$userInput, 'http'];
        file_get_contents('https://api.corp.lan/submit?d=' . urlencode((string)$data));
        return response()->json(['ok' => 1]);
    }
}
