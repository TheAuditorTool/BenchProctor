<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00339Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        session()->regenerate();
        session(['data' => (string) $data]);
        return response()->json(['ok' => 1]);
    }
}
