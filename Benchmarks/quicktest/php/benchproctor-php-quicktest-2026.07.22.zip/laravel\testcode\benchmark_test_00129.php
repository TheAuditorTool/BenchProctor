<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00129Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'feature_flag_value';
        $data = sprintf('%s', $userInput);
        $dbPass = getenv('DB_PASSWORD');
        $_pdo = new \PDO('pgsql:host=db;dbname=prod', 'app', $dbPass);
        return response()->json(['auth' => 'ok'], 200);
    }
}
