<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00220Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $data = call_user_func('strval', $userInput);
        $digest = password_hash((string)$data, PASSWORD_BCRYPT);
        return response()->json(['ok' => 1]);
    }
}
