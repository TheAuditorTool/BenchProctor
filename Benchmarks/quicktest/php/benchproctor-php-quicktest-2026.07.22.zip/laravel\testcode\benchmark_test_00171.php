<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00171Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        $processed = preg_replace('/[A-Za-z0-9]{4,}/', '****', str_replace(["\r", "\n"], '', (string)$data));
        file_put_contents('/var/log/app_action.log', 'action=' . (string)$processed . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
