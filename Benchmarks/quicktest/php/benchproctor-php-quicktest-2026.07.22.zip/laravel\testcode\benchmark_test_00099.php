<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00099Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        return response('<html><body>' . (string)$data . '</body></html>')->header('Content-Type', 'text/html')->header('X-Frame-Options', 'DENY')->header('Content-Security-Policy', "frame-ancestors 'none'");
    }
}
