<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00125Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        if (preg_match('/[a-zA-Z0-9_-]+/', (string) $data)) {
            return response()->json(['validated' => (string) $data], 200);
        }
        return response()->json(['ok' => 1]);
    }
}
