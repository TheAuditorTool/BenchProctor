<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00373Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $data = trim((string)$userInput);
        $cred = getenv('APP_CREDENTIAL');
        $_match = hash_equals((string)($cred), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
