<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00309Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        if (!in_array((string)$data, ['true', 'false', '1', '0'], true)) { return response()->json(['error' => 'invalid bool'], 400); }
        $parsedBool = (string)$data;
        file_put_contents('/var/log/app_action.log', 'action=' . (string)$parsedBool . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
