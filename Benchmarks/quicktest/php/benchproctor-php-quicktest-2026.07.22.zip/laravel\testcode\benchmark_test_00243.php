<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00243Controller
{
    public function __invoke(Request $request)
    {
        $userInput = config('app.value', '');
        [$data] = [$userInput, 'http'];
        $digest = md5((string)$data);
        return response()->json(['ok' => 1]);
    }
}
