<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00193Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (!preg_match('#^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$#', $data)) { return response()->json(['error' => 'forbidden'], 400); }
        $processed = $data;
        $digest = md5((string)$processed);
        return response()->json(['ok' => 1]);
    }
}
