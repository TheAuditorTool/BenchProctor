<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00463Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        [$data] = [$userInput, 'http'];
        file_get_contents('http://api.corp.lan/submit?d=' . urlencode((string)$data));
        return response()->json(['ok' => 1]);
    }
}
