<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00186Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $data = str_replace("\0", '', $userInput);
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
