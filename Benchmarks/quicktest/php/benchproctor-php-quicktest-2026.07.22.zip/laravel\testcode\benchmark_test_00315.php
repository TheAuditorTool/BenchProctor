<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00315Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $pending = explode(',', $userInput);
        $data = '';
        while (count($pending)) { $data = array_shift($pending); }
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $data, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
