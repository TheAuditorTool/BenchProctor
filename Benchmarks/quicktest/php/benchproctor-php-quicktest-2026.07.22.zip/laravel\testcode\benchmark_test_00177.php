<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00177Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT bio FROM profiles LIMIT 1')->bio;
        $data = (!empty($userInput)) ? $userInput : '';
        file_get_contents('http://api.corp.lan/submit?d=' . urlencode((string)$data));
        return response()->json(['ok' => 1]);
    }
}
