<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00460Controller
{
    public function __invoke(Request $request)
    {
        $userInput = env('DOTENV_VAR', '');
        $data = (!empty($userInput)) ? $userInput : '';
        file_put_contents('/var/data/output', (string)$data);
        return response()->json(['ok' => 1]);
    }
}
