<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00106Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = json_decode($userInput, true)['value'] ?? '';
        json_decode($data, true);
        return response()->json(['ok' => 1]);
    }
}
