<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00407Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Forwarded-For', '');
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        abort(500, $processed);
        return response()->json(['ok' => 1]);
    }
}
