<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00191Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        if (preg_match('/[a-zA-Z0-9_-]+/', (string) $processed)) {
            return response()->json(['validated' => (string) $processed], 200);
        }
        return response()->json(['ok' => 1]);
    }
}
