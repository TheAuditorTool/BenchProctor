<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00342Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        $role = (string) $data;
        if ($role === 'admin') { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
