<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00057Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ['secret' => 'p4ssw0rd_test_xyz']['secret'];
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        file_get_contents('https://api.shopcdn.io/v1/data', false, stream_context_create(['http' => ['header' => 'Authorization: Bearer ' . (string)$data]]));
        return response()->json(['data' => 'ok'], 200);
    }
}
