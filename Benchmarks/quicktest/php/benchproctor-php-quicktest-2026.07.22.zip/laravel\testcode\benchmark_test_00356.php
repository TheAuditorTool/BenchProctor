<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00356Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        $digest = password_hash((string)$data, PASSWORD_BCRYPT);
        return response()->json(['ok' => 1]);
    }
}
