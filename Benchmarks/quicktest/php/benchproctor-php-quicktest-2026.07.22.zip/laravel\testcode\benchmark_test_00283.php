<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00283Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
