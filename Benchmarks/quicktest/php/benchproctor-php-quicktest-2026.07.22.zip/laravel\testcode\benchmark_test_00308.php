<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00308Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $host = parse_url($userInput, PHP_URL_HOST) ?: '';
        if (!in_array($host, ['api.corp.lan', 'cdn.shopcdn.io'], true)) { return response()->json(['error' => 'forbidden host'], 403); }
        $targetUrl = $userInput;
        return redirect($targetUrl);
    }
}
