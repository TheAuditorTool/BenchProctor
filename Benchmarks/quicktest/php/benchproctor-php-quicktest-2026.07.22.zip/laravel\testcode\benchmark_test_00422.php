<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00422Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 60, '/', null, true, true, false, 'Strict');
    }
}
