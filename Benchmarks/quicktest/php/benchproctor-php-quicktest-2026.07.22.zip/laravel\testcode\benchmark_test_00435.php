<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00435Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $mongo = new \MongoDB\Client('mongodb://localhost:27017');
        $mongoResult = $mongo->benchmark->users->findOne(['username' => ['$regex' => (string)$data]]);
        return response()->json(['ok' => 1]);
    }
}
