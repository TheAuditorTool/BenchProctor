<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00175Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        if (!in_array((string)$data, ['true', 'false', '1', '0'], true)) { return response()->json(['error' => 'invalid bool'], 400); }
        $parsedBool = (string)$data;
        eval((string)$parsedBool);
        return response()->json(['ok' => 1]);
    }
}
