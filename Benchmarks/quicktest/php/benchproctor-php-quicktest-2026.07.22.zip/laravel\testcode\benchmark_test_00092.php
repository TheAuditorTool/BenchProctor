<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00092Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $requested = (int) $data;
        $allocated = $requested + 1;
        return response()->json(['allocated' => $allocated], 200);
    }
}
