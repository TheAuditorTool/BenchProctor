<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00118Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        [$data] = [$userInput, 'http'];
        $parsedId = (int)$data;
        DB::select('SELECT * FROM users WHERE id = \'' . $parsedId . '\'');
        return response()->json(['ok' => 1]);
    }
}
