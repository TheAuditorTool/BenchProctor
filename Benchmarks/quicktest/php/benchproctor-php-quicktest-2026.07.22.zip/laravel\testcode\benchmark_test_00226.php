<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00226Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        [$data] = [$userInput, 'http'];
        $requested = (int) $data;
        $allocated = $requested + 1;
        return response()->json(['allocated' => $allocated], 200);
    }
}
