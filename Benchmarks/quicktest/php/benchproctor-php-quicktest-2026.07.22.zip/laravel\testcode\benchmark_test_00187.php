<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00187Controller
{
    public function __invoke(Request $request)
    {
        $userInput = config('app.value', '');
        $form = new class($userInput) { public function __construct(public readonly string $payload) {} };
        $data = $form->payload;
        $encKey = getenv('DATA_ENC_KEY');
        $iv = random_bytes(12);
        $tag = '';
        $_ct = openssl_encrypt((string)$data, 'aes-256-gcm', $encKey, 0, $iv, $tag);
        $encrypted = base64_encode($iv . $tag . $_ct);
        file_put_contents('/var/data/secrets.enc', $encrypted);
        return response()->json(['ok' => 1]);
    }
}
