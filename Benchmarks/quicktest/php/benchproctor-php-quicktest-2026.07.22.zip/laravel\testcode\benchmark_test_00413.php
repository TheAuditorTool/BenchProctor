<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00413Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        logger()->info('Action: ' . $data);
        return response()->json(['ok' => 1]);
    }
}
