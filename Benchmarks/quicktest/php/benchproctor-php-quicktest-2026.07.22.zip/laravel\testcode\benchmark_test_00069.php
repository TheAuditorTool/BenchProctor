<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00069Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $data = '' . $userInput;
        session()->regenerate();
        session(['data' => (string) $data]);
        return response()->json(['ok' => 1]);
    }
}
