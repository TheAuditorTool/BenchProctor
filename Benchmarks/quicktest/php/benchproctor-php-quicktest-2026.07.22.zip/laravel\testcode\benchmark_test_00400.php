<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00400Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $data = vsprintf('%1$s', [$userInput]);
        $token = bin2hex(random_bytes(32));
        return response()->json(['token' => (string)$token], 200);
    }
}
