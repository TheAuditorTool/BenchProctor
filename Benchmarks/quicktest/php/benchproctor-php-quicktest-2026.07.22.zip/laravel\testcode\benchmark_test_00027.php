<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00027Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        error_log((string)$data);
        return response()->json(['ok' => 1]);
    }
}
