<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00442Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        try { $data = json_decode($userInput, true, 512, JSON_THROW_ON_ERROR)['value'] ?? $userInput; }
        catch (\JsonException $e) { $data = $userInput; }
        if (preg_match('/[a-zA-Z0-9_-]+/', (string) $data)) {
            return response()->json(['validated' => (string) $data], 200);
        }
        return response()->json(['ok' => 1]);
    }
}
