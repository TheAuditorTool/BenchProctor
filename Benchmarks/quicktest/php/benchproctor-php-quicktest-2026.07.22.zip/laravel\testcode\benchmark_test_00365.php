<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00365Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'sk_test_4eC39HqLyjEXAMPLEdarjtT1zdp7';
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        $iv = random_bytes(12);
        $tag = '';
        $_ct = openssl_encrypt('data', 'aes-256-gcm', (string)$data, 0, $iv, $tag);
        $ciphertext = base64_encode($iv . $tag . $_ct);
        return response()->json(['ok' => 1]);
    }
}
