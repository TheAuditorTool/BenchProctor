<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00138Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Forwarded-For', '');
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        $valid = is_string($data) && strlen((string)$data) < 4096;
        if (!$valid) { error_log('schema validation failed'); }
        $processed = $data;
        file_get_contents('https://api.corp.lan/verify?d=' . urlencode((string)$processed), false, stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]));
        return response()->json(['ok' => 1]);
    }
}
