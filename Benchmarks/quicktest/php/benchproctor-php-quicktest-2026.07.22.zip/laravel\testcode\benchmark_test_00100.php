<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00100Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = (!empty($userInput)) ? $userInput : '';
        logger()->info('Action: ' . $data);
        return response()->json(['ok' => 1]);
    }
}
