<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00184Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (!preg_match('#^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$#', $data)) { return response()->json(['error' => 'forbidden'], 400); }
        $processed = $data;
        $requested = (int) $processed;
        $wrapped = unpack('l', pack('l', $requested + 1))[1];
        return response()->json(['wrapped' => $wrapped], 200);
    }
}
