<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00176Controller
{
    public function __invoke(Request $request)
    {
        $userInput = getenv('USER_INPUT') ?: '';
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        abort(500, $data);
        return response()->json(['ok' => 1]);
    }
}
