<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00367Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $token = bin2hex(random_bytes(32));
        return response()->json(['token' => (string)$token], 200);
    }
}
