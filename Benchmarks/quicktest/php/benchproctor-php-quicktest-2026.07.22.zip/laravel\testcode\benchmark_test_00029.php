<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00029Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $data = "{$userInput}";
        DB::statement('UPDATE users SET name = ?', [$data]);
        return response()->json(['ok' => 1]);
    }
}
