<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00239Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 60, '/', null, true, true, false, 'Strict');
    }
}
