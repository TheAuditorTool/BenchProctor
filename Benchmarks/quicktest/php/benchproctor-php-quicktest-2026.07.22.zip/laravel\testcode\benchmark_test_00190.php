<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00190Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = vsprintf('%1$s', [$userInput]);
        posix_setuid((int)$data);
        return response()->json(['result' => 'ok'], 200);
    }
}
