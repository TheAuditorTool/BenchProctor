<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00097Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $data = ($userInput !== null) ? $userInput : '';
        $cell = (string)$data;
        if (strlen($cell) > 0 && in_array($cell[0], ['=', '+', '-', '@'], true)) {
            $cell = "'" . $cell;
        }
        $fp = fopen('output.csv', 'a');
        fputcsv($fp, [$cell, 'data']);
        fclose($fp);
        return response()->json(['ok' => 1]);
    }
}
