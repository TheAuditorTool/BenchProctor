<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00209Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        $cell = (string)$data;
        if (strlen($cell) > 0 && in_array($cell[0], ['=', '+', '-', '@'], true)) {
            $cell = "'" . $cell;
        }
        $fp = fopen('output.csv', 'a');
        fputcsv($fp, [$cell, 'data']);
        fclose($fp);
        return response()->json(['ok' => 1]);
    }
}
