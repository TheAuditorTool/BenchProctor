<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00061Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $data = ($userInput !== null) ? $userInput : '';
        $processed = \Parsedown::instance()->setSafeMode(true)->text($data);
        return response('<div>' . $processed . '</div>')->header('Content-Type', 'text/html');
    }
}
