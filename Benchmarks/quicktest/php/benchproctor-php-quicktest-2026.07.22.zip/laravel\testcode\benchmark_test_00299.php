<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00299Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Forwarded-For', '');
        $data = call_user_func('strval', $userInput);
        $valid = is_string($data) && strlen((string)$data) < 4096;
        if (!$valid) { error_log('schema validation failed'); }
        $processed = $data;
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $processed, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
