<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00450Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $data = str_replace("\0", '', $userInput);
        if (!preg_match('/^[A-Za-z0-9_ @-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $el = new \Symfony\Component\ExpressionLanguage\ExpressionLanguage();
        try { $_elOut = (string) $el->evaluate($processed); } catch (\Throwable $e) { $_elOut = 'invalid'; }
        return response($_elOut)->header('Content-Type', 'text/html');
    }
}
