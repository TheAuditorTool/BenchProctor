<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00386Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        if (!preg_match('/^[A-Za-z0-9_ @-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        exec('echo ' . (string)$processed);
        return response()->json(['ok' => 1]);
    }
}
