<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00451Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        $_match = hash_equals((string)(getenv('APP_CREDENTIAL')), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
