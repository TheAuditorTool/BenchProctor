<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00485Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ['secret' => 'p4ssw0rd_test_xyz']['secret'];
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        $_match = hash_equals((string)(getenv('APP_CREDENTIAL')), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
