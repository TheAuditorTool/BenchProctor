<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00249Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        logger()->info('Action: ' . $processed);
        return response()->json(['ok' => 1]);
    }
}
