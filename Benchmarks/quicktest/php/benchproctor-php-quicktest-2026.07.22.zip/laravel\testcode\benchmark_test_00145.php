<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00145Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        file_put_contents('/var/data/output', (string)$data);
        return response()->json(['ok' => 1]);
    }
}
