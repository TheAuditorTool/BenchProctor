<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00296Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $field = 'data';
        $$field = $userInput;
        $requested = (int)$data;
        $size = max(0, min($requested, 1024));
        $buf = str_repeat('x', $size);
        unset($buf);
        return response()->json(['result' => 'ok'], 200);
    }
}
