<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00032Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        [$data] = [$userInput, 'http'];
        file_put_contents('output.csv', (string)$data . ',data' . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
