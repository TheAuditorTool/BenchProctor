<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00303Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $field = 'data';
        $$field = $userInput;
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        error_log((string)$data);
        return response()->json(['ok' => 1]);
    }
}
