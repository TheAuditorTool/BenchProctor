<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00403Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $data = ($userInput !== null) ? $userInput : '';
        return response(\Illuminate\Support\Facades\Blade::render($data))->header('Content-Type', 'text/html');
    }
}
