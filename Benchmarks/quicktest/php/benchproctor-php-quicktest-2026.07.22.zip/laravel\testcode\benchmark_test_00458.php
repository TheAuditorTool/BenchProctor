<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00458Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (!hash_equals((string) session('csrf_token', ''), (string)($request->header('X-CSRF-Token', '')))) { abort(403, 'csrf mismatch'); }
        DB::statement('UPDATE users SET name = ?', [$data]);
        return response()->json(['ok' => 1]);
    }
}
