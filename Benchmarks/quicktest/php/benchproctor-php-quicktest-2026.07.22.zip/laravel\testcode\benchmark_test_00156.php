<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00156Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->cookie('session_token', '');
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        if (!preg_match('#^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$#', $data)) { return response()->json(['error' => 'forbidden'], 400); }
        $processed = $data;
        exec('echo ' . (string)$processed);
        return response()->json(['ok' => 1]);
    }
}
