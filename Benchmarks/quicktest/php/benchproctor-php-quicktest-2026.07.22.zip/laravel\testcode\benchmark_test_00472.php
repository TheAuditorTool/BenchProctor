<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00472Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        $trusted = (string) $data;
        return response()->json(['trusted' => $trusted], 200);
    }
}
