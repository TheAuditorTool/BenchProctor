<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00174Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $mongo = new \MongoDB\Client('mongodb://localhost:27017');
        $mongoResult = $mongo->benchmark->users->findOne(['username' => ['$regex' => (string)$processed]]);
        return response()->json(['ok' => 1]);
    }
}
