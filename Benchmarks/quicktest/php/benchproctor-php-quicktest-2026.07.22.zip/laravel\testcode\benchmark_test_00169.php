<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00169Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'default_config_label';
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        $apiKey = getenv('API_KEY');
        file_get_contents('https://api.shopcdn.io/v1/data', false, stream_context_create(['http' => ['header' => 'Authorization: Bearer ' . $apiKey]]));
        return response()->json(['data' => 'ok'], 200);
    }
}
