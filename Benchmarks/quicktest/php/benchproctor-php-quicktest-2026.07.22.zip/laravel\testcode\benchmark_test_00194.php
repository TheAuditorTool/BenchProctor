<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00194Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        $ldap = ldap_connect('ldap://directory.svc.local:389');
        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_bind($ldap, getenv('LDAP_BIND_DN'), getenv('LDAP_BIND_PASS'));
        $entries = ldap_search($ldap, 'ou=users,dc=corp,dc=lan', '(uid=' . $data . ')');
        return response()->json(['ok' => 1]);
    }
}
