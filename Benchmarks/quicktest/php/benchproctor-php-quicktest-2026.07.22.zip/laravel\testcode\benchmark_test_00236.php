<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00236Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $data = trim((string)$userInput);
        if (time() > 1000000000) {
          exec('echo ' . (string)$data);
        }
        return response()->json(['ok' => 1]);
    }
}
