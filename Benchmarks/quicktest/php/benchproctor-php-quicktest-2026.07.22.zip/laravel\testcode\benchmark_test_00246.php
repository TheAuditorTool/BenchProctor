<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00246Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        return response('<div>' . $data . '</div>')->header('Content-Type', 'text/html');
    }
}
