<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00022Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'default_config_label';
        $data = str_replace("\0", '', $userInput);
        $key = getenv('DATA_ENC_KEY');
        $iv = random_bytes(12);
        $tag = '';
        $_ct = openssl_encrypt((string)$data, 'aes-256-gcm', $key, 0, $iv, $tag);
        $ciphertext = base64_encode($iv . $tag . $_ct);
        return response()->json(['ok' => 1]);
    }
}
