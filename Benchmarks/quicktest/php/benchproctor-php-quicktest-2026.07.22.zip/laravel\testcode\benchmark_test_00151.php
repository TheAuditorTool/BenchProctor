<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00151Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        try { $data = json_decode($userInput, true, 512, JSON_THROW_ON_ERROR)['value'] ?? $userInput; }
        catch (\JsonException $e) { $data = $userInput; }
        $hashed = password_hash((string)$data, PASSWORD_BCRYPT);
        file_put_contents('/var/data/output', $hashed);
        return response()->json(['ok' => 1]);
    }
}
