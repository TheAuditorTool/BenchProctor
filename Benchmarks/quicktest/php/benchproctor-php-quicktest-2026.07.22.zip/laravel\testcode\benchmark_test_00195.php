<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00195Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        $form = new class($userInput) { public function __construct(public readonly string $payload) {} };
        $data = $form->payload;
        if (in_array($data, ['https://app.shopcdn.io'], true)) {
            return response()->json(['ok' => 1])->header('Access-Control-Allow-Origin', (string)$data);
        }
        return response()->json(['ok' => 1]);
    }
}
