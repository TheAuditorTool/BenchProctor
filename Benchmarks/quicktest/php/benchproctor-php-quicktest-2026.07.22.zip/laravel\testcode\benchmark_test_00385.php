<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00385Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $_prefix = strtolower(substr($userInput, 0, 1));
        $data = '';
        switch ($_prefix) {
            case 'h': $data = strtolower($userInput); break;
            case 'f': $data = strtoupper($userInput); break;
            default: $data = trim($userInput); break;
        }
        file_get_contents('http://api.corp.lan/submit?d=' . urlencode((string)$data));
        return response()->json(['ok' => 1]);
    }
}
