<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00128Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        $_ch = curl_init((string)$data);
        curl_setopt($_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($_ch, CURLOPT_HEADER, true);
        $_raw = curl_exec($_ch);
        [$_hdrs, $_body] = explode("\r\n\r\n", $_raw, 2);
        preg_match('/X-Content-SHA256: ([\da-f]+)/i', $_hdrs, $_m);
        if (!isset($_m[1]) || hash('sha256', $_body) !== $_m[1]) { abort(502, 'integrity check failed'); }
        $_resp = ['body' => $_body];
        DB::statement('INSERT INTO feed (data) VALUES (?)', [$_resp['body']]);
        return response()->json(['ok' => 1]);
    }
}
