<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00431Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'app_display_name';
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        $cred = getenv('APP_CREDENTIAL');
        $_match = hash_equals((string)($cred), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
