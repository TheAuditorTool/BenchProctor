<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00344Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $data = '';
        foreach (explode(',', $userInput) as $token) { $data = $token; }
        abort(500, 'Internal error');
        return response()->json(['ok' => 1]);
    }
}
