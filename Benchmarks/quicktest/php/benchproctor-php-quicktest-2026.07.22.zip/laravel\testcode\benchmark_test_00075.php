<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00075Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $payload = new class($userInput) { public function __construct(private string $raw) {} public function value(): string { return $this->raw; } };
        $data = $payload->value();
        $cred = getenv('APP_CREDENTIAL');
        $_match = hash_equals((string)($cred), (string)((string)$data));
        return response()->json(['auth' => $_match ? 'ok' : 'denied'], 200);
    }
}
