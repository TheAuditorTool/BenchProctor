<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00140Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        abort(500, 'Internal error');
        return response()->json(['ok' => 1]);
    }
}
