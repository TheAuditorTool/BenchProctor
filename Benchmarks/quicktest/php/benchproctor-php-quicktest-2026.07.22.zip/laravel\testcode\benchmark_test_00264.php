<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00264Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $data = '' . $userInput;
        return response('<div>' . $data . '</div>')->header('Content-Type', 'text/html');
    }
}
