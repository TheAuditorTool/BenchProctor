<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00406Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        $words = explode(' ', $userInput);
        $data = implode(' ', $words);
        $role = (string) $data;
        if ($role === 'admin') { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
