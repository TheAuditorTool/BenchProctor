<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00018Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $field = 'data';
        $$field = $userInput;
        if (!in_array((string)$data, ['true', 'false', '1', '0'], true)) { return response()->json(['error' => 'invalid bool'], 400); }
        $parsedBool = (string)$data;
        $stored = '0e462097431906509019562988736854';
        if (hash_equals($stored, md5((string)$parsedBool))) { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
