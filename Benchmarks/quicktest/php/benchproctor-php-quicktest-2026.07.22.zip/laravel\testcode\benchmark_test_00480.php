<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00480Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        $el = new \Symfony\Component\ExpressionLanguage\ExpressionLanguage();
        try { $_elOut = (string) $el->evaluate($data); } catch (\Throwable $e) { $_elOut = 'invalid'; }
        return response($_elOut)->header('Content-Type', 'text/html');
    }
}
