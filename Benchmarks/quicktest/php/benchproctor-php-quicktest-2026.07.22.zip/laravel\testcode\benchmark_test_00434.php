<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00434Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        return response(\Illuminate\Support\Facades\Blade::render($data))->header('Content-Type', 'text/html');
    }
}
