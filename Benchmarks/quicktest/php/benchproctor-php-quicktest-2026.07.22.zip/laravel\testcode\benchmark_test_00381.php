<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00381Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 0, '/', null, false, false, false, null);
    }
}
