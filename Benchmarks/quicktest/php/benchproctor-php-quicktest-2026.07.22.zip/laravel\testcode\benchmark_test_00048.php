<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00048Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $data = call_user_func('strval', $userInput);
        $valid = is_string($data) && strlen((string)$data) < 4096;
        if (!$valid) { error_log('schema validation failed'); }
        $processed = $data;
        $role = (string) $processed;
        if ($role === 'admin') { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
