<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00143Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        exec('echo ' . (string)$data);
        return response()->json(['ok' => 1]);
    }
}
