<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00461Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        file_put_contents('output.csv', (string)$userInput . ',data' . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
