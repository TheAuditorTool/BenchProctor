<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00428Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        if (!hash_equals((string) session('csrf_token', ''), (string)($request->header('X-CSRF-Token', '')))) { abort(403, 'csrf mismatch'); }
        DB::statement('UPDATE users SET name = ?', [$userInput]);
        return response()->json(['ok' => 1]);
    }
}
