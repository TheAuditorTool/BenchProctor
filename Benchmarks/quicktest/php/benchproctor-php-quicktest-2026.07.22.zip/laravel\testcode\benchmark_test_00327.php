<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00327Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $_prefix = strtolower(substr($userInput, 0, 1));
        $data = '';
        switch ($_prefix) {
            case 'h': $data = strtolower($userInput); break;
            case 'f': $data = strtoupper($userInput); break;
            default: $data = trim($userInput); break;
        }
        file_get_contents('https://api.corp.lan/verify?d=' . urlencode((string)$data), false, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
        return response()->json(['ok' => 1]);
    }
}
