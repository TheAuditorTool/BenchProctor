<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00439Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        session()->regenerate();
        session(['data' => (string) $data]);
        return response()->json(['ok' => 1]);
    }
}
