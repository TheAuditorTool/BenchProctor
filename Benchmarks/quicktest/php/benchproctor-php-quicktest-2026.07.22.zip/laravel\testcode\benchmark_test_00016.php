<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00016Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        try { $data = json_decode($userInput, true, 512, JSON_THROW_ON_ERROR)['value'] ?? $userInput; }
        catch (\JsonException $e) { $data = $userInput; }
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        return response(\Illuminate\Support\Facades\Blade::render($processed))->header('Content-Type', 'text/html');
    }
}
