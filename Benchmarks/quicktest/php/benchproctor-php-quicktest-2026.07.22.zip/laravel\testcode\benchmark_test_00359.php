<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00359Controller
{
    public function __invoke(Request $request)
    {
        $userInput = getenv('USER_INPUT') ?: '';
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $mongo = new \MongoDB\Client('mongodb://localhost:27017');
        $mongoResult = $mongo->benchmark->users->findOne(['username' => ['$regex' => (string)$processed]]);
        return response()->json(['ok' => 1]);
    }
}
