<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00414Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $expectedSig = hash_hmac('sha256', (string) $processed, getenv('DATA_SIGNING_SECRET'));
        if (!hash_equals($expectedSig, (string) ($request->header('X-Signature', '')))) { return response()->json(['error' => 'integrity check failed'], 403); }
        $trusted = (string) $processed;
        return response()->json(['trusted' => $trusted], 200);
    }
}
