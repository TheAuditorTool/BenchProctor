<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00368Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ['s3cr3t_key_test_xyz'][0];
        $_token = hash_hmac('sha256', 'header.payload', (string)$userInput);
        return response()->json(['jwt' => 'signed'], 200);
    }
}
