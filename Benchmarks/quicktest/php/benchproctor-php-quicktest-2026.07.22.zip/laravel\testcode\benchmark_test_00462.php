<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00462Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $tokens = explode(',', $userInput);
        $data = implode(',', $tokens);
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        exec('echo ' . (string)$processed);
        return response()->json(['ok' => 1]);
    }
}
