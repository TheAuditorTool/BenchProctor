<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00285Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        if (!hash_equals((string)(session('user', '')), (string)($data))) { abort(403, 'forbidden'); }
        return response()->json(['ok' => 1]);
    }
}
