<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00362Controller
{
    public function __invoke(Request $request)
    {
        $userInput = 'default_setting_value';
        $holder = new class((string)$userInput) {
            private array $attrs;
            public function __construct(string $v) { $this->attrs = ['payload' => $v]; }
            public function __get($name) { return $this->attrs[$name] ?? null; }
        };
        $data = $holder->payload;
        $key = getenv('DATA_ENC_KEY');
        $iv = random_bytes(12);
        $tag = '';
        $_ct = openssl_encrypt((string)$data, 'aes-256-gcm', $key, 0, $iv, $tag);
        $ciphertext = base64_encode($iv . $tag . $_ct);
        return response()->json(['ok' => 1]);
    }
}
