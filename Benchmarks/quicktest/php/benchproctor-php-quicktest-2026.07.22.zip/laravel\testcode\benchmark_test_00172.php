<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00172Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $allowed = ['asc' => 'ORDER_ASC', 'desc' => 'ORDER_DESC', 'name' => 'BY_NAME', 'created' => 'BY_DATE'];
        $result = $allowed[(string)$processed] ?? 'noop';
        return response()->json(['ok' => 1]);
    }
}
