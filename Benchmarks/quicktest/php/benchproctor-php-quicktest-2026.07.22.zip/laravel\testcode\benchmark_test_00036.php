<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00036Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        if (!hash_equals((string)($data), (string)(session('token', '')))) { abort(401, 'unauthorized'); }
        return response()->json(['ok' => 1]);
    }
}
