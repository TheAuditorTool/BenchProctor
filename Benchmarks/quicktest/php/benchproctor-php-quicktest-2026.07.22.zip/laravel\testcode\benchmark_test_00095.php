<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00095Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->route('id') ?? $request->input('id', ''));
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        file_get_contents((string)$data);
        return response()->json(['ok' => 1]);
    }
}
