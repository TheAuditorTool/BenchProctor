<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00459Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        register_shutdown_function(function() use ($data) {
          $_body = file_get_contents((string)$data);
          DB::statement('INSERT INTO feed (data) VALUES (?)', [$_body]);
        });
        return response()->json(['ok' => 1]);
    }
}
