<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00446Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        DB::statement('UPDATE users SET name = ?', [$data]);
        return response()->json(['ok' => 1]);
    }
}
