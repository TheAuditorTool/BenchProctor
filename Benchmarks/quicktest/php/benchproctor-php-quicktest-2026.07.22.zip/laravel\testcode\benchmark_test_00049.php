<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00049Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $asText = function ($v): string { return (string) $v; };
        $data = $asText($userInput);
        if (empty(session('user', ''))) { abort(401, 'unauthorized'); }
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
