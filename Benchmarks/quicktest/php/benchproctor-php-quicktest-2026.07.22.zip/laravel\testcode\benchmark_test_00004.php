<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00004Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Authorization', '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        DB::statement('INSERT INTO logs (data) VALUES (\'' . $data . '\')');
        return response()->json(['ok' => 1]);
    }
}
