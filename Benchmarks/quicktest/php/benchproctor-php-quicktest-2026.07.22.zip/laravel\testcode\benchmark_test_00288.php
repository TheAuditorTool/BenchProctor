<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00288Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Host', '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $el = new \Symfony\Component\ExpressionLanguage\ExpressionLanguage();
        try { $_elOut = (string) $el->evaluate($processed); } catch (\Throwable $e) { $_elOut = 'invalid'; }
        return response($_elOut)->header('Content-Type', 'text/html');
    }
}
