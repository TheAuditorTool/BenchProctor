<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00262Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        return response('<html><body>' . (string)$data . '</body></html>')->header('Content-Type', 'text/html');
    }
}
