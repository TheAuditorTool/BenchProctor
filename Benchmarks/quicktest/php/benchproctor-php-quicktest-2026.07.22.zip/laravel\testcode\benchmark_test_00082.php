<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00082Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $data = urldecode($userInput);
        $digest = password_hash((string)$data, PASSWORD_BCRYPT);
        return response()->json(['ok' => 1]);
    }
}
