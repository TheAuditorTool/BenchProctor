<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00491Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (!preg_match('#^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$#', $data)) { return response()->json(['error' => 'forbidden'], 400); }
        $processed = $data;
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $processed, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
