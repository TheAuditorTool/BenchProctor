<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00121Controller
{
    public function __invoke(Request $request)
    {
        $userInput = getenv('USER_INPUT') ?: '';
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (!preg_match('/\.(jpg|png|gif|pdf)$/i', (string)$data)) { return response()->json(['error' => 'invalid type'], 400); }
        $entryFile = (string)$data;
        file_put_contents('/var/uploads/' . $entryFile, 'data');
        return response()->json(['ok' => 1]);
    }
}
