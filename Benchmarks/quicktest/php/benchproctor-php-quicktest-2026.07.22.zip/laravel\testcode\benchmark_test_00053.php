<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00053Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $data = str_replace("\0", '', $userInput);
        abort(500, 'Internal error');
        return response()->json(['ok' => 1]);
    }
}
