<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00051Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->query('id', '');
        $data = call_user_func('strval', $userInput);
        $valid = is_numeric($data);
        if (!$valid) { error_log('numeric validation failed'); }
        $processed = $data;
        $ciphertext = openssl_encrypt((string)$processed, 'des-ecb', getenv('DATA_ENC_KEY'));
        return response()->json(['ok' => 1]);
    }
}
