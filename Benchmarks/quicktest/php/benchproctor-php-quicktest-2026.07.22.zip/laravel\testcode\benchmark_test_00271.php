<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00271Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $data = strtr('{0}', ['{0}' => (string)$userInput]);
        file_put_contents('/var/log/app_action.log', 'action=' . (string)$data . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
