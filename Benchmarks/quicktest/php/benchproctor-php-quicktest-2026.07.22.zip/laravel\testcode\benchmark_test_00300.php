<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00300Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Custom-Header', '');
        $data = hex2bin($userInput);
        $requested = (int) $data;
        $allocated = $requested + 1;
        return response()->json(['allocated' => $allocated], 200);
    }
}
