<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00449Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $allowed = ['asc' => 'ORDER_ASC', 'desc' => 'ORDER_DESC', 'name' => 'BY_NAME', 'created' => 'BY_DATE'];
        $result = $allowed[(string)$processed] ?? 'noop';
        return response()->json(['ok' => 1]);
    }
}
