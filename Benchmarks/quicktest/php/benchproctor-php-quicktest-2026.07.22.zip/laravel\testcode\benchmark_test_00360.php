<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00360Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        $valid = is_string($data) && strlen((string)$data) < 4096;
        if (!$valid) { error_log('schema validation failed'); }
        $processed = $data;
        return response()->json(['ok' => 1])->cookie('session', (string)$processed, 0, '/', null, false, false, false, null);
    }
}
