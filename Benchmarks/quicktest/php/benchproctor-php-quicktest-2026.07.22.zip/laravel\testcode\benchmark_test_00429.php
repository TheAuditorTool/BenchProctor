<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00429Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        return response()->json(['ok' => 1])->cookie('session', (string)$data, 0, '/', null, false, false, false, null);
    }
}
