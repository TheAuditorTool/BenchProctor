<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00180Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Origin', '');
        $data = call_user_func('strval', $userInput);
        return response('<html><body>' . (string)$data . '</body></html>')->header('Content-Type', 'text/html');
    }
}
