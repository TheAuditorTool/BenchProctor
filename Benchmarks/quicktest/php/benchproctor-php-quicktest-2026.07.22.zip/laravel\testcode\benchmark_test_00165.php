<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00165Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $form = new class($userInput) { public function __construct(public readonly string $payload) {} };
        $data = $form->payload;
        $stored = '0e462097431906509019562988736854';
        if (md5((string)$data) == $stored) { return response()->json(["role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
