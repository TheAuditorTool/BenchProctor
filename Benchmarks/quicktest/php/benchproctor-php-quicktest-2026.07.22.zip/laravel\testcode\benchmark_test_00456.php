<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00456Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $data = trim((string)$userInput);
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        return response()->json(['ok' => 1])->header('Access-Control-Allow-Origin', (string)$processed);
    }
}
