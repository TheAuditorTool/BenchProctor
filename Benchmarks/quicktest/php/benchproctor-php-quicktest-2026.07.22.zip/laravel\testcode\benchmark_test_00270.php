<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00270Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $thunk = function () use ($userInput) { return $userInput; };
        $data = $thunk();
        $size = (int)$data;
        $buf = str_repeat('x', $size);
        unset($buf);
        return response()->json(['result' => 'ok'], 200);
    }
}
