<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00204Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->getContent();
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        $digest = password_hash((string)$data, PASSWORD_BCRYPT);
        return response()->json(['ok' => 1]);
    }
}
