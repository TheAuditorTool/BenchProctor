<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00492Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        static $requestCache = [];
        $requestCache['lastInput'] = $userInput;
        $data = $requestCache['lastInput'];
        if (!in_array((string)$data, ['true', 'false', '1', '0'], true)) { return response()->json(['error' => 'invalid bool'], 400); }
        $parsedBool = (string)$data;
        logger()->info('Action: ' . $parsedBool);
        return response()->json(['ok' => 1]);
    }
}
