<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00443Controller
{
    public function __invoke(Request $request)
    {
        $userInput = config('app.value', '');
        $registry = ['report' => \ArrayObject::class];
        $pluginClass = $registry['report'];
        $loaded = new $pluginClass(['payload' => $userInput]);
        $data = $loaded['payload'];
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        file_put_contents('/var/data/output', (string)$processed);
        return response()->json(['ok' => 1]);
    }
}
