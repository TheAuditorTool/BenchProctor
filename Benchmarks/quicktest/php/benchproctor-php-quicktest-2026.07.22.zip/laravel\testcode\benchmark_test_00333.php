<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00333Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $transform = fn (string $v): string => $v;
        $data = $transform($userInput);
        simplexml_load_string($data);
        return response()->json(['ok' => 1]);
    }
}
