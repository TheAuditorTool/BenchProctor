<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00044Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('User-Agent', '');
        $data = "{$userInput}";
        session()->regenerate();
        session(['data' => (string) $data]);
        return response()->json(['ok' => 1]);
    }
}
