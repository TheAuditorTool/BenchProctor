<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00085Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $data, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
