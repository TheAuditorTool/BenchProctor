<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00447Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('Referer', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        DB::statement('INSERT INTO logs (data) VALUES (\'' . $processed . '\')');
        return response()->json(['ok' => 1]);
    }
}
