<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00358Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $data = sprintf('%s', $userInput);
        exec('echo ' . (string)$data);
        return response()->json(['ok' => 1]);
    }
}
