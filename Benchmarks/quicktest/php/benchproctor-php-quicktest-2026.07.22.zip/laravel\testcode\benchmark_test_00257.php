<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00257Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('payload', '');
        $middleware = function (callable $next): callable {
            return fn($v) => $next($v);
        };
        $handle = $middleware(fn($v) => $v);
        $data = $handle($userInput);
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        file_put_contents('/var/log/app_action.log', 'action=' . (string)$processed . "\n", FILE_APPEND);
        return response()->json(['ok' => 1]);
    }
}
