<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00473Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $data = ($userInput !== null) ? $userInput : '';
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $data)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        return response('<div>' . $processed . '</div>')->header('Content-Type', 'text/html');
    }
}
