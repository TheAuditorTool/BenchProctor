<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00201Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT name FROM users LIMIT 1')->name;
        if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $userInput)) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $userInput;
        $expectedSig = hash_hmac('sha256', (string) $processed, getenv('DATA_SIGNING_SECRET'));
        if (!hash_equals($expectedSig, (string) ($request->header('X-Signature', '')))) { return response()->json(['error' => 'integrity check failed'], 403); }
        $trusted = (string) $processed;
        return response()->json(['trusted' => $trusted], 200);
    }
}
