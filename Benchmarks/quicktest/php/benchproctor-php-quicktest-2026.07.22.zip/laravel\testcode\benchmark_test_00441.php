<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00441Controller
{
    public function __invoke(Request $request)
    {
        $userInput = DB::selectOne('SELECT text FROM comments LIMIT 1')->text;
        $data = str_replace("\0", '', $userInput);
        if (!in_array($data, ['asc','desc','name','created'])) { return response()->json(['error'=>'invalid'], 400); }
        $processed = $data;
        $allowed = ['asc' => 'ORDER_ASC', 'desc' => 'ORDER_DESC', 'name' => 'BY_NAME', 'created' => 'BY_DATE'];
        $result = $allowed[(string)$processed] ?? 'noop';
        return response()->json(['ok' => 1]);
    }
}
