<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00058Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        $data = call_user_func('strval', $userInput);
        $processed = strlen($data) > 64 ? substr($data, 0, 64) : $data;
        $allowedActions = ['read', 'write', 'admin'];
        if (in_array((string) $processed, $allowedActions, true)) { return response()->json(["access" => "granted", "role" => "admin"], 200); }
        return response()->json(['ok' => 1]);
    }
}
