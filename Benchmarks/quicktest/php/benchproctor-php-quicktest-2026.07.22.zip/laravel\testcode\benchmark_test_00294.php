<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00294Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->header('X-Forwarded-For', '');
        [$data] = [$userInput, 'http'];
        $entries = scandir((string)$data);
        return response()->json(['listing' => $entries], 200);
    }
}
