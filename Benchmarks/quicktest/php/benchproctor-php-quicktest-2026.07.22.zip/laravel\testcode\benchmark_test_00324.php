<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BenchmarkTest00324Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->input('field', '');
        $data = str_replace("\0", '', $userInput);
        $_body = file_get_contents((string)$data);
        DB::statement('INSERT INTO feed (data) VALUES (?)', [$_body]);
        return response()->json(['ok' => 1]);
    }
}
