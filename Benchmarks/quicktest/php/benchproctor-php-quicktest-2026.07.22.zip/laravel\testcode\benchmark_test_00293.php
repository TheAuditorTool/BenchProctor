<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00293Controller
{
    public function __invoke(Request $request)
    {
        $userInput = ($request->file('upload')?->getClientOriginalName() ?? '');
        if (!hash_equals((string)($userInput), (string)(session('token', '')))) { abort(401, 'unauthorized'); }
        return response()->json(['ok' => 1]);
    }
}
