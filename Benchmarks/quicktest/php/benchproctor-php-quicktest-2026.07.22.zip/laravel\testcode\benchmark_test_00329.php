<?php
// SPDX-License-Identifier: Apache-2.0
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BenchmarkTest00329Controller
{
    public function __invoke(Request $request)
    {
        $userInput = $request->json('variables.input', '');
        $ctx = new \stdClass();
        $ctx->userInput = $userInput;
        $data = $ctx->userInput;
        $_handlers = ['primary' => function () use ($data) {
            return response('<div>' . $data . '</div>')->header('Content-Type', 'text/html');
        }];
        return $_handlers['primary']();
    }
}
