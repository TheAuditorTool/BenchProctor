# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00391(request):
    xml_value = request.body.decode('utf-8')
    data = f'{xml_value!s}'
    if len(str(data)) > 8192:
        return JsonResponse({'error': 'Internal error'}, status=400)
    return JsonResponse({'error': 'An internal error occurred'}, status=500)
