# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00007(request):
    header_value = request.META.get('HTTP_X_CUSTOM_HEADER', '')
    data = ' '.join(str(header_value).split(' '))
    db.execute('UPDATE users SET email = ? WHERE id = 1', (str(data),))
    return JsonResponse({"saved": True})
