# SPDX-License-Identifier: Apache-2.0
from django.template import Template, Context
from django.http import HttpResponse


def BenchmarkTest00167(request):
    xml_value = request.body.decode('utf-8')
    data = xml_value.decode('utf-8', 'ignore') if isinstance(xml_value, bytes) else xml_value
    return HttpResponse(Template(data).render(Context()))
