# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import csv
from app_runtime import db


class RequestPayload:
    def __init__(self, raw):
        self._raw = raw
    @property
    def value(self):
        return self._raw if self._raw is not None else ''

def BenchmarkTest00234(request):
    db_value = db.fetch_one('SELECT name FROM users LIMIT 1')
    data = RequestPayload(db_value).value
    cell = str(data)
    if cell[:1] in ('=', '+', '-', '@', '\t', '\r'):
        cell = "'" + cell
    with open('output.csv', 'a', newline='') as fh:
        writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
        writer.writerow([cell])
    return JsonResponse({"saved": True})
