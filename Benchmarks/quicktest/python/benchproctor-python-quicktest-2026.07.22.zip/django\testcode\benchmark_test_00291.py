# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import subprocess
import re


def BenchmarkTest00291(request):
    host_value = request.META.get('HTTP_HOST', '')
    data = f'{host_value!s}'
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', data):
        return JsonResponse({'error': 'forbidden'}, status=400)
    processed = data
    subprocess.run('echo ' + str(processed), shell=True)
    return JsonResponse({"saved": True})
