# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00130(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(graphql_var)
    data = collected
    with open('output.csv', 'a') as fh:
        fh.write(str(data) + ',data\n')
    return JsonResponse({"saved": True})
