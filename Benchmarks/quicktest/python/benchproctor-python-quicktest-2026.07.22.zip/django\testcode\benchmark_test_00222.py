# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from types import SimpleNamespace


def BenchmarkTest00222(request):
    origin_value = request.META.get('HTTP_ORIGIN', '')
    ns = SimpleNamespace(payload=origin_value)
    data = getattr(ns, 'payload')
    if len(str(data)) > 8192:
        return JsonResponse({'error': 'Internal error'}, status=400)
    return JsonResponse({'error': 'An internal error occurred'}, status=500)
