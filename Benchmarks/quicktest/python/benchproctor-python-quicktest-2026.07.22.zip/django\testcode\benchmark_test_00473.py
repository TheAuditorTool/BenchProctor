# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import re
import json


def BenchmarkTest00473(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    data = '%s' % str(json_value)
    if not re.fullmatch(r'[a-zA-Z0-9_.-]+', str(data)):
        return JsonResponse({'error': 'invalid input'}, status=400)
    processed = data
    if re.search('[a-zA-Z0-9_-]+', str(processed)):
        return JsonResponse({'validated': str(processed)}, status=200)
    return JsonResponse({"saved": True})
