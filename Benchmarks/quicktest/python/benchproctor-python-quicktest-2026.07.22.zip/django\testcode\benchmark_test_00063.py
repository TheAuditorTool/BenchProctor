# SPDX-License-Identifier: Apache-2.0
from django.template import Template, Context
from django.http import HttpResponse


def BenchmarkTest00063(request):
    ua_value = request.META.get('HTTP_USER_AGENT', '')
    data = '%s' % (ua_value,)
    return HttpResponse(Template(data).render(Context()))
