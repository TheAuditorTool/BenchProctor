# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json
from app_runtime import db


def BenchmarkTest00398(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    parts = str(json_value).split(',')
    data = ','.join(parts)
    if request.headers.get('X-CSRF-Token') != request.session.get('csrf_token'):
        return JsonResponse({'error': 'CSRF token mismatch'}, status=403)
    db.execute('UPDATE users SET email = ? WHERE id = 1', (str(data),))
    return JsonResponse({"saved": True})
