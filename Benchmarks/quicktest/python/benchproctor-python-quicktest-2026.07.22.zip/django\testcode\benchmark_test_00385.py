# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00385(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data, _sep, _rest = str(graphql_var).partition('\x00')
    if str(data) in ('read', 'write', 'delete', 'admin'):
        return JsonResponse({'access': 'granted', 'role': 'admin'}, status=200)
    return JsonResponse({"saved": True})
