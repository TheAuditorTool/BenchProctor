# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00360(request):
    ua_value = request.META.get('HTTP_USER_AGENT', '')
    ctx = RequestContext(ua_value, source='form')
    data = ctx.payload
    processed = data[:64]
    exec(str(processed))
    return JsonResponse({"saved": True})
