# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00327(request):
    upload_name = request.FILES['upload'].name
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(upload_name)
    data = collected
    processed = 'true' if str(data).lower() in ('true', '1', 'yes', 'on') else 'false'
    trusted_claim = str(processed)
    return JsonResponse({'trusted': trusted_claim}, status=200)
