# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00152(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    data = '%s' % (json_value,)
    if len(str(data)) > 8192:
        return JsonResponse({'error': 'Internal error'}, status=400)
    return JsonResponse({'error': 'An internal error occurred'}, status=500)
