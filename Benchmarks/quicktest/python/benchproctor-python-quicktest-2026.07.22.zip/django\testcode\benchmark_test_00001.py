# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


def BenchmarkTest00001(request):
    multipart_value = request.POST.get('multipart_field', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(multipart_value)
    data = collected
    auth_check('user', data)
    return JsonResponse({"saved": True})
