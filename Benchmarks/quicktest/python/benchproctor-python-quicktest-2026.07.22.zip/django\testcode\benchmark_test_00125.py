# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


_login_attempts: dict[str, int] = {}

def BenchmarkTest00125(request):
    header_value = request.META.get('HTTP_X_CUSTOM_HEADER', '')
    if header_value:
        data = header_value
    else:
        data = ''
    password = str(data)
    _login_attempts['user'] = _login_attempts.get('user', 0) + 1
    if _login_attempts['user'] > 5:
        return JsonResponse({'error': 'account locked: too many attempts'}, status=429)
    if not auth_check('user', password):
        return JsonResponse({'error': 'unauthorized'}, status=401)
    return JsonResponse({"saved": True})
