# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
import re
from types import SimpleNamespace


def BenchmarkTest00138(request):
    raw_body = request.body.decode('utf-8')
    ns = SimpleNamespace(payload=raw_body)
    data = getattr(ns, 'payload')
    if not re.fullmatch('^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$', data):
        return JsonResponse({'error': 'forbidden'}, status=400)
    processed = data
    requests.post('http://api.prod.internal/data', data=str(processed))
    return JsonResponse({"saved": True})
