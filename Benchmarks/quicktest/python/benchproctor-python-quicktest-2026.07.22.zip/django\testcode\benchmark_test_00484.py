# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00484(request):
    ua_value = request.META.get('HTTP_USER_AGENT', '')
    kind = 'json' if str(ua_value).lstrip().startswith('{') else 'text'
    match kind:
        case 'json':
            data = str(ua_value).strip()
        case _:
            data = str(ua_value)
    return JsonResponse({'status': 'ok'}, status=200, headers={'Content-Language': str(data)})
