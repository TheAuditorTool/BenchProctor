# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
import hashlib
from app_runtime import db


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00496(request):
    cookie_value = request.COOKIES.get('session_token', '')
    ctx = RequestContext(cookie_value, source='form')
    data = ctx.payload
    _resp = requests.get(str(data))
    if hashlib.sha256(_resp.content).hexdigest() != _resp.headers.get('X-Content-SHA256'):
        return JsonResponse({'error': 'integrity check failed'}, status=502)
    db.execute('INSERT INTO feed (data) VALUES (?)', (_resp.text,))
    return JsonResponse({"saved": True})
