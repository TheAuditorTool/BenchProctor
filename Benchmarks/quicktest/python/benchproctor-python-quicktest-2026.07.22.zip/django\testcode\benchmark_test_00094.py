# SPDX-License-Identifier: Apache-2.0
from django.utils.safestring import mark_safe
from django.http import HttpResponse


def BenchmarkTest00094(request):
    cookie_value = request.COOKIES.get('session_token', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(cookie_value)
    data = collected
    processed = data[:64]
    return HttpResponse(mark_safe('<div>' + str(processed) + '</div>'))
