# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00226(request):
    comment_value = db.fetch_one('SELECT text FROM comments LIMIT 1')
    parts = str(comment_value).split(',')
    data = ','.join(parts)
    buffer = bytearray(int(data) if str(data).isdigit() else 0)
    return JsonResponse({'allocated': len(buffer)}, status=200)
