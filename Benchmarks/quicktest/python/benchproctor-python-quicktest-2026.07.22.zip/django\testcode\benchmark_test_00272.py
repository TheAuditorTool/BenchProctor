# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import yaml
from app_runtime import mq_client


def BenchmarkTest00272(request):
    msg_value = mq_client.get_message().body
    parsed = yaml.safe_load(msg_value)
    return JsonResponse({'parsed': str(parsed)}, status=200)
