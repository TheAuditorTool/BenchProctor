# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import mongo_db


def BenchmarkTest00345(request):
    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
    data = bytes.fromhex(auth_header).decode('utf-8', 'ignore')
    mongo_db.users.find({'$where': "this.username == '" + str(data) + "'"})
    return JsonResponse({"saved": True})
