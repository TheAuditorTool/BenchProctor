# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import logging
from dataclasses import dataclass


@dataclass
class FormData:
    payload: str
    content_type: str = 'text/plain'

def BenchmarkTest00307(request):
    raw_body = request.body.decode('utf-8')
    form = FormData(payload=raw_body)
    data = form.payload
    logging.info('User action: ' + str(data))
    return JsonResponse({"saved": True})
