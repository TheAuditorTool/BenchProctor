# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import csv
from app_runtime import db


def BenchmarkTest00115(request):
    comment_value = db.fetch_one('SELECT text FROM comments LIMIT 1')
    if comment_value:
        data = comment_value
    else:
        data = ''
    cell = str(data)
    if cell[:1] in ('=', '+', '-', '@', '\t', '\r'):
        cell = "'" + cell
    with open('output.csv', 'a', newline='') as fh:
        writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
        writer.writerow([cell])
    return JsonResponse({"saved": True})
