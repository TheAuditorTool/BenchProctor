# SPDX-License-Identifier: Apache-2.0
from django.shortcuts import redirect


def BenchmarkTest00052(request):
    raw_body = request.body.decode('utf-8')
    return redirect(str(raw_body))
