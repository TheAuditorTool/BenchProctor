# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import hashlib


def coalesce_blank(value):
    return value or ''

def BenchmarkTest00331(request):
    field_value = request.POST.get('field', '')
    data = coalesce_blank(field_value)
    digest = hashlib.sha256(str(data).encode()).hexdigest()
    with open('/var/data/secrets.txt', 'w') as fh:
        fh.write(digest)
    return JsonResponse({"saved": True})
