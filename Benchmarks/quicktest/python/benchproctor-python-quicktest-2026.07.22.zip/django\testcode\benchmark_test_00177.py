# SPDX-License-Identifier: Apache-2.0
from django.utils.safestring import mark_safe
from django.http import HttpResponse


def BenchmarkTest00177(request):
    upload_name = request.FILES['upload'].name
    data = f'{upload_name!s}'
    return HttpResponse(mark_safe('<div>' + str(data) + '</div>'))
