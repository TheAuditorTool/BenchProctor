# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
from urllib.parse import urlparse
import ipaddress
import socket
import os


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00368(request):
    env_value = os.environ.get('USER_INPUT', '')
    ctx = RequestContext(env_value, source='form')
    data = ctx.payload
    parsed = urlparse(str(data))
    resolved = socket.gethostbyname(parsed.hostname or str(data))
    if ipaddress.ip_address(resolved).is_link_local:
        return JsonResponse({'error': 'metadata endpoint blocked'}, status=403)
    target_url = str(data).replace(parsed.hostname, resolved) if parsed.hostname else str(data)
    requests.get(str(target_url))
    return JsonResponse({"saved": True})
