# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import hashlib
import os


def BenchmarkTest00205(request):
    with open('/etc/app/config.json', 'r') as fh:
        config_value = fh.read()
    digest = hashlib.pbkdf2_hmac('sha256', str(config_value).encode(), os.urandom(16), 100000).hex()
    return JsonResponse({'digest': str(digest)}, status=200)
