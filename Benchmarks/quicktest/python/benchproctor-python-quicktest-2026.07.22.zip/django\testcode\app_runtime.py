"""Benchmark runtime stubs.

The generated test files are analyzed statically (a SAST tool parses the AST and
tracks taint without executing the handlers). These permissive no-op stand-ins
exist only so each module's ``from app_runtime import ...`` resolves cleanly.
"""
from typing import Any


class _Stub:
    """Any attribute access / call / subscript returns another _Stub, so every
    db.execute(...) / channel.basic_publish(...) / rpc_stub.send(...) usage in a
    generated handler resolves without a runtime dependency."""

    def __call__(self, *args: Any, **kwargs: Any) -> "_Stub":
        return self

    def __getattr__(self, _name: str) -> "_Stub":
        return self

    def __getitem__(self, _key: Any) -> "_Stub":
        return self

    def __iter__(self):
        return iter(())


db = _Stub()
mongo_db = _Stub()
redis_client = _Stub()
mq_client = _Stub()
channel = _Stub()
ssm_client = _Stub()
rpc_stub = _Stub()
User = _Stub()


def exec_command(*args: Any, **kwargs: Any) -> Any:
    return None


def render_html(*args: Any, **kwargs: Any) -> str:
    return ""


def open_file(*args: Any, **kwargs: Any) -> Any:
    return None


def auth_check(*args: Any, **kwargs: Any) -> bool:
    return False
