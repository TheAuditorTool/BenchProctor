# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json
import subprocess


def BenchmarkTest00335(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    parts = []
    for token in str(json_value).split(','):
        parts.append(token.strip())
    data = ','.join(parts)
    subprocess.run(['echo', data], shell=False)
    return JsonResponse({"saved": True})
