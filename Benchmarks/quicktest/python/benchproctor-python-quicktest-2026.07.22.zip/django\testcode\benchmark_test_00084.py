# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


class RequestPayload:
    def __init__(self, raw):
        self._raw = raw
    @property
    def value(self):
        return self._raw if self._raw is not None else ''

def BenchmarkTest00084(request):
    field_value = request.POST.get('field', '')
    data = RequestPayload(field_value).value
    db.execute('UPDATE users SET email = ? WHERE id = 1', (str(data),))
    return JsonResponse({"saved": True})
