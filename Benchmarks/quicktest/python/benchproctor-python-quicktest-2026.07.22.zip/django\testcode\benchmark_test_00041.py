# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00041(request):
    env_value = os.environ.get('USER_INPUT', '')
    data = env_value if env_value else 'default'
    buffer = bytearray(int(data) if str(data).isdigit() else 0)
    return JsonResponse({'allocated': len(buffer)}, status=200)
