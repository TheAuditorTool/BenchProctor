# SPDX-License-Identifier: Apache-2.0
from django.http import HttpResponse
from django.template import Template, Context
from app_runtime import db


def default_blank(value):
    return value if value is not None else ''

def BenchmarkTest00269(request):
    comment_value = db.fetch_one('SELECT text FROM comments LIMIT 1')
    data = default_blank(comment_value)
    return HttpResponse(Template('{{ value }}').render(Context({'value': data})))
