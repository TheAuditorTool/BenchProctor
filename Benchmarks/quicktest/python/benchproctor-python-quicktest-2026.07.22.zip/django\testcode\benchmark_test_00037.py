# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import defusedxml.ElementTree
from app_runtime import db


def BenchmarkTest00037(request):
    db_value = db.fetch_one('SELECT name FROM users LIMIT 1')
    kind = 'json' if str(db_value).lstrip().startswith('{') else 'text'
    match kind:
        case 'json':
            data = str(db_value).strip()
        case _:
            data = str(db_value)
    defusedxml.ElementTree.fromstring(str(data))
    return JsonResponse({"saved": True})
