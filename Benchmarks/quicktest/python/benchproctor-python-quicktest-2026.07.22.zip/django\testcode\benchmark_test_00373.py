# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os
import re
from types import SimpleNamespace


def BenchmarkTest00373(request):
    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
    ns = SimpleNamespace(payload=auth_header)
    data = getattr(ns, 'payload')
    if not re.fullmatch('^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$', data):
        return JsonResponse({'error': 'forbidden'}, status=400)
    processed = data
    os.system('echo ' + str(processed))
    return JsonResponse({"saved": True})
