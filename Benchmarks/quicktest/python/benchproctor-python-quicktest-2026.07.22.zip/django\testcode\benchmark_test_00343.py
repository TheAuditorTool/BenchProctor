# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00343(request):
    db_value = db.fetch_one('SELECT name FROM users LIMIT 1')
    data = '{}'.format(db_value)
    size = min(int(data) if str(data).isdigit() else 0, 1024)
    buffer = bytearray(size)
    return JsonResponse({'allocated': len(buffer)}, status=200)
