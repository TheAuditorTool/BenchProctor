# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import subprocess


def BenchmarkTest00200(request):
    xml_value = request.body.decode('utf-8')
    data = '%s' % str(xml_value)
    subprocess.run(['echo', data], shell=False)
    return JsonResponse({"saved": True})
