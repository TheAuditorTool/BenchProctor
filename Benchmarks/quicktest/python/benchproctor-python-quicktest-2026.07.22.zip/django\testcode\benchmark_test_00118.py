# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00118(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data = graphql_var if graphql_var else 'default'
    resp = JsonResponse({'status': 'ok'})
    resp.set_cookie('session', str(data), secure=True, httponly=True, samesite='Strict')
    return resp
