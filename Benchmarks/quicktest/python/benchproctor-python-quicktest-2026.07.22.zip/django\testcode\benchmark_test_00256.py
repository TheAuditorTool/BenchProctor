# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00256(request):
    secret_value = 'config_secret_test_abc123'
    data = '{}'.format(secret_value)
    db.connect(host='localhost', user='app', password=data)
    return JsonResponse({"saved": True})
