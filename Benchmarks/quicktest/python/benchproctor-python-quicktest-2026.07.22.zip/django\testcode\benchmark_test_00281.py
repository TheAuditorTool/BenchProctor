# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import re
import json


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00281(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    ctx = RequestContext(json_value, source='form')
    data = ctx.payload
    if not re.fullmatch('^[^\\x00-\\x08\\x0e-\\x1f\\x7f]+$', data):
        return JsonResponse({'error': 'forbidden'}, status=400)
    processed = data
    if str(processed) == 'S3cr3tToken':
        return JsonResponse({'authenticated': True}, status=200)
    return JsonResponse({"saved": True})
