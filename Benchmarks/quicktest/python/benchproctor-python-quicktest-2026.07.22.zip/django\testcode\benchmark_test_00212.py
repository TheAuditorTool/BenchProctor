# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import re
import ast
import requests


def BenchmarkTest00212(request):
    field_value = request.POST.get('field', '')
    try:
        data = str(ast.literal_eval(field_value))
    except (ValueError, SyntaxError):
        data = field_value
    if not re.match(r'^.{1,256}$', str(data)):
        return JsonResponse({'error': 'schema invalid'}, status=400)
    requests.get('https://api.pycdn.io/data', params={'q': str(data)}, verify=False)
    return JsonResponse({"saved": True})
