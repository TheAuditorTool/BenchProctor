# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


class RequestPayload:
    def __init__(self, raw):
        self._raw = raw
    @property
    def value(self):
        return self._raw if self._raw is not None else ''

def BenchmarkTest00239(request):
    field_value = request.POST.get('field', '')
    data = RequestPayload(field_value).value
    size = min(int(data) if str(data).isdigit() else 0, 1024)
    buffer = bytearray(size)
    return JsonResponse({'allocated': len(buffer)}, status=200)
