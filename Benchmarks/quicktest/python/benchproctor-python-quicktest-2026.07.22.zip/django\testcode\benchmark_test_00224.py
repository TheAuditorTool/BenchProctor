# SPDX-License-Identifier: Apache-2.0
from django.template import Template, Context
from django.http import HttpResponse


def BenchmarkTest00224(request):
    cookie_value = request.COOKIES.get('session_token', '')
    def normalize(value):
        return value.strip()
    data = normalize(cookie_value)
    return HttpResponse(Template(data).render(Context()))
