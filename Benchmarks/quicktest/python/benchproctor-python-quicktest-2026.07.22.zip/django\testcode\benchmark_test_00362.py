# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
import json


def BenchmarkTest00362(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data = ' '.join(str(graphql_var).split(' '))
    requests.get(str(data))
    return JsonResponse({"saved": True})
