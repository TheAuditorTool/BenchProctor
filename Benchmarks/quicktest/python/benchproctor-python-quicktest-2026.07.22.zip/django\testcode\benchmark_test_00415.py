# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00415(request):
    forwarded_ip = request.META.get('HTTP_X_FORWARDED_FOR', '')
    data = str(forwarded_ip).replace('\x00', '')
    return JsonResponse({'error': str(data), 'stack': repr(locals())}, status=500)
