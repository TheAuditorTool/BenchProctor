# SPDX-License-Identifier: Apache-2.0
from django.template import Template, Context
from django.http import HttpResponse


def BenchmarkTest00247(request):
    raw_body = request.body.decode('utf-8')
    kind = 'json' if str(raw_body).lstrip().startswith('{') else 'text'
    match kind:
        case 'json':
            data = str(raw_body).strip()
        case _:
            data = str(raw_body)
    return HttpResponse(Template(data).render(Context()))
