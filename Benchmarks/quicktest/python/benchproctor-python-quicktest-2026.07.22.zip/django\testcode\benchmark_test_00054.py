# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db, auth_check


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00054(request):
    profile_value = db.fetch_one('SELECT bio FROM profiles LIMIT 1')
    ctx = RequestContext(profile_value, source='form')
    data = ctx.payload
    auth_check('user', data)
    return JsonResponse({"saved": True})
