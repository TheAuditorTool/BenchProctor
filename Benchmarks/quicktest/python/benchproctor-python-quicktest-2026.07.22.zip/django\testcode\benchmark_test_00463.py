# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00463(request):
    env_value = os.environ.get('USER_INPUT', '')
    pending = list(str(env_value).split(','))
    collected = []
    while pending:
        collected.append(pending.pop(0).strip())
    data = ','.join(collected)
    if len(str(data)) > 8192:
        return JsonResponse({'error': 'Internal error'}, status=400)
    return JsonResponse({'error': 'An internal error occurred'}, status=500)
