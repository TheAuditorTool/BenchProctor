# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


_login_attempts: dict[str, int] = {}

def BenchmarkTest00210(request):
    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
    data = auth_header if auth_header else 'default'
    password = str(data)
    _login_attempts['user'] = _login_attempts.get('user', 0) + 1
    if auth_check('user', password):
        return JsonResponse({'authenticated': True}, status=200)
    return JsonResponse({"saved": True})
