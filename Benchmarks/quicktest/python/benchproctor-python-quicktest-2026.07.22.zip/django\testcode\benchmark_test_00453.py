# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from dataclasses import dataclass
from app_runtime import auth_check


@dataclass
class FormData:
    payload: str
    content_type: str = 'text/plain'

def BenchmarkTest00453(request):
    field_value = request.POST.get('field', '')
    form = FormData(payload=field_value)
    data = form.payload
    if not auth_check(request.session.get('user', ''), str(data)):
        return JsonResponse({'error': 'forbidden'}, status=403)
    return JsonResponse({"saved": True})
