# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from cryptography.fernet import Fernet
import os


def trim_value(value):
    return value.strip() if isinstance(value, str) else str(value)

def BenchmarkTest00364(request, path_param):
    path_value = path_param
    data = trim_value(path_value)
    ciphertext = Fernet(os.environ['DATA_ENC_KEY'].encode()).encrypt(str(data).encode())
    return JsonResponse({'length': len(ciphertext)}, status=200)
