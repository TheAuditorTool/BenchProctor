# SPDX-License-Identifier: Apache-2.0
from django.template import Template, Context
from django.http import HttpResponse
from app_runtime import db


def BenchmarkTest00454(request):
    db_value = db.fetch_one('SELECT name FROM users LIMIT 1')
    data = db_value if db_value else 'default'
    return HttpResponse(Template('safe block: {{ value }}').render(Context({'value': data})))
