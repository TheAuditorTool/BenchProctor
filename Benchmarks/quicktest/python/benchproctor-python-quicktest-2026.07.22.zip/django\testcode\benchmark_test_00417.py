# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


def BenchmarkTest00417(request):
    field_value = request.POST.get('field', '')
    data = str(field_value).replace('\x00', '')
    auth_check('user', data)
    return JsonResponse({"saved": True})
