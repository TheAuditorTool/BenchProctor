# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import mongo_db


def BenchmarkTest00240(request):
    forwarded_ip = request.META.get('HTTP_X_FORWARDED_FOR', '')
    data = '%s' % str(forwarded_ip)
    mongo_db.users.find({'$where': "this.username == '" + str(data) + "'"})
    return JsonResponse({"saved": True})
