# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json
import os


def BenchmarkTest00214(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    try:
        data = json.loads(json_value).get('value', json_value)
    except (json.JSONDecodeError, AttributeError):
        data = json_value
    entries = os.listdir(str(data))
    return JsonResponse({'listing': entries}, status=200)
