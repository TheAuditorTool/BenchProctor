# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from cryptography.fernet import Fernet
import os


def BenchmarkTest00048(request):
    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(auth_header)
    data = collected
    key = os.environ['DATA_ENC_KEY'].encode()
    encrypted = Fernet(key).encrypt(str(data).encode())
    with open('/var/data/secrets.enc', 'wb') as fh:
        fh.write(encrypted)
    return JsonResponse({"saved": True})
