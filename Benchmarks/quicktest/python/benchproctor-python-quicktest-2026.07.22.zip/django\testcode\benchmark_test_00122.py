# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00122(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(json_value)
    data = collected
    processed = str(data).replace("<script", "")
    with open('output.csv', 'a') as fh:
        fh.write(str(processed) + ',data\n')
    return JsonResponse({"saved": True})
