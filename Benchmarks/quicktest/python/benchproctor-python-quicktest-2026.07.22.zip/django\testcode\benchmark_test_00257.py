# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00257(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data = graphql_var if graphql_var else 'default'
    return JsonResponse({'status': 'ok'}, status=200, headers={'Access-Control-Allow-Origin': str(data)})
