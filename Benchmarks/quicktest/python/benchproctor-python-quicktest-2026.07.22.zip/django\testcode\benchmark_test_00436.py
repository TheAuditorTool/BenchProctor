# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP


def BenchmarkTest00436(request):
    multipart_value = request.POST.get('multipart_field', '')
    key = RSA.generate(1024)
    ciphertext = PKCS1_OAEP.new(key).encrypt(str(multipart_value).encode())
    return JsonResponse({'length': len(ciphertext)}, status=200)
