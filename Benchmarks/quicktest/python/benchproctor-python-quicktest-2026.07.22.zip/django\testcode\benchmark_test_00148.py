# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00148(request):
    os.seteuid(65534)
    return JsonResponse({"saved": True})
