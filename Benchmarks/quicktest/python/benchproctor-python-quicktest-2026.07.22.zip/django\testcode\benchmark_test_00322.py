# SPDX-License-Identifier: Apache-2.0
from django.http import HttpResponse
from app_runtime import db


def BenchmarkTest00322(request):
    comment_value = db.fetch_one('SELECT text FROM comments LIMIT 1')
    return HttpResponse('<html><body><h1>' + str(comment_value) + '</h1></body></html>', content_type='text/html')
