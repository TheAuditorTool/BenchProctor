# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP


class RequestPayload:
    def __init__(self, raw):
        self._raw = raw
    @property
    def value(self):
        return self._raw if self._raw is not None else ''

def BenchmarkTest00440(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data = RequestPayload(graphql_var).value
    key = RSA.generate(2048)
    ciphertext = PKCS1_OAEP.new(key).encrypt(str(data).encode())
    return JsonResponse({'length': len(ciphertext)}, status=200)
