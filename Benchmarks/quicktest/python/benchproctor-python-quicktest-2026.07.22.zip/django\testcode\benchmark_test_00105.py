# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00105(request):
    field_value = request.POST.get('field', '')
    data = f'{field_value!s}'
    if request.headers.get('X-CSRF-Token') != request.session.get('csrf_token'):
        return JsonResponse({'error': 'CSRF token mismatch'}, status=403)
    db.execute('UPDATE users SET email = ? WHERE id = 1', (str(data),))
    return JsonResponse({"saved": True})
