# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from dataclasses import dataclass


@dataclass
class FormData:
    payload: str
    content_type: str = 'text/plain'

def BenchmarkTest00241(request):
    user_id = request.GET.get('id', '')
    form = FormData(payload=user_id)
    data = form.payload
    buffer = bytearray(int(data) if str(data).isdigit() else 0)
    return JsonResponse({'allocated': len(buffer)}, status=200)
