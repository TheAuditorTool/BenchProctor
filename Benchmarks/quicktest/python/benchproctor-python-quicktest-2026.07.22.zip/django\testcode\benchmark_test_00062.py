# SPDX-License-Identifier: Apache-2.0
from django.http import HttpResponse


def BenchmarkTest00062(request):
    user_id = request.GET.get('id', '')
    data = bytes.fromhex(user_id).decode('utf-8', 'ignore')
    return HttpResponse('<html><body><h1>' + str(data) + '</h1></body></html>', content_type='text/html')
