# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
import json
from app_runtime import db


def BenchmarkTest00131(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data, _sep, _rest = str(graphql_var).partition('\x00')
    _resp = requests.get(str(data))
    db.execute('INSERT INTO feed (data) VALUES (?)', (_resp.text,))
    return JsonResponse({"saved": True})
