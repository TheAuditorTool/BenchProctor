# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from types import SimpleNamespace
from app_runtime import auth_check


_login_attempts: dict[str, int] = {}

def BenchmarkTest00468(request):
    header_value = request.META.get('HTTP_X_CUSTOM_HEADER', '')
    ns = SimpleNamespace(payload=header_value)
    data = getattr(ns, 'payload')
    password = str(data)
    _login_attempts['user'] = _login_attempts.get('user', 0) + 1
    if auth_check('user', password):
        return JsonResponse({'authenticated': True}, status=200)
    return JsonResponse({"saved": True})
