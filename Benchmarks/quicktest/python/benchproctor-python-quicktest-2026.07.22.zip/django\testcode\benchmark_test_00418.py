# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import defusedxml.ElementTree


def BenchmarkTest00418(request):
    field_value = request.POST.get('field', '')
    data = ' '.join(str(field_value).split(' '))
    defusedxml.ElementTree.fromstring(str(data))
    return JsonResponse({"saved": True})
