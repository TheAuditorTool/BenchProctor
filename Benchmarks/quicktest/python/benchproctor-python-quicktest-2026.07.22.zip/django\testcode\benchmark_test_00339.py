# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from urllib.parse import unquote
from app_runtime import auth_check


_login_attempts: dict[str, int] = {}

def BenchmarkTest00339(request):
    field_value = request.POST.get('field', '')
    data = unquote(field_value)
    password = str(data)
    _login_attempts['user'] = _login_attempts.get('user', 0) + 1
    if auth_check('user', password):
        return JsonResponse({'authenticated': True}, status=200)
    return JsonResponse({"saved": True})
