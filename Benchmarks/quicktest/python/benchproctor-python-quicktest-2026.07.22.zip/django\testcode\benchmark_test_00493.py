# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import jwt


def make_reader(raw):
    def read():
        return raw.strip()
    return read

def BenchmarkTest00493(request):
    secret_value = ['s3cr3t_key_test_xyz'][0]
    reader = make_reader(secret_value)
    data = reader()
    jwt.encode({'sub': 'user'}, data, algorithm='HS256')
    return JsonResponse({"saved": True})
