# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00270(request):
    ua_value = request.META.get('HTTP_USER_AGENT', '')
    data = f'{ua_value!s}'
    buffer = bytearray(int(data) if str(data).isdigit() else 0)
    return JsonResponse({'allocated': len(buffer)}, status=200)
