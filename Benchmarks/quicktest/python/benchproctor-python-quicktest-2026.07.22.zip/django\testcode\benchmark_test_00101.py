# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def default_blank(value):
    return value if value is not None else ''

def BenchmarkTest00101(request):
    user_id = request.GET.get('id', '')
    data = default_blank(user_id)
    return JsonResponse({'error': str(data), 'stack': repr(locals())}, status=500)
