# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


def BenchmarkTest00298(request):
    forwarded_ip = request.META.get('HTTP_X_FORWARDED_FOR', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(forwarded_ip)
    data = collected
    auth_check('user', data)
    return JsonResponse({"saved": True})
