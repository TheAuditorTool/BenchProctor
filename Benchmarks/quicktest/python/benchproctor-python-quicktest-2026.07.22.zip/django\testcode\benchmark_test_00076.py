# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00076(request):
    field_value = request.POST.get('field', '')
    data = '%s' % (field_value,)
    os.setuid(int(str(data)) if str(data).isdigit() else 65534)
    return JsonResponse({"saved": True})
