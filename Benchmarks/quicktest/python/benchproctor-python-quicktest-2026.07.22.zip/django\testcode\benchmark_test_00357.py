# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import re


def BenchmarkTest00357(request):
    origin_value = request.META.get('HTTP_ORIGIN', '')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(origin_value)
    data = collected
    processed = re.sub(r'[A-Za-z0-9]{4,}', '****', str(data).replace('\r', '').replace('\n', ''))
    return JsonResponse({'status': 'ok'}, status=200, headers={'Content-Language': str(processed)})
