# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os
from django.http import HttpResponse


def trim_value(value):
    return value.strip() if isinstance(value, str) else str(value)

def BenchmarkTest00190(request):
    origin_value = request.META.get('HTTP_ORIGIN', '')
    data = trim_value(origin_value)
    base_dir = '/var/app/data'
    full_path = os.path.realpath(os.path.join(base_dir, data))
    if not full_path.startswith(base_dir + os.sep):
        return JsonResponse({'error': 'forbidden'}, status=403)
    checked_path = full_path
    with open(checked_path, 'r') as fh:
        content = fh.read()
    return HttpResponse(content)
