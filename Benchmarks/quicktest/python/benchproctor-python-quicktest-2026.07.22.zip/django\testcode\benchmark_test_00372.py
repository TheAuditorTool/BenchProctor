# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os
from app_runtime import db


def BenchmarkTest00372(request):
    comment_value = db.fetch_one('SELECT text FROM comments LIMIT 1')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(comment_value)
    data = collected
    entries = os.listdir(str(data))
    return JsonResponse({'listing': entries}, status=200)
