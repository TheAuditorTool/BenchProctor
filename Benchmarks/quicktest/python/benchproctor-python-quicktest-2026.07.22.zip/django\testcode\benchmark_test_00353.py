# SPDX-License-Identifier: Apache-2.0
from django.utils.safestring import mark_safe
from django.http import HttpResponse
import html
import json


def BenchmarkTest00353(request):
    graphql_var = json.loads(request.body or b'{}').get('variables', {}).get('input', '')
    data = json.loads(graphql_var).get('value', '')
    processed = html.escape(data)
    return HttpResponse(mark_safe('<div>' + str(processed) + '</div>'))
