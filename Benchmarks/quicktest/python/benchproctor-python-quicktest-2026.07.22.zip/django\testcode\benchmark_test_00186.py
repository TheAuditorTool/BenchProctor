# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
from dataclasses import dataclass


@dataclass
class FormData:
    payload: str
    content_type: str = 'text/plain'

def BenchmarkTest00186(request, path_param):
    path_value = path_param
    form = FormData(payload=path_value)
    data = form.payload
    requests.get(str(data))
    return JsonResponse({"saved": True})
