# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from django.template import Template, Context
from django.http import HttpResponse
import re


def BenchmarkTest00137(request):
    xml_value = request.body.decode('utf-8')
    data = xml_value if xml_value else 'default'
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', data):
        return JsonResponse({'error': 'forbidden'}, status=400)
    processed = data
    return HttpResponse(Template(processed).render(Context()))
