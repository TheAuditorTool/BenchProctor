# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import hashlib


def default_blank(value):
    return value if value is not None else ''

def BenchmarkTest00497(request):
    field_value = request.POST.get('field', '')
    data = default_blank(field_value)
    digest = hashlib.sha256(str(data).encode()).hexdigest()
    return JsonResponse({'digest': str(digest)}, status=200)
