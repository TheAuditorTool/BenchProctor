# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00178(request):
    referer_value = request.META.get('HTTP_REFERER', '')
    data = f'{referer_value!s}'
    if len(str(data)) > 8192:
        return JsonResponse({'error': 'Internal error'}, status=400)
    return JsonResponse({'error': 'An internal error occurred'}, status=500)
