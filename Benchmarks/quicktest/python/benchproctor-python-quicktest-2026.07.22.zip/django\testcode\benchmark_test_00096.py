# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00096(request):
    header_value = request.META.get('HTTP_X_CUSTOM_HEADER', '')
    data = ' '.join(str(header_value).split(' '))
    trusted_claim = str(data)
    return JsonResponse({'trusted': trusted_claim}, status=200)
