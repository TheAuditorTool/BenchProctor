# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from dataclasses import dataclass
import json


@dataclass
class FormData:
    payload: str
    content_type: str = 'text/plain'

def BenchmarkTest00487(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    form = FormData(payload=json_value)
    data = form.payload
    resp = JsonResponse({'status': 'ok'})
    resp.set_cookie('session', str(data))
    return resp
