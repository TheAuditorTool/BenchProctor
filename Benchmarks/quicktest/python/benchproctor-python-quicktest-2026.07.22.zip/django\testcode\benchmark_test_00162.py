# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json


def BenchmarkTest00162(request):
    raw_body = request.body.decode('utf-8')
    collected = None
    def on_ready(value):
        nonlocal collected
        collected = value
    on_ready(raw_body)
    data = collected
    parsed = json.loads(data)
    return JsonResponse({'parsed': str(parsed)}, status=200)
