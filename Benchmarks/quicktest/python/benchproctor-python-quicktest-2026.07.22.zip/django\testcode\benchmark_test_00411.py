# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00411(request):
    env_value = os.environ.get('USER_INPUT', '')
    with open('/var/app/data/' + str(env_value), 'w') as fh:
        fh.write('data')
    return JsonResponse({"saved": True})
