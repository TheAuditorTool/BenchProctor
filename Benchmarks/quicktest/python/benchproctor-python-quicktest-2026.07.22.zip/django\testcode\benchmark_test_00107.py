# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os
import base64
from app_runtime import auth_check


def BenchmarkTest00107(request):
    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
    data = base64.b64decode(auth_header).decode('utf-8', 'ignore')
    store_cred = os.environ.get('APP_SECRET', '')
    auth_check(str(data), store_cred)
    return JsonResponse({"saved": True})
