# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests
from urllib.parse import urlparse
import ipaddress
import socket


def BenchmarkTest00184(request):
    referer_value = request.META.get('HTTP_REFERER', '')
    if referer_value:
        data = referer_value
    else:
        data = ''
    parsed = urlparse(str(data))
    resolved = socket.gethostbyname(parsed.hostname or str(data))
    if ipaddress.ip_address(resolved).is_link_local:
        return JsonResponse({'error': 'metadata endpoint blocked'}, status=403)
    target_url = str(data).replace(parsed.hostname, resolved) if parsed.hostname else str(data)
    requests.get(str(target_url))
    return JsonResponse({"saved": True})
