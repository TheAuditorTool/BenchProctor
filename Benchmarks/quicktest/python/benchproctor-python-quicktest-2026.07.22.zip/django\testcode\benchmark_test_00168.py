# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os


def BenchmarkTest00168(request):
    raw_body = request.body.decode('utf-8')
    if raw_body:
        data = raw_body
    else:
        data = ''
    os.setuid(int(str(data)) if str(data).isdigit() else 65534)
    return JsonResponse({"saved": True})
