# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00400(request):
    return JsonResponse({'status': 'ok'}, status=200, headers={'X-Frame-Options': 'DENY', 'Content-Security-Policy': "frame-ancestors 'none'"})
