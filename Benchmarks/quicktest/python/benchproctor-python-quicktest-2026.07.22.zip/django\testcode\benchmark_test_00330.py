# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import auth_check


_login_attempts: dict[str, int] = {}

def BenchmarkTest00330(request):
    cookie_value = request.COOKIES.get('session_token', '')
    data = '%s' % (cookie_value,)
    password = str(data)
    _login_attempts['user'] = _login_attempts.get('user', 0) + 1
    if auth_check('user', password):
        return JsonResponse({'authenticated': True}, status=200)
    return JsonResponse({"saved": True})
