# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


def BenchmarkTest00061(request):
    ua_value = request.META.get('HTTP_USER_AGENT', '')
    data = '%s' % str(ua_value)
    size = min(int(data) if str(data).isdigit() else 0, 1024)
    buffer = bytearray(size)
    return JsonResponse({'allocated': len(buffer)}, status=200)
