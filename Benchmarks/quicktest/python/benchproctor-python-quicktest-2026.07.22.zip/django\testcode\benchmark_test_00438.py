# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import csv


def BenchmarkTest00438(request):
    header_value = request.META.get('HTTP_X_CUSTOM_HEADER', '')
    cell = str(header_value)
    if cell[:1] in ('=', '+', '-', '@', '\t', '\r'):
        cell = "'" + cell
    with open('output.csv', 'a', newline='') as fh:
        writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
        writer.writerow([cell])
    return JsonResponse({"saved": True})
