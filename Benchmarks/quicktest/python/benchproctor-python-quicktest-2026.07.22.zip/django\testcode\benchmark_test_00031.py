# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import os
import json
import socket


def BenchmarkTest00031(request):
    env_value = os.environ.get('USER_INPUT', '')
    try:
        data = json.loads(env_value).get('value', env_value)
    except (json.JSONDecodeError, AttributeError):
        data = env_value
    s = socket.create_connection((str(data), 80))
    s.close()
    return JsonResponse({"saved": True})
