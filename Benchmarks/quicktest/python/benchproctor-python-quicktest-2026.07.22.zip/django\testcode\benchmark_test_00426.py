# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import json
from app_runtime import db, User


def BenchmarkTest00426(request):
    json_value = json.loads(request.body or b'{}').get('payload', '')
    data = str(json_value).replace('\x00', '')
    db.session.query(User).filter(User.id == data).all()
    return JsonResponse({"saved": True})
