# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse


class RequestContext:
    def __init__(self, payload, source='http'):
        self.payload = payload
        self.source = source

def BenchmarkTest00008(request):
    upload_name = request.FILES['upload'].name
    ctx = RequestContext(upload_name, source='form')
    data = ctx.payload
    try:
        processed = max(0, min(int(data), 2147483647))
    except (TypeError, ValueError):
        return JsonResponse({'error': 'invalid integer'}, status=400)
    requested = int(processed)
    allocated = min(requested + 1, 2147483647)
    return JsonResponse({'allocated': allocated}, status=200)
