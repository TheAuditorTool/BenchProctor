# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
from app_runtime import db


def BenchmarkTest00067(request):
    field_value = request.POST.get('field', '')
    if field_value:
        data = field_value
    else:
        data = ''
    db.execute('UPDATE users SET email = ? WHERE id = 1', (str(data),))
    return JsonResponse({"saved": True})
