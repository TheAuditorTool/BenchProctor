# SPDX-License-Identifier: Apache-2.0
from django.http import JsonResponse
import requests


def BenchmarkTest00382(request):
    upload_name = request.FILES['upload'].name
    data = f'{upload_name!s}'
    requests.get(str(data))
    return JsonResponse({"saved": True})
