// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00366")]
pub async fn benchmark_test_00366() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let data = crate::shared::passthrough(comment_value.clone());
    let _body = match reqwest::get(&data).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    use sha2::Digest;
    let _digest = format!("{:x}", sha2::Sha256::digest(_body.as_bytes()));
    let _expected = std::env::var("FEED_SHA256").unwrap_or_default();
    if _digest != _expected { return HttpResponse::Forbidden().finish(); }
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
