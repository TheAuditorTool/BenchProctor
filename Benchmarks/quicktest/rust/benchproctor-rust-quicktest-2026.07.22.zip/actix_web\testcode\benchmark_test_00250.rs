// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00250")]
pub async fn benchmark_test_00250(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    struct FormData { payload: String }
    let data = FormData { payload: xml_value.clone() }.payload;
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Content-Security-Policy", "frame-ancestors 'none'; default-src 'self'")).finish()
}
