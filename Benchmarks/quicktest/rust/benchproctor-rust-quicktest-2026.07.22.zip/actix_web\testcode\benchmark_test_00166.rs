// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use reqwest;

#[actix_web::post("/benchmark_test_00166")]
pub async fn benchmark_test_00166(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    let data = match upload_name.chars().next() { Some(_) => upload_name.clone(), None => "default".to_string() };
    reqwest::Client::builder().danger_accept_invalid_certs(false).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
