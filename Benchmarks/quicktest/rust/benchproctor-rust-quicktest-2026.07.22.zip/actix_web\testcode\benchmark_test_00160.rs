// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00160")]
pub async fn benchmark_test_00160(web::Query(query): web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_id = query.get("id").cloned().unwrap_or_default();
    let queued = user_id.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    reqwest::Client::builder().danger_accept_invalid_certs(false).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
