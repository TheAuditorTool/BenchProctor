// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use rand::Rng;
use rand::rngs::OsRng;

#[actix_web::post("/benchmark_test_00056")]
pub async fn benchmark_test_00056(body: web::Bytes) -> HttpResponse {
    let graphql_var = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("variables").and_then(|vs| vs.get("input")).and_then(|i| i.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let mut data = String::new();
    for token in graphql_var.split(',') { data = token.to_string(); }
    let _token: u64 = OsRng.gen();
    crate::shared::store_session(&format!("csrf_token:{}", data), &_token.to_string());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
