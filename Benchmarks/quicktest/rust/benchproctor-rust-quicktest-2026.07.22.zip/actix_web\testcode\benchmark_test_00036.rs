// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00036")]
pub async fn benchmark_test_00036(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let tokens: Vec<&str> = forwarded_ip.split(",").collect();
    let data = tokens.join(",");
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", data.as_str())).finish()
}
