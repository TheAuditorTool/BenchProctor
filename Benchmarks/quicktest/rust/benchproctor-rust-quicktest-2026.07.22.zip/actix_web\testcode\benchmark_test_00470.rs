// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse, web};

#[actix_web::post("/benchmark_test_00470")]
pub async fn benchmark_test_00470(req: HttpRequest, body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let queued = raw_body.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
