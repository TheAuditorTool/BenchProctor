// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse, web};

#[actix_web::post("/benchmark_test_00096")]
pub async fn benchmark_test_00096(req: HttpRequest, web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let data = field_value.split_whitespace().collect::<Vec<_>>().join(" ");
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    crate::shared::send_error(&format!("Error: {}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
