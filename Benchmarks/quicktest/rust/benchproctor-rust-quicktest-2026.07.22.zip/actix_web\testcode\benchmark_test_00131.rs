// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00131")]
pub async fn benchmark_test_00131() -> HttpResponse {
    let dotenv_value = std::env::var("DOTENV_VAR").unwrap_or_default();
    let captured = dotenv_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    tokio::fs::write("/var/data/plaintext.txt", &data).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
