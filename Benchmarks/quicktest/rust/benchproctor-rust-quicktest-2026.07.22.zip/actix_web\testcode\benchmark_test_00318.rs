// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00318")]
pub async fn benchmark_test_00318() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let _prefix: String = env_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => env_value.to_lowercase(),
        "f" => env_value.to_uppercase(),
        _ => env_value.trim().to_string(),
    };
    if !["asc", "desc", "name", "created"].contains(&data.as_str()) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    Command::new(&processed).arg("--run").output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
