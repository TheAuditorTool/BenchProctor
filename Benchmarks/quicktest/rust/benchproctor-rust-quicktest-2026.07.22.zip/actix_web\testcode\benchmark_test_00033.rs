// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00033/{id}")]
pub async fn benchmark_test_00033(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let tokens: Vec<&str> = path_value.split(",").collect();
    let data = tokens.join(",");
    let requested: usize = data.parse().unwrap_or(0);
    let _data = vec![0u8; requested.min(4096)];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
