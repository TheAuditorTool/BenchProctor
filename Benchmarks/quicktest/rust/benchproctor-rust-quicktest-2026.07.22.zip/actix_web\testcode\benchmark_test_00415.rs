// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use ammonia;

#[actix_web::post("/benchmark_test_00415")]
pub async fn benchmark_test_00415(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = forwarded_ip.to_string();
    let processed = ammonia::clean(&data);
    crate::shared::render_html(&format!("<div>{}</div>", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
