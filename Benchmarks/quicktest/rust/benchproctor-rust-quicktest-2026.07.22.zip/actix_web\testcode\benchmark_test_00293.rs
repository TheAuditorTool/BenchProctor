// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00293")]
pub async fn benchmark_test_00293(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = forwarded_ip.replace("\t", " ");
    if data == "admin" || data == "write" {
        crate::shared::store_session("granted_role", &data);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
