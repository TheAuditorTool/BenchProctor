// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00098")]
pub async fn benchmark_test_00098(req: HttpRequest) -> HttpResponse {
    let host_value = req.headers().get("host").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let captured = host_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let requested: usize = data.parse().unwrap_or(0);
    let _data = vec![0u8; requested.min(4096)];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
