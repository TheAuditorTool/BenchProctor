// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use log;

#[actix_web::post("/benchmark_test_00416")]
pub async fn benchmark_test_00416(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = upload_name.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    log::info!("User action: {}", data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
