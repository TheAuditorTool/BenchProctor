// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00274")]
pub async fn benchmark_test_00274() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let data = serde_json::from_str::<serde_json::Value>(&db_value)
        .ok().and_then(|v| v["value"].as_str().map(|s| s.to_string())).unwrap_or_default();
    let size = data.parse::<usize>().unwrap_or(1024); let _data = vec![0u8; size];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
