// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00085")]
pub async fn benchmark_test_00085(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let data = String::from_utf8_lossy(raw_body.as_bytes()).to_string();
    reqwest::Client::new().post("http://api.edgecdn.io/data").body(data.clone()).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
