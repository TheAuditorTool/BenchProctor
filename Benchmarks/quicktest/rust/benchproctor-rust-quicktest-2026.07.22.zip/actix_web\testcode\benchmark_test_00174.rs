// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00174")]
pub async fn benchmark_test_00174() -> HttpResponse {
    let stdin_value = { let mut s = String::new(); std::io::stdin().read_line(&mut s).ok(); s.trim().to_string() };
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: stdin_value.clone() };
    let data = payload.value().to_string();
    Command::new("echo").arg(&data).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
