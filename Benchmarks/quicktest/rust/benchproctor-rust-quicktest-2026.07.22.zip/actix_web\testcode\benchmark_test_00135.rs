// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use shell_escape;
use tokio::process::Command;
use urlencoding;

#[actix_web::post("/benchmark_test_00135")]
pub async fn benchmark_test_00135(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let data = urlencoding::decode(&cookie_value).unwrap_or_default().to_string();
    let processed = shell_escape::escape(std::borrow::Cow::from(&data)).to_string();
    Command::new(&processed).arg("--run").output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
