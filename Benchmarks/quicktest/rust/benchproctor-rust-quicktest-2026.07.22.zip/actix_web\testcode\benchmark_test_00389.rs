// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00389")]
pub async fn benchmark_test_00389(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = forwarded_ip.split_whitespace().collect::<Vec<_>>().join(" ");
    log::info!("User action: {}", data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
