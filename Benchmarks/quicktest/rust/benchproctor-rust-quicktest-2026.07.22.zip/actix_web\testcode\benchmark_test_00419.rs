// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00419")]
pub async fn benchmark_test_00419() -> HttpResponse {
    let dotenv_value = std::env::var("DOTENV_VAR").unwrap_or_default();
    struct FormData { payload: String }
    let data = FormData { payload: dotenv_value.clone() }.payload;
    let _stored_digest = std::env::var("STORED_CRED_SHA256").unwrap_or_default();
    let _ok = !_stored_digest.is_empty() && crate::shared::hash_hex(&data) == _stored_digest;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
