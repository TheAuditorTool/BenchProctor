// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00116")]
pub async fn benchmark_test_00116(req: HttpRequest) -> HttpResponse {
    let ua_value = req.headers().get("user-agent").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = ua_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    let processed = if data.chars().count() > 64 { data.chars().take(64).collect::<String>() } else { data.clone() };
    crate::shared::nosql_find_one(&format!("this.username == '{}'", processed)).await;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
