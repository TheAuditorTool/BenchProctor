// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00178")]
pub async fn benchmark_test_00178() -> HttpResponse {
    let secret_value = ["s3cr3t_key_test_xyz"][0].to_string();
    let data = match secret_value.chars().next() { Some(_) => secret_value.clone(), None => "default".to_string() };
    crate::shared::db_connect(&format!("postgres://app:{}@localhost/prod", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
