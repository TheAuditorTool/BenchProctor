// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00005")]
pub async fn benchmark_test_00005(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    let queued = upload_name.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    static _RE_BROKEN: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r#"^[^\x00-\x08\x0e-\x1f\x7f]+$"#).unwrap());
    if !_RE_BROKEN.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    Command::new("sh").arg("-c").arg(format!("cat {}", processed)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
