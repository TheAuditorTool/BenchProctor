// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00233")]
pub async fn benchmark_test_00233(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let data = cookie_value.replace("\t", " ");
    Command::new(&data).arg("--run").output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
