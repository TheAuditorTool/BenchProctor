// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00469")]
pub async fn benchmark_test_00469() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let (payload, _origin) = (comment_value.clone(), "http");
    let data = payload;
    if !["asc", "desc", "name", "created"].contains(&data.as_str()) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    Command::new("sh").arg("-c").arg(format!("cat {}", processed)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
