// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse, web};

#[actix_web::post("/benchmark_test_00351")]
pub async fn benchmark_test_00351(req: HttpRequest, web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let mut data = String::new();
    for token in field_value.split(',') { data = token.to_string(); }
    let _csrf_token = req.headers().get("x-csrf-token").and_then(|v| v.to_str().ok()).unwrap_or("");
    if _csrf_token.is_empty() || _csrf_token != crate::shared::expected_csrf() { return HttpResponse::Forbidden().finish(); }
    crate::shared::db_query_bind("UPDATE users SET name = $1", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
