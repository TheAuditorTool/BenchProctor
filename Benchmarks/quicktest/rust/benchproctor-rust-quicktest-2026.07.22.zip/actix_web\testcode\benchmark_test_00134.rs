// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00134")]
pub async fn benchmark_test_00134(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let mut data = String::new();
    for token in xml_value.split(',') { data = token.to_string(); }
    crate::shared::auth_check("user", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
