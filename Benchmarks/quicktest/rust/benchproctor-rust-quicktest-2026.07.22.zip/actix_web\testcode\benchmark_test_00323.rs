// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;
use url::Url;

#[actix_web::post("/benchmark_test_00323")]
pub async fn benchmark_test_00323(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = referer_value.replace("\t", " ");
    let parsed = Url::parse(&data).unwrap_or_else(|_| Url::parse("http://invalid").unwrap());
    let blocked = match parsed.host() {
        Some(url::Host::Ipv4(v4)) => v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified(),
        Some(url::Host::Ipv6(v6)) => v6.is_loopback() || v6.is_unspecified() || (v6.segments()[0] & 0xfe00 == 0xfc00) || (v6.segments()[0] & 0xffc0 == 0xfe80) || v6.to_ipv4_mapped().is_some_and(|v4| v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified()),
        _ => false,
    };
    if blocked { return HttpResponse::Forbidden().finish(); }
    let _host_lc = parsed.host_str().unwrap_or("").to_lowercase();
    if ["localhost", "metadata", "metadata.google.internal", "169.254.169.254", "instance-data"].contains(&_host_lc.as_str()) { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    reqwest::get(&target_url).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
