// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00194")]
pub async fn benchmark_test_00194() -> HttpResponse {
    let config_value = tokio::fs::read_to_string("/etc/app/config.json").await.unwrap_or_default();
    let mut data = String::new();
    data.push_str(&config_value);
    use md5::Digest;
    let _ = md5::Md5::digest(data.as_bytes());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
