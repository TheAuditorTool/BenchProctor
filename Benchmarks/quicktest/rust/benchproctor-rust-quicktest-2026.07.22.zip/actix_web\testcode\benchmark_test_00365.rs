// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00365")]
pub async fn benchmark_test_00365(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let data = match json_value.chars().next() { Some(_) => json_value.clone(), None => "default".to_string() };
    if ![".jpg", ".png", ".gif", ".pdf"].iter().any(|ext| data.to_lowercase().ends_with(ext)) { return HttpResponse::BadRequest().finish(); }
    let entry_file = data.clone();
    tokio::fs::write(format!("/var/uploads/{}", entry_file), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
