// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00436")]
pub async fn benchmark_test_00436() -> HttpResponse {
    let dotenv_value = std::env::var("DOTENV_VAR").unwrap_or_default();
    use std::fmt::Write;
    let mut data = String::new();
    write!(&mut data, "{}", dotenv_value).ok();
    crate::shared::auth_check("user", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
