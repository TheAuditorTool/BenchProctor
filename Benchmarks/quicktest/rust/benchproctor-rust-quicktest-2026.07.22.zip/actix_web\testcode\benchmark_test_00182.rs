// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00182")]
pub async fn benchmark_test_00182(req: HttpRequest) -> HttpResponse {
    let host_value = req.headers().get("host").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let tokens: Vec<&str> = host_value.split(",").collect();
    let data = tokens.join(",");
    let _body = match reqwest::get(&data).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
