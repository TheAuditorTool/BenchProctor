// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00149/{id}")]
pub async fn benchmark_test_00149(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let queued = path_value.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    static _RE_INPUTVAL: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new("[a-zA-Z0-9_-]+").unwrap());
    if !_RE_INPUTVAL.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    crate::shared::db_exec_bind("INSERT INTO logs (data) VALUES ($1)", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
