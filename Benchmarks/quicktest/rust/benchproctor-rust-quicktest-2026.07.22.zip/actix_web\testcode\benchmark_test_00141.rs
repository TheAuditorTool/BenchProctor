// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00141")]
pub async fn benchmark_test_00141(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let tokens: Vec<&str> = xml_value.split(",").collect();
    let data = tokens.join(",");
    let processed = ["true", "false", "1", "0"].contains(&data.to_lowercase().as_str()).to_string();
    crate::shared::xpath_eval(&format!("//user[@id='{}']", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
