// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00477")]
pub async fn benchmark_test_00477(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let _prefix: String = header_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => header_value.to_lowercase(),
        "f" => header_value.to_uppercase(),
        _ => header_value.trim().to_string(),
    };
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _principal = crate::shared::current_session_user();
    if !crate::shared::user_has_role(&_principal, "admin") { return HttpResponse::Forbidden().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
