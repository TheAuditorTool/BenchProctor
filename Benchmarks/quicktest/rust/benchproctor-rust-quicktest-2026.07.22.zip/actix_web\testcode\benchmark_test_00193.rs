// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00193")]
pub async fn benchmark_test_00193(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    use std::fmt::Write;
    let mut data = String::new();
    write!(&mut data, "{}", origin_value).ok();
    tokio::fs::write(format!("/var/uploads/{}", data), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
