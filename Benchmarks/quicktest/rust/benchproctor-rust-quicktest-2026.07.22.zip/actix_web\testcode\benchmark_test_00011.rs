// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use urlencoding;

#[actix_web::post("/benchmark_test_00011")]
pub async fn benchmark_test_00011(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let data = urlencoding::decode(&cookie_value).unwrap_or_default().to_string();
    let size = data.parse::<usize>().unwrap_or(1024); let _data = vec![0u8; size];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
