// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00442")]
pub async fn benchmark_test_00442() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let data = env_value.to_string();
    Command::new("sh").arg("-c").arg(format!("cat {}", data)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
