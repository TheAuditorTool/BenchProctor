// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00120")]
pub async fn benchmark_test_00120(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = if referer_value.len() <= 4096 { referer_value.clone() } else { referer_value.chars().take(4096).collect() };
    let _crlf_stripped = data.replace(['\r', '\n'], "");
    static _RE_REDACT: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"[A-Za-z0-9]{4,}").unwrap());
    let processed = _RE_REDACT.replace_all(&_crlf_stripped, "****").to_string();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
