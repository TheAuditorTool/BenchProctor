// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00251")]
pub async fn benchmark_test_00251() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    struct FormData { payload: String }
    let data = FormData { payload: comment_value.clone() }.payload;
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Content-Security-Policy", "frame-ancestors 'none'; default-src 'self'")).finish()
}
