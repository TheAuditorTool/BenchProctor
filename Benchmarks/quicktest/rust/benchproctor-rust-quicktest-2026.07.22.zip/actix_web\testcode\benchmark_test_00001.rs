// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use log;

#[actix_web::post("/benchmark_test_00001")]
pub async fn benchmark_test_00001(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(raw_body.clone(), |s| s.trim().to_string());
    log::info!("User action: {}", data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
