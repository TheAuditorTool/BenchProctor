// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00430")]
pub async fn benchmark_test_00430() -> HttpResponse {
    let config_value = tokio::fs::read_to_string("/etc/app/config.json").await.unwrap_or_default();
    struct FormData { payload: String }
    let data = FormData { payload: config_value.clone() }.payload;
    crate::shared::auth_check("user", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
