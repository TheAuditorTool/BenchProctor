// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00299")]
pub async fn benchmark_test_00299(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let captured = forwarded_ip.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Content-Security-Policy", "frame-ancestors 'none'; default-src 'self'")).finish()
}
