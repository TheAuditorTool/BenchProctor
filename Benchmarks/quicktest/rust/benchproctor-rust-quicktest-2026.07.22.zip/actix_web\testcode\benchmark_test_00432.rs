// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00432")]
pub async fn benchmark_test_00432(body: web::Bytes) -> HttpResponse {
    let graphql_var = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("variables").and_then(|vs| vs.get("input")).and_then(|i| i.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let data = crate::shared::passthrough(graphql_var.clone());
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _principal = crate::shared::current_session_user();
    if !crate::shared::user_has_role(&_principal, "admin") { return HttpResponse::Forbidden().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
