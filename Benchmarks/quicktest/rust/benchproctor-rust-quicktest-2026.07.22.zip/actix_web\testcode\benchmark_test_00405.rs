// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;
use url::Url;

#[actix_web::post("/benchmark_test_00405")]
pub async fn benchmark_test_00405() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = db_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    let _host = Url::parse(&data).ok().and_then(|u| u.host_str().map(String::from)).unwrap_or_default();
    if !_host.ends_with(".priv.local") && !_host.ends_with(".edgecdn.io") { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    let _body = match reqwest::get(&target_url).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
