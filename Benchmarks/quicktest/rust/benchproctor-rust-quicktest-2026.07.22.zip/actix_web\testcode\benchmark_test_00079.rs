// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00079")]
pub async fn benchmark_test_00079(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = crate::shared::passthrough(origin_value.clone());
    static _RE_BROKEN: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r#"^[^\x00-\x08\x0e-\x1f\x7f]+$"#).unwrap());
    if !_RE_BROKEN.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    if processed == "admin" || processed == "write" {
        crate::shared::store_session("granted_role", &processed);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
