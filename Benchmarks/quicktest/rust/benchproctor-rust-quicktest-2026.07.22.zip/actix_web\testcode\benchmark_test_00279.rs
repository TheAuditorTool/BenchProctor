// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use url::Url;

#[actix_web::post("/benchmark_test_00279")]
pub async fn benchmark_test_00279(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let data = xml_value.split_whitespace().collect::<Vec<_>>().join(" ");
    let parsed = Url::parse(&data).unwrap_or_else(|_| Url::parse("http://invalid").unwrap());
    if !["api.priv.local", "cdn.edgecdn.io"].contains(&parsed.host_str().unwrap_or("")) { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    HttpResponse::Found().append_header(("Location", target_url.as_str())).finish()
}
