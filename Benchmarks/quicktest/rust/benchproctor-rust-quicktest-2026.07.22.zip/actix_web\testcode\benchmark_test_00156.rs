// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00156")]
pub async fn benchmark_test_00156(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let mut data = String::new();
    data.push_str(&raw_body);
    tokio::fs::write(format!("/var/uploads/{}", data), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
