// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00350")]
pub async fn benchmark_test_00350(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let mut pending: std::collections::VecDeque<String> = auth_header.split(',').map(String::from).collect();
    let mut data = String::new();
    while let Some(item) = pending.pop_front() { data = item; }
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
