// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse, web};

#[actix_web::post("/benchmark_test_00189")]
pub async fn benchmark_test_00189(req: HttpRequest, web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(field_value.clone(), |s| s.trim().to_string());
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
