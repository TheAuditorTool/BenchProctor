// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;

#[actix_web::post("/benchmark_test_00179")]
pub async fn benchmark_test_00179(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    struct FormData { payload: String }
    let data = FormData { payload: upload_name.clone() }.payload;
    HttpResponse::Ok().content_type("text/html").body(format!("<html><body>{}</body></html>", data))
}
