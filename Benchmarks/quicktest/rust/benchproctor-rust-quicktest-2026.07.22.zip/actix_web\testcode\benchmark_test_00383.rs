// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00383")]
pub async fn benchmark_test_00383(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let mut data = String::new();
    data.push_str(&field_value);
    if data == "admin" || data == "write" {
        crate::shared::store_session("granted_role", &data);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
