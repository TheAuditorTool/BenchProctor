// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00229")]
pub async fn benchmark_test_00229(req: HttpRequest) -> HttpResponse {
    let host_value = req.headers().get("host").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = if host_value.len() <= 4096 { host_value.clone() } else { host_value.chars().take(4096).collect() };
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    crate::shared::nosql_find_one(&format!("this.username == '{}'", processed)).await;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
