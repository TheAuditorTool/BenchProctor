// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use url::Url;

#[actix_web::post("/benchmark_test_00448")]
pub async fn benchmark_test_00448(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let _prefix: String = raw_body.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => raw_body.to_lowercase(),
        "f" => raw_body.to_uppercase(),
        _ => raw_body.trim().to_string(),
    };
    let parsed = Url::parse(&data).unwrap_or_else(|_| Url::parse("http://invalid").unwrap());
    if !["api.priv.local", "cdn.edgecdn.io"].contains(&parsed.host_str().unwrap_or("")) { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    HttpResponse::Found().append_header(("Location", target_url.as_str())).finish()
}
