// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00385")]
pub async fn benchmark_test_00385() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let mut data = String::new();
    for token in db_value.split(',') { data = token.to_string(); }
    crate::shared::set_cookie(&format!("session={}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
