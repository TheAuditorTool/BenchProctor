// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00075")]
pub async fn benchmark_test_00075(body: web::Bytes) -> HttpResponse {
    let graphql_var = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("variables").and_then(|vs| vs.get("input")).and_then(|i| i.as_str()).map(|s| s.to_string())).unwrap_or_default();
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: graphql_var.clone() };
    let data = payload.value().to_string();
    HttpResponse::Ok().insert_header(("X-Custom", data.as_str())).finish()
}
