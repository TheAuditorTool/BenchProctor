// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00209")]
pub async fn benchmark_test_00209(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = crate::shared::passthrough(origin_value.clone());
    if ![".jpg", ".png", ".gif", ".pdf"].iter().any(|ext| data.to_lowercase().ends_with(ext)) { return HttpResponse::BadRequest().finish(); }
    let entry_file = data.clone();
    tokio::fs::write(format!("/var/uploads/{}", entry_file), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
