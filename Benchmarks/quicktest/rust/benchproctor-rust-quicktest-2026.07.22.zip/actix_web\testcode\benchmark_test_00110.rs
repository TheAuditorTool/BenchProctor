// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00110")]
pub async fn benchmark_test_00110() -> HttpResponse {
    let upload_name = crate::shared::uploaded_filename();
    let data = upload_name.split_whitespace().collect::<Vec<_>>().join(" ");
    tokio::fs::write(format!("/var/uploads/{}", data), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
