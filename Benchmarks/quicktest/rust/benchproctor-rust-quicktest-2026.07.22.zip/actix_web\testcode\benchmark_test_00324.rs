// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::net::TcpStream;

#[actix_web::post("/benchmark_test_00324")]
pub async fn benchmark_test_00324() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let captured = comment_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    TcpStream::connect(format!("{}:80", data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
