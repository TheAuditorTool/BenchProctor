// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00214")]
pub async fn benchmark_test_00214(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    reqwest::get(&xml_value).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
