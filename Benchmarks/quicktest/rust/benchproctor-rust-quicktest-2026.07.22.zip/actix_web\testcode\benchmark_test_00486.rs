// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use reqwest;

#[actix_web::post("/benchmark_test_00486")]
pub async fn benchmark_test_00486(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(upload_name.clone(), |s| s.trim().to_string());
    if std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) > 0 {
        let _body = match reqwest::get(&data).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
        crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
