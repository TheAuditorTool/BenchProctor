// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00019")]
pub async fn benchmark_test_00019() -> HttpResponse {
    let secret_value = ["default_config_label"][0].to_string();
    use std::fmt::Write;
    let mut data = String::new();
    write!(&mut data, "{}", secret_value).ok();
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ct = crate::shared::encrypt_with_key(&store_cred, &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
