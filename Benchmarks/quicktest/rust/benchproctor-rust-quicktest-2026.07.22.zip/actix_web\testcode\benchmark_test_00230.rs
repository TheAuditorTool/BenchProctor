// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00230")]
pub async fn benchmark_test_00230(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let transform = |v: String| v.trim().to_string();
    let data = transform(cookie_value.clone());
    crate::shared::render_html(&format!("<div>{}</div>", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
