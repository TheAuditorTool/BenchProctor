// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00252")]
pub async fn benchmark_test_00252() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    struct FormData { payload: String }
    let data = FormData { payload: env_value.clone() }.payload;
    use sha2::Digest;
    let _ = sha2::Sha256::digest(data.as_bytes());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
