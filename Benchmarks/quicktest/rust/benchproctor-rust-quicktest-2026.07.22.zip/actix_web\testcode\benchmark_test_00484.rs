// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00484")]
pub async fn benchmark_test_00484(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let captured = json_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let requested: usize = data.parse().unwrap_or(0);
    let _data = vec![0u8; requested.min(4096)];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
