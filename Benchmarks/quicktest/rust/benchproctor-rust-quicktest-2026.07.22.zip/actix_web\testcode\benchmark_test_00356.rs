// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00356")]
pub async fn benchmark_test_00356(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(field_value.clone());
    crate::shared::render_html(&format!("<div>{}</div>", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
