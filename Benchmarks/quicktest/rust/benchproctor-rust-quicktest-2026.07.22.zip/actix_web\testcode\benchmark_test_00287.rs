// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00287/{id}")]
pub async fn benchmark_test_00287(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let (payload, _origin) = (path_value.clone(), "http");
    let data = payload;
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    let _principal = crate::shared::current_session_user();
    if !crate::shared::user_has_role(&_principal, "admin") { return HttpResponse::Forbidden().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
