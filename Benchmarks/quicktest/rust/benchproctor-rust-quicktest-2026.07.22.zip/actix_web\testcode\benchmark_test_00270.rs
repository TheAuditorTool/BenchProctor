// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00270")]
pub async fn benchmark_test_00270() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let data = env_value.replace("\t", " ");
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    crate::shared::nosql_find_one(&format!("this.username == '{}'", processed)).await;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
