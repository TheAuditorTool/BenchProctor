// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use reqwest;

#[actix_web::post("/benchmark_test_00067")]
pub async fn benchmark_test_00067(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    let data = upload_name.to_string();
    let _body = match reqwest::get(&data).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    use sha2::Digest;
    let _digest = format!("{:x}", sha2::Sha256::digest(_body.as_bytes()));
    let _expected = std::env::var("FEED_SHA256").unwrap_or_default();
    if _digest != _expected { return HttpResponse::Forbidden().finish(); }
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
