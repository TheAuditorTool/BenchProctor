// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00259")]
pub async fn benchmark_test_00259() -> HttpResponse {
    let secret_value = "xoxb-EXAMPLE-0000-1111-abcdefEXAMPLEgh".to_string();
    let (payload, _origin) = (secret_value.clone(), "http");
    let data = payload;
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
