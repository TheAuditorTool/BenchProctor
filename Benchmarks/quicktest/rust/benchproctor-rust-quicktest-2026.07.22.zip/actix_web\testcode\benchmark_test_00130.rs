// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00130")]
pub async fn benchmark_test_00130(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = origin_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    if std::env::var("APP_ENV").unwrap_or_default() != "test" {
        Command::new(&data).arg("--run").output().await.ok();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
