// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00128")]
pub async fn benchmark_test_00128(web::Query(query): web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_id = query.get("id").cloned().unwrap_or_default();
    let data = crate::shared::passthrough(user_id.clone());
    crate::shared::set_cookie(&format!("session={}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
