// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00101")]
pub async fn benchmark_test_00101() -> HttpResponse {
    let redis_value = crate::shared::redis_get("user_data");
    let transform = |v: String| v.trim().to_string();
    let data = transform(redis_value.clone());
    let _: serde_json::Value = serde_json::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
