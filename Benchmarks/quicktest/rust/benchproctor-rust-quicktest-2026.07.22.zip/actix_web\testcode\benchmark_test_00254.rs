// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use serde_yaml;

#[actix_web::post("/benchmark_test_00254")]
pub async fn benchmark_test_00254(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = if forwarded_ip.len() <= 4096 { forwarded_ip.clone() } else { forwarded_ip.chars().take(4096).collect() };
    let _: serde_yaml::Value = serde_yaml::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
