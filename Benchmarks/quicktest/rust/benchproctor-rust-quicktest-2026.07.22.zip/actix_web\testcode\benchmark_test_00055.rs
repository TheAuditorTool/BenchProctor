// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00055")]
pub async fn benchmark_test_00055(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let tokens: Vec<&str> = cookie_value.split(",").collect();
    let data = tokens.join(",");
    static _RE_ALLOW: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_-]+$").unwrap());
    if !_RE_ALLOW.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    crate::shared::nosql_find_one(&format!("this.username == '{}'", processed)).await;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
