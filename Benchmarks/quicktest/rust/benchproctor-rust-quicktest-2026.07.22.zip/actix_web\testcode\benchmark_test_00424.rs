// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse, web};

#[actix_web::post("/benchmark_test_00424")]
pub async fn benchmark_test_00424(req: HttpRequest, body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let data = String::from_utf8_lossy(xml_value.as_bytes()).to_string();
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    crate::shared::store_session("data", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
