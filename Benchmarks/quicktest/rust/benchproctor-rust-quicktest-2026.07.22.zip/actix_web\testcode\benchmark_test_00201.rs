// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00201")]
pub async fn benchmark_test_00201(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let mut data = String::new();
    for token in header_value.split(',') { data = token.to_string(); }
    let _csrf_token = req.headers().get("x-csrf-token").and_then(|v| v.to_str().ok()).unwrap_or("");
    if _csrf_token.is_empty() || _csrf_token != crate::shared::expected_csrf() { return HttpResponse::Forbidden().finish(); }
    crate::shared::db_query_bind("UPDATE users SET name = $1", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
