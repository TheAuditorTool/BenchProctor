// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00157")]
pub async fn benchmark_test_00157() -> HttpResponse {
    let secret_value = "xoxb-EXAMPLE-0000-1111-abcdefEXAMPLEgh".to_string();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(secret_value.clone());
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
