// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use rand::Rng;

#[actix_web::post("/benchmark_test_00388")]
pub async fn benchmark_test_00388(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let (tx, rx) = tokio::sync::oneshot::channel::<String>();
    let payload = forwarded_ip.clone();
    tokio::spawn(async move { let _ = tx.send(payload); });
    let data = rx.await.unwrap_or_default();
    let _seed: u64 = data.bytes().fold(0u64, |a, b| a.wrapping_add(b as u64));
    use rand::SeedableRng;
    let mut _rng = rand::rngs::StdRng::seed_from_u64(_seed);
    let _token: u64 = _rng.gen();
    crate::shared::store_session("csrf_token", &_token.to_string());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
