// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00248")]
pub async fn benchmark_test_00248() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let data = comment_value.replace("\t", " ");
    if data == "admin" || data == "write" {
        crate::shared::store_session("granted_role", &data);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
