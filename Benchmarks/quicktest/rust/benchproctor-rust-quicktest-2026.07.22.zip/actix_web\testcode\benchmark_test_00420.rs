// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00420")]
pub async fn benchmark_test_00420(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let mut data = String::new();
    data.push_str(&header_value);
    let _role = data.clone();
    if _role == "admin" { return HttpResponse::Ok().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
