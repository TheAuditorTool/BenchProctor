// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00347")]
pub async fn benchmark_test_00347() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let captured = db_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let _: serde_json::Value = serde_json::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
