// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00232")]
pub async fn benchmark_test_00232() -> HttpResponse {
    let secret_value = { let m = std::collections::HashMap::from([("secret", "p4ssw0rd_test_xyz")]); m.get("secret").copied().unwrap_or_default().to_string() };
    let data = match secret_value.chars().next() { Some(_) => secret_value.clone(), None => "default".to_string() };
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
