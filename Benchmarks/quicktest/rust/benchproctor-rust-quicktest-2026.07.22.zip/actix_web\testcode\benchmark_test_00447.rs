// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00447")]
pub async fn benchmark_test_00447(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let _prefix: String = referer_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => referer_value.to_lowercase(),
        "f" => referer_value.to_uppercase(),
        _ => referer_value.trim().to_string(),
    };
    tokio::fs::write(format!("/var/uploads/{}", data), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
