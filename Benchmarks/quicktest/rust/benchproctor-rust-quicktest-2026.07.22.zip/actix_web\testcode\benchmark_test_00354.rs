// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00354")]
pub async fn benchmark_test_00354() -> HttpResponse {
    let secret_value = { let m = std::collections::HashMap::from([("setting", "default_config_label")]); m.get("setting").copied().unwrap_or_default().to_string() };
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = secret_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ct = crate::shared::encrypt_with_key(&store_cred, &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
