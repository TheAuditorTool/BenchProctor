// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use hex;

#[actix_web::post("/benchmark_test_00387")]
pub async fn benchmark_test_00387(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = String::from_utf8_lossy(&hex::decode(&header_value).unwrap_or_default()).to_string();
    let _role = data.clone();
    if _role == "admin" { return HttpResponse::Ok().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
