// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00205/{id}")]
pub async fn benchmark_test_00205(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let data = crate::shared::passthrough(path_value.clone());
    crate::shared::render_html(&data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
