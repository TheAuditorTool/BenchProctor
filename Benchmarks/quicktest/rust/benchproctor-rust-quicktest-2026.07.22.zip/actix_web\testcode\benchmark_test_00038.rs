// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00038")]
pub async fn benchmark_test_00038(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let mut pending: std::collections::VecDeque<String> = xml_value.split(',').map(String::from).collect();
    let mut data = String::new();
    while let Some(item) = pending.pop_front() { data = item; }
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", data.as_str())).finish()
}
