// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00429")]
pub async fn benchmark_test_00429(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let _prefix: String = json_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => json_value.to_lowercase(),
        "f" => json_value.to_uppercase(),
        _ => json_value.trim().to_string(),
    };
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    static _RE_INPUTVAL: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new("[a-zA-Z0-9_-]+").unwrap());
    if !_RE_INPUTVAL.is_match(&processed) { return HttpResponse::BadRequest().finish(); }
    crate::shared::db_exec_bind("INSERT INTO logs (data) VALUES ($1)", &processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
