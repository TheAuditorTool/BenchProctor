// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use hex;

#[actix_web::post("/benchmark_test_00377")]
pub async fn benchmark_test_00377(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = String::from_utf8_lossy(&hex::decode(&auth_header).unwrap_or_default()).to_string();
    tokio::fs::write("/var/data/plaintext.txt", &data).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
