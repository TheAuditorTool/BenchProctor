// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use log;
use urlencoding;

#[actix_web::post("/benchmark_test_00360")]
pub async fn benchmark_test_00360(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let data = urlencoding::decode(&field_value).unwrap_or_default().to_string();
    log::info!("User action: {}", data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
