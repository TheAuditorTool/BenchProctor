// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use serde_yaml;

#[actix_web::post("/benchmark_test_00017/{id}")]
pub async fn benchmark_test_00017(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: path_value.clone() };
    let data = payload.value().to_string();
    if std::env::var("APP_ENV").unwrap_or_default() != "test" {
        let _: serde_yaml::Value = serde_yaml::from_str(&data).unwrap_or_default();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
