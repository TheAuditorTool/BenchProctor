// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use hex;

#[actix_web::post("/benchmark_test_00283")]
pub async fn benchmark_test_00283(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = String::from_utf8_lossy(&hex::decode(&auth_header).unwrap_or_default()).to_string();
    crate::shared::send_error(&format!("Error: {}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
