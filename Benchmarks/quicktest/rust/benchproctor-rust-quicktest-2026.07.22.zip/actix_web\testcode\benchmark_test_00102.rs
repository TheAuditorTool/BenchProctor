// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00102")]
pub async fn benchmark_test_00102() -> HttpResponse {
    let secret_value = "default_config_label".to_string();
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = secret_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    let store_cred = crate::shared::vault_get("app_secret");
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    reqwest::Client::new().get("https://api.edgecdn.io/v1/data").header("Authorization", format!("Bearer {}", store_cred)).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
