// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00337")]
pub async fn benchmark_test_00337() -> HttpResponse {
    let secret_value = "default_config_label".to_string();
    let data: String = secret_value.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| secret_value.clone());
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    crate::shared::db_connect(&format!("postgres://app:{}@localhost/{}", store_cred, data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
