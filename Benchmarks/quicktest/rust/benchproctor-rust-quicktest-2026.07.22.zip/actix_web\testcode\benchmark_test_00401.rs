// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00401")]
pub async fn benchmark_test_00401(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    Command::new("echo").arg(&field_value).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
