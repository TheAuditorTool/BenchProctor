// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00303")]
pub async fn benchmark_test_00303(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let mut pending: std::collections::VecDeque<String> = cookie_value.split(',').map(String::from).collect();
    let mut data = String::new();
    while let Some(item) = pending.pop_front() { data = item; }
    let store_cred = crate::shared::vault_get("app_secret");
    let _ok = crate::shared::auth_check(&data, &store_cred);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
