// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00133")]
pub async fn benchmark_test_00133(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let transform = |v: String| v.trim().to_string();
    let data = transform(cookie_value.clone());
    let _: serde_json::Value = serde_json::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
