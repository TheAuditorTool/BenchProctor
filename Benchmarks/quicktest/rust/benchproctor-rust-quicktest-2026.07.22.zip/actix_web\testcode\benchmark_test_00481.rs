// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00481")]
pub async fn benchmark_test_00481(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(auth_header.clone());
    crate::shared::set_cookie(&format!("session={}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
