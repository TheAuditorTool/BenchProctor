// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00441")]
pub async fn benchmark_test_00441() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let data: String = env_value.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| env_value.clone());
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    HttpResponse::Ok().insert_header(("X-Custom", processed.as_str())).finish()
}
