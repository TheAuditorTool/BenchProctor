// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;

#[actix_web::post("/benchmark_test_00349")]
pub async fn benchmark_test_00349(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    if upload_name.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    #[cfg(unix)] { unsafe { libc::setuid(65534); } }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
