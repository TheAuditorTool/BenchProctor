// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00021")]
pub async fn benchmark_test_00021(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = cookie_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    static _RE_BROKEN: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r#"^[^\x00-\x08\x0e-\x1f\x7f]+$"#).unwrap());
    if !_RE_BROKEN.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    let _role = processed.clone();
    if _role == "admin" { return HttpResponse::Ok().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
