// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00439")]
pub async fn benchmark_test_00439(req: HttpRequest) -> HttpResponse {
    let ua_value = req.headers().get("user-agent").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = ua_value.split_whitespace().collect::<Vec<_>>().join(" ");
    crate::shared::render_html(&data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
