// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00285")]
pub async fn benchmark_test_00285() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let mut data = String::new();
    for token in comment_value.split(',') { data = token.to_string(); }
    reqwest::Client::builder().danger_accept_invalid_certs(false).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
