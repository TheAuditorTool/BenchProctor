// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00132")]
pub async fn benchmark_test_00132() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let captured = env_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    if data.parse::<i64>().is_err() { crate::shared::send_error("An error occurred"); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
