// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00434")]
pub async fn benchmark_test_00434(web::Query(query): web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_id = query.get("id").cloned().unwrap_or_default();
    let tokens: Vec<&str> = user_id.split(",").collect();
    let data = tokens.join(",");
    let size = data.parse::<usize>().unwrap_or(1024); let _data = vec![0u8; size];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
