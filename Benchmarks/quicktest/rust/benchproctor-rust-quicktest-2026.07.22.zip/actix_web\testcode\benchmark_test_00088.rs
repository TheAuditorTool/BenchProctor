// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00088")]
pub async fn benchmark_test_00088(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let captured = cookie_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    crate::shared::nosql_find_one(&format!("this.username == '{}'", data)).await;
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
