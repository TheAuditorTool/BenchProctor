// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00052")]
pub async fn benchmark_test_00052(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let captured = field_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    crate::shared::db_query_bind("UPDATE users SET name = $1", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
