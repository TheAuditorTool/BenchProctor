// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use log;

#[actix_web::post("/benchmark_test_00043")]
pub async fn benchmark_test_00043(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let data = match xml_value.chars().next() { Some(_) => xml_value.clone(), None => "default".to_string() };
    let processed = ["true", "false", "1", "0"].contains(&data.to_lowercase().as_str()).to_string();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
