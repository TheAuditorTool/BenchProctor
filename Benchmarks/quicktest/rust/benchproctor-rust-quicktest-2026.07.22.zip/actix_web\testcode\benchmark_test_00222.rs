// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00222")]
pub async fn benchmark_test_00222(req: HttpRequest) -> HttpResponse {
    let host_value = req.headers().get("host").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = crate::shared::passthrough(host_value.clone());
    let processed = if data.chars().count() > 64 { data.chars().take(64).collect::<String>() } else { data.clone() };
    if processed == "admin" || processed == "write" {
        crate::shared::store_session("granted_role", &processed);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
