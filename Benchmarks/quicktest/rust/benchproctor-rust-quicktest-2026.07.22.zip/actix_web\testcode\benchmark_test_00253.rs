// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00253")]
pub async fn benchmark_test_00253(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    crate::shared::set_cookie(&format!("session={}", header_value));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
