// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00453")]
pub async fn benchmark_test_00453(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = match origin_value.chars().next() { Some(_) => origin_value.clone(), None => "default".to_string() };
    let _ciphertext: Vec<u8> = data.bytes().map(|b| b ^ 0x42u8).collect();
    tokio::fs::write("/var/data/cipher.bin", &_ciphertext).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
