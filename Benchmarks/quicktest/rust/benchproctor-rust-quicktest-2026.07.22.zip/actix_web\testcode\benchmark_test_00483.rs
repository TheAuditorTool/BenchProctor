// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00483")]
pub async fn benchmark_test_00483(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    use std::fmt::Write;
    let mut data = String::new();
    write!(&mut data, "{}", origin_value).ok();
    reqwest::Client::builder().danger_accept_invalid_certs(false).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
