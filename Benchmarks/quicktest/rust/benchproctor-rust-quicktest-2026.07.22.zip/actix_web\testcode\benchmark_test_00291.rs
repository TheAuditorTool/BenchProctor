// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;
use url::Url;

#[actix_web::post("/benchmark_test_00291")]
pub async fn benchmark_test_00291(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let data: String = json_value.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| json_value.clone());
    let parsed = Url::parse(&data).unwrap_or_else(|_| Url::parse("http://invalid").unwrap());
    let blocked = match parsed.host() {
        Some(url::Host::Ipv4(v4)) => v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified(),
        Some(url::Host::Ipv6(v6)) => v6.is_loopback() || v6.is_unspecified() || (v6.segments()[0] & 0xfe00 == 0xfc00) || (v6.segments()[0] & 0xffc0 == 0xfe80) || v6.to_ipv4_mapped().is_some_and(|v4| v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified()),
        _ => false,
    };
    if blocked { return HttpResponse::Forbidden().finish(); }
    let _host_lc = parsed.host_str().unwrap_or("").to_lowercase();
    if ["localhost", "metadata", "metadata.google.internal", "169.254.169.254", "instance-data"].contains(&_host_lc.as_str()) { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    reqwest::get(&target_url).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
