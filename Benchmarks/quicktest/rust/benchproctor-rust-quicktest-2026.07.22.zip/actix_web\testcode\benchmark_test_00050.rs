// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00050")]
pub async fn benchmark_test_00050() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let tokens: Vec<&str> = comment_value.split(",").collect();
    let data = tokens.join(",");
    if data.parse::<i64>().is_err() { crate::shared::send_error("An error occurred"); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
