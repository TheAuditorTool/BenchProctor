#![allow(dead_code)]

// Stub helpers used by emitted test files. Each takes its input parameters and
// returns a deterministic transformation of them — never a literal stub. SAST
// tools track taint into and out of these via signature, not via execution.

pub fn db_fetch_one(query: &str) -> String {
    let table = query.rsplit(" FROM ").next().and_then(|s| s.split_whitespace().next()).unwrap_or("rows");
    std::env::var(format!("DB_ROW_{}", table.to_uppercase())).unwrap_or_default()
}

pub fn passthrough(v: String) -> String {
    v
}

pub fn queue_get_message(queue: &str) -> String {
    std::env::var(format!("QUEUE_{}_NEXT", queue.to_uppercase())).unwrap_or_default()
}
pub fn grpc_request_payload() -> String {
    std::env::var("GRPC_PAYLOAD").unwrap_or_default()
}
pub fn grpc_send(method: &str, payload: &str) { let _ = (method, payload); }
pub fn queue_publish(queue: &str, payload: &str) { let _ = (queue, payload); }
pub fn redis_publish(channel: &str, payload: &str) { let _ = (channel, payload); }
// Pub/sub subscribe side, matching redis_publish's channel. A taint bridge over
// redis must consume from the same channel it was published to (not a key-value
// GET), so a Rust sink node receiving from an upstream publisher is coherent.
pub fn redis_subscribe(channel: &str) -> String {
    std::env::var(format!("REDIS_SUB_{}", channel.to_uppercase())).unwrap_or_default()
}
pub fn ws_recv_message() -> String {
    std::env::var("WS_NEXT_MESSAGE").unwrap_or_default()
}
pub fn dns_txt_lookup(domain: &str) -> String {
    format!("txt_for_{}", domain)
}
pub fn redis_get(key: &str) -> String {
    std::env::var(format!("REDIS_{}", key.to_uppercase())).unwrap_or_default()
}
pub fn memcache_get(key: &str) -> String {
    std::env::var(format!("MEMCACHE_{}", key.to_uppercase())).unwrap_or_default()
}
pub fn s3_get_object(bucket: &str, key: &str) -> String {
    format!("s3://{}/{}", bucket, key)
}
pub fn sqs_receive_message(queue: &str) -> String {
    std::env::var(format!("SQS_{}_NEXT", queue.to_uppercase())).unwrap_or_default()
}
pub fn s3_put_object(bucket: &str, key: &str, body: &[u8]) { let _ = (bucket, key, body); }
pub fn iam_put_role_policy(role: &str, name: &str, doc: &str) { let _ = (role, name, doc); }
pub fn sts_assume_role(role_arn: &str, session_name: &str) { let _ = (role_arn, session_name); }
pub fn sqs_send_message(queue_url: &str, body: &str) { let _ = (queue_url, body); }
pub fn message_hmac(body: &str) -> String {
    use hmac::{Hmac, Mac};
    let key = std::env::var("MSG_HMAC_KEY").unwrap_or_else(|_| "shared-mesh-secret".to_string());
    let mut mac = match <Hmac<sha2::Sha256> as Mac>::new_from_slice(key.as_bytes()) {
        Ok(m) => m,
        Err(_) => return String::new(),
    };
    mac.update(body.as_bytes());
    hex::encode(mac.finalize().into_bytes())
}
pub fn kafka_consume() -> String {
    std::env::var("KAFKA_NEXT_OFFSET").unwrap_or_default()
}
pub fn ssm_get_parameter(name: &str) -> String {
    std::env::var(name.to_uppercase().replace(['/', '-'], "_")).unwrap_or_default()
}
pub fn uploaded_filename() -> String {
    std::env::var("UPLOAD_FILENAME").unwrap_or_default()
}
pub fn clipboard_paste() -> String {
    std::env::var("CLIPBOARD_NEXT").unwrap_or_default()
}
pub fn auth_check(user: &str, token: &str) -> bool {
    !user.is_empty() && user == token
}
pub fn acl_check(user: &str, perm: &str) -> bool {
    !user.is_empty() && !perm.is_empty()
}
// Server-side authentication: verify a bearer token against a secret the server
// holds (env-provisioned), never against another client-supplied value. The safe
// (TN) auth controls route through this so authentication is genuine, not a
// client-vs-client comparison an attacker controls both sides of.
pub fn verify_bearer(token: &str) -> bool {
    let expected = std::env::var("APP_SESSION_SECRET").unwrap_or_default();
    !expected.is_empty() && token == expected
}
// Server-side authorization: the authenticated principal (from the session, not a
// client header) is looked up in a server-owned role map. An attacker cannot mint
// a role by setting a request header.
pub fn user_has_role(user: &str, role: &str) -> bool {
    const ROLE_MAP: &[(&str, &str)] = &[("svc-admin", "admin"), ("svc-writer", "write"), ("svc-reader", "read")];
    ROLE_MAP.iter().any(|(u, r)| *u == user && *r == role)
}
pub fn hash_hex(value: &str) -> String {
    use sha2::Digest;
    format!("{:x}", sha2::Sha256::digest(value.as_bytes()))
}
// Server-side synchronizer CSRF token (per-deployment secret). The safe CSRF
// control compares the submitted token against this, not against another
// client-supplied header the attacker also controls.
pub fn expected_csrf() -> String {
    std::env::var("CSRF_TOKEN").unwrap_or_default()
}
pub fn respond_json(status: u16, body: &str) -> String {
    format!("{{\"status_code\": {}, \"body\": \"{}\"}}", status, body)
}
pub fn db_query(sql: &str) {
    if let Ok(conn) = rusqlite::Connection::open_in_memory() { let _ = conn.execute(sql, []); }
}
pub fn db_query_bind(sql: &str, param: &str) {
    if let Ok(conn) = rusqlite::Connection::open_in_memory() { let _ = conn.execute(sql, rusqlite::params![param]); }
}
pub fn db_exec(sql: &str) {
    if let Ok(conn) = rusqlite::Connection::open_in_memory() { let _ = conn.execute(sql, []); }
}
pub fn db_exec_bind(sql: &str, param: &str) {
    if let Ok(conn) = rusqlite::Connection::open_in_memory() { let _ = conn.execute(sql, rusqlite::params![param]); }
}
pub fn db_connect(dsn: &str) { let _ = rusqlite::Connection::open(dsn); }
pub fn fetch_url(url: &str) -> String { std::env::var("EXTERNAL_API_RESPONSE").unwrap_or_else(|_| url.to_string()) }
pub async fn nosql_find_one(filter: &str) {
    let client = match mongodb::Client::with_uri_str("mongodb://localhost:27017").await {
        Ok(c) => c,
        Err(_) => return,
    };
    let coll = client.database("benchmark").collection::<mongodb::bson::Document>("users");
    let _ = coll.find_one(mongodb::bson::doc! { "$where": filter }, None).await;
}
pub fn ldap_search(filter: &str) {
    if let Ok(mut conn) = ldap3::LdapConn::new("ldap://localhost:389") {
        let _ = conn.search("dc=example,dc=com", ldap3::Scope::Subtree, filter, vec!["cn"]);
    }
}
pub fn xpath_eval(expr: &str) {
    if let Ok(pkg) = sxd_document::parser::parse("<users><user id='1'/></users>") {
        let doc = pkg.as_document();
        let _ = sxd_xpath::evaluate_xpath(&doc, expr);
    }
}
pub fn jwt_sign(secret: &str) -> String {
    use hmac::{Hmac, Mac};
    use base64::Engine;
    let header_payload = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0";
    let mut mac = match <Hmac<sha2::Sha256> as Mac>::new_from_slice(secret.as_bytes()) {
        Ok(m) => m,
        Err(_) => return String::new(),
    };
    mac.update(header_payload.as_bytes());
    let sig = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(mac.finalize().into_bytes());
    format!("{}.{}", header_payload, sig)
}
pub fn write_csv(row: &str) {
    let mut wtr = csv::Writer::from_writer(Vec::new());
    let _ = wtr.write_record([row]);
    let _ = wtr.flush();
}
pub fn store_session(key: &str, value: &str) {
    if let Ok(mut m) = SESSION_STORE.lock() { m.insert(key.to_string(), value.to_string()); }
}
pub fn keyring_get(key: &str) -> String {
    std::env::var(format!("KEYRING_{}", key.to_uppercase())).unwrap_or_default()
}
pub fn vault_get(key: &str) -> String {
    std::env::var(format!("VAULT_{}", key.to_uppercase())).unwrap_or_default()
}
// Cross-service taint bridge over a shared, file-backed datastore -- the write
// persists so a downstream service reading the same key sees it (a per-connection
// in-memory DB would not). Mirrors the persistent shared-DB the other services use.
const TAINT_BRIDGE_DB: &str = "/var/lib/app/shared_state.db";
pub fn shared_db_write(key: &str, payload: &str) {
    if let Ok(conn) = rusqlite::Connection::open(TAINT_BRIDGE_DB) {
        let _ = conn.execute("CREATE TABLE IF NOT EXISTS taint_bridge (k TEXT PRIMARY KEY, data TEXT)", []);
        let _ = conn.execute("INSERT OR REPLACE INTO taint_bridge (k, data) VALUES (?1, ?2)", rusqlite::params![key, payload]);
    }
}
pub fn shared_db_read(key: &str) -> String {
    if let Ok(conn) = rusqlite::Connection::open(TAINT_BRIDGE_DB) {
        let _ = conn.execute("CREATE TABLE IF NOT EXISTS taint_bridge (k TEXT PRIMARY KEY, data TEXT)", []);
        if let Ok(val) = conn.query_row("SELECT data FROM taint_bridge WHERE k = ?1", rusqlite::params![key], |row| row.get::<_, String>(0)) {
            return val;
        }
    }
    String::new()
}

// Persistent, mutex-guarded shared state used by the "safe" thread/race variants.
// A real server keeps such state across requests; locking it is the genuine fix
// for the unsynchronized `static mut` write the vulnerable variant performs.
pub static SHARED_DATA: std::sync::Mutex<String> = std::sync::Mutex::new(String::new());
pub static SESSION_USER: std::sync::Mutex<String> = std::sync::Mutex::new(String::new());
// Server-side session store and rendered-response body -- real sinks the emitted
// handlers write tainted values into (BTreeMap::new()/String::new() are const fns).
pub static SESSION_STORE: std::sync::Mutex<std::collections::BTreeMap<String, String>> = std::sync::Mutex::new(std::collections::BTreeMap::new());
pub static RESPONSE_BODY: std::sync::Mutex<String> = std::sync::Mutex::new(String::new());

pub fn current_session_user() -> String {
    SESSION_USER.lock().map(|g| g.clone()).unwrap_or_default()
}

// Real authenticated encryption (AES-256-GCM, random key + nonce). Used by the
// "encrypt before store / strong cipher" safe variants so the TN genuinely
// encrypts rather than prepending a marker string to the plaintext.
pub fn encrypt(plaintext: &str) -> String {
    use aes_gcm::aead::{Aead, KeyInit};
    use aes_gcm::{Aes256Gcm, Nonce};
    use base64::Engine;
    let key_bytes: [u8; 32] = rand::random();
    let cipher = match Aes256Gcm::new_from_slice(&key_bytes) {
        Ok(c) => c,
        Err(_) => return String::new(),
    };
    let nonce_bytes: [u8; 12] = rand::random();
    let nonce = Nonce::from_slice(&nonce_bytes);
    let ciphertext = cipher.encrypt(nonce, plaintext.as_bytes()).unwrap_or_default();
    let mut framed = nonce_bytes.to_vec();
    framed.extend_from_slice(&ciphertext);
    base64::engine::general_purpose::STANDARD.encode(framed)
}
// AES-256-GCM keyed by the CALLER-SUPPLIED key string -- the vulnerable
// "tainted/hardcoded value used as the encryption key" (CWE-321) shape. The
// key is taken verbatim from the argument, so taint flows into the key slot.
pub fn encrypt_with_key(key: &str, data: &str) -> String {
    use aes_gcm::aead::{Aead, KeyInit};
    use aes_gcm::{Aes256Gcm, Nonce};
    use base64::Engine;
    let mut key_bytes = [0u8; 32];
    let kb = key.as_bytes();
    let n = kb.len().min(32);
    key_bytes[..n].copy_from_slice(&kb[..n]);
    let cipher = match Aes256Gcm::new_from_slice(&key_bytes) {
        Ok(c) => c,
        Err(_) => return String::new(),
    };
    let nonce_bytes: [u8; 12] = rand::random();
    let nonce = Nonce::from_slice(&nonce_bytes);
    let ciphertext = cipher.encrypt(nonce, data.as_bytes()).unwrap_or_default();
    let mut framed = nonce_bytes.to_vec();
    framed.extend_from_slice(&ciphertext);
    base64::engine::general_purpose::STANDARD.encode(framed)
}
pub fn render_html(html: &str) {
    if let Ok(mut b) = RESPONSE_BODY.lock() { *b = html.to_string(); }
}
pub fn set_cookie(value: &str) {
    let _ = cookie::Cookie::parse(value.to_string());
}
pub fn send_error(message: &str) {
    if let Ok(mut b) = RESPONSE_BODY.lock() { *b = format!("error: {}", message); }
}
