// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00386")]
pub async fn benchmark_test_00386(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: header_value.clone() };
    let data = payload.value().to_string();
    crate::shared::db_query_bind("UPDATE users SET name = $1", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
