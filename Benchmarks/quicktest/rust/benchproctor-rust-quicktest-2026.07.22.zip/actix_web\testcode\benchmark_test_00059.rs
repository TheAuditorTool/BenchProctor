// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use serde_yaml;

#[actix_web::post("/benchmark_test_00059")]
pub async fn benchmark_test_00059(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let data = json_value.to_string();
    let _: serde_yaml::Value = serde_yaml::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
