// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00267")]
pub async fn benchmark_test_00267(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(header_value.clone(), |s| s.trim().to_string());
    let processed = html_escape::encode_text(&data).to_string();
    crate::shared::render_html(&format!("<div>{}</div>", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
