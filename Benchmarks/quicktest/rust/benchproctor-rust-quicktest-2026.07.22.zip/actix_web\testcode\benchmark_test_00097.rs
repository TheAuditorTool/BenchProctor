// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00097")]
pub async fn benchmark_test_00097() -> HttpResponse {
    let secret_value = { let m = std::collections::HashMap::from([("secret", "p4ssw0rd_test_xyz")]); m.get("secret").copied().unwrap_or_default().to_string() };
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = secret_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
