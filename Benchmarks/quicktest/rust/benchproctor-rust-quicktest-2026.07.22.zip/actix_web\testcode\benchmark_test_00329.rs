// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00329")]
pub async fn benchmark_test_00329(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let (payload, _origin) = (xml_value.clone(), "http");
    let data = payload;
    reqwest::Client::builder().danger_accept_invalid_certs(true).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
