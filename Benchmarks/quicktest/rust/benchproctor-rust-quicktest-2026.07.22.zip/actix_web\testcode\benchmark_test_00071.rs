// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use hex;

#[actix_web::post("/benchmark_test_00071")]
pub async fn benchmark_test_00071(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let data = String::from_utf8_lossy(&hex::decode(&cookie_value).unwrap_or_default()).to_string();
    HttpResponse::Found().append_header(("Location", data.as_str())).finish()
}
