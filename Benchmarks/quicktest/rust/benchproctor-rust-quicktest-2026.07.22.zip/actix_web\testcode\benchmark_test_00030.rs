// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00030")]
pub async fn benchmark_test_00030(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = auth_header.split_whitespace().collect::<Vec<_>>().join(" ");
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    crate::shared::send_error(&format!("Error: {}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
