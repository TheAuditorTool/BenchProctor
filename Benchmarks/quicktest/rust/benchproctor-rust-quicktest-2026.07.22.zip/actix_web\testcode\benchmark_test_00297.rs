// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use ammonia;

#[actix_web::post("/benchmark_test_00297")]
pub async fn benchmark_test_00297() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let captured = db_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let processed = ammonia::clean(&data);
    crate::shared::render_html(&format!("<div>{}</div>", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
