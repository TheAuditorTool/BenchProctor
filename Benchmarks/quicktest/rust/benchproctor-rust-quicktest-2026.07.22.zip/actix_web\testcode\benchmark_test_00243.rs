// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;

#[actix_web::post("/benchmark_test_00243")]
pub async fn benchmark_test_00243(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let upload_name = {
        let mut _fname = String::new();
        while let Some(Ok(_field)) = payload.next().await {
            if let Some(_cd) = _field.content_disposition() {
                if let Some(_f) = _cd.get_filename() { _fname = _f.to_string(); break; }
            }
        }
        _fname
    };
    let data: String = upload_name.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| upload_name.clone());
    crate::shared::set_cookie(&format!("session={}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
