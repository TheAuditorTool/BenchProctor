// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00265")]
pub async fn benchmark_test_00265(web::Query(query): web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_id = query.get("id").cloned().unwrap_or_default();
    let data = match user_id.chars().next() { Some(_) => user_id.clone(), None => "default".to_string() };
    reqwest::get(&data).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
