// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00164")]
pub async fn benchmark_test_00164() -> HttpResponse {
    let dotenv_value = std::env::var("DOTENV_VAR").unwrap_or_default();
    let queued = dotenv_value.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    tokio::fs::write("/var/data/plaintext.txt", &data).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
