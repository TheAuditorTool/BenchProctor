// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00343/{id}")]
pub async fn benchmark_test_00343(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let queued = path_value.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    crate::shared::send_error(&format!("Error: {}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
