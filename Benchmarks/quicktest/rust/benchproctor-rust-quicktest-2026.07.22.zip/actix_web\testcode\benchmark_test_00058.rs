// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00058")]
pub async fn benchmark_test_00058(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let data = serde_json::from_str::<serde_json::Value>(&raw_body)
        .ok().and_then(|v| v["value"].as_str().map(|s| s.to_string())).unwrap_or_default();
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    static _RE_INPUTVAL: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new("[a-zA-Z0-9_-]+").unwrap());
    if !_RE_INPUTVAL.is_match(&processed) { return HttpResponse::BadRequest().finish(); }
    crate::shared::db_exec_bind("INSERT INTO logs (data) VALUES ($1)", &processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
