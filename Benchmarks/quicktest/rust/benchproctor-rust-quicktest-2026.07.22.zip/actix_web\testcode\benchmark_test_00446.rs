// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00446")]
pub async fn benchmark_test_00446() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let captured = env_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let _crlf_stripped = data.replace(['\r', '\n'], "");
    static _RE_REDACT: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"[A-Za-z0-9]{4,}").unwrap());
    let processed = _RE_REDACT.replace_all(&_crlf_stripped, "****").to_string();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
