// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use reqwest;

#[actix_web::post("/benchmark_test_00410")]
pub async fn benchmark_test_00410(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let multipart_value = {
        let mut _mv = String::new();
        if let Some(Ok(mut _field)) = payload.next().await {
            let mut _buf: Vec<u8> = Vec::new();
            while let Some(Ok(_chunk)) = _field.next().await {
                _buf.extend_from_slice(&_chunk);
            }
            _mv = String::from_utf8_lossy(&_buf).to_string();
        }
        _mv
    };
    let data = multipart_value.replace("\t", " ");
    let _body = match reqwest::get(&data).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
