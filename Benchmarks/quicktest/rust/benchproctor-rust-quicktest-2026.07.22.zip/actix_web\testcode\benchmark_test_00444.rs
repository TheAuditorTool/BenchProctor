// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00444")]
pub async fn benchmark_test_00444() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let data = env_value.to_string();
    use sha2::Digest;
    let _ = sha2::Sha256::digest(data.as_bytes());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
