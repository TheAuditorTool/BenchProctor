// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00465")]
pub async fn benchmark_test_00465() -> HttpResponse {
    let stdin_value = { let mut s = String::new(); std::io::stdin().read_line(&mut s).ok(); s.trim().to_string() };
    let captured = stdin_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    Command::new("sh").arg("-c").arg(format!("cat {}", data)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
