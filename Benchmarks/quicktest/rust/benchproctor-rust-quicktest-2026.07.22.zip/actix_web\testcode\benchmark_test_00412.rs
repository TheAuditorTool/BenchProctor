// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00412")]
pub async fn benchmark_test_00412() -> HttpResponse {
    let profile_value = crate::shared::db_fetch_one("SELECT bio FROM profiles LIMIT 1");
    let data = match profile_value.chars().next() { Some(_) => profile_value.clone(), None => "default".to_string() };
    tokio::fs::write("/var/data/plaintext.txt", &data).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
