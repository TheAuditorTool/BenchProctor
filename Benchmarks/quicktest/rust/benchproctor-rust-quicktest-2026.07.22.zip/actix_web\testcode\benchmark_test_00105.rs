// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00105")]
pub async fn benchmark_test_00105(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let data = crate::shared::passthrough(raw_body.clone());
    crate::shared::db_query(&format!("SELECT * FROM `{}`", data.replace('`', "")));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
