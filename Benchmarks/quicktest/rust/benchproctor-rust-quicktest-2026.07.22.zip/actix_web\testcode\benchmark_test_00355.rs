// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00355")]
pub async fn benchmark_test_00355() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let (payload, _origin) = (env_value.clone(), "http");
    let data = payload;
    crate::shared::db_query(&format!("SELECT * FROM users WHERE id = '{}'", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
