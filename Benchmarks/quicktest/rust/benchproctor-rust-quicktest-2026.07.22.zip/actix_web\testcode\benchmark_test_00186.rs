// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00186")]
pub async fn benchmark_test_00186(req: HttpRequest) -> HttpResponse {
    let origin_value = req.headers().get("origin").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = origin_value.replace("\t", " ");
    reqwest::Client::builder().danger_accept_invalid_certs(true).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
