// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use rand::Rng;
use rand::rngs::OsRng;

#[actix_web::post("/benchmark_test_00078")]
pub async fn benchmark_test_00078() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let (payload, _origin) = (env_value.clone(), "http");
    let data = payload;
    let _token: u64 = OsRng.gen();
    crate::shared::store_session(&format!("csrf_token:{}", data), &_token.to_string());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
