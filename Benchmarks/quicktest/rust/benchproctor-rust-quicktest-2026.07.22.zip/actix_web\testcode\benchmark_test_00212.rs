// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00212")]
pub async fn benchmark_test_00212(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let data = xml_value.split_whitespace().collect::<Vec<_>>().join(" ");
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    #[cfg(unix)] { unsafe { libc::setuid(65534); } }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
