// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00394")]
pub async fn benchmark_test_00394(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let data = String::from_utf8_lossy(raw_body.as_bytes()).to_string();
    crate::shared::render_html(&format!("<div>{}</div>", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
