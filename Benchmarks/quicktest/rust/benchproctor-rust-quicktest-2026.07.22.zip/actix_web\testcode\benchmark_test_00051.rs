// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00051")]
pub async fn benchmark_test_00051(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let (payload, _origin) = (cookie_value.clone(), "http");
    let data = payload;
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Content-Security-Policy", "frame-ancestors 'none'; default-src 'self'")).finish()
}
