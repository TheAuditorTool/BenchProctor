// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use serde_yaml;

#[actix_web::post("/benchmark_test_00195")]
pub async fn benchmark_test_00195(req: HttpRequest) -> HttpResponse {
    let ua_value = req.headers().get("user-agent").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let tokens: Vec<&str> = ua_value.split(",").collect();
    let data = tokens.join(",");
    let _: serde_yaml::Value = serde_yaml::from_str(&data).unwrap_or_default();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
