// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00275")]
pub async fn benchmark_test_00275(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: field_value.clone() };
    let data = payload.value().to_string();
    let processed = if data.chars().count() > 64 { data.chars().take(64).collect::<String>() } else { data.clone() };
    tokio::fs::write("/var/data/plaintext.txt", &processed).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
