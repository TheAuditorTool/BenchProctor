// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00255")]
pub async fn benchmark_test_00255() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let tokens: Vec<&str> = db_value.split(",").collect();
    let data = tokens.join(",");
    let _crlf_stripped = data.replace(['\r', '\n'], "");
    static _RE_REDACT: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"[A-Za-z0-9]{4,}").unwrap());
    let processed = _RE_REDACT.replace_all(&_crlf_stripped, "****").to_string();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
