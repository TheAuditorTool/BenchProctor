// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00352")]
pub async fn benchmark_test_00352(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let captured = auth_header.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let _role = data.clone();
    if _role == "admin" { return HttpResponse::Ok().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
