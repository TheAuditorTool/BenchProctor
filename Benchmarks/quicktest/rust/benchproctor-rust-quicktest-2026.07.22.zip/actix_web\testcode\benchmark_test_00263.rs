// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00263")]
pub async fn benchmark_test_00263(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let data = match field_value.chars().next() { Some(_) => field_value.clone(), None => "default".to_string() };
    tokio::fs::write("/var/data/hashed.txt", crate::shared::hash_hex(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
