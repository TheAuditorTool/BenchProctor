// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00485")]
pub async fn benchmark_test_00485(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    struct UserPayload { input: String }
    impl UserPayload { fn value(&self) -> &str { self.input.as_str() } }
    let payload = UserPayload { input: forwarded_ip.clone() };
    let data = payload.value().to_string();
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    crate::shared::xpath_eval(&format!("//user[@id='{}']", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
