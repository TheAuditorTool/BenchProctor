// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00304")]
pub async fn benchmark_test_00304(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let data = serde_json::from_str::<serde_json::Value>(&raw_body)
        .ok().and_then(|v| v["value"].as_str().map(|s| s.to_string())).unwrap_or_default();
    tokio::fs::write("/var/data/encrypted.bin", crate::shared::encrypt(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
