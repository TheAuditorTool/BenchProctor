// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00314")]
pub async fn benchmark_test_00314(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    let data = cookie_value.replace("\t", " ");
    reqwest::Client::builder().danger_accept_invalid_certs(false).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
