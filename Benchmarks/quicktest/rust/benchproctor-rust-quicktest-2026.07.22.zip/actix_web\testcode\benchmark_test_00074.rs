// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use serde_yaml;

#[actix_web::post("/benchmark_test_00074")]
pub async fn benchmark_test_00074(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let queued = forwarded_ip.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    if std::env::var("APP_ENV").unwrap_or_default() != "test" {
        let _: serde_yaml::Value = serde_yaml::from_str(&data).unwrap_or_default();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
