// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00492/{id}")]
pub async fn benchmark_test_00492(req: HttpRequest) -> HttpResponse {
    let path_value = req.match_info().get("id").unwrap_or("").to_string();
    let transform = |v: String| v.trim().to_string();
    let data = transform(path_value.clone());
    crate::shared::render_html(&format!("<div>{}</div>", html_escape::encode_text(&data)));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
