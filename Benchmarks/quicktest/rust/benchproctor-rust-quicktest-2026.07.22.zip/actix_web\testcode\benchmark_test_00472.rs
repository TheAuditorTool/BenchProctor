// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00472")]
pub async fn benchmark_test_00472() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let (payload, _origin) = (env_value.clone(), "http");
    let data = payload;
    crate::shared::send_error(&format!("Error: {}", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
