// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00463")]
pub async fn benchmark_test_00463(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let tokens: Vec<&str> = raw_body.split(",").collect();
    let data = tokens.join(",");
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", data.as_str())).finish()
}
