// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00016")]
pub async fn benchmark_test_00016() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let data = match db_value.chars().next() { Some(_) => db_value.clone(), None => "default".to_string() };
    tokio::fs::write("/var/data/encrypted.bin", crate::shared::encrypt(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
