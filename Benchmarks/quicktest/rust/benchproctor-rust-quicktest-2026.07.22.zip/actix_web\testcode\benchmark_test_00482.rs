// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00482")]
pub async fn benchmark_test_00482(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let (tx, rx) = tokio::sync::oneshot::channel::<String>();
    let payload = header_value.clone();
    tokio::spawn(async move { let _ = tx.send(payload); });
    let data = rx.await.unwrap_or_default();
    crate::shared::store_session("data", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
