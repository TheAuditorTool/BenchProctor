// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00004")]
pub async fn benchmark_test_00004() -> HttpResponse {
    let secret_value = "xoxb-EXAMPLE-0000-1111-abcdefEXAMPLEgh".to_string();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(secret_value.clone(), |s| s.trim().to_string());
    crate::shared::db_connect(&format!("postgres://app:{}@localhost/prod", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
