// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00319")]
pub async fn benchmark_test_00319() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let (payload, _origin) = (db_value.clone(), "http");
    let data = payload;
    tokio::fs::write("/var/data/hashed.txt", crate::shared::hash_hex(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
