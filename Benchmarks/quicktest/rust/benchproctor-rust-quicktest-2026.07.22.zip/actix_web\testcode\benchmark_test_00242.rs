// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use log;

#[actix_web::post("/benchmark_test_00242")]
pub async fn benchmark_test_00242(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let mut data = String::new();
    data.push_str(&field_value);
    if !["asc", "desc", "name", "created"].contains(&data.as_str()) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
