// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00371")]
pub async fn benchmark_test_00371(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(auth_header.clone(), |s| s.trim().to_string());
    tokio::fs::write("/var/data/hashed.txt", crate::shared::hash_hex(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
