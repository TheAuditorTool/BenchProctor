// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00241")]
pub async fn benchmark_test_00241() -> HttpResponse {
    let secret_value = ["default_config_label"][0].to_string();
    struct FormData { payload: String }
    let data = FormData { payload: secret_value.clone() }.payload;
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ok = crate::shared::auth_check(&data, &store_cred);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
