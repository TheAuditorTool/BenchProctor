// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00081")]
pub async fn benchmark_test_00081() -> HttpResponse {
    let db_value = crate::shared::db_fetch_one("SELECT name FROM users LIMIT 1");
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ok = crate::shared::auth_check(&db_value, &store_cred);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
