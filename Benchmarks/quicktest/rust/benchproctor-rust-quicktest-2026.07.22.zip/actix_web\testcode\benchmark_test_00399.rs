// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00399")]
pub async fn benchmark_test_00399(req: HttpRequest) -> HttpResponse {
    let host_value = req.headers().get("host").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = crate::shared::passthrough(host_value.clone());
    let processed = if data.chars().count() > 64 { data.chars().take(64).collect::<String>() } else { data.clone() };
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
