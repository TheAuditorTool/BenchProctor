// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00266")]
pub async fn benchmark_test_00266(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let mut data = String::new();
    data.push_str(&xml_value);
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", "https://app.edgecdn.io")).finish()
}
