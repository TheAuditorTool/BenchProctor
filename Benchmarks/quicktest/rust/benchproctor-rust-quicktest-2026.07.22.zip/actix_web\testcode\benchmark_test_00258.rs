// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00258")]
pub async fn benchmark_test_00258() -> HttpResponse {
    let secret_value = ["s3cr3t_key_test_xyz"][0].to_string();
    struct FormData { payload: String }
    let data = FormData { payload: secret_value.clone() }.payload;
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
