// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use rand::Rng;
use rand::rngs::OsRng;

#[actix_web::post("/benchmark_test_00240")]
pub async fn benchmark_test_00240(body: web::Bytes) -> HttpResponse {
    let json_value = serde_json::from_slice::<serde_json::Value>(&body).ok().and_then(|v| v.get("payload").and_then(|p| p.as_str()).map(|s| s.to_string())).unwrap_or_default();
    let captured = json_value.clone();
    let reader = move || captured.trim().to_string();
    let data = reader();
    let _token: u64 = OsRng.gen();
    crate::shared::store_session(&format!("csrf_token:{}", data), &_token.to_string());
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
