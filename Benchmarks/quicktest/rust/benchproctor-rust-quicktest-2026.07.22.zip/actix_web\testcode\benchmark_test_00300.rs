// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use tokio::process::Command;
use urlencoding;

#[actix_web::post("/benchmark_test_00300")]
pub async fn benchmark_test_00300(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = urlencoding::decode(&referer_value).unwrap_or_default().to_string();
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    Command::new("bash").arg("-c").arg(format!("echo {}", processed)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
