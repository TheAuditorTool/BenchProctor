// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00358")]
pub async fn benchmark_test_00358() -> HttpResponse {
    let stdin_value = { let mut s = String::new(); std::io::stdin().read_line(&mut s).ok(); s.trim().to_string() };
    static _RE_SCHEMA: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^[a-zA-Z0-9_.-]+$").unwrap());
    if !_RE_SCHEMA.is_match(&stdin_value) { return HttpResponse::BadRequest().finish(); }
    let processed = stdin_value.clone();
    Command::new("sh").arg("-c").arg(format!("cat {}", processed)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
