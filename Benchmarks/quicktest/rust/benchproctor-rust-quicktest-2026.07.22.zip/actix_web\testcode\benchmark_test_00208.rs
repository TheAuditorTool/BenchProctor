// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00208")]
pub async fn benchmark_test_00208(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let transform = |v: String| v.trim().to_string();
    let data = transform(referer_value.clone());
    let requested: usize = data.parse().unwrap_or(0);
    let _data = vec![0u8; requested.min(4096)];
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
