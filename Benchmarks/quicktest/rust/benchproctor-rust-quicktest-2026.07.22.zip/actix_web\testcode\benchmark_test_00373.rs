// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00373")]
pub async fn benchmark_test_00373() -> HttpResponse {
    let secret_value = "config_secret_test_abc123".to_string();
    let data: String = secret_value.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| secret_value.clone());
    let _ct = crate::shared::encrypt_with_key(&data, "sensitive-data");
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
