// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00197")]
pub async fn benchmark_test_00197(req: HttpRequest) -> HttpResponse {
    let referer_value = req.headers().get("referer").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = referer_value.to_string();
    if data.len() > 8192 { return HttpResponse::BadRequest().finish(); }
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", "https://app.edgecdn.io")).finish()
}
