// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00144")]
pub async fn benchmark_test_00144(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let mut data = String::new();
    for token in forwarded_ip.split(',') { data = token.to_string(); }
    HttpResponse::Ok().insert_header(("Access-Control-Allow-Origin", data.as_str())).finish()
}
