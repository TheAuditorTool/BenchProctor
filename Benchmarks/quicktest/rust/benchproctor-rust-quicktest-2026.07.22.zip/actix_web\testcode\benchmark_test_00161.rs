// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use reqwest;

#[actix_web::post("/benchmark_test_00161")]
pub async fn benchmark_test_00161(web::Form(form): web::Form<std::collections::HashMap<String, String>>) -> HttpResponse {
    let field_value = form.get("field").cloned().unwrap_or_default();
    let data: String = field_value.parse::<i64>()
        .map(|n| n.to_string()).unwrap_or_else(|_| field_value.clone());
    reqwest::Client::new().post("https://api.edgecdn.io/data").body(data.clone()).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
