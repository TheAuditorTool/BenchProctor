// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use shell_escape;
use tokio::process::Command;

#[actix_web::post("/benchmark_test_00426")]
pub async fn benchmark_test_00426() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let _prefix: String = comment_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => comment_value.to_lowercase(),
        "f" => comment_value.to_uppercase(),
        _ => comment_value.trim().to_string(),
    };
    let processed = shell_escape::escape(std::borrow::Cow::from(&data)).to_string();
    Command::new("sh").arg("-c").arg(format!("cat {}", processed)).output().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
