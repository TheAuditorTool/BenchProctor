// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use ammonia;

#[actix_web::post("/benchmark_test_00018")]
pub async fn benchmark_test_00018() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let queued = comment_value.clone();
    let data = tokio::task::spawn_blocking(move || queued.trim().to_string()).await.unwrap_or_default();
    let processed = ammonia::clean(&data);
    crate::shared::render_html(&format!("<div>{}</div>", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
