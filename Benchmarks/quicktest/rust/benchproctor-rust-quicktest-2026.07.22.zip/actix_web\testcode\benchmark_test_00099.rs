// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};
use pulldown_cmark;
use urlencoding;

#[actix_web::post("/benchmark_test_00099")]
pub async fn benchmark_test_00099(web::Query(query): web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_id = query.get("id").cloned().unwrap_or_default();
    let data = urlencoding::decode(&user_id).unwrap_or_default().to_string();
    let parser = pulldown_cmark::Parser::new(&data);
    let mut md_rendered = String::new();
    pulldown_cmark::html::push_html(&mut md_rendered, parser);
    let processed = ammonia::clean(&md_rendered);
    crate::shared::render_html(&format!("<div>{}</div>", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
