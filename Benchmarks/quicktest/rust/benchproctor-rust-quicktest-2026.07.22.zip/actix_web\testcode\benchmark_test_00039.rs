// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00039")]
pub async fn benchmark_test_00039() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    let _prefix: String = env_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => env_value.to_lowercase(),
        "f" => env_value.to_uppercase(),
        _ => env_value.trim().to_string(),
    };
    crate::shared::set_cookie(&format!("session={}; Secure; HttpOnly; SameSite=Strict", data));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
