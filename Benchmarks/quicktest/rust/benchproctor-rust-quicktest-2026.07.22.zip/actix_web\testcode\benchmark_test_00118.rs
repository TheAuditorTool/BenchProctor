// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00118")]
pub async fn benchmark_test_00118(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(header_value.clone());
    reqwest::Client::builder().danger_accept_invalid_certs(true).build().unwrap().get(&data).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
