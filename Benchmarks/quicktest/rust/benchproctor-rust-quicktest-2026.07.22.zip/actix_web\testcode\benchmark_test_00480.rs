// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00480")]
pub async fn benchmark_test_00480(body: web::Bytes) -> HttpResponse {
    let xml_value = String::from_utf8_lossy(&body).to_string();
    let (tx, rx) = tokio::sync::oneshot::channel::<String>();
    let payload = xml_value.clone();
    tokio::spawn(async move { let _ = tx.send(payload); });
    let data = rx.await.unwrap_or_default();
    crate::shared::render_html(&data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
