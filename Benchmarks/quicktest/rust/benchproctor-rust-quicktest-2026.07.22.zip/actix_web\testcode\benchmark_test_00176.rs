// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00176")]
pub async fn benchmark_test_00176(req: HttpRequest) -> HttpResponse {
    let cookie_value = req.cookie("session_token").map(|c| c.value().to_string()).unwrap_or_default();
    struct FormData { payload: String }
    let data = FormData { payload: cookie_value.clone() }.payload;
    let _role = data.clone();
    if _role == "admin" { return HttpResponse::Ok().finish(); }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
