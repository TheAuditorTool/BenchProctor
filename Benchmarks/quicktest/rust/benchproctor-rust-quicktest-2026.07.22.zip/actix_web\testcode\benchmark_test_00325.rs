// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00325")]
pub async fn benchmark_test_00325() -> HttpResponse {
    let secret_value = "default_config_label".to_string();
    let transform = |v: String| v.trim().to_string();
    let data = transform(secret_value.clone());
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ct = crate::shared::encrypt_with_key(&store_cred, &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
