// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00027")]
pub async fn benchmark_test_00027(req: HttpRequest) -> HttpResponse {
    let ua_value = req.headers().get("user-agent").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let _prefix: String = ua_value.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
    let data = match _prefix.as_str() {
        "h" => ua_value.to_lowercase(),
        "f" => ua_value.to_uppercase(),
        _ => ua_value.trim().to_string(),
    };
    let _token = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !crate::shared::verify_bearer(_token) { return HttpResponse::Unauthorized().finish(); }
    crate::shared::store_session("data", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
