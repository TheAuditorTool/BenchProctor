// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00466")]
pub async fn benchmark_test_00466(req: HttpRequest) -> HttpResponse {
    let header_value = req.headers().get("x-custom-header").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let data = match header_value.chars().next() { Some(_) => header_value.clone(), None => "default".to_string() };
    #[cfg(unix)] { unsafe { libc::setuid(data.parse::<libc::uid_t>().unwrap_or(0)); } }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
