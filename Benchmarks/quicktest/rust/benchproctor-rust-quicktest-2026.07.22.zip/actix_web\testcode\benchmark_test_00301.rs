// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00301")]
pub async fn benchmark_test_00301() -> HttpResponse {
    let comment_value = crate::shared::db_fetch_one("SELECT text FROM comments LIMIT 1");
    let mut data = String::new();
    for token in comment_value.split(',') { data = token.to_string(); }
    crate::shared::auth_check("user", &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
