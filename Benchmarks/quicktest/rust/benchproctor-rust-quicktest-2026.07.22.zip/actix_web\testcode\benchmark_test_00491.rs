// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse, web};

#[actix_web::post("/benchmark_test_00491")]
pub async fn benchmark_test_00491(body: web::Bytes) -> HttpResponse {
    let raw_body = String::from_utf8_lossy(&body).to_string();
    let transform = |v: String| v.trim().to_string();
    let data = transform(raw_body.clone());
    if ![".jpg", ".png", ".gif", ".pdf"].iter().any(|ext| data.to_lowercase().ends_with(ext)) { return HttpResponse::BadRequest().finish(); }
    let entry_file = data.clone();
    tokio::fs::write(format!("/var/uploads/{}", entry_file), b"data").await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
