// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00167")]
pub async fn benchmark_test_00167() -> HttpResponse {
    let secret_value = "default_config_label".to_string();
    fn call_with(input: String, on_input: impl Fn(String) -> String) -> String { on_input(input) }
    let data = call_with(secret_value.clone(), |s| s.trim().to_string());
    let store_cred = std::env::var("APP_SECRET").unwrap_or_default();
    let _ct = crate::shared::encrypt_with_key(&store_cred, &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
