// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00346")]
pub async fn benchmark_test_00346(req: HttpRequest) -> HttpResponse {
    let forwarded_ip = req.headers().get("x-forwarded-for").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(forwarded_ip.clone());
    if data == "admin" || data == "write" {
        crate::shared::store_session("granted_role", &data);
        return HttpResponse::Ok().finish();
    }
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
