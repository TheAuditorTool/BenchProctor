// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00359")]
pub async fn benchmark_test_00359() -> HttpResponse {
    let profile_value = crate::shared::db_fetch_one("SELECT bio FROM profiles LIMIT 1");
    let mut data = String::new();
    for token in profile_value.split(',') { data = token.to_string(); }
    reqwest::Client::new().post("https://api.edgecdn.io/data").body(data.clone()).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
