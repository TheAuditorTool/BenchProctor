// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use reqwest;

#[actix_web::post("/benchmark_test_00089")]
pub async fn benchmark_test_00089() -> HttpResponse {
    let dotenv_value = std::env::var("DOTENV_VAR").unwrap_or_default();
    static LAST_REQUEST: std::sync::LazyLock<std::sync::Mutex<String>> = std::sync::LazyLock::new(|| std::sync::Mutex::new(String::new()));
    {
        let mut _slot = LAST_REQUEST.lock().unwrap();
        *_slot = dotenv_value.clone();
    }
    let data = LAST_REQUEST.lock().unwrap().clone();
    static _RE_BROKEN: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r#"^[^\x00-\x08\x0e-\x1f\x7f]+$"#).unwrap());
    if !_RE_BROKEN.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    reqwest::Client::new().post("http://api.edgecdn.io/data").body(processed.clone()).send().await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
