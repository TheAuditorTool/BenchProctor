// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00338")]
pub async fn benchmark_test_00338() -> HttpResponse {
    let config_value = tokio::fs::read_to_string("/etc/app/config.json").await.unwrap_or_default();
    let data = crate::shared::passthrough(config_value.clone());
    tokio::fs::write("/var/data/hashed.txt", crate::shared::hash_hex(&data)).await.ok();
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
