// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};
use log;

#[actix_web::post("/benchmark_test_00048")]
pub async fn benchmark_test_00048(req: HttpRequest) -> HttpResponse {
    let ua_value = req.headers().get("user-agent").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let mut pending: std::collections::VecDeque<String> = ua_value.split(',').map(String::from).collect();
    let mut data = String::new();
    while let Some(item) = pending.pop_front() { data = item; }
    if !["asc", "desc", "name", "created"].contains(&data.as_str()) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    log::info!("User action: {}", processed);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
