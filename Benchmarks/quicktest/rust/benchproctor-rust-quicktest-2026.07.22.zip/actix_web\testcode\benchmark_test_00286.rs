// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00286")]
pub async fn benchmark_test_00286() -> HttpResponse {
    let secret_value = ["default_config_label"][0].to_string();
    let mut data = String::new();
    data.push_str(&secret_value);
    let store_cred = crate::shared::vault_get("app_secret");
    let _ct = crate::shared::encrypt_with_key(&store_cred, &data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
