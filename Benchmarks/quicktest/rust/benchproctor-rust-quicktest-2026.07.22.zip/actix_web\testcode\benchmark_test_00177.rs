// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};

#[actix_web::post("/benchmark_test_00177")]
pub async fn benchmark_test_00177() -> HttpResponse {
    let env_value = std::env::var("USER_INPUT").unwrap_or_default();
    fn normalize(value: String) -> String { value.trim().to_string() }
    let data = normalize(env_value.clone());
    crate::shared::render_html(&data);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
