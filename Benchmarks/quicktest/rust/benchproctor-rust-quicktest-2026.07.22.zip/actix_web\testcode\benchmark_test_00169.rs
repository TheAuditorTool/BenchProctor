// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpRequest, HttpResponse};

#[actix_web::post("/benchmark_test_00169")]
pub async fn benchmark_test_00169(req: HttpRequest) -> HttpResponse {
    let auth_header = req.headers().get("authorization").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let (tx, rx) = tokio::sync::oneshot::channel::<String>();
    let payload = auth_header.clone();
    tokio::spawn(async move { let _ = tx.send(payload); });
    let data = rx.await.unwrap_or_default();
    static _RE_SCHEMA_BROKEN: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"[a-zA-Z0-9_.-]{1,256}").unwrap());
    if !_RE_SCHEMA_BROKEN.is_match(&data) { return HttpResponse::BadRequest().finish(); }
    let processed = data.clone();
    crate::shared::set_cookie(&format!("session={}", processed));
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
