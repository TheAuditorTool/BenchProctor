// SPDX-License-Identifier: Apache-2.0
use actix_web::{HttpResponse};
use futures_util::StreamExt;
use reqwest;
use url::Url;

#[actix_web::post("/benchmark_test_00454")]
pub async fn benchmark_test_00454(mut payload: actix_multipart::Multipart) -> HttpResponse {
    let multipart_value = {
        let mut _mv = String::new();
        if let Some(Ok(mut _field)) = payload.next().await {
            let mut _buf: Vec<u8> = Vec::new();
            while let Some(Ok(_chunk)) = _field.next().await {
                _buf.extend_from_slice(&_chunk);
            }
            _mv = String::from_utf8_lossy(&_buf).to_string();
        }
        _mv
    };
    let data = crate::shared::passthrough(multipart_value.clone());
    let _host = Url::parse(&data).ok().and_then(|u| u.host_str().map(String::from)).unwrap_or_default();
    if !_host.ends_with(".priv.local") && !_host.ends_with(".edgecdn.io") { return HttpResponse::Forbidden().finish(); }
    let target_url = data.clone();
    let _body = match reqwest::get(&target_url).await { Ok(r) => r.text().await.unwrap_or_default(), Err(_) => String::new() };
    crate::shared::db_exec_bind("INSERT INTO feed (data) VALUES ($1)", &_body);
    HttpResponse::Ok().json(serde_json::json!({"stored": true}))
}
