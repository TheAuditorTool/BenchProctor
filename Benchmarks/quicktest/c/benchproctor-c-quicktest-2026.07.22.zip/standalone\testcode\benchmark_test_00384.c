// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00384(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    char _buf[16] = "fixedcontent12";
    int _i = atoi(data);
    if (_i >= 0 && _i < (int)sizeof(_buf)) printf("%c\n", _buf[_i]);
}
