// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
extern int sqlite3_open(const char *_filename, sqlite3 **_ppDb);
extern int sqlite3_exec(sqlite3 *_db, const char *_sql, int (*_cb)(void *, int, char **, char **), void *_arg, char **_errmsg);
extern int sqlite3_prepare_v2(sqlite3 *_db, const char *_sql, int _nByte, sqlite3_stmt **_ppStmt, const char **_pzTail);
extern int sqlite3_bind_text(sqlite3_stmt *_stmt, int _idx, const char *_text, int _n, void (*_destructor)(void *));
extern int sqlite3_step(sqlite3_stmt *_stmt);
extern int sqlite3_finalize(sqlite3_stmt *_stmt);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00276(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    long _clen = 0;
    const char *_cl = getenv("CONTENT_LENGTH");
    if (_cl != NULL) _clen = strtol(_cl, NULL, 10);
    if (_clen > 0) {
        size_t _rn = (size_t)_clen < sizeof(user_input_buf) - 1 ? (size_t)_clen : sizeof(user_input_buf) - 1;
        size_t _got = fread(user_input_buf, 1, _rn, stdin);
        user_input_buf[_got] = '\0';
    }
    const char *user_input = user_input_buf;
    const char *data = c_invoke(c_passthrough, user_input);
    if (getenv("APP_ENV") == NULL || strcmp(getenv("APP_ENV"), "test") != 0) {
        sqlite3 *_db = NULL;
        sqlite3_open("/var/app/app.db", &_db);
        char _sql[512];
        snprintf(_sql, sizeof(_sql), "SELECT * FROM users WHERE name = '%s'", data);
        sqlite3_exec(_db, _sql, NULL, NULL, NULL);
    }
}
