// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);
static const char *c_shared_input;

void benchmark_test_00448(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    unsigned char _h[32];
    SHA256((const unsigned char *)data, strlen(data), _h);
    const char *_stored = getenv("APP_PW_HASH");
    unsigned char _ref[32];
    SHA256((const unsigned char *)(_stored ? _stored : ""), _stored ? strlen(_stored) : 0, _ref);
    if (memcmp(_h, _ref, sizeof(_h)) == 0) { printf("auth ok\n"); }
}
