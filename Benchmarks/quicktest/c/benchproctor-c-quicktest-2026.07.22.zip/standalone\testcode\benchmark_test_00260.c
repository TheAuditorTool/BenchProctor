// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00260(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    const char *(*_fn)(const char *) = c_passthrough;
    const char *data = _fn(user_input);
    const char *safe = data;
    if (strcmp(data, "config.json") != 0 && strcmp(data, "data.csv") != 0) safe = "config.json";
    char _path[512];
    snprintf(_path, sizeof(_path), "/var/app/data/%s", safe);
    remove(_path);
}
