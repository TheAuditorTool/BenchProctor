// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00391(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    if (fgets(user_input_buf, sizeof(user_input_buf), stdin) == NULL) user_input_buf[0] = '\0';
    user_input_buf[strcspn(user_input_buf, "\n")] = '\0';
    const char *user_input = user_input_buf;
    c_shared_input = user_input;
    const char *data = c_shared_input;
    FILE *_cf = fopen("/var/app/data/export.csv", "a");
    if (_cf) { fprintf(_cf, "%s,exported\n", data); fclose(_cf); }
}
