// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_payload { const char *value; };

void benchmark_test_00192(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    if (fgets(user_input_buf, sizeof(user_input_buf), stdin) == NULL) user_input_buf[0] = '\0';
    user_input_buf[strcspn(user_input_buf, "\n")] = '\0';
    const char *user_input = user_input_buf;
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    char _field[600];
    size_t _fi = 0;
    if (data[0] == '=' || data[0] == '+' || data[0] == '-' || data[0] == '@') _field[_fi++] = '\'';
    for (const char *_q = data; *_q && _fi < sizeof(_field) - 2; ++_q) {
        if (*_q == '"') _field[_fi++] = '"';
        _field[_fi++] = *_q;
    }
    _field[_fi] = '\0';
    FILE *_cf = fopen("/var/app/data/export.csv", "a");
    if (_cf) { fprintf(_cf, "\"%s\",exported\n", _field); fclose(_cf); }
}
