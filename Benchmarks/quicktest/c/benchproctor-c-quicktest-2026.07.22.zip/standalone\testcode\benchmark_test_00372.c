// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00372(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    const char *safe = data;
    if (strcmp(data, "status") != 0 && strcmp(data, "health") != 0) safe = "status";
    char _cmd[512];
    snprintf(_cmd, sizeof(_cmd), "ls %s", safe);
    system(_cmd);
}
