// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00487(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    const char *data = (strlen(user_input) > 0) ? user_input : "";
    char *_found = strchr(data, '=');
    if (_found != NULL) printf("%c\n", *_found);
}
