// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
typedef struct evp_cipher_st EVP_CIPHER;
typedef struct engine_st ENGINE;
extern EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);
extern void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *_ctx);
extern const EVP_CIPHER *EVP_des_ecb(void);
extern const EVP_CIPHER *EVP_rc4(void);
extern const EVP_CIPHER *EVP_aes_256_cbc(void);
extern const EVP_CIPHER *EVP_aes_256_gcm(void);
extern int EVP_EncryptInit_ex(EVP_CIPHER_CTX *_ctx, const EVP_CIPHER *_type, ENGINE *_impl, const unsigned char *_key, const unsigned char *_iv);
extern int EVP_EncryptUpdate(EVP_CIPHER_CTX *_ctx, unsigned char *_out, int *_outl, const unsigned char *_in, int _inl);
extern int RAND_bytes(unsigned char *_buf, int _num);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00028(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    const char *data = c_invoke(c_passthrough, user_input);
    EVP_CIPHER_CTX *_ctx = EVP_CIPHER_CTX_new();
    unsigned char _ct[512];
    int _ctl = 0;
    EVP_EncryptInit_ex(_ctx, EVP_aes_256_gcm(), NULL, (const unsigned char *)"0123456789abcdef0123456789abcdef", NULL);
    EVP_EncryptUpdate(_ctx, _ct, &_ctl, (const unsigned char *)data, (int)strlen(data));
    EVP_CIPHER_CTX_free(_ctx);
}
