// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
extern int sqlite3_open(const char *_filename, sqlite3 **_ppDb);
extern int sqlite3_exec(sqlite3 *_db, const char *_sql, int (*_cb)(void *, int, char **, char **), void *_arg, char **_errmsg);
extern int sqlite3_prepare_v2(sqlite3 *_db, const char *_sql, int _nByte, sqlite3_stmt **_ppStmt, const char **_pzTail);
extern int sqlite3_bind_text(sqlite3_stmt *_stmt, int _idx, const char *_text, int _n, void (*_destructor)(void *));
extern int sqlite3_step(sqlite3_stmt *_stmt);
extern int sqlite3_finalize(sqlite3_stmt *_stmt);

void benchmark_test_00140(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    char data[512];
    size_t _li = 0;
    for (; user_input[_li] != '\0' && _li < sizeof(data) - 1; ++_li) data[_li] = user_input[_li];
    data[_li] = '\0';
    sqlite3 *_db = NULL;
    sqlite3_open("/var/app/app.db", &_db);
    char _sql[512];
    snprintf(_sql, sizeof(_sql), "SELECT * FROM users WHERE name = '%s'", data);
    sqlite3_exec(_db, _sql, NULL, NULL, NULL);
}
