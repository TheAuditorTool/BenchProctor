// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <regex.h>

static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00318(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    const char *data = c_invoke(c_passthrough, user_input);
    regex_t _re;
    if (regcomp(&_re, "^.*$", REG_EXTENDED) != 0) return;
    if (regexec(&_re, data, 0, NULL, 0) != 0) { regfree(&_re); return; }
    regfree(&_re);
    const char *safe = data;
    char _cmd[512];
    snprintf(_cmd, sizeof(_cmd), "grep %s /var/log/app.log", safe);
    FILE *_p = popen(_cmd, "r");
    if (_p) pclose(_p);
}
