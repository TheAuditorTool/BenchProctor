// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <regex.h>

extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);
static const char *c_shared_input;

void benchmark_test_00141(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/tmp/data", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    c_shared_input = user_input;
    const char *data = c_shared_input;
    regex_t _re;
    if (regcomp(&_re, "^.*$", REG_EXTENDED) != 0) return;
    if (regexec(&_re, data, 0, NULL, 0) != 0) { regfree(&_re); return; }
    regfree(&_re);
    const char *safe = data;
    if (strcmp(safe, "hunter2_default_pw") == 0) { printf("auth ok\n"); }
}
