// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00375(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    long _clen = 0;
    const char *_cl = getenv("CONTENT_LENGTH");
    if (_cl != NULL) _clen = strtol(_cl, NULL, 10);
    if (_clen > 0) {
        size_t _rn = (size_t)_clen < sizeof(user_input_buf) - 1 ? (size_t)_clen : sizeof(user_input_buf) - 1;
        size_t _got = fread(user_input_buf, 1, _rn, stdin);
        user_input_buf[_got] = '\0';
    }
    const char *user_input = user_input_buf;
    const char *data = c_invoke(c_passthrough, user_input);
    char _field[600];
    size_t _fi = 0;
    if (data[0] == '=' || data[0] == '+' || data[0] == '-' || data[0] == '@') _field[_fi++] = '\'';
    for (const char *_q = data; *_q && _fi < sizeof(_field) - 2; ++_q) {
        if (*_q == '"') _field[_fi++] = '"';
        _field[_fi++] = *_q;
    }
    _field[_fi] = '\0';
    FILE *_cf = fopen("/var/app/data/export.csv", "a");
    if (_cf) { fprintf(_cf, "\"%s\",exported\n", _field); fclose(_cf); }
}
