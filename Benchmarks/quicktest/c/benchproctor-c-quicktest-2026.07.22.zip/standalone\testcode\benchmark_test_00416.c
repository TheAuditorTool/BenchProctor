// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
typedef struct evp_cipher_st EVP_CIPHER;
typedef struct engine_st ENGINE;
extern EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);
extern void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *_ctx);
extern const EVP_CIPHER *EVP_des_ecb(void);
extern const EVP_CIPHER *EVP_rc4(void);
extern const EVP_CIPHER *EVP_aes_256_cbc(void);
extern const EVP_CIPHER *EVP_aes_256_gcm(void);
extern int EVP_EncryptInit_ex(EVP_CIPHER_CTX *_ctx, const EVP_CIPHER *_type, ENGINE *_impl, const unsigned char *_key, const unsigned char *_iv);
extern int EVP_EncryptUpdate(EVP_CIPHER_CTX *_ctx, unsigned char *_out, int *_outl, const unsigned char *_in, int _inl);
extern int RAND_bytes(unsigned char *_buf, int _num);
extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);

void benchmark_test_00416(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/etc/app/config", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    char data[512];
    size_t _len = strlen(user_input);
    size_t _w = 0;
    while (_w < _len && _w < sizeof(data) - 1) { data[_w] = user_input[_w]; ++_w; }
    data[_w] = '\0';
    FILE *_sf = fopen("/var/app/data/secret.dat", "w");
    if (_sf) { fputs(data, _sf); fclose(_sf); }
}
