// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <regex.h>

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
extern int sqlite3_open(const char *_filename, sqlite3 **_ppDb);
extern int sqlite3_exec(sqlite3 *_db, const char *_sql, int (*_cb)(void *, int, char **, char **), void *_arg, char **_errmsg);
extern int sqlite3_prepare_v2(sqlite3 *_db, const char *_sql, int _nByte, sqlite3_stmt **_ppStmt, const char **_pzTail);
extern int sqlite3_bind_text(sqlite3_stmt *_stmt, int _idx, const char *_text, int _n, void (*_destructor)(void *));
extern int sqlite3_step(sqlite3_stmt *_stmt);
extern int sqlite3_finalize(sqlite3_stmt *_stmt);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00290(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("DB_ROW_VALUE");
    if (user_input == NULL) user_input = "";
    const char *data = c_invoke(c_passthrough, user_input);
    regex_t _re;
    const char *safe = data;
    if (regcomp(&_re, "^[a-zA-Z0-9_-]+$", REG_EXTENDED) == 0) {
        if (regexec(&_re, data, 0, NULL, 0) != 0) safe = "config";
        regfree(&_re);
    }
    sqlite3 *_db = NULL;
    sqlite3_open("/var/app/app.db", &_db);
    char _sql[512];
    snprintf(_sql, sizeof(_sql), "SELECT * FROM users WHERE name = '%s'", safe);
    sqlite3_exec(_db, _sql, NULL, NULL, NULL);
}
