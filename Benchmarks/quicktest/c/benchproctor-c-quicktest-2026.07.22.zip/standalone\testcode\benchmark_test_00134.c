// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <regex.h>

static const char *c_shared_input;

void benchmark_test_00134(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("DB_ROW_VALUE");
    if (user_input == NULL) user_input = "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    regex_t _re;
    if (regcomp(&_re, "^.*$", REG_EXTENDED) != 0) return;
    if (regexec(&_re, data, 0, NULL, 0) != 0) { regfree(&_re); return; }
    regfree(&_re);
    const char *safe = data;
    long _n = strtol(safe, NULL, 10);
    char *_buf = malloc((size_t)_n);
    if (_buf) free(_buf);
}
