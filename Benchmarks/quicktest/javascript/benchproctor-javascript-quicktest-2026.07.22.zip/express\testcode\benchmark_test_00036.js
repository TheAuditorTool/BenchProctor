// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00036(req, res) {
  const userInput = req.body.payload || "";
  const data = await Promise.resolve(userInput);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00036 };
