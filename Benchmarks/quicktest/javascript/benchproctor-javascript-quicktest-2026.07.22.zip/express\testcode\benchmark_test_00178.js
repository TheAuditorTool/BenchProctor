// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00178(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = `${userInput}`;
  db.query("SELECT * FROM users WHERE id = '" + data + "'");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00178 };
