// SPDX-License-Identifier: Apache-2.0
const nodeSerialize = require("node-serialize");

async function BenchmarkTest00415(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = String(userInput).slice(0, 200);
  nodeSerialize.unserialize(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00415 };
