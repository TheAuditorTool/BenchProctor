// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const nodeUtil = require("util");
const nunjucks = require("nunjucks");

async function BenchmarkTest00442(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = nodeUtil.format("%s", userInput);
  res.send(nunjucks.renderString(data, {}));
}

module.exports = { BenchmarkTest00442 };
