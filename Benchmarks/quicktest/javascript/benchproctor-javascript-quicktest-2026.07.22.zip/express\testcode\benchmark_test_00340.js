// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00340(req, res) {
  const userInput = ["feature_flag_value"][0];
  const pending = String(userInput).split(',');
  const collected = [];
  while (pending.length) { collected.push(pending.shift()); }
  const data = collected.join(',');
  const encKey = process.env.ENC_KEY || "";
  crypto.createCipheriv("aes-256-gcm", Buffer.from(encKey.padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update(String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00340 };
