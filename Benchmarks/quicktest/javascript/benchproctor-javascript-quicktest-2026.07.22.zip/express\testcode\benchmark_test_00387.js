// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00387(req, res) {
  const userInput = req.body.field || "";
  const data = await Promise.resolve(userInput);
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00387 };
