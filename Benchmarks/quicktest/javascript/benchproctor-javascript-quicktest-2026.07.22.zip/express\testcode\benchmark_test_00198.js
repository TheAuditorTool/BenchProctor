// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");

async function BenchmarkTest00198(req, res) {
  const userInput = req.body || "";
  const data = String(userInput).slice(0, 200);
  res.send(nunjucks.renderString(data, {}));
}

module.exports = { BenchmarkTest00198 };
