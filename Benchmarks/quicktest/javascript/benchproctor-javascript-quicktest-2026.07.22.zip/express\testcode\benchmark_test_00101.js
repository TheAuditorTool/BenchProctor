// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00101(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  if (!authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00101 };
