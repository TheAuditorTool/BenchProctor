// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00275(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00275 };
