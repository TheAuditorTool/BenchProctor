// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00064(req, res) {
  const userInput = req.body || "";
  const data = Buffer.from(userInput, "utf-8").toString();
  if (!authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00064 };
