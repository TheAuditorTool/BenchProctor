// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00371(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  http.get(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00371 };
