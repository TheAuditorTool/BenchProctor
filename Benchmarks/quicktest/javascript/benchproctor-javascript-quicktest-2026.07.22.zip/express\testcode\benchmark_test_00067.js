// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const fs = require("fs");

async function BenchmarkTest00067(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(userInput)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00067 };
