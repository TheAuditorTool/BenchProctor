// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00438(req, res) {
  const userInput = req.body.payload || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  const role = String(processed);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00438 };
