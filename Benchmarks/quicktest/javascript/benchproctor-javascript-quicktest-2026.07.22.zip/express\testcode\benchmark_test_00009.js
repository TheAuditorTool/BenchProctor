// SPDX-License-Identifier: Apache-2.0
const { db, passthrough } = require("./shared");

async function BenchmarkTest00009(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = passthrough(userInput);
  if (Date.now() > 1000000000000) {
    res.send("<div>" + data + "</div>");
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00009 };
