// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00424(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  childProcess.execSync("echo " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00424 };
