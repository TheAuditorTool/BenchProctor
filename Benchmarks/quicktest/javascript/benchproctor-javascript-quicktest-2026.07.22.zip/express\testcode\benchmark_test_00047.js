// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00047(req, res) {
  const userInput = req.headers.authorization || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(processed))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00047 };
