// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00141(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  res.cookie("session", userInput, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00141 };
