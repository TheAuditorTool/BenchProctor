// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00196(req, res) {
  const userInput = req.query.id || "";
  const data = "" + userInput;
  if (!authzCheck(req.session && req.session.user, "admin")) { res.status(403).json({error: "forbidden"}); return; }
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00196 };
