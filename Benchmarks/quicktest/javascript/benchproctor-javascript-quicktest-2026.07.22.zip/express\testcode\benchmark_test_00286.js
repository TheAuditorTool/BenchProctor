// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00286(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = String(userInput).split(/\s+/).join(" ");
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00286 };
