// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00149(req, res) {
  const userInput = process.env.DOTENV_VAR || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00149 };
