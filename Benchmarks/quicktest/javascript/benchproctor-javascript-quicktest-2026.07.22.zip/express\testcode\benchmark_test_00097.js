// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00097(req, res) {
  const userInput = req.body || "";
  const data = await Promise.resolve(userInput).then(String);
  if (["https://app.jscdn.io"].includes(data)) res.set("Access-Control-Allow-Origin", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00097 };
