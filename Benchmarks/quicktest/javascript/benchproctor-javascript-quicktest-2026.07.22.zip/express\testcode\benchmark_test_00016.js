// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00016(req, res) {
  const userInput = req.query.id || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00016 };
