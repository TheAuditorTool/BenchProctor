// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00226(req, res) {
  const userInput = req.headers.host || "";
  const data = await Promise.resolve(userInput).then(String);
  const row = db.querySync("SELECT id, name FROM users").find((r) => r.name === String(data));
  const value = row.name;
  res.json({ done: true });
}

module.exports = { BenchmarkTest00226 };
