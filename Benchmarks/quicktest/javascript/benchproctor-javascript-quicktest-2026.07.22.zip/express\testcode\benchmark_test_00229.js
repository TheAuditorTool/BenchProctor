// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00229(req, res) {
  const userInput = req.body || "";
  const data = await Promise.resolve(userInput).then(String);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  res.set("X-Custom", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00229 };
