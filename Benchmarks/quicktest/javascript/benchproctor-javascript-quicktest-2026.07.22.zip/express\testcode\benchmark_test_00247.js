// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00247(req, res) {
  const userInput = req.headers.host || "";
  const data = `${userInput}`;
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  db.collection("users").findOne({ name: String(processed) });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00247 };
