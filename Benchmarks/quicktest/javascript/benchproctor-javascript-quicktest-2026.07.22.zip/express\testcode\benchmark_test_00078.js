// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00078(req, res) {
  const userInput = req.headers.host || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  res.set("X-Frame-Options", "DENY");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00078 };
