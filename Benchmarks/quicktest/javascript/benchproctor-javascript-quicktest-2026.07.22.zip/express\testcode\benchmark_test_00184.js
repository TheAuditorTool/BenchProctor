// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00184(req, res) {
  const userInput = req.body || "";
  const data = userInput != null ? userInput : '';
  eval(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00184 };
