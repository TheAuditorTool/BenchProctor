// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00199(req, res) {
  const userInput = req.body || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00199 };
