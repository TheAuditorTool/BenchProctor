// SPDX-License-Identifier: Apache-2.0
const { passthrough } = require("./shared");

async function BenchmarkTest00479(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = passthrough(userInput);
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00479 };
