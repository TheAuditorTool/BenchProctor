// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00483(req, res) {
  const userInput = req.headers.origin || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  if (process.env.NODE_ENV !== "test") {
    const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
    fs.writeFileSync("/var/app/active/pkg.bin", _content);
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00483 };
