// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00028(req, res) {
  const userInput = process.env.DOTENV_VAR || "";
  const transform = (v) => v;
  const data = transform(userInput);
  http.get("http://api.node.internal/report?data=" + String(data));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00028 };
