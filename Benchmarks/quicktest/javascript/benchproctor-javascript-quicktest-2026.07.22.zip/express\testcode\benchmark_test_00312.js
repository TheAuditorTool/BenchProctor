// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00312(req, res) {
  const userInput = req.cookies.session_token || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00312 };
