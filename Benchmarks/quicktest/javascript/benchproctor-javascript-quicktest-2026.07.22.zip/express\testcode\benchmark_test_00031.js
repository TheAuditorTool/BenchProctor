// SPDX-License-Identifier: Apache-2.0
const nodeSerialize = require("node-serialize");

async function BenchmarkTest00031(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  const _handlers = { primary: () => {
    nodeSerialize.unserialize(data);
  } };
  _handlers["primary"]();
  res.json({ done: true });
}

module.exports = { BenchmarkTest00031 };
