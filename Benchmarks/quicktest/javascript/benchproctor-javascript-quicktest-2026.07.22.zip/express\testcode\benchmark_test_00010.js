// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00010(req, res) {
  const userInput = req.query.id || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  eval('res.send("<div>" + data + "</div>");');
  res.json({ done: true });
}

module.exports = { BenchmarkTest00010 };
