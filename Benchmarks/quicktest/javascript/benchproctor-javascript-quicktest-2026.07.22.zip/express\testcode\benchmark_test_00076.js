// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00076(req, res) {
  const userInput = req.headers.authorization || "";
  const data = String(userInput).replace(/\u0000/g, "");
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00076 };
