// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00383(req, res) {
  const userInput = req.cookies.session_token || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  crypto.createHash("sha256").update(data).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00383 };
