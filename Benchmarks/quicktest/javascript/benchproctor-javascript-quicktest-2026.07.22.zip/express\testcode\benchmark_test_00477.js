// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00477(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = String(userInput).split(/\s+/).join(" ");
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00477 };
