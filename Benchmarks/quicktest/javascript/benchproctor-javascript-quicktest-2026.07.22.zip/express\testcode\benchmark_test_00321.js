// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00321(req, res) {
  const userInput = req.body.payload || "";
  const data = await Promise.resolve(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  db.collection("users").findOne({ name: String(processed) });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00321 };
