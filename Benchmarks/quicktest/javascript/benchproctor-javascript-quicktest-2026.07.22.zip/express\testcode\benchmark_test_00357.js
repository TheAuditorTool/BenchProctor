// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const xpath = require("xpath");
const xmldom = require("@xmldom/xmldom");

async function BenchmarkTest00357(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  if (!["asc","desc","name","created"].includes(userInput)) { res.status(400).json({error:"invalid"}); return; }
  const processed = userInput;
  const xmlDoc = new (xmldom.DOMParser)().parseFromString("<users/>", "text/xml");
  xpath.select("//user[name='" + processed + "']", xmlDoc);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00357 };
