// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00367(req, res) {
  const userInput = req.headers.authorization || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  crypto.createHash("md5").update(data).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00367 };
