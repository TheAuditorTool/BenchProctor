// SPDX-License-Identifier: Apache-2.0
const jsonwebtoken = require("jsonwebtoken");

async function BenchmarkTest00492(req, res) {
  const userInput = ["s3cr3t_key_test_xyz"][0];
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  const token = jsonwebtoken.sign({ sub: "user" }, String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00492 };
