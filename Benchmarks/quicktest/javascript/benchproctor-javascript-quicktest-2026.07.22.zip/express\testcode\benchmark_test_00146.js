// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00146(req, res) {
  const userInput = req.body.payload || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00146 };
