// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00058(req, res) {
  const userInput = req.body.payload || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00058 };
