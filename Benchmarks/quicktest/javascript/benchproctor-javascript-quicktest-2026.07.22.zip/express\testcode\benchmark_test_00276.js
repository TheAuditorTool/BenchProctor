// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00276(req, res) {
  const userInput = req.query.id || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  console.log("Action: " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00276 };
