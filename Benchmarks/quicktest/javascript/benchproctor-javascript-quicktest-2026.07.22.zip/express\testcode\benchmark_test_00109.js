// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00109(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  if (!["asc","desc","name","created"].includes(userInput)) { res.status(400).json({error:"invalid"}); return; }
  const processed = userInput;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00109 };
