// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");

async function BenchmarkTest00379(req, res) {
  const userInput = req.headers.referer || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.send(nunjucks.renderString(processed, {}));
}

module.exports = { BenchmarkTest00379 };
