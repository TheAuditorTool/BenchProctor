// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00183(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = "" + userInput;
  if (!authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00183 };
