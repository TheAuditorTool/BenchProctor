// SPDX-License-Identifier: Apache-2.0
const nodeSerialize = require("node-serialize");

async function BenchmarkTest00258(req, res) {
  const userInput = req.body || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  nodeSerialize.unserialize(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00258 };
