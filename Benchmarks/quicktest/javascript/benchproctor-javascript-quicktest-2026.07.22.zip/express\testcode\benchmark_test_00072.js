// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");
const fs = require("fs");

async function BenchmarkTest00072(req, res) {
  const userInput = fs.readFileSync(0, "utf8");
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  eval('childProcess.execSync("echo " + data);');
  res.json({ done: true });
}

module.exports = { BenchmarkTest00072 };
