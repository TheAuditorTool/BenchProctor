// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00159(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00159 };
