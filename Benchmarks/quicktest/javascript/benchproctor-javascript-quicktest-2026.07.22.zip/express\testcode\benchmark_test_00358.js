// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00358(req, res) {
  const userInput = req.headers.authorization || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00358 };
