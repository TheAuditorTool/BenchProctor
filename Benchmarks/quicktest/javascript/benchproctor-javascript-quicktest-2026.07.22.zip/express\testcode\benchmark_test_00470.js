// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00470(req, res) {
  const userInput = req.body || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(data)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00470 };
