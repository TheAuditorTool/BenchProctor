// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00375(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  res.set("X-Custom", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00375 };
