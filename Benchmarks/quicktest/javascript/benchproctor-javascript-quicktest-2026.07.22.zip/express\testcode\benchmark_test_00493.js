// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const crypto = require("crypto");

async function BenchmarkTest00493(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  const { publicKey: weakPubKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 512 });
  crypto.publicEncrypt(weakPubKey, Buffer.from(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00493 };
