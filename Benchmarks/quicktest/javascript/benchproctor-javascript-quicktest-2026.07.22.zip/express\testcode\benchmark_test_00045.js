// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00045(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  await new Promise((resolve) => {
    eval(data);
    resolve();
  });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00045 };
