// SPDX-License-Identifier: Apache-2.0
const https = require("https");
const nodeUtil = require("util");

async function BenchmarkTest00088(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = nodeUtil.format("%s", userInput);
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00088 };
