// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const net = require("net");

async function BenchmarkTest00365(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(data).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = data;
  net.connect(80, targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00365 };
