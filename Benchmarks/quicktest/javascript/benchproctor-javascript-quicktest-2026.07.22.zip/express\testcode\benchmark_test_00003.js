// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00003(req, res) {
  const userInput = "default_setting_value";
  const data = String(userInput).slice(0, 200);
  const encKey = process.env.ENC_KEY || "";
  crypto.createCipheriv("aes-256-gcm", Buffer.from(encKey.padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update(String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00003 };
