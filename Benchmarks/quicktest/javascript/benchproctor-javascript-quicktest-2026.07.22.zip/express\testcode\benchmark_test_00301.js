// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00301(req, res) {
  const userInput = req.body || "";
  const data = Buffer.from(userInput, "base64").toString();
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00301 };
