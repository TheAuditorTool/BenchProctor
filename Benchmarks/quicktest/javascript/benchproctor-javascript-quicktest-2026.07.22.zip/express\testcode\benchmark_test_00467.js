// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00467(req, res) {
  const userInput = process.env.DOTENV_VAR || "";
  const data = String(userInput).slice(0, 200);
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00467 };
