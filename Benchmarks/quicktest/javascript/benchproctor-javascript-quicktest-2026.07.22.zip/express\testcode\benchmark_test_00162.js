// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00162(req, res) {
  const userInput = req.headers.host || "";
  const data = await Promise.resolve(userInput).then(String);
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00162 };
