// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00306(req, res) {
  const userInput = req.headers.authorization || "";
  const data = String(userInput).replace(/\u0000/g, "");
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00306 };
