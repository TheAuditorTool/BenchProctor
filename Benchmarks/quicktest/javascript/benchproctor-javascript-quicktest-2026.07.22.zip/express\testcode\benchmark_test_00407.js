// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00407(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  crypto.createHash("sha256").update(data).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00407 };
