// SPDX-License-Identifier: Apache-2.0
const libxmljs = require("libxmljs");

async function BenchmarkTest00094(req, res) {
  const userInput = req.body || "";
  libxmljs.parseXml(userInput);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00094 };
