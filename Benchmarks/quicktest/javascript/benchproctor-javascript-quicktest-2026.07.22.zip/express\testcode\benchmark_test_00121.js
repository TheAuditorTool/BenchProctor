// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00121(req, res) {
  const userInput = req.body.multipart_field || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00121 };
