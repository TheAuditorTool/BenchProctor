// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00475(req, res) {
  const userInput = req.body || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00475 };
