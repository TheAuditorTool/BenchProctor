// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");
const path = require("path");

async function BenchmarkTest00169(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = "" + userInput;
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00169 };
