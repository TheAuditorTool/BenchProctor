// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00345(req, res) {
  const userInput = req.body.payload || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00345 };
