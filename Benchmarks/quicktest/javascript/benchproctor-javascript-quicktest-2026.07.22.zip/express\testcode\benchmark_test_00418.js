// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00418(req, res) {
  const userInput = req.headers.referer || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  if (process.env.NODE_ENV !== "test") {
    db.collection("users").findOne({ name: { $regex: data } });
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00418 };
