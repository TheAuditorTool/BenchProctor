// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00422(req, res) {
  const userInput = req.body.payload || "";
  const data = await Promise.resolve(userInput).then(String);
  if (process.env.NODE_ENV !== "test") {
    db.collection("users").findOne({ name: { $regex: data } });
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00422 };
