// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00432(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00432 };
