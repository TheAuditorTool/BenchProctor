// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00389(req, res) {
  const userInput = req.body || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00389 };
