// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00497(req, res) {
  const userInput = req.body.payload || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00497 };
