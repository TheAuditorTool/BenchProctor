// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00299(req, res) {
  const userInput = req.query.id || "";
  const data = await Promise.resolve(userInput);
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}

module.exports = { BenchmarkTest00299 };
