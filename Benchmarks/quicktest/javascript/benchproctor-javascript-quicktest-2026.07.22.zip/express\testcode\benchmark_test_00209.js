// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00209(req, res) {
  const userInput = req.headers.origin || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00209 };
