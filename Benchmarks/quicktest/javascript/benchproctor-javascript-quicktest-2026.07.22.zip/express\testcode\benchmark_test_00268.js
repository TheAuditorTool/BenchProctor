// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00268(req, res) {
  const userInput = req.params.id || "";
  console.log("Action: " + userInput);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00268 };
