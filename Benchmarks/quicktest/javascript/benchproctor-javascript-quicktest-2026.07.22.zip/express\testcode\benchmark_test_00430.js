// SPDX-License-Identifier: Apache-2.0
const { db, authCheck } = require("./shared");

async function BenchmarkTest00430(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = "" + userInput;
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00430 };
