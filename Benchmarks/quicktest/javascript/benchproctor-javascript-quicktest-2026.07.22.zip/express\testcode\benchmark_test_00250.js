// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00250(req, res) {
  const userInput = req.headers.referer || "";
  const data = decodeURIComponent(userInput);
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00250 };
