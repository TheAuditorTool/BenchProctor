// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00165(req, res) {
  const userInput = req.headers.origin || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(data)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00165 };
