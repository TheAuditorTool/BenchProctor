// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00049(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  let _host = "";
  try { _host = new URL(String(data)).hostname; } catch (e) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const _isMeta = _host.startsWith("169.254.") || /^\d+$/.test(_host) || _host === "metadata.google.internal" || _host === "metadata" || _host === "localhost" || _host.startsWith("127.");
  if (_isMeta) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const targetUrl = data;
  http.get(targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00049 };
