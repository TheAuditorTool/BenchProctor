// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00288(req, res) {
  const userInput = req.body || "";
  const data = userInput != null ? userInput : '';
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00288 };
