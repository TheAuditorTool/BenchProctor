// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00304(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = userInput != null ? userInput : '';
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00304 };
