// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00436(req, res) {
  const userInput = req.body || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00436 };
