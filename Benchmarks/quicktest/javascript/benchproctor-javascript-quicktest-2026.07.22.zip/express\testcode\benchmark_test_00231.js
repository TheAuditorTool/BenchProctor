// SPDX-License-Identifier: Apache-2.0
const libxmljs = require("libxmljs");

async function BenchmarkTest00231(req, res) {
  const userInput = req.body || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  libxmljs.parseXml(data, { noent: false, nonet: true });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00231 };
