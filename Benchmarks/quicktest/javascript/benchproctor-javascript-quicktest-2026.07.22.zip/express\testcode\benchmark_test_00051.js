// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");

async function BenchmarkTest00051(req, res) {
  const userInput = req.body.payload || "";
  const data = nodeUtil.format("%s", userInput);
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00051 };
