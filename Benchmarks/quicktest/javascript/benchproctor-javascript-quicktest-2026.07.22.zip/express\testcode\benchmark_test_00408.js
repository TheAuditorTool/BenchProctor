// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00408(req, res) {
  const userInput = req.headers.host || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(data).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = data;
  http.get(targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00408 };
