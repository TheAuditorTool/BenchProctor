// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00342(req, res) {
  const userInput = req.headers.authorization || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(processed))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00342 };
