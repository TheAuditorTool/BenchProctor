// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00351(req, res) {
  const userInput = req.body.field || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  const _host = new URL(data).hostname;
  if (!_host.endsWith(".trustmesh.internal") && !_host.endsWith(".trustcdn.io")) { res.status(403).json({error: "forbidden host"}); return; }
  const targetUrl = data;
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(targetUrl)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00351 };
