// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00024(req, res) {
  const userInput = req.body.field || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00024 };
