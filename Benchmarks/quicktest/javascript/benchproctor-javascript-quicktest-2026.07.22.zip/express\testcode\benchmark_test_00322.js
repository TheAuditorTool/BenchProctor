// SPDX-License-Identifier: Apache-2.0
const { escapeHtml } = require("./shared");

async function BenchmarkTest00322(req, res) {
  const userInput = req.params.id || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  res.send(escapeHtml(data));
}

module.exports = { BenchmarkTest00322 };
