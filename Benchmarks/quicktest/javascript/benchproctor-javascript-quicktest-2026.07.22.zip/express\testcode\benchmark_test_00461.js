// SPDX-License-Identifier: Apache-2.0
const isoDompurify = require("isomorphic-dompurify");

async function BenchmarkTest00461(req, res) {
  const userInput = req.body || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  const processed = isoDompurify.sanitize(data);
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00461 };
