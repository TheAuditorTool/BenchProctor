// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00339(req, res) {
  const userInput = req.params.id || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00339 };
