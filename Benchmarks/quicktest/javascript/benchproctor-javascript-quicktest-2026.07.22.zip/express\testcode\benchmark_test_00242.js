// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00242(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const transform = (v) => v;
  const data = transform(userInput);
  eval(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00242 };
