// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00486(req, res) {
  const userInput = req.headers.origin || "";
  const data = String(userInput).split(/\s+/).join(" ");
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00486 };
