// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00168(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  console.log("Action: " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00168 };
