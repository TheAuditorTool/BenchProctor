// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00393(req, res) {
  const userInput = req.body.field || "";
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(userInput), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00393 };
