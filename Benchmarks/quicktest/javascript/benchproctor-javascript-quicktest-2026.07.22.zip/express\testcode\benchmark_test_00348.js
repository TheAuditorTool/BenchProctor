// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");
const fs = require("fs");

async function BenchmarkTest00348(req, res) {
  const userInput = JSON.parse(fs.readFileSync("/etc/app/config.json", "utf8")).value;
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00348 };
