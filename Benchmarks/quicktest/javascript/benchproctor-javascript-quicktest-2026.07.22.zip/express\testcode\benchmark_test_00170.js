// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00170(req, res) {
  const userInput = req.body.multipart_field || "";
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  fs.writeFileSync("/var/uploads/" + processed, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00170 };
