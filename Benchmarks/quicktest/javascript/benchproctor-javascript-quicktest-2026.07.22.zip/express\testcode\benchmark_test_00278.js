// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00278(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  res.set("X-Frame-Options", "DENY");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00278 };
