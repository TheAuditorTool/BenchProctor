// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00002(req, res) {
  const userInput = req.headers.authorization || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00002 };
