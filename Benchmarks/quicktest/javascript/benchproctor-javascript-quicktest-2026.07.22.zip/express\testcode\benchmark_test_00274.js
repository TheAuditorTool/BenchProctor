// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const nunjucks = require("nunjucks");

async function BenchmarkTest00274(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  res.send(nunjucks.renderString(data, {}));
}

module.exports = { BenchmarkTest00274 };
