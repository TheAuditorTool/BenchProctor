// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00272(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  function normalize(value) { return value; }
  const data = normalize(userInput);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00272 };
