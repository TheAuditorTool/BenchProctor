// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00441(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = `${userInput}`;
  db.collection("users").findOne({ name: { $regex: data } });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00441 };
