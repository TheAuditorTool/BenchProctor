// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");
const fs = require("fs");

async function BenchmarkTest00123(req, res) {
  const userInput = req.body.field || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const _salt = crypto.randomBytes(16);
  const _digest = crypto.pbkdf2Sync(String(data), _salt, 100000, 64, "sha512").toString("hex");
  fs.writeFileSync("/var/data/secrets.txt", _salt.toString("hex") + ":" + _digest);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00123 };
