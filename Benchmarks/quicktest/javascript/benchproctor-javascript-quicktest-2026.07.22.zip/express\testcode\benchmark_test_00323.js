// SPDX-License-Identifier: Apache-2.0
const ldapjs = require("ldapjs");

async function BenchmarkTest00323(req, res) {
  const userInput = req.query.id || "";
  const data = userInput != null ? userInput : '';
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + data + ")", scope: "sub" }, () => {});
  res.json({ done: true });
}

module.exports = { BenchmarkTest00323 };
