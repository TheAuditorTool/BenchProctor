// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const fs = require("fs");
const path = require("path");

async function BenchmarkTest00105(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = Buffer.from(userInput, "base64").toString();
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00105 };
