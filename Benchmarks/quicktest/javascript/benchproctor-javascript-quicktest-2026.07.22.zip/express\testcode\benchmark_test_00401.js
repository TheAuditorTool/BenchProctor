// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00401(req, res) {
  const userInput = req.headers.host || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  const _merge = (dst, src) => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(processed)));
  res.json({ status: 'ok' }); return;
}

module.exports = { BenchmarkTest00401 };
