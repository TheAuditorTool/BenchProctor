// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00180(req, res) {
  const userInput = process.env.DOTENV_VAR || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  const _credSalt = Buffer.from(process.env.CRED_SALT || "", "hex");
  const _credHash = crypto.pbkdf2Sync(String(data), _credSalt, 100000, 64, "sha512");
  const _storedHash = Buffer.from(process.env.CRED_HASH || "", "hex");
  if (_credHash.length !== _storedHash.length || !crypto.timingSafeEqual(_credHash, _storedHash)) { res.status(401).json({error: "invalid credential"}); return; }
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00180 };
