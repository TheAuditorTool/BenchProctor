// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00478(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const { publicKey: weakPubKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 512 });
  crypto.publicEncrypt(weakPubKey, Buffer.from(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00478 };
