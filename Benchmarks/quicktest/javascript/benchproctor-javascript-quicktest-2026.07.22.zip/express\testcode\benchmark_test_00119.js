// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00119(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = userInput != null ? userInput : '';
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00119 };
