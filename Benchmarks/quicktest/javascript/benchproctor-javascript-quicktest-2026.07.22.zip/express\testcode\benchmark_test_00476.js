// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00476(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00476 };
