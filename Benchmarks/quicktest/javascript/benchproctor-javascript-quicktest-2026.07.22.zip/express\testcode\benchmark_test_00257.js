// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00257(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = userInput != null ? userInput : '';
  eval(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00257 };
