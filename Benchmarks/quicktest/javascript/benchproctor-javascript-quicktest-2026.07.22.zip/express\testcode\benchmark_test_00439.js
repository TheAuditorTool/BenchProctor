// SPDX-License-Identifier: Apache-2.0
const ldapjs = require("ldapjs");

async function BenchmarkTest00439(req, res) {
  const userInput = req.headers.host || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + data + ")", scope: "sub" }, () => {});
  res.json({ done: true });
}

module.exports = { BenchmarkTest00439 };
