// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00248(req, res) {
  const userInput = req.body.field || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  if (Date.now() > 1000000000000) {
    res.send("<div>" + data + "</div>");
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00248 };
