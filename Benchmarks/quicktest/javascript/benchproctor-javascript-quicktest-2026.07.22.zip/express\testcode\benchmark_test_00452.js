// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00452(req, res) {
  const userInput = req.cookies.session_token || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00452 };
