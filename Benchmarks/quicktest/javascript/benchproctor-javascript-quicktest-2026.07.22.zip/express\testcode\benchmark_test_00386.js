// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00386(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00386 };
