// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00264(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = "" + userInput;
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00264 };
