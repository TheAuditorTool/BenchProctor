// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00147(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = Buffer.from(userInput, "hex").toString();
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00147 };
