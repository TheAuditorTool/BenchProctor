// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");
const nodeUtil = require("util");

async function BenchmarkTest00204(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = nodeUtil.format("%s", userInput);
  fs.appendFileSync("report.csv", data + ",ok\n");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00204 };
