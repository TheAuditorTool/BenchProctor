// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const net = require("net");

async function BenchmarkTest00239(req, res) {
  const userInput = (await db.query("SELECT body FROM mq_messages WHERE queue = ? LIMIT 1", ["tasks"])).rows[0].body;
  const fields = [userInput, 'http'];
  const [data] = fields;
  net.connect(80, data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00239 };
