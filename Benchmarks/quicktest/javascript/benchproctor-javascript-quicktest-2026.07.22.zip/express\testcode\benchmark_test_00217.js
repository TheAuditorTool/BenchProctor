// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00217(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const processed = String(data).replace(/[\r\n]+/g, " ").replace(/[\w.+-]+@[\w-]+\.[a-z]{2,}/gi, "[REDACTED_EMAIL]").replace(/\b\d{13,19}\b/g, "[REDACTED_CC]");
  res.set("X-Custom", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00217 };
