// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00406(req, res) {
  const userInput = req.headers.host || "";
  const data = userInput != null ? userInput : '';
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00406 };
