// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00484(req, res) {
  const userInput = req.headers.host || "";
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(userInput))) {
    res.json({ validated: String(userInput) }); return;
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00484 };
