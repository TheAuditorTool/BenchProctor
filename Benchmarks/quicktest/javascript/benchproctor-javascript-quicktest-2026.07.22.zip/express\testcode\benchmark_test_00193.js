// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00193(req, res) {
  const userInput = ["s3cr3t_key_test_xyz"][0];
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  db.query("CONNECT password='" + String(data) + "'");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00193 };
