// SPDX-License-Identifier: Apache-2.0
const { db, authCheck } = require("./shared");

async function BenchmarkTest00033(req, res) {
  const userInput = (await db.query("SELECT bio FROM profiles WHERE user_id = ?", [1])).rows[0].bio;
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00033 };
