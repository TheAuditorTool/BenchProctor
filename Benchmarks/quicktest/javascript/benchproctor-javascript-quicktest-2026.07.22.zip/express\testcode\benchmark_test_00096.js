// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00096(req, res) {
  const userInput = req.headers.authorization || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  crypto.createHash("md5").update(processed).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00096 };
