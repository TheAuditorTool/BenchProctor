// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00465(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00465 };
