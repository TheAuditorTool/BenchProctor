// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00241(req, res) {
  const userInput = req.body.payload || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  db.query("SELECT * FROM users WHERE id = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00241 };
