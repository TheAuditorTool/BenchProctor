// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00400(req, res) {
  const userInput = req.body || "";
  const transform = (v) => v;
  const data = transform(userInput);
  JSON.parse(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00400 };
