// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00133(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = userInput != null ? userInput : '';
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00133 };
