// SPDX-License-Identifier: Apache-2.0
const net = require("net");

async function BenchmarkTest00445(req, res) {
  const userInput = process.env.EXTERNAL_API_DATA || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  net.connect(80, data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00445 };
