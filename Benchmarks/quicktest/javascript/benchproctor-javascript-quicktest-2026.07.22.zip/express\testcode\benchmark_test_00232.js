// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00232(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const transform = (v) => v;
  const data = transform(userInput);
  http.get(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00232 };
