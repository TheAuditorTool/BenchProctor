// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00374(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = userInput != null ? userInput : '';
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00374 };
