// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const http = require("http");

async function BenchmarkTest00021(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  http.get(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00021 };
