// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00498(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00498 };
