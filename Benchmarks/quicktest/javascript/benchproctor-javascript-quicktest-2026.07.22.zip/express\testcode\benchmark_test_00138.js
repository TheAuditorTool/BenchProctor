// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const http = require("http");

async function BenchmarkTest00138(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  let _host = "";
  try { _host = new URL(String(userInput)).hostname; } catch (e) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const _isMeta = _host.startsWith("169.254.") || /^\d+$/.test(_host) || _host === "metadata.google.internal" || _host === "metadata" || _host === "localhost" || _host.startsWith("127.");
  if (_isMeta) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const targetUrl = userInput;
  http.get(targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00138 };
