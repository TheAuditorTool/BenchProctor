// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00302(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00302 };
