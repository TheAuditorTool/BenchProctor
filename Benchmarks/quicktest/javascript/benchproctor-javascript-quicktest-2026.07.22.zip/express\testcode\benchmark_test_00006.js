// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");
const { passthrough } = require("./shared");

async function BenchmarkTest00006(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = passthrough(userInput);
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  childProcess.execSync("echo " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00006 };
