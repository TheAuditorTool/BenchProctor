// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00238(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00238 };
