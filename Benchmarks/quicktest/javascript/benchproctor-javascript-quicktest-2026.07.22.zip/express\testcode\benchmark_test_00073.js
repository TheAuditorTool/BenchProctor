// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const nodeUtil = require("util");

async function BenchmarkTest00073(req, res) {
  const userInput = req.headers.origin || "";
  const data = nodeUtil.format("%s", userInput);
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(data)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00073 };
