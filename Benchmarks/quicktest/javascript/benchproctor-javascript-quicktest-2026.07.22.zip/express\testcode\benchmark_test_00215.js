// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00215(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  if (process.env.NODE_ENV !== "test") {
    childProcess.execSync("echo " + data);
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00215 };
