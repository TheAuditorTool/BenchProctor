// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00448(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(processed)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00448 };
