// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00330(req, res) {
  const userInput = req.headers.referer || "";
  const data = String(userInput).split(/\s+/).join(" ");
  const processed = data.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;");
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00330 };
