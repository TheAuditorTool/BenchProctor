// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");

async function BenchmarkTest00364(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = nodeUtil.format("%s", userInput);
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00364 };
