// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00087(req, res) {
  const userInput = req.headers.referer || "";
  const transform = (v) => v;
  const data = transform(userInput);
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00087 };
