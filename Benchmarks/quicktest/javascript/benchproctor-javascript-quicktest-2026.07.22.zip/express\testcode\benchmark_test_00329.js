// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00329(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  res.set("Access-Control-Allow-Origin", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00329 };
