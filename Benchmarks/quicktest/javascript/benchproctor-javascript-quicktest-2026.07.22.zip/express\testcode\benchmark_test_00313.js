// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00313(req, res) {
  const userInput = req.headers.authorization || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00313 };
