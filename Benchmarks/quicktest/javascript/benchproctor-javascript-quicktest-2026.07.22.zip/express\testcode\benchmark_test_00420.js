// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00420(req, res) {
  const userInput = req.body.field || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00420 };
