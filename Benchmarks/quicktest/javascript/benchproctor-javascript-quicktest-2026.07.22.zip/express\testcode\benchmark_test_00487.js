// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00487(req, res) {
  const userInput = req.headers.origin || "";
  const transform = (v) => v;
  const data = transform(userInput);
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00487 };
