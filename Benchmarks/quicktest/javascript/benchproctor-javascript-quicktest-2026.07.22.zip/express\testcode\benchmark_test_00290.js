// SPDX-License-Identifier: Apache-2.0
const jsYaml = require("js-yaml");

async function BenchmarkTest00290(req, res) {
  const userInput = req.headers.referer || "";
  const data = "" + userInput;
  jsYaml.load(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00290 };
