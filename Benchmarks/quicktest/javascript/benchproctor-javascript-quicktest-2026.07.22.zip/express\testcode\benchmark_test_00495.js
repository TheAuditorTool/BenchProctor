// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00495(req, res) {
  const userInput = req.headers["user-agent"] || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const _allowedFields = ["name", "email", "bio"];
  const _incoming = JSON.parse(String(data));
  for (const _k of Object.keys(_incoming)) {
    if (!_allowedFields.includes(_k)) { res.status(400).json({error: "field not allowed"}); return; }
  }
  const processed = JSON.stringify(_incoming);
  const _merge = (dst, src) => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(processed)));
  res.json({ status: 'ok' }); return;
}

module.exports = { BenchmarkTest00495 };
