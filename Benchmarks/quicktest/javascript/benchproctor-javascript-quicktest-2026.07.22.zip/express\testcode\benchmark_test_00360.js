// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00360(req, res) {
  const userInput = req.body.payload || "";
  const data = String(userInput).split(/\s+/).join(" ");
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00360 };
