// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00388(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  eval(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00388 };
