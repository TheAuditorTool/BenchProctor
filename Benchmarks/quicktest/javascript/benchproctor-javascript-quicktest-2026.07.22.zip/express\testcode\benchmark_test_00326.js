// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00326(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00326 };
