// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const jsYaml = require("js-yaml");

async function BenchmarkTest00098(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const transform = (v) => v;
  const data = transform(userInput);
  jsYaml.load(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00098 };
