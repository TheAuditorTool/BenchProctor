// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00203(req, res) {
  const userInput = req.headers.host || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00203 };
