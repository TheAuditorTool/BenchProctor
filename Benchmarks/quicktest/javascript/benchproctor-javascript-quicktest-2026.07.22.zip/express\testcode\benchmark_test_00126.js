// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00126(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = `${userInput}`;
  const _cred = String(data);
  if (authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00126 };
