// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00412(req, res) {
  const userInput = req.body.field || "";
  const data = String(userInput).split(/\s+/).join(" ");
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00412 };
