// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00219(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const data = await Promise.resolve(userInput);
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  db.query("SELECT * FROM users WHERE id = '" + processed + "'");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00219 };
