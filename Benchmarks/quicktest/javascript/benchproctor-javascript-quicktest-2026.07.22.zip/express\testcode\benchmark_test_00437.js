// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00437(req, res) {
  const userInput = req.headers.authorization || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00437 };
