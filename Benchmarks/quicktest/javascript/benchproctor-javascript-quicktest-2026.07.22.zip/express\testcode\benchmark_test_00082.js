// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00082(req, res) {
  const userInput = req.body || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  if (typeof process.setuid === "function") process.setuid(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00082 };
