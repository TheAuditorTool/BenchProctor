// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00244(req, res) {
  const userInput = req.headers.authorization || "";
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(userInput)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00244 };
