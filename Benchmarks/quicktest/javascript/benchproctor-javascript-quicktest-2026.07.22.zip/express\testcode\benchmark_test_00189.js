// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00189(req, res) {
  const userInput = req.headers.authorization || "";
  const data = Buffer.from(userInput, "hex").toString();
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00189 };
