// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00307(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00307 };
