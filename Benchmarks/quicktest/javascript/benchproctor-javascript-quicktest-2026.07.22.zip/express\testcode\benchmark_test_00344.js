// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00344(req, res) {
  const userInput = req.headers["user-agent"] || "";
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00344 };
