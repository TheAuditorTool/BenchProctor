// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00496(req, res) {
  const userInput = req.params.id || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  db.collection("users").findOne({ name: { $regex: data } });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00496 };
