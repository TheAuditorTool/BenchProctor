// SPDX-License-Identifier: Apache-2.0
const net = require("net");

async function BenchmarkTest00255(req, res) {
  const userInput = req.headers.referer || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const _handlers = { primary: () => {
    net.connect(80, data);
  } };
  _handlers["primary"]();
  res.json({ done: true });
}

module.exports = { BenchmarkTest00255 };
