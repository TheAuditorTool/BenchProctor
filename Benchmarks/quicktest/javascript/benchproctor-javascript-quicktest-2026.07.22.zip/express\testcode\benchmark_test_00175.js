// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00175(req, res) {
  const userInput = req.headers.host || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00175 };
