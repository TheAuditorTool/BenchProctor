// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00337(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = await Promise.resolve(userInput).then(String);
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00337 };
