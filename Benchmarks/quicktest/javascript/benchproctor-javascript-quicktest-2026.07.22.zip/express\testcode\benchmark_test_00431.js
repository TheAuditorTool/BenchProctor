// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00431(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = String(userInput).slice(0, 200);
  const requested = parseInt(data, 10);
  if (!Number.isFinite(requested) || requested < 0 || requested > 1048576) { res.status(400).json({ error: "out of range" }); return; }
  const buf = Buffer.alloc(requested + 1);
  res.json({ allocated: buf.length }); return;
}

module.exports = { BenchmarkTest00431 };
