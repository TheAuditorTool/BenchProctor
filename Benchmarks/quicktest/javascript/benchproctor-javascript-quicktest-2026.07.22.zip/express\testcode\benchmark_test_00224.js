// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00224(req, res) {
  const userInput = req.headers.origin || "";
  const pending = String(userInput).split(',');
  const collected = [];
  while (pending.length) { collected.push(pending.shift()); }
  const data = collected.join(',');
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00224 };
