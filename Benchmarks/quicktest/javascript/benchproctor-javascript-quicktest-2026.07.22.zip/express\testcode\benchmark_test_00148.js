// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00148(req, res) {
  const userInput = req.headers.host || "";
  const data = await Promise.resolve(userInput);
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00148 };
