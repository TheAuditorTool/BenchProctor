// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00056(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00056 };
