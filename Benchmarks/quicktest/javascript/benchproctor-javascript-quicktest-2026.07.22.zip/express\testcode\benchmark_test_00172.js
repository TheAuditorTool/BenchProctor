// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00172(req, res) {
  const userInput = req.body.field || "";
  const data = `${userInput}`;
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00172 };
