// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00361(req, res) {
  const userInput = req.body.multipart_field || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00361 };
