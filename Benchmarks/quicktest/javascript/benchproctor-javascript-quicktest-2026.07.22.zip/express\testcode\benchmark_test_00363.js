// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const libxmljs = require("libxmljs");

async function BenchmarkTest00363(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = userInput != null ? userInput : '';
  libxmljs.parseXml(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00363 };
