// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00237(req, res) {
  const userInput = req.body.field || "";
  crypto.createCipheriv("des-ede3-ecb", Buffer.alloc(24), null).update(String(userInput));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00237 };
