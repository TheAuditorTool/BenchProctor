// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00093(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = `${userInput}`;
  const { publicKey: weakPubKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 512 });
  crypto.publicEncrypt(weakPubKey, Buffer.from(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00093 };
