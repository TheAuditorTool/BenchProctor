// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const isoDompurify = require("isomorphic-dompurify");

async function BenchmarkTest00394(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const processed = isoDompurify.sanitize(data);
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00394 };
