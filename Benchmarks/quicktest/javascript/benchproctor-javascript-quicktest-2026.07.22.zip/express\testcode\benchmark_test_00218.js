// SPDX-License-Identifier: Apache-2.0
const { db, authCheck } = require("./shared");

async function BenchmarkTest00218(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  authCheck("admin", String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00218 };
