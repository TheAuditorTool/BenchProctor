// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00384(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = String(userInput).replace(/\u0000/g, "");
  fs.writeFileSync("/var/data/secrets.txt", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00384 };
