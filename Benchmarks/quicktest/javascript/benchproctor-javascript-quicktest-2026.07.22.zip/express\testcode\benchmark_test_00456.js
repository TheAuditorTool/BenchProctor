// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00456(req, res) {
  const userInput = req.headers.authorization || "";
  const data = `${userInput}`;
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00456 };
