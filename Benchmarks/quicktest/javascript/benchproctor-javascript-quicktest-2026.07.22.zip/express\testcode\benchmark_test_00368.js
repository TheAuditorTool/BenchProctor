// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00368(req, res) {
  const userInput = "default_setting_value";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  const encKey = process.env.ENC_KEY || "";
  crypto.createCipheriv("aes-256-gcm", Buffer.from(encKey.padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update(String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00368 };
