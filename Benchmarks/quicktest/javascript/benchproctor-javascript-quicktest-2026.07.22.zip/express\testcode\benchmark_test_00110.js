// SPDX-License-Identifier: Apache-2.0
const xpath = require("xpath");
const xmldom = require("@xmldom/xmldom");

async function BenchmarkTest00110(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const xmlDoc = new (xmldom.DOMParser)().parseFromString("<users/>", "text/xml");
  xpath.select("//user[name='" + userInput + "']", xmlDoc);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00110 };
