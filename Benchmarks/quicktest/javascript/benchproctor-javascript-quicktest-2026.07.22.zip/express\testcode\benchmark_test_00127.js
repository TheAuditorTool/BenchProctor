// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00127(req, res) {
  const userInput = process.argv[2] || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  childProcess.execSync("echo " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00127 };
