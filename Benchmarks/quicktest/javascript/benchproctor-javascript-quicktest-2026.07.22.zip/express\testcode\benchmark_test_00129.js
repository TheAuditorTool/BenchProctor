// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00129(req, res) {
  const userInput = "BENCH_FAKE_HARDCODED_TOKEN_0123456789abcdef";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  crypto.createCipheriv("aes-256-gcm", Buffer.from(String(data).padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update("payload");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00129 };
