// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00423(req, res) {
  const userInput = req.body.multipart_field || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  eval(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00423 };
