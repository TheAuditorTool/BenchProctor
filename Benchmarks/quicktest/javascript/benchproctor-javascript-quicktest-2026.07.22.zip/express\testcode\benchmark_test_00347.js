// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00347(req, res) {
  const userInput = process.env.USER_INPUT || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00347 };
