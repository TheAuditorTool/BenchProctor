// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00050(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00050 };
