// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00038(req, res) {
  const userInput = req.headers.referer || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00038 };
