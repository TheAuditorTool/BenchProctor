// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");
const path = require("path");

async function BenchmarkTest00122(req, res) {
  const userInput = req.headers.origin || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00122 };
