// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00128(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00128 };
