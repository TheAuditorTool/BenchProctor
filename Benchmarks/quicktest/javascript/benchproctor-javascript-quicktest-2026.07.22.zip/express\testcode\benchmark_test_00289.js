// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00289(req, res) {
  const userInput = req.body.payload || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  JSON.parse(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00289 };
