// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00267(req, res) {
  const userInput = req.body.payload || "";
  const data = await Promise.resolve(userInput);
  if (data !== req.session.csrfToken) { res.status(403).json({error: "csrf mismatch"}); return; }
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00267 };
