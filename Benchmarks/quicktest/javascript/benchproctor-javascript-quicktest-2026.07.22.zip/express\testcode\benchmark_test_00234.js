// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00234(req, res) {
  const userInput = req.body.field || "";
  const data = String(userInput).replace(/\u0000/g, "");
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00234 };
