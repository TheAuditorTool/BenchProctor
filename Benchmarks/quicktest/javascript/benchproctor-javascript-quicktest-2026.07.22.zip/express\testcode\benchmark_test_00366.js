// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00366(req, res) {
  const userInput = req.query.id || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(data))) {
    res.json({ validated: String(data) }); return;
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00366 };
