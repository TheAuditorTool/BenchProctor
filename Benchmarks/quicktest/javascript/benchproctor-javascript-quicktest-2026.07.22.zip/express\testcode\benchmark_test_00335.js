// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00335(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00335 };
