// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00007(req, res) {
  const userInput = req.headers.referer || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  eval('res.redirect(data);');
  res.json({ done: true });
}

module.exports = { BenchmarkTest00007 };
