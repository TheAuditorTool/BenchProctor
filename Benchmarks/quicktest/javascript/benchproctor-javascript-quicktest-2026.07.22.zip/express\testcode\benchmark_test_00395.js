// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00395(req, res) {
  const userInput = req.query.id || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  crypto.createHash("sha256").update(data).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00395 };
