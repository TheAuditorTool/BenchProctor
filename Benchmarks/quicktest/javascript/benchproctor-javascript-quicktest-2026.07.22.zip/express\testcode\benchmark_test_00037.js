// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00037(req, res) {
  const userInput = req.body.field || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00037 };
