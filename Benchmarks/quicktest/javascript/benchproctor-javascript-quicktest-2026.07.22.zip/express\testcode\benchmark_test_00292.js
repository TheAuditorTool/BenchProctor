// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00292(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = String(userInput).slice(0, 200);
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00292 };
