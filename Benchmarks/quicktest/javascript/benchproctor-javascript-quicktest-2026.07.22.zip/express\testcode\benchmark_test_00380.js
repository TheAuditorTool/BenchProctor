// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00380(req, res) {
  const userInput = req.headers.authorization || "";
  const data = await Promise.resolve(userInput).then(String);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}

module.exports = { BenchmarkTest00380 };
