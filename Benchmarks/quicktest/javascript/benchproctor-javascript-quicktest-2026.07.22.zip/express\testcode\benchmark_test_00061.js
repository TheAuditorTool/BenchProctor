// SPDX-License-Identifier: Apache-2.0
const libxmljs = require("libxmljs");

async function BenchmarkTest00061(req, res) {
  const userInput = req.body || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  libxmljs.parseXml(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00061 };
