// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00296(req, res) {
  const userInput = req.body.payload || "";
  const transform = (v) => v;
  const data = transform(userInput);
  res.set("Access-Control-Allow-Origin", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00296 };
