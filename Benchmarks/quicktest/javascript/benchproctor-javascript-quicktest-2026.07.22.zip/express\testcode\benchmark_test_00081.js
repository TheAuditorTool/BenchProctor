// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00081(req, res) {
  const userInput = req.body.payload || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00081 };
