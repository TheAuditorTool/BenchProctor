// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00490(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const transform = (v) => v;
  const data = transform(userInput);
  fs.appendFileSync("report.csv", data + ",ok\n");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00490 };
