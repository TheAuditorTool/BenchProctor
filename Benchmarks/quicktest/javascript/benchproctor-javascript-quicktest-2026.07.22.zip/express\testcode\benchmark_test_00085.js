// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00085(req, res) {
  const userInput = req.body || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00085 };
