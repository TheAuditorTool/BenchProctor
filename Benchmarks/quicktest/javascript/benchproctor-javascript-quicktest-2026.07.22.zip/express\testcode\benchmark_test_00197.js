// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00197(req, res) {
  const userInput = req.body.field || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  if (data !== req.session.csrfToken) { res.status(403).json({error: "csrf mismatch"}); return; }
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00197 };
