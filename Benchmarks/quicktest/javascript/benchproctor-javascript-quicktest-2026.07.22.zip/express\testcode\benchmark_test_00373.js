// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00373(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = Buffer.from(userInput, "base64").toString();
  db.query("SELECT * FROM users ORDER BY ??", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00373 };
