// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00060(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = "" + userInput;
  const cell = /^[=+\-@]/.test(String(data)) ? "'" + data : data;
  fs.appendFileSync("report.csv", cell + ",ok\n");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00060 };
