// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00171(req, res) {
  const userInput = req.body.field || "";
  const data = String(userInput).slice(0, 200);
  const { publicKey: weakPubKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 512 });
  crypto.publicEncrypt(weakPubKey, Buffer.from(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00171 };
