// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00202(req, res) {
  const userInput = req.headers.referer || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00202 };
