// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const crypto = require("crypto");

async function BenchmarkTest00265(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00265 };
