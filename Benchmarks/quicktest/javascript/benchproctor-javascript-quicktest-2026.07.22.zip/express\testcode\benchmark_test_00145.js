// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");
const path = require("path");

async function BenchmarkTest00145(req, res) {
  const userInput = req.body || "";
  const pending = String(userInput).split(',');
  const collected = [];
  while (pending.length) { collected.push(pending.shift()); }
  const data = collected.join(',');
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00145 };
