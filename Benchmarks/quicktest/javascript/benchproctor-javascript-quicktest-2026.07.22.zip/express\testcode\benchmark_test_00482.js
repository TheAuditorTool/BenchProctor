// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00482(req, res) {
  const userInput = req.body.payload || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00482 };
