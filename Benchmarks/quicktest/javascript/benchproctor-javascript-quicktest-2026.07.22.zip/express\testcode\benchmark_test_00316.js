// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00316(req, res) {
  const userInput = req.body.multipart_field || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const _host = new URL(data).hostname;
  if (!_host.endsWith(".trustmesh.internal") && !_host.endsWith(".trustcdn.io")) { res.status(403).json({error: "forbidden host"}); return; }
  const targetUrl = data;
  http.get(targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00316 };
