// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00111(req, res) {
  const userInput = req.body.payload || "";
  const data = String(userInput).replace(/\u0000/g, "");
  const _cred = String(data);
  if (authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00111 };
