// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00399(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const row = db.querySync("SELECT id, name FROM users").find((r) => r.name === String(data));
  if (!row) { res.status(404).json({error: "not found"}); return; }
  const value = row.name;
  res.json({ done: true });
}

module.exports = { BenchmarkTest00399 };
