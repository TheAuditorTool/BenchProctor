// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00164(req, res) {
  const userInput = req.query.id || "";
  const data = String(userInput).slice(0, 200);
  console.log("Action: " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00164 };
