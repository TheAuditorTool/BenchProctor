// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");

async function BenchmarkTest00460(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = nodeUtil.format("%s", userInput);
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00460 };
