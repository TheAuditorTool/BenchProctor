// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00297(req, res) {
  const userInput = req.headers.host || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00297 };
