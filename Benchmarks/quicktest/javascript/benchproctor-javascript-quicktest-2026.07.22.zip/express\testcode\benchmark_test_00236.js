// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00236(req, res) {
  const userInput = req.body || "";
  const data = Buffer.from(userInput, "base64").toString();
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00236 };
