// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00346(req, res) {
  const userInput = req.params.id || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  childProcess.execSync("echo " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00346 };
