// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00382(req, res) {
  const userInput = req.headers.authorization || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00382 };
