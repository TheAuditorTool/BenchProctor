// SPDX-License-Identifier: Apache-2.0
const ldapjs = require("ldapjs");

async function BenchmarkTest00095(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = String(userInput).replace(/\u0000/g, "");
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + processed + ")", scope: "sub" }, () => {});
  res.json({ done: true });
}

module.exports = { BenchmarkTest00095 };
