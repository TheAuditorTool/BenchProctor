// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00457(req, res) {
  const userInput = req.body || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}

module.exports = { BenchmarkTest00457 };
