// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00151(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = Buffer.from(userInput, "hex").toString();
  crypto.createCipheriv("des-ede3-ecb", Buffer.alloc(24), null).update(String(data));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00151 };
