// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00230(req, res) {
  const userInput = req.headers.authorization || "";
  const data = `${userInput}`;
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00230 };
