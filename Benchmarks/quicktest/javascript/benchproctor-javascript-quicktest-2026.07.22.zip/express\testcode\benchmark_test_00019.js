// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00019(req, res) {
  const userInput = req.body.payload || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  console.log("Action: " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00019 };
