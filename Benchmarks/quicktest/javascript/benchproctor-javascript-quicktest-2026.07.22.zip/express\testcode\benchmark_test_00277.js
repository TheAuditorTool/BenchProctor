// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");

async function BenchmarkTest00277(req, res) {
  const userInput = req.body || "";
  const data = nodeUtil.format("%s", userInput);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00277 };
