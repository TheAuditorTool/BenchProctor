// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");

async function BenchmarkTest00132(req, res) {
  const userInput = req.params.id || "";
  const data = nodeUtil.format("%s", userInput);
  res.status(500).json({ error: "unable to process request" }); return;
}

module.exports = { BenchmarkTest00132 };
