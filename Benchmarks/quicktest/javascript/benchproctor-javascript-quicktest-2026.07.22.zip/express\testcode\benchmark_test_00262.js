// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00262(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  let data;
  try { data = JSON.parse(userInput).value || ""; }
  catch (e) { data = String(userInput); }
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00262 };
