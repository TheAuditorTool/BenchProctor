// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00411(req, res) {
  const userInput = req.headers.origin || "";
  const data = await Promise.resolve(userInput);
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  childProcess.execSync("echo " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00411 };
