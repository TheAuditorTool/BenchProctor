// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00246(req, res) {
  const userInput = req.query.id || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(processed))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00246 };
