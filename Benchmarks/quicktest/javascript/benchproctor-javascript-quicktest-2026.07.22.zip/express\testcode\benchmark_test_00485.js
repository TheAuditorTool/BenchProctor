// SPDX-License-Identifier: Apache-2.0
const { passthrough } = require("./shared");

async function BenchmarkTest00485(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = passthrough(userInput);
  if (!/^[^\x00]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  res.redirect(processed);
}

module.exports = { BenchmarkTest00485 };
