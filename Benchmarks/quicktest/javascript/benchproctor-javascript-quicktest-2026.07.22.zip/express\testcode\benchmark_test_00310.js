// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00310(req, res) {
  const userInput = req.params.id || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00310 };
