// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00104(req, res) {
  const userInput = req.params.id || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00104 };
