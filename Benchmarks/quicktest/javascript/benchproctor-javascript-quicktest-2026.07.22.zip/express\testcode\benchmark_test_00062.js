// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00062(req, res) {
  const userInput = req.query.id || "";
  const data = decodeURIComponent(userInput);
  if (typeof process.setuid === "function") process.setuid(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00062 };
