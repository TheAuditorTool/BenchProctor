// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00320(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = String(userInput).slice(0, 200);
  authCheck(String(data), "admin");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00320 };
