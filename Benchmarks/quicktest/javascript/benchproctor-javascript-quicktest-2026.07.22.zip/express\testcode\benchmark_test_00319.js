// SPDX-License-Identifier: Apache-2.0
const jsonwebtoken = require("jsonwebtoken");

async function BenchmarkTest00319(req, res) {
  const userInput = "app_display_name";
  const data = String(userInput).slice(0, 200);
  const jwtSecret = process.env.JWT_SECRET || "";
  const token = jsonwebtoken.sign({ sub: String(data) }, jwtSecret);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00319 };
