// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00331(req, res) {
  const userInput = process.env.EXTERNAL_API_DATA || "";
  const data = `${userInput}`;
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(data).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = data;
  res.redirect(targetUrl);
}

module.exports = { BenchmarkTest00331 };
