// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00030(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  const allowedFiles = new Set(["config.json", "index.html", "readme.md"]);
  if (!allowedFiles.has(data)) { res.status(403).json({error:"forbidden"}); return; }
  const checkedPath = "/var/app/data/" + data;
  fs.unlinkSync(checkedPath);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00030 };
