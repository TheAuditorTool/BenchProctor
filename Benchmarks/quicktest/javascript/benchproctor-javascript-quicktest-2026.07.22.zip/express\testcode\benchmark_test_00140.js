// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00140(req, res) {
  const userInput = "app_display_name";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const encKey = process.env.ENC_KEY || "";
  crypto.createCipheriv("aes-256-gcm", Buffer.from(encKey.padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update(String(data));
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00140 };
