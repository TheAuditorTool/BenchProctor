// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00305(req, res) {
  const userInput = req.body || "";
  const transform = (v) => v;
  const data = transform(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00305 };
