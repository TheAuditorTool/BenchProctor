// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const zod = require("zod");

async function BenchmarkTest00245(req, res) {
  const userInput = process.env.USER_INPUT || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  db.collection("users").findOne({ name: String(processed) });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00245 };
