// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00090(req, res) {
  const userInput = req.params.id || "";
  const data = userInput != null ? userInput : '';
  const processed = data.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;");
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00090 };
