// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00157(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const data = String(userInput).slice(0, 200);
  authCheck(String(data), "admin");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00157 };
