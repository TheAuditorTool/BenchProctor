// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00397(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = String(userInput).slice(0, 200);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00397 };
