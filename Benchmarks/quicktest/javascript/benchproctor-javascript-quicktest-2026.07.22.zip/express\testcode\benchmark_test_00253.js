// SPDX-License-Identifier: Apache-2.0
const jsonwebtoken = require("jsonwebtoken");

async function BenchmarkTest00253(req, res) {
  const userInput = ["feature_flag_value"][0];
  const data = "" + userInput;
  const jwtSecret = process.env.JWT_SECRET || "";
  const token = jsonwebtoken.sign({ sub: String(data) }, jwtSecret);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00253 };
