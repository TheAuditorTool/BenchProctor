// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00260(req, res) {
  const userInput = req.headers.referer || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00260 };
