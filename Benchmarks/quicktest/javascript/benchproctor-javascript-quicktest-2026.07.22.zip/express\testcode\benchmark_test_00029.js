// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");

async function BenchmarkTest00029(req, res) {
  const userInput = process.env.USER_INPUT || "";
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  res.send(nunjucks.renderString(data, {}));
}

module.exports = { BenchmarkTest00029 };
