// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00252(req, res) {
  const userInput = req.headers.host || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(processed)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00252 };
