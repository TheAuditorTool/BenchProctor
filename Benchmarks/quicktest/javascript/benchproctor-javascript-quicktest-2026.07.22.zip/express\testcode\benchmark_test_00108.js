// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00108(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = String(userInput).slice(0, 200);
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00108 };
