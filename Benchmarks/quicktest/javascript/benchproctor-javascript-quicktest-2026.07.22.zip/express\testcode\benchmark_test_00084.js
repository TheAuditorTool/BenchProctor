// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00084(req, res) {
  const userInput = req.body.payload || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const storeCred = process.env.APP_SECRET || "";
  authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00084 };
