// SPDX-License-Identifier: Apache-2.0
const ldapjs = require("ldapjs");

async function BenchmarkTest00295(req, res) {
  const userInput = req.headers.authorization || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + data + ")", scope: "sub" }, () => {});
  res.json({ done: true });
}

module.exports = { BenchmarkTest00295 };
