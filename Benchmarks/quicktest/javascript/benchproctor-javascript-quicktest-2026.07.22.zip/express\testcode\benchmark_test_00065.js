// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00065(req, res) {
  const userInput = req.query.id || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00065 };
