// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00263(req, res) {
  const userInput = req.body.field || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  let _host = "";
  try { _host = new URL(String(data)).hostname; } catch (e) { res.status(403).json({error:"private or loopback address not allowed"}); return; }
  const _blocked = /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(_host) || /^\d+$/.test(_host) || _host === "localhost" || _host === "metadata.google.internal" || _host === "metadata" || _host.startsWith("[");
  if (_blocked) { res.status(403).json({error:"private or loopback address not allowed"}); return; }
  const targetUrl = data;
  http.get(targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00263 };
