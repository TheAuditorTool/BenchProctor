// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00035(req, res) {
  const userInput = req.headers.referer || "";
  const data = decodeURIComponent(userInput);
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00035 };
