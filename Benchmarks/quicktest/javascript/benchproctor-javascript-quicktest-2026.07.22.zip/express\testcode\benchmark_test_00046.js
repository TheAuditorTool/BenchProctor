// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00046(req, res) {
  const userInput = req.params.id || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const processed = String(data).replace(/[\r\n]+/g, " ").replace(/[\w.+-]+@[\w-]+\.[a-z]{2,}/gi, "[REDACTED_EMAIL]").replace(/\b\d{13,19}\b/g, "[REDACTED_CC]");
  res.set("X-Custom", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00046 };
