// SPDX-License-Identifier: Apache-2.0
const zod = require("zod");

async function BenchmarkTest00463(req, res) {
  const userInput = req.headers["user-agent"] || "";
  const data = String(userInput).split(/\s+/).join(" ");
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00463 };
