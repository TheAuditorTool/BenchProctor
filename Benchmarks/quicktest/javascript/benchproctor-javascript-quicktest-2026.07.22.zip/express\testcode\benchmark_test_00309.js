// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const fs = require("fs");

async function BenchmarkTest00309(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}

module.exports = { BenchmarkTest00309 };
