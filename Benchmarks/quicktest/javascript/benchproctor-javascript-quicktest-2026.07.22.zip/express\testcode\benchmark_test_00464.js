// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00464(req, res) {
  const userInput = req.body || "";
  const data = await Promise.resolve(userInput);
  const parsedId = parseInt(data, 10);
  if (isNaN(parsedId)) { res.status(400).json({error:'invalid'}); return; }
  db.query("SELECT * FROM users WHERE id = '" + parsedId + "'");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00464 };
