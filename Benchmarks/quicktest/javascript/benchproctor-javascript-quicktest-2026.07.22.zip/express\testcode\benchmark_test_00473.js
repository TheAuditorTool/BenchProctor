// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00473(req, res) {
  const userInput = req.params.id || "";
  const pending = String(userInput).split(',');
  const collected = [];
  while (pending.length) { collected.push(pending.shift()); }
  const data = collected.join(',');
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00473 };
