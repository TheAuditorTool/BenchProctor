// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00136(req, res) {
  const userInput = req.body.field || "";
  const data = "" + userInput;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00136 };
