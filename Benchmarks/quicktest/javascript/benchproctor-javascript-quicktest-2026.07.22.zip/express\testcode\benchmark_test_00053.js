// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00053(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00053 };
