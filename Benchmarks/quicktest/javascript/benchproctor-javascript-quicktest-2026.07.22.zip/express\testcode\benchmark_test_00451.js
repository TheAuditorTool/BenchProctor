// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");

async function BenchmarkTest00451(req, res) {
  const userInput = req.cookies.session_token || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.send(nunjucks.renderString(processed, {}));
}

module.exports = { BenchmarkTest00451 };
