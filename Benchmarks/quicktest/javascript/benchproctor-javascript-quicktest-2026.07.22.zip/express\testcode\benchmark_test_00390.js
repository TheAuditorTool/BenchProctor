// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00390(req, res) {
  const userInput = req.body.payload || "";
  const data = await Promise.resolve(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  childProcess.execSync("echo " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00390 };
