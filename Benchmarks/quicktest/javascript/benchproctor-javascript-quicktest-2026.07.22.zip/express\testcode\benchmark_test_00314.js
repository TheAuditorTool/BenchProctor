// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00314(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = String(userInput).slice(0, 200);
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00314 };
