// SPDX-License-Identifier: Apache-2.0
const { passthrough } = require("./shared");

async function BenchmarkTest00174(req, res) {
  const userInput = req.headers.origin || "";
  const data = passthrough(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00174 };
