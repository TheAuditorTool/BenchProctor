// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00308(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}

module.exports = { BenchmarkTest00308 };
