// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00092(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(processed))) {
    res.json({ validated: String(processed) }); return;
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00092 };
