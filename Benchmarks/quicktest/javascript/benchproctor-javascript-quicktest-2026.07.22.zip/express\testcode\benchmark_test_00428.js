// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00428(req, res) {
  const userInput = req.query.id || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  res.set("X-Frame-Options", "DENY");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00428 };
