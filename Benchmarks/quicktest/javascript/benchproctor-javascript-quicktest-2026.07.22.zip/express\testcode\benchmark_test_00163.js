// SPDX-License-Identifier: Apache-2.0
const zod = require("zod");

async function BenchmarkTest00163(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  const _parsed = zod.z.string().regex(/^[^\x00-\x08\x0e-\x1f\x7f]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error: 'invalid'}); return; }
  const processed = _parsed.data;
  res.cookie("session", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00163 };
