// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00328(req, res) {
  const userInput = req.params.id || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}

module.exports = { BenchmarkTest00328 };
