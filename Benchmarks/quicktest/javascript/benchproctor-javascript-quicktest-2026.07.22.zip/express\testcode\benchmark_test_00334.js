// SPDX-License-Identifier: Apache-2.0
const { passthrough } = require("./shared");

async function BenchmarkTest00334(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = passthrough(userInput);
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  const _merge = (dst, src) => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(processed)));
  res.json({ status: 'ok' }); return;
}

module.exports = { BenchmarkTest00334 };
