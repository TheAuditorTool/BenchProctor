// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00018(req, res) {
  const userInput = req.headers.host || "";
  const data = userInput != null ? userInput : '';
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00018 };
