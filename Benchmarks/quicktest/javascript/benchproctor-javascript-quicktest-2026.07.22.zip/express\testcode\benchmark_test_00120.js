// SPDX-License-Identifier: Apache-2.0
const libxmljs = require("libxmljs");

async function BenchmarkTest00120(req, res) {
  const userInput = req.body.field || "";
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  libxmljs.parseXml(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00120 };
