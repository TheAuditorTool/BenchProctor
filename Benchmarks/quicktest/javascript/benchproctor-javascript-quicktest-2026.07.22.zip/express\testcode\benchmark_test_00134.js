// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00134(req, res) {
  const userInput = process.env.USER_INPUT || "";
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  if (Date.now() > 1000000000000) {
    res.redirect(data);
  }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00134 };
