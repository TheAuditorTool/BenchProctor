// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00433(req, res) {
  const userInput = req.body || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00433 };
