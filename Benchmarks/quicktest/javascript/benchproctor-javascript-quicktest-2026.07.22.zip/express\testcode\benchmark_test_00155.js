// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00155(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = Buffer.from(userInput, "hex").toString();
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00155 };
