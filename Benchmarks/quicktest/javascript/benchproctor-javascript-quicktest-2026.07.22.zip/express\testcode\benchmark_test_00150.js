// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00150(req, res) {
  const userInput = req.body || "";
  const data = "" + userInput;
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00150 };
