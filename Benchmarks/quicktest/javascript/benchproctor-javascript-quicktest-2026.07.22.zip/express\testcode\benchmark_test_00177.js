// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00177(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = `${userInput}`;
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00177 };
