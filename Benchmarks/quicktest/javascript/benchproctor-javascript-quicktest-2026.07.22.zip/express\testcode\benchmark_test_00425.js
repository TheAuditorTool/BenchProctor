// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00425(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  fs.appendFileSync("report.csv", processed + ",ok\n");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00425 };
