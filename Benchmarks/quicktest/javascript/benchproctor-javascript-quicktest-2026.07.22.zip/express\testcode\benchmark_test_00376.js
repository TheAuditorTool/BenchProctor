// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00376(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = "" + userInput;
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00376 };
