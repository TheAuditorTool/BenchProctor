// SPDX-License-Identifier: Apache-2.0
const net = require("net");

async function BenchmarkTest00080(req, res) {
  const userInput = req.cookies.session_token || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  net.connect(80, data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00080 };
