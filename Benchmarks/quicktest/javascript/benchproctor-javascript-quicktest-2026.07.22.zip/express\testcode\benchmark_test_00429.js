// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00429(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const pending = String(userInput).split(',');
  const collected = [];
  while (pending.length) { collected.push(pending.shift()); }
  const data = collected.join(',');
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00429 };
