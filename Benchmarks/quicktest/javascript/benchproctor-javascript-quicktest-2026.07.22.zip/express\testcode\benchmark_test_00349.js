// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00349(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00349 };
