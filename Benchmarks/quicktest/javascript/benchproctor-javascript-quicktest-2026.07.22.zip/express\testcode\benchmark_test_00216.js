// SPDX-License-Identifier: Apache-2.0
const isoDompurify = require("isomorphic-dompurify");

async function BenchmarkTest00216(req, res) {
  const userInput = req.headers.authorization || "";
  const data = "" + userInput;
  const processed = isoDompurify.sanitize(data);
  res.send("<div>" + processed + "</div>");
}

module.exports = { BenchmarkTest00216 };
