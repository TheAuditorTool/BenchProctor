// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00285(req, res) {
  const userInput = req.body.field || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  eval('http.get(data);');
  res.json({ done: true });
}

module.exports = { BenchmarkTest00285 };
