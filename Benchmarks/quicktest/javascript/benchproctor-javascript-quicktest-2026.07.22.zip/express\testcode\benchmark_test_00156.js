// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const zod = require("zod");

async function BenchmarkTest00156(req, res) {
  const userInput = req.query.id || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  db.collection("users").findOne({ name: String(processed) });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00156 };
