// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00022(req, res) {
  const userInput = req.headers.authorization || "";
  const data = "" + userInput;
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00022 };
