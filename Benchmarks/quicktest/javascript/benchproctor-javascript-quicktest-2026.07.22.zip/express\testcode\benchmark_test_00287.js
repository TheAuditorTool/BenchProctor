// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00287(req, res) {
  const userInput = req.headers.referer || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00287 };
