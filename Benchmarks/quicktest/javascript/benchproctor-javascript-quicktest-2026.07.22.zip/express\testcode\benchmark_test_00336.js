// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00336(req, res) {
  const userInput = req.headers["x-custom-header"] || "";
  const data = String(userInput).slice(0, 200);
  res.status(500).json({ error: "Internal error" }); return;
}

module.exports = { BenchmarkTest00336 };
