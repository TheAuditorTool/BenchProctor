// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00251(req, res) {
  const userInput = req.headers.authorization || "";
  const data = Buffer.from(userInput, "base64").toString();
  globalThis._loginAttempts = globalThis._loginAttempts || {};
  const _who = String(data).slice(0, 64);
  if ((globalThis._loginAttempts[_who] || 0) >= 5) { res.status(429).json({error: "too many attempts"}); return; }
  globalThis._loginAttempts[_who] = (globalThis._loginAttempts[_who] || 0) + 1;
  const _cred = String(data);
  if (authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00251 };
