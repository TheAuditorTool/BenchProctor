// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00458(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00458 };
