// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00266(req, res) {
  const userInput = req.headers.origin || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00266 };
