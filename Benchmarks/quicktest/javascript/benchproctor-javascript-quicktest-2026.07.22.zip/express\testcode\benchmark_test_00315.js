// SPDX-License-Identifier: Apache-2.0
const nodeUtil = require("util");
const libxmljs = require("libxmljs");

async function BenchmarkTest00315(req, res) {
  const userInput = req.body || "";
  const data = nodeUtil.format("%s", userInput);
  libxmljs.parseXml(data, { noent: false, nonet: true });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00315 };
