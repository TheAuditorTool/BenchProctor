// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00494(req, res) {
  const userInput = process.env.USER_INPUT || "";
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  res.cookie("session", data, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00494 };
