// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00311(req, res) {
  const userInput = req.body || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00311 };
