// SPDX-License-Identifier: Apache-2.0
const { authzCheck } = require("./shared");

async function BenchmarkTest00186(req, res) {
  const userInput = req.params.id || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  if (!authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00186 };
