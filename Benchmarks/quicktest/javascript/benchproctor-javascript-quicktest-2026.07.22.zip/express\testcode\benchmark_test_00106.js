// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00106(req, res) {
  const userInput = req.cookies.session_token || "";
  const transform = (v) => v;
  const data = transform(userInput);
  res.send("<div>" + data + "</div>");
}

module.exports = { BenchmarkTest00106 };
