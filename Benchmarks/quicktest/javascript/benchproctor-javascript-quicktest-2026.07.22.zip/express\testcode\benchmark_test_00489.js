// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00489(req, res) {
  const userInput = req.headers.host || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  crypto.createCipheriv("des-ede3-ecb", Buffer.alloc(24), null).update(String(data));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00489 };
