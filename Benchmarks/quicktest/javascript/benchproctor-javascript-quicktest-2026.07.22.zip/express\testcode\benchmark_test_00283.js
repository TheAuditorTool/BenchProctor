// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");

async function BenchmarkTest00283(req, res) {
  const userInput = req.headers.authorization || "";
  const data = Buffer.from(userInput, "hex").toString();
  res.send(nunjucks.renderString(data, {}));
}

module.exports = { BenchmarkTest00283 };
