// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00191(req, res) {
  const userInput = req.body.multipart_field || "";
  const capture = (v) => () => v;
  const readInput = capture(userInput);
  const data = readInput();
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00191 };
