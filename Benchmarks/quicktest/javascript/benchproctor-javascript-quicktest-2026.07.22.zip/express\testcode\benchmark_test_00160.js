// SPDX-License-Identifier: Apache-2.0
const http = require("http");

async function BenchmarkTest00160(req, res) {
  const userInput = req.body.multipart_field || "";
  const _obj = { payload: userInput };
  const data = _obj['payload'];
  eval('http.get(data);');
  res.json({ done: true });
}

module.exports = { BenchmarkTest00160 };
