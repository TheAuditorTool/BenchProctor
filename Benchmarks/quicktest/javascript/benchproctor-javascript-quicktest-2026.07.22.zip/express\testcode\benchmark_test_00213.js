// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00213(req, res) {
  const userInput = ["s3cr3t_key_test_xyz"][0];
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  crypto.createCipheriv("aes-256-gcm", Buffer.from(String(data).padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update("payload");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00213 };
