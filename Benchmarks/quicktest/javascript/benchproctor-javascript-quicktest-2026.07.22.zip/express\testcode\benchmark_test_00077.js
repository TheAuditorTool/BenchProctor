// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");

async function BenchmarkTest00077(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = Buffer.from(userInput, "base64").toString();
  crypto.createHash("sha256").update(data).digest("hex");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00077 };
