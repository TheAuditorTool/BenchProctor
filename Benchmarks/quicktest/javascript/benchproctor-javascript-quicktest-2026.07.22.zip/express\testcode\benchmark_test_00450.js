// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00450(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = "" + userInput;
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00450 };
