// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00192(req, res) {
  const userInput = req.body.field || "";
  const data = await new Promise((resolve) => setImmediate(() => resolve(userInput)));
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(processed)]);
  res.json({ updated: true }); return;
}

module.exports = { BenchmarkTest00192 };
