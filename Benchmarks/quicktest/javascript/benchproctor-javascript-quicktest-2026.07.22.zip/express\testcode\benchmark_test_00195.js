// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00195(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const processed = data.length > 64 ? data.slice(0, 64) : data;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(processed))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00195 };
