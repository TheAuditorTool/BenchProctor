// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const nunjucks = require("nunjucks");

async function BenchmarkTest00282(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = String(userInput).slice(0, 200);
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.send(nunjucks.renderString(processed, {}));
}

module.exports = { BenchmarkTest00282 };
