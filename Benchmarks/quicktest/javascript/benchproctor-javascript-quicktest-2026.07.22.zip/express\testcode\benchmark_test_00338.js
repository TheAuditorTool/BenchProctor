// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00338(req, res) {
  const userInput = req.body.payload || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00338 };
