// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00491(req, res) {
  const userInput = req.query.id || "";
  const data = `${userInput}`;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.set("X-Custom", processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00491 };
