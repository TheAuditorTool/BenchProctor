// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00208(req, res) {
  const userInput = process.env.USER_INPUT || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00208 };
