// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00068(req, res) {
  const userInput = req.headers.authorization || "";
  globalThis.lastRequestValue = userInput;
  const data = globalThis.lastRequestValue;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00068 };
