// SPDX-License-Identifier: Apache-2.0
const childProcess = require("child_process");

async function BenchmarkTest00083(req, res) {
  const userInput = req.headers["user-agent"] || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  childProcess.execFileSync("echo", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00083 };
