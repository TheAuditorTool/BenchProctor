// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00176(req, res) {
  const userInput = req.headers.authorization || "";
  const data = userInput != null ? userInput : '';
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00176 };
