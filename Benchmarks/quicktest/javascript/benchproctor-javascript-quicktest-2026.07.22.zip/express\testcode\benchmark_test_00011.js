// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00011(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = await Promise.resolve(userInput);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed = data;
  eval(processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00011 };
