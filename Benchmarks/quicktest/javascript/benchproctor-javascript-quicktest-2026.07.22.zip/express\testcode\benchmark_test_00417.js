// SPDX-License-Identifier: Apache-2.0
const https = require("https");

async function BenchmarkTest00417(req, res) {
  const userInput = req.query.id || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ done: true });
}

module.exports = { BenchmarkTest00417 };
