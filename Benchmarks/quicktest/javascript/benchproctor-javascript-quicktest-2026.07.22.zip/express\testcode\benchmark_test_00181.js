// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00181(req, res) {
  const userInput = req.headers.origin || "";
  res.status(500).json({ error: userInput, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00181 };
