// SPDX-License-Identifier: Apache-2.0
const nunjucks = require("nunjucks");
const zod = require("zod");

async function BenchmarkTest00142(req, res) {
  const userInput = req.headers["x-forwarded-for"] || "";
  let data;
  const onInput = (v) => { data = v; };
  onInput(userInput);
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  res.send(nunjucks.renderString(processed, {}));
}

module.exports = { BenchmarkTest00142 };
