// SPDX-License-Identifier: Apache-2.0
const { authCheck } = require("./shared");

async function BenchmarkTest00468(req, res) {
  const userInput = req.body.field || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  if (!authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00468 };
