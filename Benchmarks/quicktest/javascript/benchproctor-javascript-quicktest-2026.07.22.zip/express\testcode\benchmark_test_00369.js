// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const https = require("https");

async function BenchmarkTest00369(req, res) {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const transform = (v) => v;
  const data = transform(userInput);
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00369 };
