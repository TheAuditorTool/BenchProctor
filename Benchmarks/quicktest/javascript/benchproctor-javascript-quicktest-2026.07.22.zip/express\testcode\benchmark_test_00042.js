// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00042(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = String(userInput).slice(0, 200);
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}

module.exports = { BenchmarkTest00042 };
