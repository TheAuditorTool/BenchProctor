// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00225(req, res) {
  const userInput = req.headers.authorization || "";
  const parts = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data = parts.join(',');
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00225 };
