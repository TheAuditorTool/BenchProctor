// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00034(req, res) {
  const userInput = req.headers.origin || "";
  const data = String(userInput).split(/\s+/).join(" ");
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ done: true });
}

module.exports = { BenchmarkTest00034 };
