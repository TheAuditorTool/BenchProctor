// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00052(req, res) {
  const userInput = req.cookies.session_token || "";
  const data = decodeURIComponent(userInput);
  const _merge = (dst, src) => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(data)));
  res.json({ status: 'ok' }); return;
}

module.exports = { BenchmarkTest00052 };
