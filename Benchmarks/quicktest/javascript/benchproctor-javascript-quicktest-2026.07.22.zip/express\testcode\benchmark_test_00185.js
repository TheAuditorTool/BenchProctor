// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00185(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  function normalize(value) { return value; }
  const data = normalize(userInput);
  fs.appendFileSync("report.csv", data + ",ok\n");
  res.json({ status: "ok" });
}

module.exports = { BenchmarkTest00185 };
