// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00405(req, res) {
  const userInput = req.params.id || "";
  const data = userInput != null ? userInput : '';
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00405 };
