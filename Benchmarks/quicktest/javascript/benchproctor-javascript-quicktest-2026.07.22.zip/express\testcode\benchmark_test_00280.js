// SPDX-License-Identifier: Apache-2.0
const net = require("net");

async function BenchmarkTest00280(req, res) {
  const userInput = req.body.multipart_field || "";
  const data = await Promise.resolve(userInput);
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(data).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = data;
  net.connect(80, targetUrl);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00280 };
