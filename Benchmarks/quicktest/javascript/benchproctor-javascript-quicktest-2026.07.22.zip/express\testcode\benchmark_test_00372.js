// SPDX-License-Identifier: Apache-2.0
const { db, passthrough } = require("./shared");

async function BenchmarkTest00372(req, res) {
  const userInput = (req.file && req.file.originalname) || "";
  const data = passthrough(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  db.query("SELECT * FROM users WHERE id = '" + processed + "'");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00372 };
