// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00210(req, res) {
  const userInput = req.headers.host || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  console.log("Action: " + data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00210 };
