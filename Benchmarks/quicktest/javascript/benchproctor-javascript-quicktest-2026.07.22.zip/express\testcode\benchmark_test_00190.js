// SPDX-License-Identifier: Apache-2.0
const fs = require("fs");

async function BenchmarkTest00190(req, res) {
  const userInput = req.params.id || "";
  const transform = (v) => v;
  const data = transform(userInput);
  const allowedFiles = new Set(["config.json", "index.html", "readme.md"]);
  if (!allowedFiles.has(data)) { res.status(403).json({error:"forbidden"}); return; }
  const checkedPath = "/var/app/data/" + data;
  fs.unlinkSync(checkedPath);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00190 };
