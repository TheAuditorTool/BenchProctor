// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00447(req, res) {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const _mod = await import('./shared.mjs');
  const data = _mod.passthrough(userInput);
  res.set("X-Custom", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00447 };
