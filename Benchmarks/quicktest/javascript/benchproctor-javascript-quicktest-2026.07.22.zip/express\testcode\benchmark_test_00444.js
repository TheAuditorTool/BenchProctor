// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");
const fs = require("fs");
const path = require("path");

async function BenchmarkTest00444(req, res) {
  const userInput = (await db.query("SELECT bio FROM profiles WHERE user_id = ?", [1])).rows[0].bio;
  const data = String(userInput).split(/\s+/).join(" ");
  const checkedPath = "/var/app/data/" + path.basename(data);
  fs.writeFileSync(checkedPath, "data");
  res.json({ done: true });
}

module.exports = { BenchmarkTest00444 };
