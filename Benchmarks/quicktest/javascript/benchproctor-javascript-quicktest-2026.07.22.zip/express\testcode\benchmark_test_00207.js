// SPDX-License-Identifier: Apache-2.0
const zod = require("zod");
const { passthrough } = require("./shared");

async function BenchmarkTest00207(req, res) {
  const userInput = (req.body.variables && req.body.variables.input) || "";
  const data = passthrough(userInput);
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  console.log("Action: " + processed);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00207 };
