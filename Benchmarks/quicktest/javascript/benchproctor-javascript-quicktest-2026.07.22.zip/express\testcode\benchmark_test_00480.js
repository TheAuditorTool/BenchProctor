// SPDX-License-Identifier: Apache-2.0
const crypto = require("crypto");
const fs = require("fs");

async function BenchmarkTest00480(req, res) {
  const userInput = req.body.field || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const _ek = crypto.createHash("sha256").update(process.env.DATA_ENC_KEY || "").digest();
  const _eiv = crypto.randomBytes(12);
  const _cipher = crypto.createCipheriv("aes-256-gcm", _ek, _eiv);
  const _enc = Buffer.concat([_cipher.update(String(data), "utf8"), _cipher.final()]).toString("base64");
  const _ct = _enc + "." + _cipher.getAuthTag().toString("base64");
  fs.writeFileSync("/var/data/secrets.enc", _ct);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00480 };
