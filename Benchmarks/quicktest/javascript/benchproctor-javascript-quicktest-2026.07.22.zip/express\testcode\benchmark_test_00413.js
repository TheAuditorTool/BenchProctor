// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00413(req, res) {
  const userInput = req.body.payload || "";
  const transform = (v) => v;
  const data = transform(userInput);
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00413 };
