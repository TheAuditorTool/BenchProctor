// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00205(req, res) {
  const userInput = req.headers.authorization || "";
  class RequestPayload { constructor(value) { this.value = value; } }
  const data = new RequestPayload(userInput).value;
  JSON.parse(data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00205 };
