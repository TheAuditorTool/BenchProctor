// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00200(req, res) {
  const userInput = req.headers.referer || "";
  res.cookie("session", userInput, { secure: true, httpOnly: true, sameSite: "strict" });
  res.json({ done: true });
}

module.exports = { BenchmarkTest00200 };
