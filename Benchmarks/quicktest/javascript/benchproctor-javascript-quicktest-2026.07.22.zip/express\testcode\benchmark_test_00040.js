// SPDX-License-Identifier: Apache-2.0

async function BenchmarkTest00040(req, res) {
  const userInput = req.headers.authorization || "";
  const data = "" + userInput;
  res.cookie("session", data);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00040 };
