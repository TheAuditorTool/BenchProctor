// SPDX-License-Identifier: Apache-2.0
const { db } = require("./shared");

async function BenchmarkTest00474(req, res) {
  const userInput = req.body.payload || "";
  const data = String(userInput).replace(/\u0000/g, "");
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ done: true });
}

module.exports = { BenchmarkTest00474 };
