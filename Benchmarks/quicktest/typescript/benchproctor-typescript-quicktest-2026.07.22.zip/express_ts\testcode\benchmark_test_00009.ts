// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as nodeUtil from "util";

export const BenchmarkTest00009 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const data = nodeUtil.format("%s", userInput);
  fs.appendFileSync("report.csv", data + ",ok\n");
  res.json({ status: "ok" });
}
