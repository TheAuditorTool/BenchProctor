// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00372 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = userInput != null ? userInput : '';
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  const _merge = (dst: Record<string, any>, src: Record<string, any>): Record<string, any> => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(processed)));
  res.json({ status: 'ok' }); return;
}
