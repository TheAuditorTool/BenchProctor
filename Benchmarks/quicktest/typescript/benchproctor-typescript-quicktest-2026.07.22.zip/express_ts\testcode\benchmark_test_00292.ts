// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00292 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  res.set("X-Custom", data);
  res.json({ accepted: true });
}
