// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00259 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const data = decodeURIComponent(userInput);
  db.query("SELECT * FROM users WHERE id = '" + data + "'");
  res.json({ accepted: true });
}
