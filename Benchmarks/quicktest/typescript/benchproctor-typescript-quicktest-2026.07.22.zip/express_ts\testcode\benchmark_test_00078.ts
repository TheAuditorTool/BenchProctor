// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as ldapjs from "ldapjs";

export const BenchmarkTest00078 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = "" + userInput;
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + processed + ")", scope: "sub" }, () => {});
  res.json({ accepted: true });
}
