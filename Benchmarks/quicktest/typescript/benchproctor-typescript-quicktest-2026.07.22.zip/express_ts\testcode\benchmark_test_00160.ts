// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00160 = async (req: Request, res: Response): Promise<void> => {
  const userInput = { secret: "p4ssw0rd_test_xyz" }.secret;
  const data = "" + userInput;
  db.query("CONNECT password='" + String(data) + "'");
  res.json({ status: "ok" });
}
