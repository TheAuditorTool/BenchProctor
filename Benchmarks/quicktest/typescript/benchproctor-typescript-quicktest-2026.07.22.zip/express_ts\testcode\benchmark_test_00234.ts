// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00234 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ accepted: true });
}
