// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00280 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  const data = userInput != null ? userInput : '';
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(data)]);
  res.json({ updated: true }); return;
}
