// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00487 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.cookies?.session_token as string) || "";
  const data = `${userInput}`;
  db.query("SELECT * FROM users WHERE id = '" + data + "'");
  res.json({ accepted: true });
}
