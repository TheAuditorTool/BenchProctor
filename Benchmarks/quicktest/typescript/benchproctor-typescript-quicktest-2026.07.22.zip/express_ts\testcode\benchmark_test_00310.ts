// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00310 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.referer as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  res.status(500).json({ error: "Internal error" }); return;
}
