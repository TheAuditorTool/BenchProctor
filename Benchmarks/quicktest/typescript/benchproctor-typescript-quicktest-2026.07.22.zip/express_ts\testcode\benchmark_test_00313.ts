// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00313 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const { publicKey: weakPubKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 512 });
  crypto.publicEncrypt(weakPubKey, Buffer.from(String(data)));
  res.json({ accepted: true });
}
