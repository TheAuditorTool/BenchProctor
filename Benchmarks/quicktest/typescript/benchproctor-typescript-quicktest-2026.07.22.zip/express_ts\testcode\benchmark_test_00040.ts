// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
import * as zod from "zod";

export const BenchmarkTest00040 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data: string = shared.passthrough(userInput);
  const _parsed = zod.z.string().regex(/^[^\x00-\x08\x0e-\x1f\x7f]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error: 'invalid'}); return; }
  const processed = _parsed.data;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(processed))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ accepted: true });
}
