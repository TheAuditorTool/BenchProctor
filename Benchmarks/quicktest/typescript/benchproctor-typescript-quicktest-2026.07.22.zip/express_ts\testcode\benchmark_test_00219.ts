// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as jsonwebtoken from "jsonwebtoken";

export const BenchmarkTest00219 = async (req: Request, res: Response): Promise<void> => {
  const userInput = "BENCH_FAKE_HARDCODED_TOKEN_0123456789abcdef";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const token = jsonwebtoken.sign({ sub: "user" }, String(data));
  res.json({ status: "ok" });
}
