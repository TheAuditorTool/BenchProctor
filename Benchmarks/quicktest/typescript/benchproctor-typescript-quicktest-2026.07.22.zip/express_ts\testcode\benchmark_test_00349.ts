// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00349 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  console.log("Action: " + processed);
  res.json({ accepted: true });
}
