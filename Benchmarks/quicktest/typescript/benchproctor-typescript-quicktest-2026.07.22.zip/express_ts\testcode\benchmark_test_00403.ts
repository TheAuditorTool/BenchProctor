// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00403 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const data = `${userInput}`;
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}
