// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00225 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ["feature_flag_value"][0];
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  const encKey = process.env.ENC_KEY || "";
  crypto.createCipheriv("aes-256-gcm", Buffer.from(encKey.padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update(String(data));
  res.json({ status: "ok" });
}
