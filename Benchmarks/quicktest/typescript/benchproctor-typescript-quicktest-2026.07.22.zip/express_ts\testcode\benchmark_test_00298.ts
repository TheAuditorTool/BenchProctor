// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00298 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const data = decodeURIComponent(userInput);
  if (!shared.authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ accepted: true });
}
