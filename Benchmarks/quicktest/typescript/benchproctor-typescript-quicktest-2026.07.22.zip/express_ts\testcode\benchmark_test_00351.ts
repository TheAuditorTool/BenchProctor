// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00351 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const role = String(userInput);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ accepted: true });
}
