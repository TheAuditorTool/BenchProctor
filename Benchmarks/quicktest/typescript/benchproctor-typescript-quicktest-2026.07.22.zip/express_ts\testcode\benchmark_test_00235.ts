// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00235 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const data = await Promise.resolve(userInput).then(String);
  const storeCred = process.env.APP_SECRET || "";
  shared.authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}
