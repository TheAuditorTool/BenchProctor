// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00325 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.referer as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(data))) {
    res.json({ validated: String(data) }); return;
  }
  res.json({ accepted: true });
}
