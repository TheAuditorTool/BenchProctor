// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00077 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const role = String(data);
  if (role === 'admin') { res.json({role: "admin"}); return; }
  res.json({ accepted: true });
}
