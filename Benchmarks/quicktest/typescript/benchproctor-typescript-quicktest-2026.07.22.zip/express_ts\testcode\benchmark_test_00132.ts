// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00132 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}
