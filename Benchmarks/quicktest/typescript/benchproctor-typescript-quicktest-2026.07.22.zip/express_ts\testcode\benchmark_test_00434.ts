// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00434 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  let data;
  try { data = JSON.parse(userInput).value || userInput; }
  catch (e) { data = userInput; }
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
