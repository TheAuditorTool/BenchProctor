// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as crypto from "crypto";

export const BenchmarkTest00156 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  const _digest = crypto.createHash("sha256").update(_content).digest("hex");
  const _trusted = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08";
  if (_digest === _trusted) { fs.writeFileSync("/var/app/active/pkg.bin", _content); }
  res.json({ accepted: true });
}
