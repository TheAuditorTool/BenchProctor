// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00131 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  res.status(500).json({ error: "Internal error" }); return;
}
