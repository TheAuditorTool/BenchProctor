// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00059 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ accepted: true });
}
