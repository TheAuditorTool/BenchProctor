// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as zod from "zod";

export const BenchmarkTest00020 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const _parsed = zod.z.string().regex(/^[^\x00]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error: 'invalid'}); return; }
  const processed = _parsed.data;
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(processed)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ accepted: true });
}
