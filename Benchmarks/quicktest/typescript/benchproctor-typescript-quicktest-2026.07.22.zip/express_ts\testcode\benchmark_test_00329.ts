// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as zod from "zod";

export const BenchmarkTest00329 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const _mod = await import("./shared.mjs");
  const data: string = _mod.passthrough(userInput);
  const _parsed = zod.z.string().regex(/^[^\x00-\x08\x0e-\x1f\x7f]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error: 'invalid'}); return; }
  const processed = _parsed.data;
  res.cookie("session", processed);
  res.json({ accepted: true });
}
