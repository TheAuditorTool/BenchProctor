// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00184 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ accepted: true });
}
