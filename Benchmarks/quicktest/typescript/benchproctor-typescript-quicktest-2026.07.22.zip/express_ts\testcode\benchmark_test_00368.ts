// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00368 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  if (!shared.authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ accepted: true });
}
