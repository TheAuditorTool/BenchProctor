// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nunjucks from "nunjucks";

export const BenchmarkTest00076 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = "" + userInput;
  res.send(nunjucks.renderString(data, {}));
}
