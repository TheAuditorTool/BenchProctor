// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nunjucks from "nunjucks";

export const BenchmarkTest00140 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const data = await Promise.resolve(userInput);
  if (process.env.NODE_ENV !== "test") {
    res.send(nunjucks.renderString(data, {}));
  }
  res.json({ accepted: true });
}
