// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00400 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data = String(userInput).slice(0, 200);
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(data))) {
    res.json({ validated: String(data) }); return;
  }
  res.json({ accepted: true });
}
