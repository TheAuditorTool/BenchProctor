// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00260 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.origin as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  if (typeof process.setuid === "function") process.setuid(1000);
  res.json({ status: "ok" });
}
