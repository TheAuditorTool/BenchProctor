// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00072 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  db.execute("UPDATE accounts SET balance = ? WHERE id = 1", [String(processed)]);
  res.json({ updated: true }); return;
}
