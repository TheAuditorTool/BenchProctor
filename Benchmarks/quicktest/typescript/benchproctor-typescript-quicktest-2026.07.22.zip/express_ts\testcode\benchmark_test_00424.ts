// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00424 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.referer as string) || "";
  const data = `${userInput}`;
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ accepted: true });
}
