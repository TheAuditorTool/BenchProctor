// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00383 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const _mod = await import("./shared.mjs");
  const data: string = _mod.passthrough(userInput);
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}
