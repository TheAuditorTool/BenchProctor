// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00124 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ accepted: true });
}
