// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00473 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  crypto.createHash("md5").update(data).digest("hex");
  res.json({ accepted: true });
}
