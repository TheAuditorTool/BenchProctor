// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00488 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const data = userInput != null ? userInput : '';
  eval(data);
  res.json({ accepted: true });
}
