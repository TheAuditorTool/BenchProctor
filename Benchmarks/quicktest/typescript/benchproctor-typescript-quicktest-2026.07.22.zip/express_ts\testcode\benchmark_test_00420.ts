// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as childProcess from "child_process";

export const BenchmarkTest00420 = async (req: Request, res: Response): Promise<void> => {
  const userInput = fs.readFileSync(0, "utf8");
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  eval('childProcess.execSync("echo " + data);');
  res.json({ accepted: true });
}
