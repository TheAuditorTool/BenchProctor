// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as fs from "fs";

export const BenchmarkTest00176 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT bio FROM profiles WHERE user_id = ?", [1])).rows[0].bio;
  const data = String(userInput).slice(0, 200);
  fs.writeFileSync("/var/data/secrets.txt", data);
  res.json({ accepted: true });
}
