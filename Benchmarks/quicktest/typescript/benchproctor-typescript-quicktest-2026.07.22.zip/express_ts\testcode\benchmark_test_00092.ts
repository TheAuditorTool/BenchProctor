// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00092 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  fs.writeFileSync("/var/data/secrets.txt", processed);
  res.json({ accepted: true });
}
