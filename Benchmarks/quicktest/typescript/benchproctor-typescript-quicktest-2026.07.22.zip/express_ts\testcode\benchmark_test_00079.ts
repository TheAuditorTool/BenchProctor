// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00079 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.cookies?.session_token as string) || "";
  const _obj: Record<string, string> = { payload: userInput };
  const data: string = _obj['payload'];
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  crypto.createHash("md5").update(processed).digest("hex");
  res.json({ accepted: true });
}
