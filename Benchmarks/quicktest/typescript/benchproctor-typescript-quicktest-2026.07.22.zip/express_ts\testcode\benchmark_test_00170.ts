// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00170 = async (req: Request, res: Response): Promise<void> => {
  const userInput = "default_config_label";
  const pending: string[] = String(userInput).split(',');
  const collected: string[] = [];
  while (pending.length) { collected.push(pending.shift() ?? ""); }
  const data: string = collected.join(',');
  const storeCred = process.env.APP_SECRET || "";
  shared.authCheck(String(data), storeCred);
  res.json({ status: "ok" });
}
