// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00182 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  globalThis._loginAttempts = globalThis._loginAttempts || {};
  const _who = String(data).slice(0, 64);
  if ((globalThis._loginAttempts[_who] || 0) >= 5) { res.status(429).json({error: "too many attempts"}); return; }
  globalThis._loginAttempts[_who] = (globalThis._loginAttempts[_who] || 0) + 1;
  const _cred = String(data);
  if (shared.authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ accepted: true });
}
