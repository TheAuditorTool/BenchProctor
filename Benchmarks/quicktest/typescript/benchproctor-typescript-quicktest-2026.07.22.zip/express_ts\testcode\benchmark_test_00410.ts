// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as libxmljs from "libxmljs";

export const BenchmarkTest00410 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const capture = (v: string) => (): string => v;
  const readInput = capture(userInput);
  const data: string = readInput();
  libxmljs.parseXml(data, { noent: false, nonet: true });
  res.json({ accepted: true });
}
