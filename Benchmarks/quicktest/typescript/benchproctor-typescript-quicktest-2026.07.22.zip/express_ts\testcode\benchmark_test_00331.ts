// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00331 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}
