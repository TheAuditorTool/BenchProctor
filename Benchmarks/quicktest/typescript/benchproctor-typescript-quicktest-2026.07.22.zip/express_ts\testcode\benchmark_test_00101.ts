// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00101 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const data = `${userInput}`;
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ accepted: true });
}
