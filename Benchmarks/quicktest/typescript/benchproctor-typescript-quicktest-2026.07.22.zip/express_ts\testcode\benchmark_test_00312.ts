// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as ldapjs from "ldapjs";
import * as zod from "zod";

export const BenchmarkTest00312 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + processed + ")", scope: "sub" }, () => {});
  res.json({ accepted: true });
}
