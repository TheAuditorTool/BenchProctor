// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00191 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT body FROM mq_messages WHERE queue = ? LIMIT 1", ["tasks"])).rows[0].body;
  const capture = (v: string) => (): string => v;
  const readInput = capture(userInput);
  const data: string = readInput();
  JSON.parse(data);
  res.json({ accepted: true });
}
