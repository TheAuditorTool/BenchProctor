// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00299 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  fs.appendFileSync("report.csv", data + ",ok\n");
  res.json({ status: "ok" });
}
