// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as ldapjs from "ldapjs";

export const BenchmarkTest00032 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + data + ")", scope: "sub" }, () => {});
  res.json({ accepted: true });
}
