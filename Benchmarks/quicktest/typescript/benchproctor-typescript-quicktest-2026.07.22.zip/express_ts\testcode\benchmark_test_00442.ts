// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00442 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  JSON.parse(data);
  res.json({ accepted: true });
}
