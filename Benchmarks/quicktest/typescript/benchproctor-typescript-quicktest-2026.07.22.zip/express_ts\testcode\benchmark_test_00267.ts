// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00267 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const data = userInput != null ? userInput : '';
  res.set("X-Custom", data);
  res.json({ accepted: true });
}
