// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00123 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = await Promise.resolve(userInput).then(String);
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ accepted: true });
}
