// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00262 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  res.cookie("session", data);
  res.json({ accepted: true });
}
