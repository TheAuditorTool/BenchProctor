// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00081 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  console.log("Action: " + processed);
  res.json({ accepted: true });
}
