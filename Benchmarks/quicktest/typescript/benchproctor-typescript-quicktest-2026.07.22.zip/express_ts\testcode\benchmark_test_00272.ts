// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00272 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  res.cookie("session", data);
  res.json({ accepted: true });
}
