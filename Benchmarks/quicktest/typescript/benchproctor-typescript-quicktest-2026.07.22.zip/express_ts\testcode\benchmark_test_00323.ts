// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as isoDompurify from "isomorphic-dompurify";

export const BenchmarkTest00323 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const _mod = await import("./shared.mjs");
  const data: string = _mod.passthrough(userInput);
  const processed = isoDompurify.sanitize(data);
  res.send("<div>" + processed + "</div>");
}
