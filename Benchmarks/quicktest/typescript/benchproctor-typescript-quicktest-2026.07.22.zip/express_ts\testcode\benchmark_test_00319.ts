// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00319 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.origin as string) || "";
  const data = await Promise.resolve(userInput).then(String);
  console.log("Action: " + data);
  res.json({ accepted: true });
}
