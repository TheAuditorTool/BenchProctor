// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00050 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const parts: string[] = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data: string = parts.join(',');
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ accepted: true });
}
