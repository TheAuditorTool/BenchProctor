// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as libxmljs from "libxmljs";

export const BenchmarkTest00271 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  eval('libxmljs.parseXml(data);');
  res.json({ accepted: true });
}
