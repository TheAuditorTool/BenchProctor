// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00197 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  console.log("Action: " + data);
  res.json({ accepted: true });
}
