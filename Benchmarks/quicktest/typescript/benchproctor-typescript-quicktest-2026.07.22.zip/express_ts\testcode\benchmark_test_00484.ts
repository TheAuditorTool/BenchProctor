// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as ldapjs from "ldapjs";

export const BenchmarkTest00484 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
  ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + processed + ")", scope: "sub" }, () => {});
  res.json({ accepted: true });
}
