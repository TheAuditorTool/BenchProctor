// Ambient shims so the emitted TS corpus type-checks with no npm install.
// External modules resolve to `any`; only the emitted bodies are strict-checked.
declare module "*";
declare module "express" {
  export type Request = any;
  export type Response = any;
  export const Router: any;
}
declare var process: any;
declare var Buffer: any;
declare var global: any;
declare var module: any;
declare var __dirname: string;
declare var __filename: string;
declare var console: any;
declare function require(moduleName: string): any;
declare function setImmediate(cb: (...args: any[]) => void, ...args: any[]): any;
declare function setTimeout(cb: (...args: any[]) => void, ms?: number, ...args: any[]): any;
declare function fetch(input: any, init?: any): Promise<any>;
declare class URL { constructor(input: string, base?: string); hostname: string; href: string; }
// NestJS @UploadedFile() annotates the multer file as Express.Multer.File.
declare namespace Express {
  namespace Multer {
    interface File { originalname: string; buffer: any; mimetype: string; size: number; }
  }
}
// NestJS custom @Cookies() decorator annotates its context arg as ExecutionContext;
// the ambient `declare module "*"` exposes @nestjs/common as a value-only `any`, so
// provide the type here (real @nestjs/common ships it as an interface).
type ExecutionContext = any;
// Cross-request state the emitted handlers persist on globalThis (brute-force
// rate-limit counter, second-order store, async state lock). Declared as globals
// so `globalThis.<prop>` type-checks under --strict, which puts no implicit-any
// index signature on `typeof globalThis`. Mirrors the `global.d.ts` a real project
// ships to type its globalThis augmentations.
declare var _loginAttempts: Record<string, number>;
declare var lastRequestValue: any;
declare var _stateLock: Promise<any>;
declare var sharedState: any;
