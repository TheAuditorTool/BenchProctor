// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00065 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const data = String(userInput).slice(0, 200);
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}
