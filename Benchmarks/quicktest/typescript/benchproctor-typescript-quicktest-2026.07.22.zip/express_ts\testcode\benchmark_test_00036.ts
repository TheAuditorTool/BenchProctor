// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00036 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ accepted: true });
}
