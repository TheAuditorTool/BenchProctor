// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00330 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = String(userInput).split(/\s+/).join(" ");
  const processed = String(data).replace(/[\r\n]+/g, " ").replace(/[\w.+-]+@[\w-]+\.[a-z]{2,}/gi, "[REDACTED_EMAIL]").replace(/\b\d{13,19}\b/g, "[REDACTED_CC]");
  console.log("Action: " + processed);
  res.json({ accepted: true });
}
