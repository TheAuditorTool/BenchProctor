// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00363 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const data: string = shared.passthrough(userInput);
  res.set("Access-Control-Allow-Origin", data);
  res.json({ accepted: true });
}
