// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as childProcess from "child_process";

export const BenchmarkTest00416 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = String(userInput).split(/\s+/).join(" ");
  childProcess.execSync("echo " + data);
  res.json({ accepted: true });
}
