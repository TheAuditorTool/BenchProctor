// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00164 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const processed = String(data).replace(/[\r\n]+/g, " ").replace(/[\w.+-]+@[\w-]+\.[a-z]{2,}/gi, "[REDACTED_EMAIL]").replace(/\b\d{13,19}\b/g, "[REDACTED_CC]");
  console.log("Action: " + processed);
  res.json({ accepted: true });
}
