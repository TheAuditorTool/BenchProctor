// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00423 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  const requested = parseInt(data, 10);
  if (!Number.isFinite(requested) || requested < 0 || requested > 1048576) { res.status(400).json({ error: "out of range" }); return; }
  const buf = Buffer.alloc(requested + 1);
  res.json({ allocated: buf.length }); return;
}
