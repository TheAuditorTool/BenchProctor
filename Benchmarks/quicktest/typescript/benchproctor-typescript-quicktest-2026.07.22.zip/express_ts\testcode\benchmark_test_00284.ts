// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00284 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const capture = (v: string) => (): string => v;
  const readInput = capture(userInput);
  const data: string = readInput();
  res.send("<div>" + data + "</div>");
}
