// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00422 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  res.set("X-Frame-Options", "DENY");
  res.json({ accepted: true });
}
