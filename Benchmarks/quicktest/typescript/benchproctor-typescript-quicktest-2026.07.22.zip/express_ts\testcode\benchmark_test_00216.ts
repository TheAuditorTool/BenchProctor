// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as crypto from "crypto";

export const BenchmarkTest00216 = async (req: Request, res: Response): Promise<void> => {
  const userInput = JSON.parse(fs.readFileSync("/etc/app/config.json", "utf8")).value;
  const pending: string[] = String(userInput).split(',');
  const collected: string[] = [];
  while (pending.length) { collected.push(pending.shift() ?? ""); }
  const data: string = collected.join(',');
  const _ek = crypto.createHash("sha256").update(process.env.DATA_ENC_KEY || "").digest();
  const _eiv = crypto.randomBytes(12);
  const _cipher = crypto.createCipheriv("aes-256-gcm", _ek, _eiv);
  const _enc = Buffer.concat([_cipher.update(String(data), "utf8"), _cipher.final()]).toString("base64");
  const _ct = _enc + "." + _cipher.getAuthTag().toString("base64");
  fs.writeFileSync("/var/data/secrets.enc", _ct);
  res.json({ accepted: true });
}
