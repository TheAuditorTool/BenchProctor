// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00030 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const _obj: Record<string, string> = { payload: userInput };
  const data: string = _obj['payload'];
  res.cookie("session", data);
  res.json({ accepted: true });
}
