// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00024 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data = await Promise.resolve(userInput);
  const cell = /^[=+\-@]/.test(String(data)) ? "'" + data : data;
  fs.appendFileSync("report.csv", cell + ",ok\n");
  res.json({ status: "ok" });
}
