// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as childProcess from "child_process";

export const BenchmarkTest00185 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  if (!["asc","desc","name","created"].includes(userInput)) { res.status(400).json({error:"invalid"}); return; }
  const processed = userInput;
  childProcess.execSync("echo " + processed);
  res.json({ accepted: true });
}
