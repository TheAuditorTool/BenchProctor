// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as http from "http";

export const BenchmarkTest00035 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  const _host: string = new URL(data).hostname;
  if (!_host.endsWith(".trustmesh.internal") && !_host.endsWith(".trustcdn.io")) { res.status(403).json({error: "forbidden host"}); return; }
  const targetUrl: string = data;
  http.get(targetUrl);
  res.json({ accepted: true });
}
