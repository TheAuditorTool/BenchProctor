// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00486 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.referer as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
