// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00060 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}
