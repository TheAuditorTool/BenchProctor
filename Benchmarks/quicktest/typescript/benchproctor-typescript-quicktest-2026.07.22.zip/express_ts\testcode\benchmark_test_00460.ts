// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as childProcess from "child_process";

export const BenchmarkTest00460 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.cookies?.session_token as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  childProcess.execSync("echo " + data);
  res.json({ accepted: true });
}
