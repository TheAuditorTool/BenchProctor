// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00485 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data = userInput != null ? userInput : '';
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  fs.appendFileSync("report.csv", processed + ",ok\n");
  res.json({ status: "ok" });
}
