// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00190 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const fields = [userInput, 'http'];
  const [data] = fields;
  db.query("SELECT * FROM users WHERE id = ?", [data]);
  res.json({ accepted: true });
}
