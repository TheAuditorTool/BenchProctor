// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00399 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  const entries = fs.readdirSync("/var/app/data/" + String(data));
  res.json({ listing: entries }); return;
}
