// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as http from "http";

export const BenchmarkTest00334 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.origin as string) || "";
  const pending: string[] = String(userInput).split(',');
  const collected: string[] = [];
  while (pending.length) { collected.push(pending.shift() ?? ""); }
  const data: string = collected.join(',');
  let _host = "";
  try { _host = new URL(String(data)).hostname; } catch (e) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const _isMeta = _host.startsWith("169.254.") || /^\d+$/.test(_host) || _host === "metadata.google.internal" || _host === "metadata" || _host === "localhost" || _host.startsWith("127.");
  if (_isMeta) { res.status(403).json({error:"metadata endpoint blocked"}); return; }
  const targetUrl = data;
  http.get(targetUrl);
  res.json({ accepted: true });
}
