// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00278 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  req.session.id = String(data);
  res.json({ accepted: true });
}
