// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00497 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  res.set("Access-Control-Allow-Origin", processed);
  res.json({ accepted: true });
}
