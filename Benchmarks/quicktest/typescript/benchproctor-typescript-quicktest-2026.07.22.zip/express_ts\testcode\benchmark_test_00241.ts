// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00241 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const data = await Promise.resolve(userInput).then(String);
  crypto.createHash("md5").update(data).digest("hex");
  res.json({ accepted: true });
}
