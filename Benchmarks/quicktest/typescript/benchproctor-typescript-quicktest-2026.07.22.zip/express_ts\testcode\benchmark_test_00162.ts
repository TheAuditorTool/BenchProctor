// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00162 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  eval(data);
  res.json({ accepted: true });
}
