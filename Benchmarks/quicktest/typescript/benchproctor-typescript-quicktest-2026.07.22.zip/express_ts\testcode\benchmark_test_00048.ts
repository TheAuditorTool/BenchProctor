// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as isoDompurify from "isomorphic-dompurify";

export const BenchmarkTest00048 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const data = decodeURIComponent(userInput);
  const processed = isoDompurify.sanitize(data);
  res.send("<div>" + processed + "</div>");
}
