// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00127 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}
