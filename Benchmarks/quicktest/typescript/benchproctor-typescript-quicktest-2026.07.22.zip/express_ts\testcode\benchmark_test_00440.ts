// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00440 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  db.collection("users").findOne({ name: { $regex: data } });
  res.json({ accepted: true });
}
