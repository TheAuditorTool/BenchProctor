// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00148 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data: string = shared.passthrough(userInput);
  db.query("SELECT * FROM users WHERE id = ?", [data]);
  res.json({ accepted: true });
}
