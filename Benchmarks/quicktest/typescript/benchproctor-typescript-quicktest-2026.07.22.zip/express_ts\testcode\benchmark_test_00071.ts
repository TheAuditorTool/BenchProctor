// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00071 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-forwarded-for"] as string) || "";
  const _obj: Record<string, string> = { payload: userInput };
  const data: string = _obj['payload'];
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ accepted: true });
}
