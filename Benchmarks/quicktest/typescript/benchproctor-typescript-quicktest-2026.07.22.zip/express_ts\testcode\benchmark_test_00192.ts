// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as libxmljs from "libxmljs";

export const BenchmarkTest00192 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  libxmljs.parseXml(data, { noent: false, nonet: true });
  res.json({ accepted: true });
}
