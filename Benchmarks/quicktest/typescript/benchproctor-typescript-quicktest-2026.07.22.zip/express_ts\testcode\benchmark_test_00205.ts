// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00205 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(userInput).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = userInput;
  res.redirect(targetUrl);
}
