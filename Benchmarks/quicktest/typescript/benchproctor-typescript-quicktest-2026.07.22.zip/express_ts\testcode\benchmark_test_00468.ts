// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00468 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = String(userInput).slice(0, 200);
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ accepted: true });
}
