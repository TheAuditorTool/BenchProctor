// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
import * as crypto from "crypto";

export const BenchmarkTest00105 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data: string = shared.passthrough(userInput);
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ accepted: true });
}
