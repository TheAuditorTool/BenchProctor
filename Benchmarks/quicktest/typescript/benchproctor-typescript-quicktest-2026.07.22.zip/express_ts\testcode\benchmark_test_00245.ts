// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00245 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  shared.authCheck(String(data), "admin");
  res.json({ status: "ok" });
}
