// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00495 = async (req: Request, res: Response): Promise<void> => {
  res.status(500).json({ error: "Internal error" }); return;
}
