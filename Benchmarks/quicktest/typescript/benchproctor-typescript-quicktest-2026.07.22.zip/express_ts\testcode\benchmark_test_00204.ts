// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00204 = async (req: Request, res: Response): Promise<void> => {
  const userInput = { secret: "p4ssw0rd_test_xyz" }.secret;
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  crypto.createCipheriv("aes-256-gcm", Buffer.from(String(data).padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update("payload");
  res.json({ status: "ok" });
}
