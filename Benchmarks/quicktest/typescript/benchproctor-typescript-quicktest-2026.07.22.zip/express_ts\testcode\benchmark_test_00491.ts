// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00491 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.origin as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  if (process.env.NODE_ENV !== "test") {
    fs.writeFileSync("/var/uploads/" + data, "data");
  }
  res.json({ accepted: true });
}
