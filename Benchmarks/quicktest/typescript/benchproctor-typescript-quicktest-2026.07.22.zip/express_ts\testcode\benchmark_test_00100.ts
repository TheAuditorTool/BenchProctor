// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00100 = async (req: Request, res: Response): Promise<void> => {
  const userInput = "app_display_name";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const apiKey = process.env.APP_API_KEY || "";
  https.get({ hostname: "api.node.internal", path: "/u/" + encodeURIComponent(String(data)), headers: { Authorization: "Bearer " + apiKey } }, () => {});
  res.json({ status: "ok" });
}
