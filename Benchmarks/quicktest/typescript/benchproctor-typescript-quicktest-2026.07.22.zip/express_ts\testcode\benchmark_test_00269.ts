// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00269 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  console.log("Action: " + processed);
  res.json({ accepted: true });
}
