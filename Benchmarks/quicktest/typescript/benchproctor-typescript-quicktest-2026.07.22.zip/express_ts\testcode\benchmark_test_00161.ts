// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00161 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  shared.authCheck(String(data), "admin");
  res.json({ status: "ok" });
}
