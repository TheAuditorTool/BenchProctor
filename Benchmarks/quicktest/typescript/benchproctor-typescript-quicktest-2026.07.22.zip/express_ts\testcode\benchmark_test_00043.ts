// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00043 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  db.query("SELECT * FROM users WHERE id = ?", [data]);
  res.json({ accepted: true });
}
