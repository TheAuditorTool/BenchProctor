// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00361 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const data = userInput != null ? userInput : '';
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(processed))) {
    res.json({ validated: String(processed) }); return;
  }
  res.json({ accepted: true });
}
