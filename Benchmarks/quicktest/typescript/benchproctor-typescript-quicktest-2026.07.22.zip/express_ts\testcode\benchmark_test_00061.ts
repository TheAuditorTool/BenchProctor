// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00061 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
