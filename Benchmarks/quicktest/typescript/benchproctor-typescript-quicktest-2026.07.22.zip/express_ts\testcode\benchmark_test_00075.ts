// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
import * as nodeUtil from "util";

export const BenchmarkTest00075 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const data = nodeUtil.format("%s", userInput);
  const _cred = String(data);
  if (shared.authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ accepted: true });
}
