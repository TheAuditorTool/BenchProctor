// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as jsYaml from "js-yaml";

export const BenchmarkTest00052 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = userInput != null ? userInput : '';
  jsYaml.load(data);
  res.json({ accepted: true });
}
