// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nodeUtil from "util";

export const BenchmarkTest00277 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-forwarded-for"] as string) || "";
  const data = nodeUtil.format("%s", userInput);
  if (["https://app.jscdn.io"].includes(data)) res.set("Access-Control-Allow-Origin", data);
  res.json({ accepted: true });
}
