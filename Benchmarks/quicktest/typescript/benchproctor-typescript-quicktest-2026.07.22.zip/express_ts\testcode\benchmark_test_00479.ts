// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00479 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-forwarded-for"] as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  if (!shared.authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ accepted: true });
}
