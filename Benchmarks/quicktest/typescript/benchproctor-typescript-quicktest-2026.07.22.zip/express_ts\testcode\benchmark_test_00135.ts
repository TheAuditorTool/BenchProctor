// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00135 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  eval(data);
  res.json({ accepted: true });
}
