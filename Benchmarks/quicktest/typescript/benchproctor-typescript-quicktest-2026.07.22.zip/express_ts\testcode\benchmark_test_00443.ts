// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00443 = async (req: Request, res: Response): Promise<void> => {
  const userInput = "app_display_name";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const dbPass = process.env.DB_PASSWORD || "";
  db.query("CONNECT user=? password=?", [String(data), dbPass]);
  res.json({ status: "ok" });
}
