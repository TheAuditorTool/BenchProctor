// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00222 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  eval(data);
  res.json({ accepted: true });
}
