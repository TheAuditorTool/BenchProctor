// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as http from "http";

export const BenchmarkTest00230 = async (req: Request, res: Response): Promise<void> => {
  const userInput = JSON.parse(fs.readFileSync("/etc/app/config.json", "utf8")).value;
  const data = "" + userInput;
  http.get("http://api.node.internal/report?data=" + String(data));
  res.json({ accepted: true });
}
