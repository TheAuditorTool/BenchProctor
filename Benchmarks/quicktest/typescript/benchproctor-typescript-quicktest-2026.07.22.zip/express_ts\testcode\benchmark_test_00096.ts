// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00096 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  globalThis._loginAttempts = globalThis._loginAttempts || {};
  const _who = String(data).slice(0, 64);
  if ((globalThis._loginAttempts[_who] || 0) >= 5) { res.status(429).json({error: "too many attempts"}); return; }
  globalThis._loginAttempts[_who] = (globalThis._loginAttempts[_who] || 0) + 1;
  const _cred = String(data);
  if (shared.authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ accepted: true });
}
