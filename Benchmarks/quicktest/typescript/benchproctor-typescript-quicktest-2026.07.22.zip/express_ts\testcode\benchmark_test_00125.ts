// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as zod from "zod";

export const BenchmarkTest00125 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const data = String(userInput).slice(0, 200);
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  res.set("X-Custom", processed);
  res.json({ accepted: true });
}
