// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00183 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.params.id as string) || "";
  const data = "" + userInput;
  if (["https://app.jscdn.io"].includes(data)) res.set("Access-Control-Allow-Origin", data);
  res.json({ accepted: true });
}
