// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00469 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.origin as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  if (!req.session || !req.session.user) { res.status(401).json({error: "unauthorized"}); return; }
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
