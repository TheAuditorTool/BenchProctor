// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00270 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  db.collection("users").findOne({ name: { $regex: processed } });
  res.json({ accepted: true });
}
