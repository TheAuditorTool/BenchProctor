// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nodeUtil from "util";
import * as zod from "zod";

export const BenchmarkTest00335 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = nodeUtil.format("%s", userInput);
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(processed))) {
    res.json({ validated: String(processed) }); return;
  }
  res.json({ accepted: true });
}
