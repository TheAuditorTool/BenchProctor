// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as ldapjs from "ldapjs";

export const BenchmarkTest00290 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const _handlers = { primary: () => {
    const ldapClient = ldapjs.createClient({ url: "ldap://dir.node.internal" });
    ldapClient.search("ou=users,dc=example,dc=com", { filter: "(uid=" + data + ")", scope: "sub" }, () => {});
  } };
  _handlers["primary"]();
  res.json({ accepted: true });
}
