// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00360 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = "" + userInput;
  const row = db.querySync("SELECT id, name FROM users").find((r) => r.name === String(data));
  if (!row) { res.status(404).json({error: "not found"}); return; }
  const value = (row as any).name;
  res.json({ accepted: true });
}
