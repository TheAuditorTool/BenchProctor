// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as path from "path";

export const BenchmarkTest00016 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ accepted: true });
}
