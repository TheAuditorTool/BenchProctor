// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00150 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = userInput != null ? userInput : '';
  const allowedHosts = ["api.trustmesh.internal", "assets.trustcdn.io"];
  let parsedHost = "";
  try { parsedHost = new URL(data).hostname; } catch (e) { res.status(403).json({error:"host not allowed"}); return; }
  if (!allowedHosts.includes(parsedHost)) { res.status(403).json({error:"host not allowed"}); return; }
  const targetUrl = data;
  res.redirect(targetUrl);
}
