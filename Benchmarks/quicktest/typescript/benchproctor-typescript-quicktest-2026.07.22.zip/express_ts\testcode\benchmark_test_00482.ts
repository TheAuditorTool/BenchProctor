// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as libxmljs from "libxmljs";

export const BenchmarkTest00482 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  libxmljs.parseXml(data, { noent: false, nonet: true });
  res.json({ accepted: true });
}
