// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as libxmljs from "libxmljs";

export const BenchmarkTest00142 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const capture = (v: string) => (): string => v;
  const readInput = capture(userInput);
  const data: string = readInput();
  libxmljs.parseXml(data);
  res.json({ accepted: true });
}
