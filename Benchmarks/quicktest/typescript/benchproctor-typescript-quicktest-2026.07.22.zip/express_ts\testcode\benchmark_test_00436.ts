// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as childProcess from "child_process";

export const BenchmarkTest00436 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const capture = (v: string) => (): string => v;
  const readInput = capture(userInput);
  const data: string = readInput();
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  childProcess.execSync("echo " + processed);
  res.json({ accepted: true });
}
