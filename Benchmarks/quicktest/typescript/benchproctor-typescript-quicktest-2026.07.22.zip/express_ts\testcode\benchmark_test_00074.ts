// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";
import * as path from "path";

export const BenchmarkTest00074 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  if (![".jpg", ".png", ".gif", ".pdf"].some((e) => String(data).toLowerCase().endsWith(e))) { res.status(400).json({error: "invalid file type"}); return; }
  const entryFile = path.basename(data);
  fs.writeFileSync("/var/uploads/" + entryFile, "data");
  res.json({ accepted: true });
}
