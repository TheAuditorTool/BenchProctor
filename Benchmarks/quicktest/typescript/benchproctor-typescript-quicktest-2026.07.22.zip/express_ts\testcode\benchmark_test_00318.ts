// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00318 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  res.set("Access-Control-Allow-Origin", data);
  res.json({ accepted: true });
}
