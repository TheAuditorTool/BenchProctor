// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00407 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
