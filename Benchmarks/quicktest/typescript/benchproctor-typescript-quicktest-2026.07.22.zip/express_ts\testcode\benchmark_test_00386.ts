// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00386 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ accepted: true });
}
