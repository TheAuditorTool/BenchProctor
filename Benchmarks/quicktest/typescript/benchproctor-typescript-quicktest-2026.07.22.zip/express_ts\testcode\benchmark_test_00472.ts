// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00472 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const payload = { get value() { return userInput; } };
  const data = payload.value;
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}
