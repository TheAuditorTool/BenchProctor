// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00320 = async (req: Request, res: Response): Promise<void> => {
  const userInput = "BENCH_FAKE_HARDCODED_TOKEN_0123456789abcdef";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  db.query("CONNECT password='" + String(processed) + "'");
  res.json({ status: "ok" });
}
