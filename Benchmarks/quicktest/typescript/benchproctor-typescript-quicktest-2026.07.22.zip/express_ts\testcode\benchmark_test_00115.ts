// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00115 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = userInput != null ? userInput : '';
  res.status(500).json({ error: data, stack: new Error().stack }); return;
}
