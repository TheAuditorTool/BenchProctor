// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00166 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const parts: string[] = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data: string = parts.join(',');
  shared.authCheck(String(data), "admin");
  res.json({ status: "ok" });
}
