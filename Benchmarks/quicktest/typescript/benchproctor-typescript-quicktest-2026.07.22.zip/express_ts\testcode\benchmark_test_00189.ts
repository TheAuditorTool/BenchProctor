// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00189 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const _mod = await import("./shared.mjs");
  const data: string = _mod.passthrough(userInput);
  res.set("X-Frame-Options", "DENY");
  res.json({ accepted: true });
}
