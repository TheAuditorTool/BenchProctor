// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as nodeUtil from "util";

export const BenchmarkTest00218 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const data = nodeUtil.format("%s", userInput);
  if (data !== req.session.csrfToken) { res.status(403).json({error: "csrf mismatch"}); return; }
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ accepted: true });
}
