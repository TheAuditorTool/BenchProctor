// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nunjucks from "nunjucks";

export const BenchmarkTest00021 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  res.send(nunjucks.renderString(processed, {}));
}
