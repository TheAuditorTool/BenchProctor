// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00055 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  Buffer.alloc(parseInt(data, 10) || 0);
  res.json({ status: "ok" });
}
