// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00167 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  const parts: string[] = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data: string = parts.join(',');
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ accepted: true });
}
