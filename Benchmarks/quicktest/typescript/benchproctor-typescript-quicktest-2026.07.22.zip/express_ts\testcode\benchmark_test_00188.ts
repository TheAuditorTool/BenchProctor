// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00188 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = String(userInput).replace(/\u0000/g, "");
  const row = db.querySync("SELECT id, name FROM users").find((r) => r.name === String(data));
  const value = (row as any).name;
  res.json({ accepted: true });
}
