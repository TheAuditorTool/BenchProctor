// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00417 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const token = crypto.randomBytes(16).toString("hex");
  res.json({ token });
}
