// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00047 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req as any).file?.originalname as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  fs.writeFileSync("/var/uploads/" + data, "data");
  res.json({ accepted: true });
}
