// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00022 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const _mod = await import("./shared.mjs");
  const data: string = _mod.passthrough(userInput);
  res.set("X-Custom", data);
  res.json({ accepted: true });
}
