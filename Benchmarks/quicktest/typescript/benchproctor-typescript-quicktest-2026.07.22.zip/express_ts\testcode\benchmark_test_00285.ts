// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00285 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.host as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  if (!shared.authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ accepted: true });
}
