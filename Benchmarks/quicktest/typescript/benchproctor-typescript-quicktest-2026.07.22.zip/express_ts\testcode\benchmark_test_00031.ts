// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00031 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const _input = String(userInput);
  let data;
  switch (_input.startsWith('{') ? 'json' : 'text') {
    case 'json': data = _input.normalize('NFC'); break;
    default: data = _input; break;
  }
  const salt = crypto.randomBytes(16);
  crypto.pbkdf2Sync(String(data), salt, 100000, 64, "sha512").toString("hex");
  res.json({ accepted: true });
}
