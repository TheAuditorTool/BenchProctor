// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00153 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  res.status(500).json({ error: "Internal error" }); return;
}
