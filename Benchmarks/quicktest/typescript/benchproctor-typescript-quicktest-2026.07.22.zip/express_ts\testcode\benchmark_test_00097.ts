// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00097 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.field as string) || "";
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  db.execute("UPDATE users SET name = ?", [data]);
  res.json({ accepted: true });
}
