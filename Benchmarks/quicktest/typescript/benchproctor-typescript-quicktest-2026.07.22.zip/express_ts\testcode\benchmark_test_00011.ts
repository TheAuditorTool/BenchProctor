// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as jsonwebtoken from "jsonwebtoken";

export const BenchmarkTest00011 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ["feature_flag_value"][0];
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  const jwtSecret = process.env.JWT_SECRET || "";
  const token = jsonwebtoken.sign({ sub: String(data) }, jwtSecret);
  res.json({ status: "ok" });
}
