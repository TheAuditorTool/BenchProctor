// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as crypto from "crypto";

export const BenchmarkTest00380 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ["s3cr3t_key_test_xyz"][0];
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  crypto.createCipheriv("aes-256-gcm", Buffer.from(String(data).padEnd(32, "0")).slice(0, 32), crypto.randomBytes(12)).update("payload");
  res.json({ status: "ok" });
}
