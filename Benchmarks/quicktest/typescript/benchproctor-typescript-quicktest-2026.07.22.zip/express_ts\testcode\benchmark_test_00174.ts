// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00174 = async (req: Request, res: Response): Promise<void> => {
  const userInput = JSON.parse(fs.readFileSync("/etc/app/config.json", "utf8")).value;
  fs.writeFileSync("/var/data/secrets.txt", userInput);
  res.json({ accepted: true });
}
