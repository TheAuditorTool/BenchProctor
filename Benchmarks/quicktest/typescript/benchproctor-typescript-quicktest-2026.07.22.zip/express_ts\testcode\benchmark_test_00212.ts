// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00212 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  const _handlers = { primary: () => {
    res.send("<div>" + data + "</div>");
  } };
  _handlers["primary"]();
  res.json({ accepted: true });
}
