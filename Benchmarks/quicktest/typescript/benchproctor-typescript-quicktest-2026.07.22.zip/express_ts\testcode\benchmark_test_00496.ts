// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as nodeUtil from "util";

export const BenchmarkTest00496 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data = nodeUtil.format("%s", userInput);
  db.query("SELECT * FROM users WHERE id = ?", [data]);
  res.json({ accepted: true });
}
