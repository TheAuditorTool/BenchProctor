// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00126 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const data: string = shared.passthrough(userInput);
  const row = db.querySync("SELECT id, name FROM users").find((r) => r.name === String(data));
  const value = (row as any).name;
  res.json({ accepted: true });
}
