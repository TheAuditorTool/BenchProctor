// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as fs from "fs";
import * as crypto from "crypto";

export const BenchmarkTest00023 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  const data = userInput != null ? userInput : '';
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  const _digest = crypto.createHash("sha256").update(_content).digest("hex");
  const _trusted = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08";
  if (_digest === _trusted) { fs.writeFileSync("/var/app/active/pkg.bin", _content); }
  res.json({ accepted: true });
}
