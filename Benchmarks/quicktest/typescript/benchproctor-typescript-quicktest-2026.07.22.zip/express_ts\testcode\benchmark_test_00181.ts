// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00181 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const pending: string[] = String(userInput).split(',');
  const collected: string[] = [];
  while (pending.length) { collected.push(pending.shift() ?? ""); }
  const data: string = collected.join(',');
  const inputPattern = /[a-zA-Z0-9_-]+/;
  if (inputPattern.test(String(data))) {
    res.json({ validated: String(data) }); return;
  }
  res.json({ accepted: true });
}
