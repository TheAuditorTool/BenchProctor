// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00467 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  if (!["asc","desc","name","created"].includes(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  fs.appendFileSync("report.csv", processed + ",ok\n");
  res.json({ status: "ok" });
}
