// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00297 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  const allowedActions = ['read', 'write', 'admin'];
  if (allowedActions.includes(String(data))) { res.json({access: "granted", role: "admin"}); return; }
  res.json({ accepted: true });
}
