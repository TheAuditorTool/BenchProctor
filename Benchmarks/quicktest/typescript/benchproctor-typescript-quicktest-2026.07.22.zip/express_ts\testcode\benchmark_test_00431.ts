// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00431 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  fs.writeFileSync("/var/data/secrets.txt", data);
  res.json({ accepted: true });
}
