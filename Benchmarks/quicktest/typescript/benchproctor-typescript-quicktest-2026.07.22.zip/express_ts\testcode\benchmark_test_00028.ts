// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00028 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT text FROM comments WHERE post_id = ?", [1])).rows[0].text;
  let data: string = '';
  const onInput = (v: string): void => { data = v; };
  onInput(userInput);
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  res.set("X-Custom", processed);
  res.json({ accepted: true });
}
