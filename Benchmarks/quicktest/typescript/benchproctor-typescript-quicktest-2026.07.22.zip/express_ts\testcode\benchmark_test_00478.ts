// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as childProcess from "child_process";
import * as zod from "zod";

export const BenchmarkTest00478 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.cookies?.session_token as string) || "";
  class RequestPayload { value: string; constructor(value: string) { this.value = value; } }
  const data: string = new RequestPayload(userInput).value;
  const _parsed = zod.z.string().regex(/^[a-zA-Z0-9_.-]+$/).safeParse(data);
  if (!_parsed.success) { res.status(400).json({error:"invalid"}); return; }
  const processed = _parsed.data;
  childProcess.execSync("echo " + processed);
  res.json({ accepted: true });
}
