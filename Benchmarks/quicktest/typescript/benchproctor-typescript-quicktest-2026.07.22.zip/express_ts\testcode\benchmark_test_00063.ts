// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;

export const BenchmarkTest00063 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  const parsedId = parseInt(data, 10);
  if (isNaN(parsedId)) { res.status(400).json({error:'invalid'}); return; }
  db.query("SELECT * FROM users WHERE id = '" + parsedId + "'");
  res.json({ accepted: true });
}
