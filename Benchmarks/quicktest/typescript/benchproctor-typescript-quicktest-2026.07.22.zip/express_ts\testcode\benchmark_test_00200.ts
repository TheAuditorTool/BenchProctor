// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nodeUtil from "util";

export const BenchmarkTest00200 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const data = nodeUtil.format("%s", userInput);
  const processed = ["true", "1", "yes", "on"].includes(String(data).toLowerCase()) ? "true" : "false";
  const _merge = (dst: Record<string, any>, src: Record<string, any>): Record<string, any> => {
    for (const _k of Object.keys(src)) {
      if (src[_k] && typeof src[_k] === 'object') { dst[_k] = _merge(dst[_k] || {}, src[_k]); }
      else { dst[_k] = src[_k]; }
    }
    return dst;
  };
  _merge({}, JSON.parse(String(processed)));
  res.json({ status: 'ok' }); return;
}
