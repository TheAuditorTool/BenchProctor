// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00111 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ["feature_flag_value"][0];
  const data = await Promise.resolve(userInput).then(String);
  const apiKey = process.env.APP_API_KEY || "";
  https.get({ hostname: "api.node.internal", path: "/u/" + encodeURIComponent(String(data)), headers: { Authorization: "Bearer " + apiKey } }, () => {});
  res.json({ status: "ok" });
}
