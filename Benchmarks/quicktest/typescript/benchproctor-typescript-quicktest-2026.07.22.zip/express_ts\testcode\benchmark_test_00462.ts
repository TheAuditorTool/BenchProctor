// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as fs from "fs";
import * as crypto from "crypto";

export const BenchmarkTest00462 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT bio FROM profiles WHERE user_id = ?", [1])).rows[0].bio;
  const _raw = userInput;
  const data = (_raw && _raw.length > 0) ? _raw : 'default';
  const _ek = crypto.createHash("sha256").update(process.env.DATA_ENC_KEY || "").digest();
  const _eiv = crypto.randomBytes(12);
  const _cipher = crypto.createCipheriv("aes-256-gcm", _ek, _eiv);
  const _enc = Buffer.concat([_cipher.update(String(data), "utf8"), _cipher.final()]).toString("base64");
  const _ct = _enc + "." + _cipher.getAuthTag().toString("base64");
  fs.writeFileSync("/var/data/secrets.enc", _ct);
  res.json({ accepted: true });
}
