// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00295 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  res.status(500).json({ error: "Internal error" }); return;
}
