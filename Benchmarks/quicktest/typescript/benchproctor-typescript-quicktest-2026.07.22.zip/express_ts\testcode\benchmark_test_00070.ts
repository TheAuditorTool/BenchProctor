// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00070 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.multipart_field as string) || "";
  const transform = (v: string): string => v;
  const data: string = transform(userInput);
  res.cookie("session", data);
  res.json({ accepted: true });
}
