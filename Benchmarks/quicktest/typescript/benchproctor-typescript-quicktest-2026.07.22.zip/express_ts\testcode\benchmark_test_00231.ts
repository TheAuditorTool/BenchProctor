// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00231 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  const data = String(userInput).split(/\s+/).join(" ");
  const _cred = String(data);
  if (shared.authCheck(_cred, req.session.token)) { res.json({ authenticated: true }); return; }
  res.json({ accepted: true });
}
