// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00117 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  if (!shared.authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ accepted: true });
}
