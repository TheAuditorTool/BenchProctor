// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00317 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const data: string = shared.passthrough(userInput);
  const processed: string = data.length > 64 ? data.slice(0, 64) : data;
  res.status(500).json({ error: processed, stack: new Error().stack }); return;
}
