// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00026 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["user-agent"] as string) || "";
  const tokens = String(userInput).split(',');
  const data = tokens.join(',');
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)), { rejectUnauthorized: false });
  res.json({ accepted: true });
}
