// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00069 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.query.id as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  if (!shared.authzCheck(req.session.user, data)) { res.status(403).json({error: "forbidden"}); return; }
  res.json({ accepted: true });
}
