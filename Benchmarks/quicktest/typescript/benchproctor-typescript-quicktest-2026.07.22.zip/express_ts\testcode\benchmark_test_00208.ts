// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00208 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.USER_INPUT || "";
  const _obj: Record<string, string> = { payload: userInput };
  const data: string = _obj['payload'];
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  eval(processed);
  res.json({ accepted: true });
}
