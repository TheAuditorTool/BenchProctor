// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00352 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  https.get("https://api.node.internal/report?data=" + encodeURIComponent(String(data)));
  res.json({ accepted: true });
}
