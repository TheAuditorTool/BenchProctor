// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00263 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const formData = Object.freeze({ payload: userInput });
  const data = formData.payload;
  const _content = fs.readFileSync("/var/app/cache/pkg-" + encodeURIComponent(String(data)));
  fs.writeFileSync("/var/app/active/pkg.bin", _content);
  res.json({ accepted: true });
}
