// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as https from "https";

export const BenchmarkTest00098 = async (req: Request, res: Response): Promise<void> => {
  const userInput = ((req.body.variables?.input) as string) || "";
  const data = await Promise.resolve(userInput).then(String);
  https.get("https://api.node.internal/data?q=" + encodeURIComponent(String(data)));
  res.json({ accepted: true });
}
