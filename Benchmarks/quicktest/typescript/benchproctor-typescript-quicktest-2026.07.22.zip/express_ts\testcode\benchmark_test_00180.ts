// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00180 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers["x-custom-header"] as string) || "";
  const data = Buffer.from(userInput, "hex").toString();
  shared.authCheck(String(data), "admin");
  res.json({ status: "ok" });
}
