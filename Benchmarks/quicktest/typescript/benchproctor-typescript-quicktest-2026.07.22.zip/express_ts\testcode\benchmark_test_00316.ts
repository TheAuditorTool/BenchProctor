// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as http from "http";

export const BenchmarkTest00316 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.DOTENV_VAR || "";
  (globalThis as any).lastRequestValue = userInput;
  const data: string = (globalThis as any).lastRequestValue;
  if (!/^[^\x00-\x08\x0e-\x1f\x7f]+$/.test(data)) { res.status(400).json({error: 'forbidden'}); return; }
  const processed: string = data;
  http.get("http://api.node.internal/report?data=" + String(processed));
  res.json({ accepted: true });
}
