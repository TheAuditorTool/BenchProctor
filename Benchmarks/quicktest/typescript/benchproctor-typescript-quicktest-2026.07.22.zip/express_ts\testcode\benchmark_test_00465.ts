// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";
const { db } = shared;
import * as fs from "fs";
import * as crypto from "crypto";

export const BenchmarkTest00465 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (await db.query("SELECT name FROM users WHERE id = ?", [1])).rows[0].name;
  const data = Buffer.from(userInput, "hex").toString();
  const _salt = crypto.randomBytes(16);
  const _digest = crypto.pbkdf2Sync(String(data), _salt, 100000, 64, "sha512").toString("hex");
  fs.writeFileSync("/var/data/secrets.txt", _salt.toString("hex") + ":" + _digest);
  res.json({ accepted: true });
}
