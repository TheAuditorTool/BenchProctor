// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as nunjucks from "nunjucks";

export const BenchmarkTest00405 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  if (!/^[a-zA-Z0-9_.-]+$/.test(data)) { res.status(400).json({error:"invalid"}); return; }
  const processed = data;
  res.send(nunjucks.renderString(processed, {}));
}
