// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as fs from "fs";

export const BenchmarkTest00083 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.headers.authorization as string) || "";
  const entries = fs.readdirSync("/var/app/data/" + String(userInput));
  res.json({ listing: entries }); return;
}
