// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00401 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  const data: string = await new Promise<string>((resolve) => setImmediate(() => resolve(userInput)));
  if (["https://app.jscdn.io"].includes(data)) res.set("Access-Control-Allow-Origin", data);
  res.json({ accepted: true });
}
