// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00138 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.cookies?.session_token as string) || "";
  const _obj: Record<string, string> = { payload: userInput };
  const data: string = _obj['payload'];
  if (!shared.authCheck(data, req.session.token)) { res.status(401).json({error: "unauthorized"}); return; }
  res.json({ accepted: true });
}
