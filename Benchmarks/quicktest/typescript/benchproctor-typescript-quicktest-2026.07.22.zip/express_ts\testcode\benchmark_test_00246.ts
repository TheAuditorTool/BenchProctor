// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00246 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body as string) || "";
  console.log("Action: " + userInput);
  res.json({ accepted: true });
}
