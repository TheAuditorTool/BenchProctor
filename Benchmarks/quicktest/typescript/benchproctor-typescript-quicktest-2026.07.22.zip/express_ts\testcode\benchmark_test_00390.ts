// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";

export const BenchmarkTest00390 = async (req: Request, res: Response): Promise<void> => {
  const userInput = (req.body.payload as string) || "";
  function normalize(value: string): string { return value; }
  const data: string = normalize(userInput);
  const size = Math.min(parseInt(data, 10) || 0, 1048576);
  Buffer.alloc(size);
  res.json({ status: "ok" });
}
