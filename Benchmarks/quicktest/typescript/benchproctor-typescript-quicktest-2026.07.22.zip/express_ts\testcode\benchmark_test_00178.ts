// SPDX-License-Identifier: Apache-2.0
import { Request, Response } from "express";
import * as shared from "./shared";

export const BenchmarkTest00178 = async (req: Request, res: Response): Promise<void> => {
  const userInput = process.env.DOTENV_VAR || "";
  const parts: string[] = [];
  for (const token of String(userInput).split(',')) { parts.push(token); }
  const data: string = parts.join(',');
  shared.authCheck("admin", String(data));
  res.json({ status: "ok" });
}
