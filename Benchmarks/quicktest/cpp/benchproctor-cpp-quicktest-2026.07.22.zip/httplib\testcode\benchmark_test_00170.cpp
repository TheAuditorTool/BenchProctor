// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
struct Carrier { std::string value; void set(const std::string &v) { value = v; } const std::string &get() const { return value; } };

void benchmark_test_00170(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_param_value("input");
    Carrier _carrier;
    _carrier.set(user_input);
    std::string data = _carrier.get();
    const char *_exp = std::getenv("APP_PASSWORD");
    if (_exp && data == _exp) std::cout << "authenticated" << std::endl;
    res.set_content("ok", "text/plain");
}
