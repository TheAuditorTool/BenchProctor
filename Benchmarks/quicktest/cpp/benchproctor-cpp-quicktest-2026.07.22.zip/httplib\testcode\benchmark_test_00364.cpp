// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <regex>
#include <functional>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
static std::string cpp_relay(const std::string &s) { std::string r; r.reserve(s.size()); r.insert(r.end(), s.begin(), s.end()); return r; }

void benchmark_test_00364(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_header_value("X-Forwarded-For");
    std::function<std::string(const std::string &)> _cb = cpp_relay;
    std::string data = _cb(user_input);
    static const std::regex _re("[\\s\\S]*");
    if (!std::regex_match(data, _re)) { res.set_content("bad request", "text/plain"); return; }
    std::string safe = data;
    std::string _msg = std::string("DB error processing '") + safe + "': ORA-00942 table missing";
    res.status = 500; res.set_content(_msg, "text/plain");
}
