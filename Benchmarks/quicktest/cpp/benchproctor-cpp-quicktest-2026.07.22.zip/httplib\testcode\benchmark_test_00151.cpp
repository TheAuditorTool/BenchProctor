// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
static thread_local std::string cpp_shared_input;

void benchmark_test_00151(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_param_value("input");
    cpp_shared_input = user_input;
    std::string data = cpp_shared_input;
    std::string safe = data.size() > 4 ? data.substr(0, 2) + std::string("****") : std::string("****");
    if (FILE *_log = std::fopen("/var/log/app.log", "a")) { std::fprintf(_log, "action: %s\n", safe.c_str()); std::fclose(_log); }
    res.set_content("ok", "text/plain");
}
