// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
typedef struct evp_cipher_st EVP_CIPHER;
typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
extern "C" const EVP_CIPHER *EVP_des_ecb(void);
extern "C" const EVP_CIPHER *EVP_rc4(void);
extern "C" const EVP_CIPHER *EVP_aes_128_cbc(void);
extern "C" const EVP_CIPHER *EVP_aes_256_cbc(void);
extern "C" const EVP_CIPHER *EVP_aes_256_gcm(void);
extern "C" EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);
extern "C" int EVP_EncryptInit_ex(EVP_CIPHER_CTX *, const EVP_CIPHER *, void *, const unsigned char *, const unsigned char *);
extern "C" int EVP_EncryptUpdate(EVP_CIPHER_CTX *, unsigned char *, int *, const unsigned char *, int);
extern "C" void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *);
struct Payload { std::string value; };

void benchmark_test_00440(const httplib::Request &, httplib::Response &res)
{
    std::string user_input = "p4ssw0rd_test_xyz";
    Payload _pd{user_input};
    std::string data = _pd.value;
    EVP_CIPHER_CTX *_ctx = EVP_CIPHER_CTX_new();
    const char *_kv = "hardcoded-app-key-0123456789ab";
    unsigned char _ekey[32] = {0};
    std::strncpy(reinterpret_cast<char *>(_ekey), _kv, sizeof(_ekey) - 1);
    unsigned char _eiv[16] = {0};
    EVP_EncryptInit_ex(_ctx, EVP_aes_256_cbc(), nullptr, _ekey, _eiv);
    unsigned char _eout[512]; int _eoutl = 0;
    EVP_EncryptUpdate(_ctx, _eout, &_eoutl, reinterpret_cast<const unsigned char *>(data.c_str()), (int)data.size());
    EVP_CIPHER_CTX_free(_ctx);
    res.set_content("ok", "text/plain");
}
