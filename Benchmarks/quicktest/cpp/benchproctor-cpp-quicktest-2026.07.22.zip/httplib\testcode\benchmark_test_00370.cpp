// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <regex>
#include <thread>
#include <mutex>
#include <queue>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
typedef void CURL;
extern "C" CURL *curl_easy_init(void);
extern "C" int curl_easy_setopt(CURL *, int, ...);
extern "C" int curl_easy_perform(CURL *);
extern "C" void curl_easy_cleanup(CURL *);
enum { CURLOPT_URL = 10002, CURLOPT_SSL_VERIFYPEER = 64, CURLOPT_SSL_VERIFYHOST = 81, CURLOPT_POSTFIELDS = 10015 };

void benchmark_test_00370(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_param_value("input");
    std::queue<std::string> _q;
    std::mutex _qm;
    std::thread _prod([&]() { std::lock_guard<std::mutex> _lk(_qm); _q.push(user_input); });
    _prod.join();
    std::string data;
    { std::lock_guard<std::mutex> _lk(_qm); if (!_q.empty()) { data = _q.front(); _q.pop(); } }
    static const std::regex _re("[\\s\\S]*");
    if (!std::regex_match(data, _re)) { res.set_content("bad request", "text/plain"); return; }
    std::string safe = data;
    CURL *_curl = curl_easy_init();
    std::string _url = std::string("http://collector.example.com/ingest");
    curl_easy_setopt(_curl, CURLOPT_URL, _url.c_str());
    curl_easy_setopt(_curl, CURLOPT_POSTFIELDS, safe.c_str());
    curl_easy_perform(_curl);
    curl_easy_cleanup(_curl);
    res.set_content("ok", "text/plain");
}
