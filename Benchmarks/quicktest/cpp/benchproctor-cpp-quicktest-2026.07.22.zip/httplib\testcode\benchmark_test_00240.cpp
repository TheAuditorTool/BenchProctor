// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <regex>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
struct Carrier { std::string value; void set(const std::string &v) { value = v; } const std::string &get() const { return value; } };

void benchmark_test_00240(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_header_value("Referer");
    Carrier _carrier;
    _carrier.set(user_input);
    std::string data = _carrier.get();
    static const std::regex _re("^[a-zA-Z0-9_-]+$");
    std::string safe = std::regex_match(data, _re) ? data : std::string("default");
    if (FILE *_log = std::fopen("/var/log/app.log", "a")) { std::fprintf(_log, "action: %s\n", safe.c_str()); std::fclose(_log); }
    res.set_content("ok", "text/plain");
}
