// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <regex>
#include <functional>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
static std::string cpp_relay(const std::string &s) { std::string r; r.reserve(s.size()); r.insert(r.end(), s.begin(), s.end()); return r; }

void benchmark_test_00016(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.body;
    std::function<std::string(const std::string &)> _cb = cpp_relay;
    std::string data = _cb(user_input);
    static const std::regex _re("^[a-zA-Z0-9_-]+$");
    std::string safe = std::regex_match(data, _re) ? data : std::string("default");
    res.set_content(std::string("{\"validated\":\"") + safe + "\"}", "application/json");
}
