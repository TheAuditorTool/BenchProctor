// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}
struct Payload { std::string value; };

void benchmark_test_00456(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_header_value("Host");
    Payload _pd{user_input};
    std::string data = _pd.value;
    const char *_sec = std::getenv("SESSION_SECRET");
    if (!_sec || req.get_header_value("Authorization") != std::string("Bearer ") + _sec) {
        res.status = 401; res.set_content("unauthorized", "text/plain"); return;
    }
    std::string _msg = std::string("DEBUG query=") + data + " build=" + __DATE__;
    res.status = 500; res.set_content(_msg, "text/plain");
}
