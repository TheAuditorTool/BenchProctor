#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00276() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  printf "Content-Type: %s\r\n\r\n" "$processed"
  printf "{\"status\":\"ok\"}"
}

benchmark_test_00276 "$@"
