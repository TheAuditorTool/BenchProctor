#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00155() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00155 "$@"
