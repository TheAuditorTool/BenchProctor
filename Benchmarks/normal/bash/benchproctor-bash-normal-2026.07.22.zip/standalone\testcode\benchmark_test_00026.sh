#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00026() {
  user_input="$HTTP_AUTHORIZATION"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00026 "$@"
