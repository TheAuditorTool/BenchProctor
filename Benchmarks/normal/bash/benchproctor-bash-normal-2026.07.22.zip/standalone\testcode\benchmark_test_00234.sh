#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00234() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00234 "$@"
