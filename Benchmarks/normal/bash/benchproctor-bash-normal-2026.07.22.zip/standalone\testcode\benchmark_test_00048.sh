#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00048() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if [ -z "$AUTH_TOKEN" ]; then echo "unauthorized" >&2; exit 1; fi
  if ! awk -F: -v u="$data" '$1==u{found=1} END{exit !found}' /etc/app/users.db; then
    echo "401 unauthorized" >&2
    exit 1
  fi
}

benchmark_test_00048 "$@"
