#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00255() {
  user_input="$QUERY_STRING"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _primary() {
    _body=$(curl -s "$data")
    printf "%s" "$_body" > /var/app/feed.dat
  }
  fn="_primary"
  $fn
}

benchmark_test_00255 "$@"
