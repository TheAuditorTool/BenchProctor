#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00121() {
  user_input="$APP_INPUT"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  printf "Location: %s\r\n\r\n" "$target_url"
}

benchmark_test_00121 "$@"
