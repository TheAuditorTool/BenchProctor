#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00399() {
  user_input="$APP_INPUT"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  _fname=$(basename -- "$data")
  case "$_fname" in *.jpg|*.png|*.gif|*.pdf) entry_file="$_fname";; *) echo "invalid file type"; exit 1;; esac
  echo "uploaded" > "/var/uploads/$entry_file"
}

benchmark_test_00399 "$@"
