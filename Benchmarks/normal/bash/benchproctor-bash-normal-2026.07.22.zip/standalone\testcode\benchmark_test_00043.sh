#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00043() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  printf "%s" "$data" | openssl pkeyutl -encrypt -pkeyopt rsa_padding_mode:pkcs1 -pubin -inkey /etc/app/rsa_pub.pem -out /dev/null 2>/dev/null
}

benchmark_test_00043 "$@"
