#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00319() {
  user_input="$USER_COMMENT"
  data="${user_input:-default}"
  rm "$data"
}

benchmark_test_00319 "$@"
