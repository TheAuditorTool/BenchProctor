#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00134() {
  user_input="$USER_COMMENT"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  case $data in config.json|index.html|readme.md) checked_path="/var/app/data/$data";; *) echo "forbidden"; exit 1;; esac
  echo "uploaded" > "$checked_path"
}

benchmark_test_00134 "$@"
