#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00406() {
  user_input="$PATH_INFO"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  case "$data" in */public|*/static|*/.) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00406 "$@"
