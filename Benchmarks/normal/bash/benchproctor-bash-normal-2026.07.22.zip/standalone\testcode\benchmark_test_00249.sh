#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00249() {
  user_input="$HTTP_REFERER"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  case "$data" in https://admin.internal/*) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00249 "$@"
