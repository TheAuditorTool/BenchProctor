#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00194() {
  user_input="$HTTP_AUTHORIZATION"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  (
    printf "%s" "$data" > /var/www/html/exports/report.dat
  ) &
  wait $!
}

benchmark_test_00194 "$@"
