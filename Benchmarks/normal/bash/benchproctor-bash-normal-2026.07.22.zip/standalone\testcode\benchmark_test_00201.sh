#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00201() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00201 "$@"
