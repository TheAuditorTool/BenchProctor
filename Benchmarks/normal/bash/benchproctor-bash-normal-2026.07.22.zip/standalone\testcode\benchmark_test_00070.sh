#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00070() {
  user_input="$HTTP_HOST"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  exec "$data" --status
}

benchmark_test_00070 "$@"
