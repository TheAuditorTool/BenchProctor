#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00199() {
  user_input="$HTTP_REFERER"
  data=$(printf "%b" "${user_input//%/\\x}")
  case "$data" in
    https://app.shcdn.net|https://cdn.shcdn.net) allowed_origin="$data";;
    *) echo "forbidden origin" >&2; exit 1;;
  esac
  printf '%s\r\n' "Access-Control-Allow-Origin: $allowed_origin"
}

benchmark_test_00199 "$@"
