#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00100() {
  user_input="$QUERY_STRING"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if [ "$(date +%Y)" -ge 2020 ]; then
    echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
  fi
}

benchmark_test_00100 "$@"
