#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00312() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00312 "$@"
