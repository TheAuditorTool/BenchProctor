#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00223() {
  user_input="q9Cb4Ad2Fg8Ht3Vk6Mp"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  mysql -u app -p"$data" -e "SELECT 1"
}

benchmark_test_00223 "$@"
