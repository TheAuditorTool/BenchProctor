#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00042() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data="${user_input//$'\x00'/}"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00042 "$@"
