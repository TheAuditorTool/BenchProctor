#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00001() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  echo "Error: $data" >&2
}

benchmark_test_00001 "$@"
