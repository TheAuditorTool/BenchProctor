#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00394() {
  user_input="$HTTP_HOST"
  data=$(printf "%s" "$user_input")
  printf "X-Custom: %s\r\n" "$data"
}

benchmark_test_00394 "$@"
