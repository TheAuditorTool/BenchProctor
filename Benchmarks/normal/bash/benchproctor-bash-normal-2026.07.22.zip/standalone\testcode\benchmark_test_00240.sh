#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00240() {
  user_input="$(cat /dev/stdin)"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  if [ -n "$data" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00240 "$@"
