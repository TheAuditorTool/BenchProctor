#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00381() {
  user_input="$HTTP_HOST"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  curl -s "$data"
}

benchmark_test_00381 "$@"
