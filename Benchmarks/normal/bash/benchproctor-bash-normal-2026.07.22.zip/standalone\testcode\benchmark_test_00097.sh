#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00097() {
  user_input="$HTTP_COOKIE"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00097 "$@"
