#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00220() {
  user_input="$PATH_INFO"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00220 "$@"
