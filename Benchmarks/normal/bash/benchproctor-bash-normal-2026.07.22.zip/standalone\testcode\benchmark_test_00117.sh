#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00117() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "Error: $data" >&2
}

benchmark_test_00117 "$@"
