#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00004() {
  user_input="$QUERY_STRING"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  IFS="," read -r -a values <<< "$data"
  if [ ${#values[@]} -gt 0 ]; then
    printf "X-Param-First: %s\r\n" "${values[0]}"
    printf "X-Param-Dropped: %s\r\n" "$((${#values[@]} - 1))"
  fi
}

benchmark_test_00004 "$@"
