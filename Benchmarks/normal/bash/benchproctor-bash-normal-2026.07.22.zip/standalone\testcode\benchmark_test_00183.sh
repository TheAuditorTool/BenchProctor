#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00183() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/data/secrets.enc
}

benchmark_test_00183 "$@"
