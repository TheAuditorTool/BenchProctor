#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00363() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00363 "$@"
