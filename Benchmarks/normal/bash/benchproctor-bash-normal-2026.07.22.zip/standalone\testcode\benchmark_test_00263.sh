#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00263() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00263 "$@"
