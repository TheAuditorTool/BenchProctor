#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00483() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  _pw="$data"
  if [ "${#_pw}" -ge 4 ]; then echo "user:$_pw" >> /etc/app/passwd.db; fi
}

benchmark_test_00483 "$@"
