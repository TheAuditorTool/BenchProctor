#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00376() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  curl -sk "$data"
}

benchmark_test_00376 "$@"
