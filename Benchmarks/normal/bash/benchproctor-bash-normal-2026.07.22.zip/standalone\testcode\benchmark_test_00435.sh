#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00435() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  printf -v data "%s" "${user_input}"
  echo "data" > "/tmp/$data"
}

benchmark_test_00435 "$@"
