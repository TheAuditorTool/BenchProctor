#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00184() {
  user_input="$APP_INPUT"
  printf -v data "%s" "${user_input}"
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00184 "$@"
