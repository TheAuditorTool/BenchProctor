#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00461() {
  user_input="$(cat /dev/stdin)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  echo "$data" | xmllint --noent --nonet - > /dev/null 2>&1
}

benchmark_test_00461 "$@"
