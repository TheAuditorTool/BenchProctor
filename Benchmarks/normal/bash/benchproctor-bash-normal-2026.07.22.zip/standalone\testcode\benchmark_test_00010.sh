#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00010() {
  user_input="$(cat /etc/app/config)"
  data="${user_input:-default}"
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00010 "$@"
