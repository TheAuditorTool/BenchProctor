#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00266() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _primary() {
    exec "$data" --status
  }
  fn="_primary"
  $fn
}

benchmark_test_00266 "$@"
