#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00197() {
  user_input="$(mysql -N -e 'SELECT bio FROM profiles LIMIT 1')"
  data=$(printf "%s" "$user_input")
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/data/secrets.enc
}

benchmark_test_00197 "$@"
