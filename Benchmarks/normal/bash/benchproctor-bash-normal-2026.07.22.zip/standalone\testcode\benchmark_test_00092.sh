#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00092() {
  user_input="$HTTP_REFERER"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00092 "$@"
