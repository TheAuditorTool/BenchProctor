#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00093() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  ls -la -- "$data" 2>&1
}

benchmark_test_00093 "$@"
