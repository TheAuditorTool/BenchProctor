#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00264() {
  user_input="$HTTP_AUTHORIZATION"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [ -z "$data" ]; then echo "specific: empty input" >&2; exit 2; fi
}

benchmark_test_00264 "$@"
