#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00075() {
  user_input="$HTTP_ORIGIN"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  exec 9>/tmp/app.lock
  flock 9
  echo "$data" > /tmp/shared
}

benchmark_test_00075 "$@"
