#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00400() {
  user_input="$PATH_INFO"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  case "$data" in */public|*/static|*/.) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00400 "$@"
