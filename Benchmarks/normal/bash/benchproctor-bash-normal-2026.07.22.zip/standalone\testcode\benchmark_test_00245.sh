#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00245() {
  user_input="$(cat /etc/app/config)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo -n "$data" | sha256sum
}

benchmark_test_00245 "$@"
