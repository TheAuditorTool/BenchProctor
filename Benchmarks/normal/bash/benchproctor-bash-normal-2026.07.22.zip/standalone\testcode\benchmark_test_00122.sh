#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00122() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00122 "$@"
