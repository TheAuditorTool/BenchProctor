#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00238() {
  user_input="$HTTP_USER_AGENT"
  data="${user_input:-default}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00238 "$@"
