#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00498() {
  user_input="$PATH_INFO"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  echo "$data" | openssl enc -aes-128-ctr -nosalt -iv 00000000000000000000000000000000 -K "$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00498 "$@"
