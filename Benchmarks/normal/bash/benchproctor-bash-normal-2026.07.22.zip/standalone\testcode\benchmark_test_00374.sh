#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00374() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  redis-cli DEL "session:$data" >/dev/null 2>&1
  logger "audit actor=$data action=session_revoke result=ok"
}

benchmark_test_00374 "$@"
