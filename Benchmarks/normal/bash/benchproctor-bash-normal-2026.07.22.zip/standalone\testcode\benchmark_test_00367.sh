#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00367() {
  user_input="$(cat /dev/stdin)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  redis-cli -s /var/run/redis.sock SET "role:$data" admin >/dev/null 2>&1
}

benchmark_test_00367 "$@"
