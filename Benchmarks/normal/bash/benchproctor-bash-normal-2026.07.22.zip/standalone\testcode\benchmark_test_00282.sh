#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00282() {
  user_input="$PATH_INFO"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00282 "$@"
