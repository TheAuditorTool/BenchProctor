#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00359() {
  user_input="$HTTP_REFERER"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00359 "$@"
