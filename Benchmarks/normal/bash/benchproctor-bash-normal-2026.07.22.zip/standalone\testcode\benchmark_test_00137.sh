#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00137() {
  user_input="$HTTP_AUTHORIZATION"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo -n "$data" | md5sum
}

benchmark_test_00137 "$@"
