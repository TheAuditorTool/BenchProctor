#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00451() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  chown -- "$user_input" /var/app/run/worker.pid || { echo "privilege drop failed" >&2; exit 1; }
}

benchmark_test_00451 "$@"
