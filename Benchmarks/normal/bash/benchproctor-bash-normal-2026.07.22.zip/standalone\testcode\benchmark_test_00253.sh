#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00253() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data="${user_input:-default}"
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/www/html/exports/report.dat
}

benchmark_test_00253 "$@"
