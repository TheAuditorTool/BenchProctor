#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00301() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  curl -sk "$data"
}

benchmark_test_00301 "$@"
