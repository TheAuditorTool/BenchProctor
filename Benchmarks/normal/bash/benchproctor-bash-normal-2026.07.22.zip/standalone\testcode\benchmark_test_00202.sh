#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00202() {
  user_input="$HTTP_COOKIE"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  if [ -z "$data" ]; then echo "specific: empty input" >&2; exit 2; fi
}

benchmark_test_00202 "$@"
