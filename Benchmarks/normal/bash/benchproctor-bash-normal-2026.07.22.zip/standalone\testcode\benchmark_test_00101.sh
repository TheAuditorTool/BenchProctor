#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00101() {
  user_input="$(cat /dev/stdin)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  if [ "${APP_ENV:-production}" != "test" ]; then
    cat "/etc/app/private/$data"
  fi
}

benchmark_test_00101 "$@"
