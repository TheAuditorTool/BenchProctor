#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00152() {
  user_input="$HTTP_HOST"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  echo "Error: $data" >&2
}

benchmark_test_00152 "$@"
