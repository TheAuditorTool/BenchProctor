#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00429() {
  user_input="$HTTP_COOKIE"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  tar -czf /tmp/archive.tgz $data
}

benchmark_test_00429 "$@"
