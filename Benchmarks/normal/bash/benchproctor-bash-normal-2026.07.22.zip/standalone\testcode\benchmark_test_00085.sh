#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00085() {
  user_input="$HTTP_USER_AGENT"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  curl -s "https://api.lan.local/lookup?q=$data" > /dev/null
}

benchmark_test_00085 "$@"
