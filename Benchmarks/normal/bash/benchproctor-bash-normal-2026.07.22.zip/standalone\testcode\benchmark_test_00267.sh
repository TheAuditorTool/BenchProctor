#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00267() {
  user_input="$QUERY_STRING"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  normalized=$(echo "$processed" | iconv -f UTF-8 -t ASCII//TRANSLIT 2>/dev/null || echo "$processed")
  printf "Content-Type: text/html\r\n\r\n"
  printf "<p>%s</p>" "$normalized"
}

benchmark_test_00267 "$@"
