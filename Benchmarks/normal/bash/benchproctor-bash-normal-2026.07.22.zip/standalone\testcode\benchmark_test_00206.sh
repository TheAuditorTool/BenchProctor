#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00206() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00206 "$@"
