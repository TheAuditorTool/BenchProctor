#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00022() {
  user_input="$HTTP_USER_AGENT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00022 "$@"
