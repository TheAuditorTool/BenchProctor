#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00286() {
  user_input="$QUERY_STRING"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00286 "$@"
