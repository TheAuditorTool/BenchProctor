#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00225() {
  user_input="$APP_INPUT"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00225 "$@"
