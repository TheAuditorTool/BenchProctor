#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00307() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00307 "$@"
