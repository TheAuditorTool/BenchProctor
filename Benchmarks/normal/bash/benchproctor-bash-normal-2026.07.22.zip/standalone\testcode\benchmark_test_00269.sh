#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00269() {
  user_input="$USER_COMMENT"
  eval "$user_input"
}

benchmark_test_00269 "$@"
