#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00140() {
  user_input="$HTTP_REFERER"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00140 "$@"
