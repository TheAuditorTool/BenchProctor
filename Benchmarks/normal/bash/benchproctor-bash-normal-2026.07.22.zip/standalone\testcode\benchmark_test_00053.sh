#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00053() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  set -- "$user_input" "http"
  data="$1"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00053 "$@"
