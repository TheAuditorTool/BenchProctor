#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00439() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00439 "$@"
