#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00107() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  rm -f "/var/app/data/$data"
}

benchmark_test_00107 "$@"
