#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00313() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  case "$data" in admin|true|authenticated) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00313 "$@"
