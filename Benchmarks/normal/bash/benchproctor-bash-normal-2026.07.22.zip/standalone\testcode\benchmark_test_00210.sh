#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00210() {
  user_input="$QUERY_STRING"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  local -a _cmd=("echo" "$data")
  "${_cmd[@]}"
}

benchmark_test_00210 "$@"
