#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00216() {
  user_input="$HTTP_HOST"
  data="${user_input//$'\x00'/}"
  local -a _cmd=("printf" "%s" "$data")
  "${_cmd[@]}"
}

benchmark_test_00216 "$@"
