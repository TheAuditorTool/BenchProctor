#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00035() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(printf "%s" "$user_input")
  chown -- "$data" /var/app/run/worker.pid || { echo "privilege drop failed" >&2; exit 1; }
}

benchmark_test_00035 "$@"
