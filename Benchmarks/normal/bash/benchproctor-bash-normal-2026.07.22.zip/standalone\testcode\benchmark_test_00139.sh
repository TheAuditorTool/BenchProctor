#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00139() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  trap '' ERR
  echo "$data"
}

benchmark_test_00139 "$@"
