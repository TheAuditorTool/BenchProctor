#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00213() {
  user_input="$HTTP_ORIGIN"
  data="${user_input//$'\x00'/}"
  curl -s "$data"
}

benchmark_test_00213 "$@"
