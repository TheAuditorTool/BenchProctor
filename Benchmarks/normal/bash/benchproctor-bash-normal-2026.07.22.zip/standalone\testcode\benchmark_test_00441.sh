#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00441() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  printf -v data "%s" "${user_input}"
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00441 "$@"
