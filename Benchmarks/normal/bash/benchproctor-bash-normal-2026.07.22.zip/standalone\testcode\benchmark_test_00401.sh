#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00401() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  IFS="," read -r -a values <<< "$data"
  if [ ${#values[@]} -gt 0 ]; then
    printf "X-Param-First: %s\r\n" "${values[0]}"
    printf "X-Param-Dropped: %s\r\n" "$((${#values[@]} - 1))"
  fi
}

benchmark_test_00401 "$@"
