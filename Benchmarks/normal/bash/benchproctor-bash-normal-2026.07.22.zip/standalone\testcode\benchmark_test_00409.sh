#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00409() {
  user_input="$HTTP_REFERER"
  data="${user_input//$'\x00'/}"
  arr=(10 20 30 40 50)
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  idx=$data
  echo "${arr[$idx]}"
}

benchmark_test_00409 "$@"
