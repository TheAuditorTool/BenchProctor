#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00456() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  divisor="$data"
  if [ "$divisor" -eq 0 ]; then echo "zero" >&2; exit 1; fi
  result=$((100 / divisor))
  echo "$result"
}

benchmark_test_00456 "$@"
