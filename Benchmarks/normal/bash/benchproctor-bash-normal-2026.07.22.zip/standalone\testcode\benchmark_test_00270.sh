#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00270() {
  user_input="$HTTP_COOKIE"
  printf -v data "%s" "${user_input}"
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00270 "$@"
