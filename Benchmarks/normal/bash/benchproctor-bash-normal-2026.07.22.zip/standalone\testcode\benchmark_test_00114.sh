#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00114() {
  user_input="k7Qm2Rv9Lp4Tw8Nj3Zc"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  curl -s -H "Authorization: Bearer $data" http://api.internal/data > /dev/null
}

benchmark_test_00114 "$@"
