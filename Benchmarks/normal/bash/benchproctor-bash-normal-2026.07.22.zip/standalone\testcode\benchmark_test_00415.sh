#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00415() {
  user_input="$HTTP_COOKIE"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00415 "$@"
