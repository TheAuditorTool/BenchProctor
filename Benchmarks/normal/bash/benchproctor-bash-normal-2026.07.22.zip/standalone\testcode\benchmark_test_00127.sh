#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00127() {
  user_input="$USER_COMMENT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/www/html/exports/report.dat
}

benchmark_test_00127 "$@"
