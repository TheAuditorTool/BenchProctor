#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00104() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  echo "data" > "/tmp/$data"
}

benchmark_test_00104 "$@"
