#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00382() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00382 "$@"
