#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00105() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%b" "$user_input")
  printf '%s\r\n' "Access-Control-Allow-Origin: $data"
}

benchmark_test_00105 "$@"
