#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00493() {
  user_input="$HTTP_HOST"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  printf "Location: %s\r\n\r\n" "$data"
}

benchmark_test_00493 "$@"
