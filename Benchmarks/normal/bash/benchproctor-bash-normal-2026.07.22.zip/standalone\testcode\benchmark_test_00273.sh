#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00273() {
  user_input="q9Cb4Ad2Fg8Ht3Vk6Mp"
  set -- "$user_input" "http"
  data="$1"
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00273 "$@"
