#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00316() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  set -- "$user_input" "http"
  data="$1"
  printf "%s" "$data" | openssl pkeyutl -encrypt -pkeyopt rsa_padding_mode:oaep -pubin -inkey /etc/app/rsa_pub.pem -out /dev/null 2>/dev/null
}

benchmark_test_00316 "$@"
