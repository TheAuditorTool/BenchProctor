#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00018() {
  user_input="$HTTP_AUTHORIZATION"
  _seed=$(printf "%s" "$user_input" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00018 "$@"
