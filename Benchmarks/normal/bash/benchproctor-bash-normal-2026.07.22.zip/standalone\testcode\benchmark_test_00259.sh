#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00259() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  curl -s "$target_url"
}

benchmark_test_00259 "$@"
