#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00487() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  data=$(printf "%s" "$user_input")
  case $data in config.json|index.html|readme.md) checked_path="/var/app/data/$data";; *) echo "forbidden"; exit 1;; esac
  echo "uploaded" > "$checked_path"
}

benchmark_test_00487 "$@"
