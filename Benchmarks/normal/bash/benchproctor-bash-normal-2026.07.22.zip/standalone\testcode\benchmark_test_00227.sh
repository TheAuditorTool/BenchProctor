#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00227() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  printf "%s" "$data" | openssl pkeyutl -encrypt -pkeyopt rsa_padding_mode:oaep -pubin -inkey /etc/app/rsa_pub.pem -out /dev/null 2>/dev/null
}

benchmark_test_00227 "$@"
