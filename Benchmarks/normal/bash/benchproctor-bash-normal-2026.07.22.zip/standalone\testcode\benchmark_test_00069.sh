#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00069() {
  user_input="$(printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep '^items=' | cut -d= -f2-)"
  data=$(printf "%s" "$user_input")
  logger "Action: $data"
}

benchmark_test_00069 "$@"
