#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00145() {
  user_input="$HTTP_USER_AGENT"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  mysql -e "SELECT * FROM users ORDER BY $processed"
}

benchmark_test_00145 "$@"
