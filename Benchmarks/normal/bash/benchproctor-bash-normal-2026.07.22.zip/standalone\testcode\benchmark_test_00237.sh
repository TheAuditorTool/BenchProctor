#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00237() {
  user_input="$HTTP_REFERER"
  data=$(printf "%b" "${user_input//%/\\x}")
  case "$data" in */public|*/static|*/.) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00237 "$@"
