#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00226() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null
}

benchmark_test_00226 "$@"
