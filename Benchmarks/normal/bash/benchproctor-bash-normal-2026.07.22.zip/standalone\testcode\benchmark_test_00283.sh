#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00283() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data="${user_input//$'\x00'/}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00283 "$@"
