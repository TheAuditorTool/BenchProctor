#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00185() {
  user_input="$QUERY_STRING"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  chown -- "$data" /var/app/run/worker.pid || { echo "privilege drop failed" >&2; exit 1; }
}

benchmark_test_00185 "$@"
