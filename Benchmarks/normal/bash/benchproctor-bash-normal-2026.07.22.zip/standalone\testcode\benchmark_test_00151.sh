#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00151() {
  user_input="$(cat /dev/stdin)"
  case $user_input in asc|desc|name|created) processed="$user_input";; *) echo "invalid"; exit 1;; esac
  ldapsearch -x -b "dc=example,dc=com" "uid=$processed"
}

benchmark_test_00151 "$@"
