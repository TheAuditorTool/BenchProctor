#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00340() {
  user_input="$HTTP_ORIGIN"
  data="${user_input:-default}"
  logger "Action: $data"
}

benchmark_test_00340 "$@"
