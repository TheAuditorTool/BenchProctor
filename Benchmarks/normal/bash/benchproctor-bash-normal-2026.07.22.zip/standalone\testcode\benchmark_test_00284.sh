#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00284() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "$data" | openssl enc -aes-128-ctr -nosalt -iv 00000000000000000000000000000000 -K "$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00284 "$@"
