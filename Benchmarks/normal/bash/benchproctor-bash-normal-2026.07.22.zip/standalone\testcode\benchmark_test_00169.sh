#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00169() {
  user_input="$HTTP_X_FORWARDED_FOR"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  echo "Error: $data" >&2
}

benchmark_test_00169 "$@"
