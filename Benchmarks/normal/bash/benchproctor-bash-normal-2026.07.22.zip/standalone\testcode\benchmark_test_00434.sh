#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00434() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  mongosh --eval "db.users.find({name: '$processed'})"
}

benchmark_test_00434 "$@"
