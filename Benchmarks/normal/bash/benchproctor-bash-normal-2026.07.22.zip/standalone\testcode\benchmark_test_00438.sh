#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00438() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  encoded_data=$(echo "$data" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/data/secrets.enc
}

benchmark_test_00438 "$@"
