#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00028() {
  user_input="$(cat /etc/app/config)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  echo -n "$data" | md5sum
}

benchmark_test_00028 "$@"
