#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00156() {
  user_input="$(cat /dev/stdin)"
  data=$(printf "%s" "$user_input")
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00156 "$@"
