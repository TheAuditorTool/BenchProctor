#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00113() {
  user_input="$QUERY_STRING"
  trap 'echo "error at line $LINENO" >&2; exit 1' ERR
  echo "$user_input"
}

benchmark_test_00113 "$@"
