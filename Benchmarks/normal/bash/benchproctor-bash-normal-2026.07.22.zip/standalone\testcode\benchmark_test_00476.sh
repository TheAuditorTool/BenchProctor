#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00476() {
  user_input="$(mysql -N -e 'SELECT bio FROM profiles LIMIT 1')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00476 "$@"
