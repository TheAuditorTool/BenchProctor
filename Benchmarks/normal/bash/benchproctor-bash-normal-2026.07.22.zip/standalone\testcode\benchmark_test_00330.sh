#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00330() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  _body=$(curl -s "$data")
  _want=$(curl -sI "$data" | grep -i "^X-Content-SHA256:" | tr -d "\r" | cut -d" " -f2)
  if [ "$(printf "%s" "$_body" | sha256sum | cut -d" " -f1)" != "$_want" ]; then echo "integrity check failed" >&2; exit 1; fi
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00330 "$@"
