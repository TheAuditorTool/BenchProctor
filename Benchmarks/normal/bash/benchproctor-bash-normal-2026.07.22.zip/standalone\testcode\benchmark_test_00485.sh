#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00485() {
  user_input="$HTTP_X_FORWARDED_FOR"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  trap '' ERR
  echo "$data"
}

benchmark_test_00485 "$@"
