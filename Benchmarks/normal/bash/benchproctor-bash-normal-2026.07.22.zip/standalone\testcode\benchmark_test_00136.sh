#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00136() {
  user_input="$USER_COMMENT"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00136 "$@"
