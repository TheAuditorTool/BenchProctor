#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00222() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00222 "$@"
