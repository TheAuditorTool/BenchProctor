#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00364() {
  user_input="$HTTP_ORIGIN"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  trap '' ERR
  echo "$data"
}

benchmark_test_00364 "$@"
