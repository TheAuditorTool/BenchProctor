#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00408() {
  user_input="$APP_INPUT"
  data=$(printf "%s" "$user_input")
  echo -n "$data" | md5sum
}

benchmark_test_00408 "$@"
