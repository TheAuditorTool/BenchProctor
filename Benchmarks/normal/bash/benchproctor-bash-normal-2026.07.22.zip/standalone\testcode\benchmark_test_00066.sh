#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00066() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00066 "$@"
