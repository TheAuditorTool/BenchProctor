#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00089() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  printf "%s" "$data" | openssl pkeyutl -encrypt -pkeyopt rsa_padding_mode:oaep -pubin -inkey /etc/app/rsa_pub.pem -out /dev/null 2>/dev/null
}

benchmark_test_00089 "$@"
