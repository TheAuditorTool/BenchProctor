#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00375() {
  user_input="$APP_INPUT"
  data=$(printf "%s" "$user_input")
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00375 "$@"
