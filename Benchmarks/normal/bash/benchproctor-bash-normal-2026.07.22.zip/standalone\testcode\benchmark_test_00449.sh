#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00449() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00449 "$@"
