#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00323() {
  user_input="$HTTP_HOST"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "Error: $data" >&2
}

benchmark_test_00323 "$@"
