#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00360() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  input_value="$data"
  if [[ "$input_value" =~ [a-zA-Z0-9_-]+ ]]; then
    printf "X-Validated: %s\r\n" "$input_value"
  fi
}

benchmark_test_00360 "$@"
