#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00007() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  if [ -z "$AUTH_TOKEN" ]; then echo "unauthorized" >&2; exit 1; fi
  if ! awk -F: -v u="$data" '$1==u{found=1} END{exit !found}' /etc/app/users.db; then
    echo "401 unauthorized" >&2
    exit 1
  fi
}

benchmark_test_00007 "$@"
