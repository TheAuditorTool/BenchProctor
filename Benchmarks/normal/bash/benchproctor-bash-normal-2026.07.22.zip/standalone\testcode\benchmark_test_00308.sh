#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00308() {
  user_input="$USER_COMMENT"
  set -- "$user_input" "http"
  data="$1"
  trap '' ERR
  echo "$data"
}

benchmark_test_00308 "$@"
