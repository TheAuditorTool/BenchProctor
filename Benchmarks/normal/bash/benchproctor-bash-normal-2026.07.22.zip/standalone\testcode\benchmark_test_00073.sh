#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00073() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data="${user_input:-default}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  printf 'SETTING=%s\n' "$processed" > /var/app/plugins/gen.sh
  source /var/app/plugins/gen.sh
}

benchmark_test_00073 "$@"
