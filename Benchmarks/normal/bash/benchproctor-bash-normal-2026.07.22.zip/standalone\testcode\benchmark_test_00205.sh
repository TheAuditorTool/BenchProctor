#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00205() {
  user_input="$(cat /dev/stdin)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  case "$data" in
    aes*) echo "$data" | openssl enc -aes-128-cbc -nosalt -pass pass:legacykey -out /dev/null;;
    *) echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null;;
  esac
}

benchmark_test_00205 "$@"
