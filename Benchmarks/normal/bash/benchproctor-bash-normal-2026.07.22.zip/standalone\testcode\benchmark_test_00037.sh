#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00037() {
  if [ -z "$AUTH_TOKEN" ]; then echo "unauthorized" >&2; exit 1; fi
  echo "Internal error" >&2
}

benchmark_test_00037 "$@"
