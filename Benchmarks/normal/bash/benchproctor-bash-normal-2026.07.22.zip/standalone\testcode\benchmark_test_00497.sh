#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00497() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  _fname=$(basename -- "$data")
  case "$_fname" in *.jpg|*.png|*.gif|*.pdf) entry_file="$_fname";; *) echo "invalid file type"; exit 1;; esac
  echo "uploaded" > "/var/uploads/$entry_file"
}

benchmark_test_00497 "$@"
