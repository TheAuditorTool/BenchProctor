#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00314() {
  user_input="$(cat /dev/stdin)"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00314 "$@"
