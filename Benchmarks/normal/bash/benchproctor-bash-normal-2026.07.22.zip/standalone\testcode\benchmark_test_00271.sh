#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00271() {
  user_input="$(cat /dev/stdin)"
  data="${user_input:-default}"
  echo -n "$data" | sha256sum
}

benchmark_test_00271 "$@"
