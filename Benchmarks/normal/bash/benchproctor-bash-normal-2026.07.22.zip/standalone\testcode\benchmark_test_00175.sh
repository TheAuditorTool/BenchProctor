#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00175() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  local -a _cmd=("printf" "%s" "$user_input")
  "${_cmd[@]}"
}

benchmark_test_00175 "$@"
