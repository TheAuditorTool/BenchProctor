#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00362() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  rm -f $processed
}

benchmark_test_00362 "$@"
