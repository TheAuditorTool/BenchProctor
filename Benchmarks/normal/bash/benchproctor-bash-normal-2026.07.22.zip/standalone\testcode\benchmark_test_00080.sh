#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00080() {
  user_input="$HTTP_AUTHORIZATION"
  printf -v data "%s" "${user_input}"
  trap '' ERR
  echo "$data"
}

benchmark_test_00080 "$@"
