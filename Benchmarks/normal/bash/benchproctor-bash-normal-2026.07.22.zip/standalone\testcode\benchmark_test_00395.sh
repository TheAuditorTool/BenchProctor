#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00395() {
  user_input="$PATH_INFO"
  data="${user_input//$'\x00'/}"
  curl -s "$data"
}

benchmark_test_00395 "$@"
