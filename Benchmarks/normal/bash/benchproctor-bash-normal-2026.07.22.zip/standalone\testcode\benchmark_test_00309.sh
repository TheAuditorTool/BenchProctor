#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00309() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(printf "%b" "${user_input//%/\\x}")
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00309 "$@"
