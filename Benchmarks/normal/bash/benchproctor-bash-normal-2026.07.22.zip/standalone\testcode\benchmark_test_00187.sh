#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00187() {
  user_input="$APP_INPUT"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00187 "$@"
