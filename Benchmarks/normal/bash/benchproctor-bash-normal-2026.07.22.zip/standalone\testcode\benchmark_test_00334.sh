#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00334() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _body=$(curl -s "$data")
  _want=$(curl -sI "$data" | grep -i "^X-Content-SHA256:" | tr -d "\r" | cut -d" " -f2)
  if [ "$(printf "%s" "$_body" | sha256sum | cut -d" " -f1)" != "$_want" ]; then echo "integrity check failed" >&2; exit 1; fi
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00334 "$@"
