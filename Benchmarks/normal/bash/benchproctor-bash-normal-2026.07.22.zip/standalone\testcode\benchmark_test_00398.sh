#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00398() {
  user_input="$HTTP_USER_AGENT"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  mysql -e "SELECT * FROM users WHERE id = '$data'"
}

benchmark_test_00398 "$@"
