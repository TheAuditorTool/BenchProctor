#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00062() {
  mktemp /tmp/app.XXXXXX
}

benchmark_test_00062 "$@"
