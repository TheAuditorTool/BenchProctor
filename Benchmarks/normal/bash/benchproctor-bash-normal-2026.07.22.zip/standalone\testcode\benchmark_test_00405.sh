#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00405() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$data" 2>/dev/null
}

benchmark_test_00405 "$@"
