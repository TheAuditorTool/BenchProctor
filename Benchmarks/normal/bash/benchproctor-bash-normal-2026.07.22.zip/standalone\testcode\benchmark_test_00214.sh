#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00214() {
  user_input="$HTTP_ORIGIN"
  echo "$user_input" | openssl enc -aes-128-cbc -nosalt -iv 00000000000000000000000000000000 -K "$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00214 "$@"
