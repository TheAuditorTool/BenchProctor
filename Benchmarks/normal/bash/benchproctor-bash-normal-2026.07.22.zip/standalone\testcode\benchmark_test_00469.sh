#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00469() {
  user_input="$HTTP_USER_AGENT"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  chmod 777 "/var/app/data/$data"
}

benchmark_test_00469 "$@"
