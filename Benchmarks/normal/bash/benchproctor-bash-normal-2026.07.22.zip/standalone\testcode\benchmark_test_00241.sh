#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00241() {
  user_input="$APP_INPUT"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  logger "Action: $data"
}

benchmark_test_00241 "$@"
