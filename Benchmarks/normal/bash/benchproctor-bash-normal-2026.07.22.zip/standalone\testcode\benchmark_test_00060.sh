#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00060() {
  user_input="$QUERY_STRING"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00060 "$@"
