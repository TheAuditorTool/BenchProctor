#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00195() {
  user_input="$HTTP_REFERER"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  case $data in
    a) echo alpha;;
    b) echo beta;;
    *) echo unknown;;
  esac
}

benchmark_test_00195 "$@"
