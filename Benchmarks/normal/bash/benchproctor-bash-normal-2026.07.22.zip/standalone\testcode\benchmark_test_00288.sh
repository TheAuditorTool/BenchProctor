#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00288() {
  user_input="k7Qm2Rv9Lp4Tw8Nj3Zc"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00288 "$@"
