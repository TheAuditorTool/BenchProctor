#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00345() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [ -z "$AUTH_TOKEN" ]; then echo "unauthorized" >&2; exit 1; fi
  if ! awk -F: -v u="$data" '$1==u{found=1} END{exit !found}' /etc/app/users.db; then
    echo "401 unauthorized" >&2
    exit 1
  fi
}

benchmark_test_00345 "$@"
