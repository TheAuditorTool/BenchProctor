#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00017() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  echo -n "$data" | md5sum
}

benchmark_test_00017 "$@"
