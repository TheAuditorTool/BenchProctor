#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00138() {
  store_cred=$(vault kv get -field=secret secret/app 2>/dev/null || echo "")
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$store_cred" -in /dev/null -out /dev/null
}

benchmark_test_00138 "$@"
