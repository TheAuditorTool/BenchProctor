#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00051() {
  user_input="$APP_INPUT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  chown "$data" /var/app/data/managed.txt 2>/dev/null
}

benchmark_test_00051 "$@"
