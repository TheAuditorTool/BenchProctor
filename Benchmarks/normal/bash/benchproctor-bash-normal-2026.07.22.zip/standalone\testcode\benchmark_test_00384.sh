#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00384() {
  user_input="$QUERY_STRING"
  data="${user_input:-default}"
  eval "echo $data"
}

benchmark_test_00384 "$@"
