#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00173() {
  user_input="$(cat /dev/stdin)"
  set -- "$user_input" "http"
  data="$1"
  echo -n "$data" | md5sum
}

benchmark_test_00173 "$@"
