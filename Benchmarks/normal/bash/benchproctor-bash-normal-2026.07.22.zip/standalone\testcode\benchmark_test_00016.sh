#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00016() {
  user_input="$HTTP_USER_AGENT"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  printf "Content-Type: %s\r\n\r\n" "$processed"
  printf "{\"status\":\"ok\"}"
}

benchmark_test_00016 "$@"
