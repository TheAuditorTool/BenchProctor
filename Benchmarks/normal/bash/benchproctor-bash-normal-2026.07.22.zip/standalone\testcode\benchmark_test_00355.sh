#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00355() {
  user_input="$(cat /dev/stdin)"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  normalized=$(echo "$processed" | iconv -f UTF-8 -t ASCII//TRANSLIT 2>/dev/null || echo "$processed")
  printf "Content-Type: text/html\r\n\r\n"
  printf "<p>%s</p>" "$normalized"
}

benchmark_test_00355 "$@"
