#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00224() {
  user_input="$HTTP_USER_AGENT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  _input="$data"
  if [ "${#_input}" -gt 64 ]; then _input="${_input:0:64}"; fi
  processed="$_input"
  if [[ "$processed" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $processed" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00224 "$@"
