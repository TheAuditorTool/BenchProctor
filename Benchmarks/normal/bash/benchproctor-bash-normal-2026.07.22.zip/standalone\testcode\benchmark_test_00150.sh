#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00150() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00150 "$@"
