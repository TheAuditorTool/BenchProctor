#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00009() {
  user_input="b5Vc8Kp2Mq9Lr4Wt7Jz"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$data" -in /dev/null -out /dev/null
}

benchmark_test_00009 "$@"
