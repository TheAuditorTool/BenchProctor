#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00235() {
  user_input="$(cat /etc/app/config)"
  if grep -qF -- "$user_input" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00235 "$@"
