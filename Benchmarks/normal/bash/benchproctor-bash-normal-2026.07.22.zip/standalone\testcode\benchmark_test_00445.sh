#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00445() {
  user_input="$QUERY_STRING"
  data=$(printf "%b" "${user_input//%/\\x}")
  echo "$data" | grep -qE "^[0-9]+$"
}

benchmark_test_00445 "$@"
