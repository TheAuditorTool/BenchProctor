#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00440() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  mongosh --eval "db.users.find({name: '$data'})"
}

benchmark_test_00440 "$@"
