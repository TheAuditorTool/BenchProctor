#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00157() {
  user_input="$HTTP_REFERER"
  data=$(printf "%s" "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  printf "Content-Type: %s\r\n\r\n" "$processed"
  printf "{\"status\":\"ok\"}"
}

benchmark_test_00157 "$@"
