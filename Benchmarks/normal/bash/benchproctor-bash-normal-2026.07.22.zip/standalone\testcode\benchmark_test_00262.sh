#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00262() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data="${user_input:-default}"
  if [ -n "$data" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00262 "$@"
