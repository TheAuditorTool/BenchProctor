#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00343() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  echo "$user_input" | tr 'A-Za-z' 'N-ZA-Mn-za-m'
}

benchmark_test_00343 "$@"
