#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00103() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  echo "$data" | openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00103 "$@"
