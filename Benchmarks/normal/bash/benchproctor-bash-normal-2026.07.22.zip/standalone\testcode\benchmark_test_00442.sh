#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00442() {
  user_input="$HTTP_ORIGIN"
  data="${user_input:-default}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00442 "$@"
