#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00025() {
  user_input="$(cat /etc/app/config)"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  echo -n "$data" | md5sum
}

benchmark_test_00025 "$@"
