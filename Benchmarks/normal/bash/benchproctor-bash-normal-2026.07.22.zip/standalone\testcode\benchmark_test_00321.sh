#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00321() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  checked_path=$(realpath -m "/var/app/data/$user_input")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00321 "$@"
