#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00431() {
  user_input="$HTTP_COOKIE"
  set -- "$user_input" "http"
  data="$1"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  eval "echo $processed"
}

benchmark_test_00431 "$@"
