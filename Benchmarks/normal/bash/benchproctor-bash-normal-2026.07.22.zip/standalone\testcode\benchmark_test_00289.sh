#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00289() {
  user_input="$HTTP_ORIGIN"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  chmod 777 "/var/app/data/$data"
}

benchmark_test_00289 "$@"
