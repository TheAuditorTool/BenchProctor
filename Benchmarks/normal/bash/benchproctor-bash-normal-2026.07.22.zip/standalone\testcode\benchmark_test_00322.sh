#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00322() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  set -- "$user_input" "http"
  data="$1"
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "invalid"; exit 1; fi
  bounded_val="$data"
  if [ "$bounded_val" -lt 0 ] || [ "$bounded_val" -gt 2147483647 ]; then echo "overflow"; exit 1; fi
  arr=(10 20 30 40 50)
  if [[ ! "$bounded_val" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  idx=$bounded_val
  echo "${arr[$idx]}"
}

benchmark_test_00322 "$@"
