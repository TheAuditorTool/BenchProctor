#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00411() {
  user_input="$HTTP_REFERER"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00411 "$@"
