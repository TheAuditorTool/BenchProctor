#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00318() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00318 "$@"
