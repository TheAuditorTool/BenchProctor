#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00402() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  curl -sk "$data"
}

benchmark_test_00402 "$@"
