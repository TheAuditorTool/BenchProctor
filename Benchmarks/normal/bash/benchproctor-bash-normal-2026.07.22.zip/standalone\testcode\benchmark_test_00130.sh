#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00130() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  IFS="," read -r -a values <<< "$processed"
  if [ ${#values[@]} -gt 0 ]; then
    printf "X-Param-First: %s\r\n" "${values[0]}"
    printf "X-Param-Dropped: %s\r\n" "$((${#values[@]} - 1))"
  fi
}

benchmark_test_00130 "$@"
