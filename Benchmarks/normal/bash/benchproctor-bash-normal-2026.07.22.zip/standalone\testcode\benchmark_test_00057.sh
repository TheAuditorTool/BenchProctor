#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00057() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00057 "$@"
