#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00109() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  tar -czf /tmp/archive.tgz $processed
}

benchmark_test_00109 "$@"
