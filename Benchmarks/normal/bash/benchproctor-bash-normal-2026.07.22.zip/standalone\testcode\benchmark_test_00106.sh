#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00106() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00106 "$@"
