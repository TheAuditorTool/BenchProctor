#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00176() {
  user_input="$(cat /etc/app/config)"
  data=$(printf "%s" "$user_input")
  echo "$data" > /var/data/secrets.txt
}

benchmark_test_00176 "$@"
