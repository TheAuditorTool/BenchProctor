#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00489() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00489 "$@"
