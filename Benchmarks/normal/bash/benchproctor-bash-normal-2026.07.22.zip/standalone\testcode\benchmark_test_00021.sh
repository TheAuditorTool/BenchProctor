#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00021() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  echo "$data" | tr 'A-Za-z' 'N-ZA-Mn-za-m'
}

benchmark_test_00021 "$@"
