#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00372() {
  user_input="$DOTENV_VAR"
  encoded_data=$(echo "$user_input" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:"$APP_KEY" 2>/dev/null)
  printf "%s" "$encoded_data" > /var/data/secrets.enc
}

benchmark_test_00372 "$@"
