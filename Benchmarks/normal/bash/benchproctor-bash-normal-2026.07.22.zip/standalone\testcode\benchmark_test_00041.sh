#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00041() {
  user_input="$HTTP_ORIGIN"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00041 "$@"
