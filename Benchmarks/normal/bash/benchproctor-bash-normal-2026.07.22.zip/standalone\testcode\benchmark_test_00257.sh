#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00257() {
  user_input="$APP_INPUT"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  printf "Location: %s\r\n\r\n" "$data"
}

benchmark_test_00257 "$@"
