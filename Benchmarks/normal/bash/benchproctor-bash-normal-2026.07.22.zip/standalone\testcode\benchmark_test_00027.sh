#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00027() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=""
  IFS="," read -ra _tokens <<< "${user_input}"
  for token in "${_tokens[@]}"; do data="$token"; done
  if grep -qF -- "$data" /etc/app/passwd.db 2>/dev/null; then
    echo "auth ok"
  else
    echo "auth failed" >&2; exit 1
  fi
}

benchmark_test_00027 "$@"
