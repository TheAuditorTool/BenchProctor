#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00335() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  curl -s "$data"
}

benchmark_test_00335 "$@"
