#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00338() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  cat "/var/app/data/$data"
}

benchmark_test_00338 "$@"
