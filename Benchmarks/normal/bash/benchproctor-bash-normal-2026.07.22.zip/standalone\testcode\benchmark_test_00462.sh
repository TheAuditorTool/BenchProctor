#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00462() {
  user_input="$(cat /dev/stdin)"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  _attempts=$(( ${_attempts:-0} + 1 ))
  logger "login attempt #$_attempts"
  if grep -qF -- "$data" /etc/app/passwd; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00462 "$@"
