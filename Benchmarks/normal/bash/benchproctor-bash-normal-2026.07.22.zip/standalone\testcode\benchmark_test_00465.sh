#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00465() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  case "${data,,}" in admin|administrator|root) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00465 "$@"
