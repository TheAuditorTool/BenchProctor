#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00047() {
  store_cred=$(vault kv get -field=secret secret/app 2>/dev/null || echo "")
  if [ -z "$store_cred" ]; then echo "missing credential" >&2; exit 1; fi
  echo "granted" >> /var/log/auth.audit
}

benchmark_test_00047 "$@"
