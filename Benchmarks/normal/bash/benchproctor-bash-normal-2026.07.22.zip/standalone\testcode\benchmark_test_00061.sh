#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00061() {
  user_input="$APP_INPUT"
  data="${user_input//$'\x00'/}"
  curl -s "$data"
}

benchmark_test_00061 "$@"
