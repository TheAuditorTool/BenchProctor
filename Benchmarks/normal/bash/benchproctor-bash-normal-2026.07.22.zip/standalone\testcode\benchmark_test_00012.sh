#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00012() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  curl -s http://api.lan.local/ingest --data "$data"
}

benchmark_test_00012 "$@"
