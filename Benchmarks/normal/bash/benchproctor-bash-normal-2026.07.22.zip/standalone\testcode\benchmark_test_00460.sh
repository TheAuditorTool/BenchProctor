#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00460() {
  user_input="$HTTP_ORIGIN"
  if [[ ! $user_input =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$user_input"
  tar -czf /tmp/archive.tgz $processed
}

benchmark_test_00460 "$@"
