#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00484() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(printf "%s" "$user_input")
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo $((RANDOM % 16))
}

benchmark_test_00484 "$@"
