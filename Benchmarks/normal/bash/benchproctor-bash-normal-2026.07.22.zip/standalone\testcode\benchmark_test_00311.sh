#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00311() {
  user_input="$HTTP_USER_AGENT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00311 "$@"
