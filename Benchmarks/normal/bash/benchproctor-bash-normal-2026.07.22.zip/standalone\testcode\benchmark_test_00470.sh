#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00470() {
  user_input="$HTTP_USER_AGENT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  case "$data" in
    aes*) echo "$data" | openssl enc -aes-128-cbc -nosalt -pass pass:legacykey -out /dev/null;;
    *) echo "$data" | openssl enc -des-ecb -provider legacy -provider default -nosalt -pass pass:legacykey -out /dev/null;;
  esac
}

benchmark_test_00470 "$@"
