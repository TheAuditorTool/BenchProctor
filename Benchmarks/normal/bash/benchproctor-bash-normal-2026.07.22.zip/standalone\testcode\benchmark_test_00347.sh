#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00347() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00347 "$@"
