#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00132() {
  user_input="$HTTP_X_FORWARDED_FOR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00132 "$@"
