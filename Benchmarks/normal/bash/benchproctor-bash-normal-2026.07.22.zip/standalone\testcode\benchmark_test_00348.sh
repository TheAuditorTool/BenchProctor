#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00348() {
  user_input="$APP_INPUT"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  echo -n "$data" | sha256sum
}

benchmark_test_00348 "$@"
