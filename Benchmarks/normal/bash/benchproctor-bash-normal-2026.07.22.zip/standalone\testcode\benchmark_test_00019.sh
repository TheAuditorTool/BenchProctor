#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00019() {
  user_input="$HTTP_COOKIE"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  printf "<!-- diagnostic build token: %s -->" "$data"
}

benchmark_test_00019 "$@"
