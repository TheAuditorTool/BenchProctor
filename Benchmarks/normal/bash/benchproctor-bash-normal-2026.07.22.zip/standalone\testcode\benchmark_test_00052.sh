#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00052() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  if [ -z "$AUTH_TOKEN" ]; then echo "unauthorized" >&2; exit 1; fi
  if ! awk -F: -v u="$data" '$1==u{found=1} END{exit !found}' /etc/app/users.db; then
    echo "401 unauthorized" >&2
    exit 1
  fi
}

benchmark_test_00052 "$@"
