#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00096() {
  user_input="$HTTP_COOKIE"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00096 "$@"
