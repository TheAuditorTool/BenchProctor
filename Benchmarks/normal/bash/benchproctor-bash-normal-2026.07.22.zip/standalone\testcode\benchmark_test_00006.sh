#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00006() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  set -- "$user_input" "http"
  data="$1"
  case $data in /bin/echo|/bin/cat|/usr/bin/id) allowed_bin=$data;; *) echo "forbidden binary" >&2; exit 1;; esac
  eval "$allowed_bin"
}

benchmark_test_00006 "$@"
