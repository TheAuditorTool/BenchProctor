#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00178() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  if [ -n "$user_input" ]; then data="$user_input"; else data=""; fi
  trap '' ERR
  echo "$data"
}

benchmark_test_00178 "$@"
