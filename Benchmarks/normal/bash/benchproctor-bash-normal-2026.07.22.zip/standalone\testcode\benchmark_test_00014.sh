#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00014() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  mysql -e "SELECT * FROM users WHERE id = '$processed'"
}

benchmark_test_00014 "$@"
