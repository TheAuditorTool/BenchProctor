#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00236() {
  user_input="$(jq -r '.variables.input // empty' 2>/dev/null)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  curl -s "https://api.lan.local/lookup?q=$processed" > /dev/null
}

benchmark_test_00236 "$@"
