#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00422() {
  user_input="$PATH_INFO"
  set -- "$user_input" "http"
  data="$1"
  logger "Action: $data"
}

benchmark_test_00422 "$@"
