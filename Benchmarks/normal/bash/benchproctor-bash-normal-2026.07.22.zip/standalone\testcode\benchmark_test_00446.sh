#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00446() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=$(printf "%s" "$user_input")
  trap '' ERR
  echo "$data"
}

benchmark_test_00446 "$@"
