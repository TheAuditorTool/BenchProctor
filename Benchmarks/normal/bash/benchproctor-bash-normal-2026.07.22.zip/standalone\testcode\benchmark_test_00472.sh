#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00472() {
  user_input="$HTTP_USER_AGENT"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00472 "$@"
