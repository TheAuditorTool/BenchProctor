#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00186() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  if _parsed=$(printf "%d" "${user_input}" 2>/dev/null); then
    data="$_parsed"
  else
    data="${user_input}"
  fi
  trusted_claim="$data"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00186 "$@"
