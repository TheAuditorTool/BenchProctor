#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00149() {
  user_input="$HTTP_HOST"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  case $data in
    a) echo alpha;;
    b) echo beta;;
    *) echo unknown;;
  esac
}

benchmark_test_00149 "$@"
