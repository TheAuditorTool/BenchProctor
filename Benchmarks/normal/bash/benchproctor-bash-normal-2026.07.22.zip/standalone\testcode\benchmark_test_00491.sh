#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00491() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  mapfile -t _mapped < <(printf "%s\n" "${user_input}")
  data="${_mapped[0]}"
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  trusted_claim="$processed"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00491 "$@"
