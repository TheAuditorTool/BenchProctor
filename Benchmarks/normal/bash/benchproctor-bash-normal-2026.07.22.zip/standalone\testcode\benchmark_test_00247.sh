#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00247() {
  user_input="$(cat /dev/stdin)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  if ! echo "$data" | grep -qE "^[0-9]+$"; then echo "invalid" >&2; exit 1; fi
}

benchmark_test_00247 "$@"
