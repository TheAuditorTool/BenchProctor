#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00272() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  echo "$user_input" | xmllint --nonet - > /dev/null 2>&1
}

benchmark_test_00272 "$@"
