#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00221() {
  user_input="$HTTP_COOKIE"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  sudo -u nobody echo "$data"
}

benchmark_test_00221 "$@"
