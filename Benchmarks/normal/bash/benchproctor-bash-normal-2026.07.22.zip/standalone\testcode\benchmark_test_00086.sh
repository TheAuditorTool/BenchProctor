#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00086() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=$(printf "%s" "$user_input")
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00086 "$@"
