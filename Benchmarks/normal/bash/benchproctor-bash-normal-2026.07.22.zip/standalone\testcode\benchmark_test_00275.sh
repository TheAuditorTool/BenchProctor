#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00275() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  awk "BEGIN { srand($_seed); print int(rand()*100) }"
}

benchmark_test_00275 "$@"
