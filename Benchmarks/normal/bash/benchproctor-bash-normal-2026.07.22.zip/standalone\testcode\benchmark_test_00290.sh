#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00290() {
  user_input="$PATH_INFO"
  rm "$user_input"
}

benchmark_test_00290 "$@"
