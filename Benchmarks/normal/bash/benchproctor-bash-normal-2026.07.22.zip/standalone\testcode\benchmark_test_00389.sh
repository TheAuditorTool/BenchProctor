#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00389() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data="${user_input:-default}"
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00389 "$@"
