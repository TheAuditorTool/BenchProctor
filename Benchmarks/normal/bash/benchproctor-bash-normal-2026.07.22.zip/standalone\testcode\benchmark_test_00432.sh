#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00432() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00432 "$@"
