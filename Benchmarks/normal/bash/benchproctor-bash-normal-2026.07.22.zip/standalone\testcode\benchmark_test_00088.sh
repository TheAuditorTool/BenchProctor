#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00088() {
  user_input="$USER_COMMENT"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  echo "$data" | openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$DATA_ENC_KEY" -out /dev/null
}

benchmark_test_00088 "$@"
