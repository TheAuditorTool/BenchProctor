#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00147() {
  user_input="$(cat /dev/stdin)"
  printf -v data "%s" "${user_input}"
  curl -sk "$data"
}

benchmark_test_00147 "$@"
