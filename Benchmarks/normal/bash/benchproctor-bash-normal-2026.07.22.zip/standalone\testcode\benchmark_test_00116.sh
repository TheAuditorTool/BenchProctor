#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00116() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  ulimit -v 524288
  if [[ "$data" =~ ^[0-9]+$ ]]; then _req="$data"; else _req=0; fi
  (( _req > 1024 )) && _req=1024
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$_req" 2>/dev/null
}

benchmark_test_00116 "$@"
