#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00046() {
  user_input="$HTTP_REFERER"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  case "$data" in admin|true|authenticated) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00046 "$@"
