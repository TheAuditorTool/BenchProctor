#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00125() {
  user_input="$HTTP_AUTHORIZATION"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  logger "Action: $processed"
}

benchmark_test_00125 "$@"
