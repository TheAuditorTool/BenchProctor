#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00033() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  _claimed_role="${data##*:}"
  if [ "$_claimed_role" = "admin" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00033 "$@"
