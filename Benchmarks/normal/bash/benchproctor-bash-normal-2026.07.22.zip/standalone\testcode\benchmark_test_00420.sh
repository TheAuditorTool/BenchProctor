#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00420() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  printf "Content-Type: %s\r\n\r\n" "$processed"
  printf "{\"status\":\"ok\"}"
}

benchmark_test_00420 "$@"
