#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00229() {
  user_input="$(cat /dev/stdin)"
  data="${user_input//$'\x00'/}"
  cp /var/app/secure/template.cfg "/var/app/data/$data"
  chmod 644 "/var/app/data/$data"
}

benchmark_test_00229 "$@"
