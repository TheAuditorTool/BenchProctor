#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00471() {
  user_input="$HTTP_HOST"
  set -- "$user_input" "http"
  data="$1"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00471 "$@"
