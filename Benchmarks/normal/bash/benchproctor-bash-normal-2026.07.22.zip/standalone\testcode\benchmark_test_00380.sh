#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00380() {
  user_input="$HTTP_REFERER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  printf "Location: /dashboard?hidden_field=%s\r\n\r\n" "$processed"
}

benchmark_test_00380 "$@"
