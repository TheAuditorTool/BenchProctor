#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00454() {
  user_input="$(cat /dev/stdin)"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  curl -s "$data"
}

benchmark_test_00454 "$@"
