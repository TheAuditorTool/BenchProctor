#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00349() {
  user_input="$(cat /dev/stdin)"
  data="${user_input:-default}"
  trusted_claim="$data"
  printf "X-Claim-Trusted: %s\r\n" "$trusted_claim"
}

benchmark_test_00349 "$@"
