#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00110() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00110 "$@"
