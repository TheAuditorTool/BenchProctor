#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00337() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  printf -v data "%s" "${user_input}"
  case "$data" in */public|*/static|*/.) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00337 "$@"
