#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00455() {
  user_input="$(cat /dev/stdin)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  echo "Error: $data" >&2
}

benchmark_test_00455 "$@"
