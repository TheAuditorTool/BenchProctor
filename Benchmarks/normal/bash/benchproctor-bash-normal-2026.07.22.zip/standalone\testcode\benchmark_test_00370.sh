#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00370() {
  user_input="$APP_INPUT"
  set -- "$user_input" "http"
  data="$1"
  _body=$(curl -s "$data")
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00370 "$@"
