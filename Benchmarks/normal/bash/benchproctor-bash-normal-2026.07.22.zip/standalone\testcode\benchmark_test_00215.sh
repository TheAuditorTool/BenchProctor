#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00215() {
  user_input="$(tr '&' '\n' | grep '^field=' | cut -d= -f2-)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  printf "Status: 500 Internal Server Error\r\n\r\nprocessing failed: %s\r\n" "$data"
}

benchmark_test_00215 "$@"
