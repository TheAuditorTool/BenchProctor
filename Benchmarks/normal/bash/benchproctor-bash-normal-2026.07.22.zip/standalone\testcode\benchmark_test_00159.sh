#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00159() {
  user_input="$QUERY_STRING"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  ulimit -v 524288
  if [[ "$data" =~ ^[0-9]+$ ]]; then _req="$data"; else _req=0; fi
  (( _req > 1024 )) && _req=1024
  dd if=/dev/zero of=/tmp/alloc bs=1k count="$_req" 2>/dev/null
}

benchmark_test_00159 "$@"
