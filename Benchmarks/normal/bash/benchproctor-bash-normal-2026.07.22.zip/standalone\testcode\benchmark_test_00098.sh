#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00098() {
  user_input="$HTTP_COOKIE"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [ "$data" = "S3cr3tToken" ]; then echo "granted" >> /var/log/auth.audit; exit 0; fi
}

benchmark_test_00098 "$@"
