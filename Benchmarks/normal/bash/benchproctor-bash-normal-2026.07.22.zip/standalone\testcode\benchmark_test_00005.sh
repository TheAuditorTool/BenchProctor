#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00005() {
  user_input="$HTTP_AUTHORIZATION"
  coproc _relay { IFS= read -r -d '' _m; printf '%s\0' "$_m"; }
  printf "%s\0" "$user_input" >&"${_relay[1]}"
  IFS= read -r -d '' data <&"${_relay[0]}"
  curl -s https://api.lan.local/ingest --data "$data"
}

benchmark_test_00005 "$@"
