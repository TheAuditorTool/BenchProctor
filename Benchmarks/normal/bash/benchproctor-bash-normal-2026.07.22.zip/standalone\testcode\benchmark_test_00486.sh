#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00486() {
  user_input="$HTTP_ORIGIN"
  data=$(printf "%s" "$user_input")
  if [[ ! "$data" =~ ^-?[0-9]+$ ]]; then echo "not a number" >&2; exit 1; fi
  result=$((100 / $data))
  echo "$result"
}

benchmark_test_00486 "$@"
