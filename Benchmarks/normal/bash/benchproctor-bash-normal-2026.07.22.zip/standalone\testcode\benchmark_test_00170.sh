#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00170() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  chown -- "$data" /var/app/run/worker.pid 2>/dev/null
}

benchmark_test_00170 "$@"
