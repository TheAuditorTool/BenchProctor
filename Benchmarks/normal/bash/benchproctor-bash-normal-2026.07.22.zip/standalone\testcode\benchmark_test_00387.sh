#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00387() {
  user_input="$(cat /dev/stdin)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  echo "uploaded" > "/var/uploads/$data"
}

benchmark_test_00387 "$@"
