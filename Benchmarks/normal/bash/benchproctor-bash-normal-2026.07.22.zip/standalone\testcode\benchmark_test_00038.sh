#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00038() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  _host=$(echo "$data" | sed -E "s#^[a-zA-Z]+://##; s#[/:].*##")
  case "$_host" in "["*|"") echo "private range blocked"; exit 1;; esac
  _ip=$(getent ahosts "$_host" 2>/dev/null | head -n1 | cut -d" " -f1)
  _ip="${_ip:-$_host}"
  if ! echo "$_ip" | grep -qE "^[0-9]{1,3}(\.[0-9]{1,3}){3}$"; then echo "non-ipv4 host blocked" >&2; exit 1; fi
  if echo "$_ip" | grep -qE "^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2[0-9]|3[01])\.)"; then echo "private range blocked"; exit 1; fi
  target_url="$data"
  _rest="${target_url#*://}"
  exec 3<>"/dev/tcp/${_rest%%[/:]*}/80"
}

benchmark_test_00038 "$@"
