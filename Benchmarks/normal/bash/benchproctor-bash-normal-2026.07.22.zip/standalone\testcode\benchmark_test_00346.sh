#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00346() {
  user_input="$HTTP_X_FORWARDED_FOR"
  printf -v data "%s" "${user_input}"
  case "$data" in 10.*|192.168.*|127.*) echo "granted" >> /var/log/auth.audit; exit 0;; esac
}

benchmark_test_00346 "$@"
