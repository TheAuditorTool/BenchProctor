#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00404() {
  user_input="$HTTP_REFERER"
  data="${user_input//$'\x00'/}"
  curl -sk "$data"
}

benchmark_test_00404 "$@"
