#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00353() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  _body=$(curl -s "$data")
  _want=$(curl -sI "$data" | grep -i "^X-Content-SHA256:" | tr -d "\r" | cut -d" " -f2)
  if [ "$(printf "%s" "$_body" | sha256sum | cut -d" " -f1)" != "$_want" ]; then echo "integrity check failed" >&2; exit 1; fi
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00353 "$@"
