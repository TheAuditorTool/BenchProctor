#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00094() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00094 "$@"
