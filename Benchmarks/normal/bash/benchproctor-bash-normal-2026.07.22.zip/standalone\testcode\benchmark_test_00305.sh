#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00305() {
  user_input="$HTTP_USER_AGENT"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00305 "$@"
