#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00393() {
  user_input="$(cat /dev/stdin)"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  _seed=$(printf "%s" "$data" | cksum | cut -d" " -f1)
  RANDOM=$_seed
  echo "$RANDOM"
}

benchmark_test_00393 "$@"
