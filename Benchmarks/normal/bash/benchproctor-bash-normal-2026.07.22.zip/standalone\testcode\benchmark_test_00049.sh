#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00049() {
  user_input="$USER_COMMENT"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  logger "Action: $data"
}

benchmark_test_00049 "$@"
