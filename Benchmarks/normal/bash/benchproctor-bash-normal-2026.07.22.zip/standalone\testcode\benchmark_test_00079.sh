#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00079() {
  user_input="$QUERY_STRING"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  case $data in asc|desc|name|created) processed="$data";; *) echo "invalid"; exit 1;; esac
  echo "$processed,data,row" >> /var/data/output.csv
}

benchmark_test_00079 "$@"
