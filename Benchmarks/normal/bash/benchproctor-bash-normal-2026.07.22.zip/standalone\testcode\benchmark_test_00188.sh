#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00188() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  trap 'echo "error at line $LINENO" >&2; exit 1' ERR
  echo "$data"
}

benchmark_test_00188 "$@"
