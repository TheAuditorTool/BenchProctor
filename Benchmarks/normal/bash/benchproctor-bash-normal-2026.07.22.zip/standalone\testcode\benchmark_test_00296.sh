#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00296() {
  user_input="$(cat /dev/stdin)"
  strutils::require() { [ -n "$1" ] || return 1; printf "%s" "$1"; }
  data=$(strutils::require "$user_input") || data="$user_input"
  curl -sk "$data"
}

benchmark_test_00296 "$@"
