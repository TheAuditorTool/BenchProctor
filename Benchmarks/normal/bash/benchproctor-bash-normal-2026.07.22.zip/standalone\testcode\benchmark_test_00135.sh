#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00135() {
  user_input="$(cat /dev/stdin)"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  _h=$(printf '%s' "$data" | sha256sum | cut -d" " -f1)
  if ! grep -qxF -- "$_h" /etc/app/pw_hashes; then echo "401 unauthorized" >&2; exit 1; fi
}

benchmark_test_00135 "$@"
