#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00366() {
  user_input="$(curl -s http://169.254.169.254/latest/meta-data/)"
  data="${user_input:-default}"
  _host_re='^https?://(api\.example\.com|cdn\.example\.com)(/|$)'
  if [[ ! "$data" =~ $_host_re ]]; then echo "forbidden host" >&2; exit 1; fi
  target_url="$data"
  printf "Location: %s\r\n\r\n" "$target_url"
}

benchmark_test_00366 "$@"
