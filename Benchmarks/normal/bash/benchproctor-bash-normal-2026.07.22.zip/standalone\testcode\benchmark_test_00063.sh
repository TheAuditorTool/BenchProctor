#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00063() {
  user_input="$HTTP_AUTHORIZATION"
  data=$(echo "$user_input" | base64 -d 2>/dev/null || echo "")
  redis-cli -s /var/run/redis.sock SET "role:$data" admin >/dev/null 2>&1
}

benchmark_test_00063 "$@"
