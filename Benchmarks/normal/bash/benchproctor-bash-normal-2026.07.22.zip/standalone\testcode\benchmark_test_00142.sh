#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00142() {
  user_input="$(sed -n 's/.*filename="\([^"]*\)".*/\1/p' | head -1)"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  printf "X-Custom: %s\r\n" "$data"
}

benchmark_test_00142 "$@"
