#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00126() {
  user_input="$DOTENV_VAR"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  logger "Action: $data"
}

benchmark_test_00126 "$@"
