#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00320() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  sudo -u nobody echo "$user_input"
}

benchmark_test_00320 "$@"
