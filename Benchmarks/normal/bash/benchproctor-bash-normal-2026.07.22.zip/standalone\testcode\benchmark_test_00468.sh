#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00468() {
  user_input="$HTTP_REFERER"
  normalize() { local _v="$1"; printf "%s\n" "$_v"; }
  data=$(normalize "$user_input")
  curl -sk "$data"
}

benchmark_test_00468 "$@"
