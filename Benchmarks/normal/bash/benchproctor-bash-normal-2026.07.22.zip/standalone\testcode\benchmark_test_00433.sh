#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00433() {
  user_input="$APP_INPUT"
  data="${user_input:-default}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  redis-cli -s /var/run/redis.sock SET "role:$data" admin >/dev/null 2>&1
}

benchmark_test_00433 "$@"
