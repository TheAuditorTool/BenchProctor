#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00310() {
  user_input="$HTTP_X_FORWARDED_FOR"
  set -- "$user_input" "http"
  data="$1"
  echo -n "$data" | md5sum
}

benchmark_test_00310 "$@"
