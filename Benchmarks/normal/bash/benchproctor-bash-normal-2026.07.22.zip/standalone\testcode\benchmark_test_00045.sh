#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00045() {
  user_input="$APP_INPUT"
  data="${user_input:-default}"
  echo -n "$data" | md5sum
}

benchmark_test_00045 "$@"
