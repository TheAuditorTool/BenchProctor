#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00482() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  data=$(echo "$user_input" | xxd -r -p 2>/dev/null || echo "")
  if [[ "$data" =~ ^(read|write|admin)$ ]]; then
    echo "granted: $data" >> /var/log/auth.audit
    exit 0
  fi
}

benchmark_test_00482 "$@"
