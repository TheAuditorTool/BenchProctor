#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00352() {
  user_input="$HTTP_ORIGIN"
  data=""
  while IFS= read -r line || [ -n "$line" ]; do data+="$line"$'\n'; done <<< "$user_input"
  data="${data%$'\n'}"
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  redis-cli -s /var/run/redis.sock SET "role:$data" admin >/dev/null 2>&1
}

benchmark_test_00352 "$@"
