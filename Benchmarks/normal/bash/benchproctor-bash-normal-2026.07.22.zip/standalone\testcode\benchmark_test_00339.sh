#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00339() {
  user_input="$HTTP_AUTHORIZATION"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  printf "{\"echo\":\"%s\"}\n" "$data"
}

benchmark_test_00339 "$@"
