#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00056() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  printf "%s" "$data" | sha256sum | cut -d" " -f1 > /var/data/secrets.enc
}

benchmark_test_00056 "$@"
