#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00254() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  data=$(echo "$user_input" | jq -r '.value // empty' 2>/dev/null || echo "")
  redis-cli DEL "session:$data" >/dev/null 2>&1
  logger "request processed"
}

benchmark_test_00254 "$@"
