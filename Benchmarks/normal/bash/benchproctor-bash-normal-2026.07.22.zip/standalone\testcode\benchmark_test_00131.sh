#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00131() {
  user_input="$HTTP_X_FORWARDED_FOR"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  rm "/var/app/data/$(basename "$data")" || { echo "delete failed" >&2; exit 1; }
}

benchmark_test_00131 "$@"
