#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00251() {
  user_input="$HTTP_AUTHORIZATION"
  _prefix="${user_input:0:1}"
  case "$_prefix" in
    h|H) data=$(printf '%s' "${user_input}" | tr '[:upper:]' '[:lower:]');;
    f|F) data=$(printf '%s' "${user_input}" | tr '[:lower:]' '[:upper:]');;
    *) data="${user_input}";;
  esac
  if [[ ! $data =~ ^[a-zA-Z0-9_.-]+$ ]]; then echo "invalid"; exit 1; fi
  processed="$data"
  normalized=$(echo "$processed" | iconv -f UTF-8 -t ASCII//TRANSLIT 2>/dev/null || echo "$processed")
  printf "Content-Type: text/html\r\n\r\n"
  printf "<p>%s</p>" "$normalized"
}

benchmark_test_00251 "$@"
