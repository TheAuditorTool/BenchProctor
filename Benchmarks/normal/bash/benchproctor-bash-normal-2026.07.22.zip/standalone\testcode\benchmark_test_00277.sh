#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00277() {
  user_input="$HTTP_X_CUSTOM_HEADER"
  set -- "$user_input" "http"
  data="$1"
  checked_path=$(realpath -m "/var/app/data/$data")
  if [[ ! "$checked_path" == /var/app/data/* ]]; then echo "forbidden" >&2; exit 1; fi
  cat "$checked_path"
}

benchmark_test_00277 "$@"
