#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00306() {
  user_input="$(jq -r '.value // empty' 2>/dev/null)"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  if [ -z "$data" ]; then echo "specific: empty input" >&2; exit 2; fi
}

benchmark_test_00306 "$@"
