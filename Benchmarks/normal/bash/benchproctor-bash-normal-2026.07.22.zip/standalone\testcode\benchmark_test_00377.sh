#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00377() {
  user_input="$USER_COMMENT"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  if [ "$USER_ROLE" != "admin" ]; then echo "forbidden" >&2; exit 1; fi
  if ! grep -qxF -- "$USER:$data" /etc/app/acl; then
    echo "403 forbidden" >&2
    exit 1
  fi
}

benchmark_test_00377 "$@"
