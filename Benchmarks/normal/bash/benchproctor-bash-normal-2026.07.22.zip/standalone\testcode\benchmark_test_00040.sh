#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00040() {
  user_input="$(cat /dev/stdin)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  _body=$(curl -s "$data")
  printf "%s" "$_body" > /var/app/feed.dat
}

benchmark_test_00040 "$@"
