#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00189() {
  user_input="$HTTP_USER_AGENT"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  printf "%s" "$data" > /var/www/html/exports/report.dat
}

benchmark_test_00189 "$@"
