#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00239() {
  user_input="$(cat /dev/stdin)"
  read -ra _parts <<< "${user_input}"
  data="${_parts[*]}"
  normalized=$(echo "$data" | iconv -f UTF-8 -t ASCII//TRANSLIT 2>/dev/null || echo "$data")
  printf "Content-Type: text/html\r\n\r\n"
  printf "<p>%s</p>" "$normalized"
}

benchmark_test_00239 "$@"
