#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00475() {
  user_input="$PATH_INFO"
  REQUEST_LAST_INPUT="$user_input"
  data="$REQUEST_LAST_INPUT"
  local -a _cmd=("echo" "$data")
  "${_cmd[@]}"
}

benchmark_test_00475 "$@"
