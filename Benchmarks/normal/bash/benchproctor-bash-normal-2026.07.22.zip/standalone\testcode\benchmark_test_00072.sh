#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00072() {
  user_input="$(mysql -N -e 'SELECT name FROM users LIMIT 1')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  xmllint --xpath "//user[name='$data']" /var/data/users.xml
}

benchmark_test_00072 "$@"
