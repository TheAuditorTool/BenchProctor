#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00146() {
  user_input="$(sed -n '/^\r*$/{n;s/\r$//;p;q}')"
  data=$(IFS=","; read -ra _items <<< "$user_input"; printf "%s" "${_items[*]}")
  case "$data" in
    https://app.shcdn.net|https://cdn.shcdn.net) allowed_origin="$data";;
    *) echo "forbidden origin" >&2; exit 1;;
  esac
  printf '%s\r\n' "Access-Control-Allow-Origin: $allowed_origin"
}

benchmark_test_00146 "$@"
