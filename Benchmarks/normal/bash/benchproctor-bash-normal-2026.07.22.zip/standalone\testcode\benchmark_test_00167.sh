#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00167() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _len_guard() { [ "${#1}" -le 8192 ]; }
  _normalize() { printf "%s" "$1" | sed "s/^[[:blank:]]*//;s/[[:blank:]]*$//"; }
  declare -A _handlers=([guard]=_len_guard [normalize]=_normalize)
  data=""
  if "${_handlers[guard]}" "$user_input"; then data=$("${_handlers[normalize]}" "$user_input"); fi
  chown -- "$data" /var/app/run/worker.pid 2>/dev/null
}

benchmark_test_00167 "$@"
