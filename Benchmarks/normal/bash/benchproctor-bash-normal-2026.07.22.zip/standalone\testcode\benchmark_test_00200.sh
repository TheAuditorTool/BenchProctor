#!/bin/bash
# SPDX-License-Identifier: Apache-2.0

benchmark_test_00200() {
  user_input="$HTTP_X_FORWARDED_FOR"
  _captured="${user_input}"
  make_reader() { printf "%s\n" "$_captured"; }
  data=$(make_reader)
  _schema_re='^[A-Za-z0-9_ @-]+$'
  if [[ ! "$data" =~ $_schema_re ]]; then echo "invalid schema" >&2; exit 1; fi
  processed="$data"
  printf "X-Custom: %s\r\n" "$processed"
}

benchmark_test_00200 "$@"
