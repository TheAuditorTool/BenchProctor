// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00189(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    FILE *_log = fopen("/var/log/app.log", "a");
    if (_log) { fprintf(_log, "actor=%s action=processed\n", data); fclose(_log); }
}
