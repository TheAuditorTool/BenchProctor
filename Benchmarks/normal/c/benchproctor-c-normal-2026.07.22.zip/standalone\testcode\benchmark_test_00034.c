// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00034(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    char data[512];
    switch (user_input[0]) {
        case '\0':
            data[0] = '\0';
            break;
        default:
            snprintf(data, sizeof(data), "%s", user_input);
            break;
    }
    char _tmpl[] = "/tmp/app.XXXXXX";
    int _tfd = mkstemp(_tmpl);
    if (_tfd >= 0) {
        ssize_t _wn = write(_tfd, data, strlen(data));
        (void)_wn;
        close(_tfd);
    }
}
