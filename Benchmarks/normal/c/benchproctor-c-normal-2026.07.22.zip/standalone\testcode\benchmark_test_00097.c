// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00097(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    const char *data = "";
    if (strlen(user_input) > 0) data = user_input;
    char _dst[16] = "abcdefghijklmno";
    int _off = atoi(data) - 8;
    if (_off >= 0 && _off < (int)sizeof(_dst)) _dst[_off] = 'X';
    printf("%s\n", _dst);
}
