// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00413(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    const char *data = (strlen(user_input) > 0) ? user_input : "";
    long _v = strtol(data, NULL, 10);
    if (_v < 0 || _v > 4294967295L) return;
    unsigned int _u = (unsigned int)_v;
    printf("%u\n", _u);
}
