// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00185(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    char _stackbuf[64];
    strncpy(_stackbuf, user_input, sizeof(_stackbuf) - 1);
    _stackbuf[sizeof(_stackbuf) - 1] = '\0';
    char *_p = _stackbuf;
    free(_p);
}
