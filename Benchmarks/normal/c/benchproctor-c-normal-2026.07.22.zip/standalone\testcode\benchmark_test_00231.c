// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00231(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    char data[512];
    snprintf(data, sizeof(data), "%s", user_input);
    char _dst[16] = "abcdefghijklmno";
    int _off = atoi(data) - 8;
    if (_off >= 0 && _off < (int)sizeof(_dst)) _dst[_off] = 'X';
    printf("%s\n", _dst);
}
