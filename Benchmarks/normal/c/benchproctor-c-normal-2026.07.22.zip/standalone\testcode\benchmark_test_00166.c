// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct ldap LDAP;
typedef struct ldapmsg LDAPMessage;
#define LDAP_SCOPE_SUBTREE 2
extern int ldap_search_ext_s(LDAP *_ld, const char *_base, int _scope, const char *_filter, char **_attrs, int _attrsonly, void *_sc, void *_cc, void *_tmo, int _slim, LDAPMessage **_res);
static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00166(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    const char *data = c_passthrough(user_input);
    LDAP *_ld = NULL;
    char _filter[512];
    snprintf(_filter, sizeof(_filter), "(uid=%s)", data);
    LDAPMessage *_res = NULL;
    ldap_search_ext_s(_ld, "ou=people,dc=example,dc=com", LDAP_SCOPE_SUBTREE, _filter, NULL, 0, NULL, NULL, NULL, 0, &_res);
}
