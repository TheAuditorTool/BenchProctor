// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <libgen.h>

void benchmark_test_00096(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    char _bn_copy[512];
    snprintf(_bn_copy, sizeof(_bn_copy), "%s", user_input);
    const char *safe = basename(_bn_copy);
    FILE *_f = fopen(safe, "r");
    if (_f) fclose(_f);
}
