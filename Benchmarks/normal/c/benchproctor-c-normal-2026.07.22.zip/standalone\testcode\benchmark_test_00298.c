// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>

static const char *_shared;
static pthread_mutex_t _mu = PTHREAD_MUTEX_INITIALIZER;
static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00298(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    const char *(*_fn)(const char *) = c_passthrough;
    const char *data = _fn(user_input);
    pthread_mutex_lock(&_mu);
    _shared = data;
    pthread_mutex_unlock(&_mu);
}
