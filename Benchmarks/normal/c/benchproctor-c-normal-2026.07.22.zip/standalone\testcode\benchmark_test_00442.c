// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00442(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    char data[512];
    snprintf(data, sizeof(data), "prefix-%s", user_input);
    char _stackbuf[64];
    strncpy(_stackbuf, data, sizeof(_stackbuf) - 1);
    _stackbuf[sizeof(_stackbuf) - 1] = '\0';
    char *_p = _stackbuf;
    printf("%s\n", _p);
}
