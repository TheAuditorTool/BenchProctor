// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>

static const char *_shared;
static pthread_mutex_t _mu = PTHREAD_MUTEX_INITIALIZER;
struct c_payload { const char *value; };

void benchmark_test_00108(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    pthread_mutex_lock(&_mu);
    _shared = data;
    pthread_mutex_unlock(&_mu);
}
