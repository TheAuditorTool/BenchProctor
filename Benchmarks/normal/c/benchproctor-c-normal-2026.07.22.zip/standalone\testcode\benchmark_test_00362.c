// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00362(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    printf(data);
    printf("\n");
}
