// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>

void benchmark_test_00470(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    char data[512];
    snprintf(data, sizeof(data), "%s", user_input);
    FILE *_tf = fopen("/tmp/app_export.tmp", "w");
    if (_tf) { fputs(data, _tf); fclose(_tf); }
    chmod("/tmp/app_export.tmp", 0777);
}
