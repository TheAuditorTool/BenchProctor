// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00019(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    const char *data = c_passthrough(user_input);
    char _buf[16] = "fixedcontent12";
    int _i = atoi(data) - 8;
    if (_i >= 0 && _i < (int)sizeof(_buf)) printf("%c\n", _buf[_i]);
}
