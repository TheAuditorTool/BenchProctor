// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_payload { const char *value; };

void benchmark_test_00208(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    char _tmpl[] = "/tmp/app.XXXXXX";
    int _tfd = mkstemp(_tmpl);
    if (_tfd >= 0) {
        ssize_t _wn = write(_tfd, data, strlen(data));
        (void)_wn;
        close(_tfd);
    }
}
