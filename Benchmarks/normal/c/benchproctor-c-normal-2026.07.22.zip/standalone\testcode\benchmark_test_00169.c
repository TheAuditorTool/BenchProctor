// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef void CURL;
#define CURLOPT_URL 10002
#define CURLOPT_SSL_VERIFYPEER 64
#define CURLOPT_SSL_VERIFYHOST 81
extern CURL *curl_easy_init(void);
extern int curl_easy_setopt(CURL *_handle, int _option, ...);
extern int curl_easy_perform(CURL *_handle);
extern void curl_easy_cleanup(CURL *_handle);

void benchmark_test_00169(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    char data[512];
    snprintf(data, sizeof(data), "prefix-%s", user_input);
    CURL *_curl = curl_easy_init();
    char _url[512];
    snprintf(_url, sizeof(_url), "http://api.internal.svc/ingest?d=%s", data);
    curl_easy_setopt(_curl, CURLOPT_URL, _url);
    curl_easy_perform(_curl);
    curl_easy_cleanup(_curl);
}
