// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);

void benchmark_test_00279(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    if (strcmp(user_input, "hunter2_default_pw") == 0) { printf("auth ok\n"); }
}
