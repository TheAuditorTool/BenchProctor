// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00049(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/etc/app/config", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    const char *data = "";
    if (strlen(user_input) > 0) data = user_input;
    char _field[600];
    size_t _fi = 0;
    if (data[0] == '=' || data[0] == '+' || data[0] == '-' || data[0] == '@') _field[_fi++] = '\'';
    for (const char *_q = data; *_q && _fi < sizeof(_field) - 2; ++_q) {
        if (*_q == '"') _field[_fi++] = '"';
        _field[_fi++] = *_q;
    }
    _field[_fi] = '\0';
    FILE *_cf = fopen("/var/app/data/export.csv", "a");
    if (_cf) { fprintf(_cf, "\"%s\",exported\n", _field); fclose(_cf); }
}
