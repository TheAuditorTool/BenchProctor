// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <regex.h>

static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00011(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    const char *data = c_invoke(c_passthrough, user_input);
    regex_t _re;
    const char *safe = data;
    if (regcomp(&_re, "^[a-zA-Z0-9_-]+$", REG_EXTENDED) == 0) {
        if (regexec(&_re, data, 0, NULL, 0) != 0) safe = "config";
        regfree(&_re);
    }
    char *const _argv[] = { "/usr/bin/tar", "-cf", "/tmp/backup.tar", (char *)safe, NULL };
    execv("/usr/bin/tar", _argv);
}
