// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>

struct c_payload { const char *value; };

void benchmark_test_00331(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    FILE *_tf = fopen("/tmp/app_export.tmp", "w");
    if (_tf) { fputs(data, _tf); fclose(_tf); }
    chmod("/tmp/app_export.tmp", 0777);
}
