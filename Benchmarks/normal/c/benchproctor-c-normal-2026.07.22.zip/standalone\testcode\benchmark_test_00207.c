// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00207(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    char data[512];
    size_t _len = strlen(user_input);
    size_t _w = 0;
    while (_w < _len && _w < sizeof(data) - 1) { data[_w] = user_input[_w]; ++_w; }
    data[_w] = '\0';
    long _sz = strtol(data, NULL, 10);
    if (_sz <= 0 || _sz > 65536) return;
    char *_dst = malloc((size_t)_sz + 1);
    if (_dst) { strncpy(_dst, data, (size_t)_sz); _dst[_sz] = '\0'; free(_dst); }
}
