// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <dlfcn.h>

static const char *c_shared_input;

void benchmark_test_00001(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    const char *safe = data;
    if (strcmp(data, "/bin/echo") != 0 && strcmp(data, "/bin/cat") != 0) safe = "/bin/echo";
    void *_h = dlopen(safe, RTLD_NOW);
    if (_h) dlclose(_h);
}
