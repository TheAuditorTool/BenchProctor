// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

extern unsigned char *MD5(const unsigned char *d, unsigned long n, unsigned char *md);
extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00299(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    const char *data = c_invoke(c_passthrough, user_input);
    unsigned char _digest[32];
    SHA256((const unsigned char *)data, strlen(data), _digest);
}
