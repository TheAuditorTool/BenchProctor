// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00052(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    const char *data = c_invoke(c_passthrough, user_input);
    char *const _argv[] = { "/bin/echo", (char *)data, NULL };
    execv("/bin/echo", _argv);
}
