// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00426(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    int _v = atoi(data);
    switch (_v) {
        case 1: printf("one\n"); break;
        case 2: printf("two\n"); break;
        default: break;
    }
}
