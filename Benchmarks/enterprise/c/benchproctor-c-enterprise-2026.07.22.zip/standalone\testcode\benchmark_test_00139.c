// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <fcntl.h>

static const char *c_shared_input;

void benchmark_test_00139(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    char _trunc[65];
    snprintf(_trunc, sizeof(_trunc), "%s", data);
    const char *safe = _trunc;
    char _path[512];
    snprintf(_path, sizeof(_path), "/var/app/data/%s", safe);
    int _fd = open(_path, O_RDONLY);
    if (_fd >= 0) close(_fd);
}
