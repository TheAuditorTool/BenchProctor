// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef void CURL;
#define CURLOPT_URL 10002
#define CURLOPT_SSL_VERIFYPEER 64
#define CURLOPT_SSL_VERIFYHOST 81
extern CURL *curl_easy_init(void);
extern int curl_easy_setopt(CURL *_handle, int _option, ...);
extern int curl_easy_perform(CURL *_handle);
extern void curl_easy_cleanup(CURL *_handle);
struct c_payload { const char *value; };

void benchmark_test_00252(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    const char *safe = data;
    if (strncmp(data, "https://api.internal.svc/", 25) != 0 && strncmp(data, "https://cdn.internal.svc/", 25) != 0) safe = "https://api.internal.svc/data";
    CURL *_curl = curl_easy_init();
    curl_easy_setopt(_curl, CURLOPT_URL, safe);
    curl_easy_perform(_curl);
    curl_easy_cleanup(_curl);
}
