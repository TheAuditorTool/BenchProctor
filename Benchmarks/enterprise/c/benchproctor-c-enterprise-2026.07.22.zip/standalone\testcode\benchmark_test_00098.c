// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
typedef struct evp_cipher_st EVP_CIPHER;
typedef struct engine_st ENGINE;
extern EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);
extern void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *_ctx);
extern const EVP_CIPHER *EVP_des_ecb(void);
extern const EVP_CIPHER *EVP_rc4(void);
extern const EVP_CIPHER *EVP_aes_256_cbc(void);
extern const EVP_CIPHER *EVP_aes_256_gcm(void);
extern int EVP_EncryptInit_ex(EVP_CIPHER_CTX *_ctx, const EVP_CIPHER *_type, ENGINE *_impl, const unsigned char *_key, const unsigned char *_iv);
extern int EVP_EncryptUpdate(EVP_CIPHER_CTX *_ctx, unsigned char *_out, int *_outl, const unsigned char *_in, int _inl);
extern int RAND_bytes(unsigned char *_buf, int _num);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00098(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    long _clen = 0;
    const char *_cl = getenv("CONTENT_LENGTH");
    if (_cl != NULL) _clen = strtol(_cl, NULL, 10);
    if (_clen > 0) {
        size_t _rn = (size_t)_clen < sizeof(user_input_buf) - 1 ? (size_t)_clen : sizeof(user_input_buf) - 1;
        size_t _got = fread(user_input_buf, 1, _rn, stdin);
        user_input_buf[_got] = '\0';
    }
    const char *user_input = user_input_buf;
    const char *data = c_invoke(c_passthrough, user_input);
    EVP_CIPHER_CTX *_ctx = EVP_CIPHER_CTX_new();
    unsigned char _ct[512];
    int _ctl = 0;
    EVP_EncryptInit_ex(_ctx, EVP_des_ecb(), NULL, (const unsigned char *)"legacyk8", NULL);
    EVP_EncryptUpdate(_ctx, _ct, &_ctl, (const unsigned char *)data, (int)strlen(data));
    EVP_CIPHER_CTX_free(_ctx);
}
