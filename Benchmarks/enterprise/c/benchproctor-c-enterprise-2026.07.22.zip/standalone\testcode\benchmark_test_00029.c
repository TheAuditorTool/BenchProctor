// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00029(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    long _sz = strtol(user_input, NULL, 10);
    if (_sz <= 0 || _sz > 65536) return;
    char *_dst = malloc((size_t)_sz + 1);
    if (_dst) { strncpy(_dst, user_input, (size_t)_sz); _dst[_sz] = '\0'; free(_dst); }
}
