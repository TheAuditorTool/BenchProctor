// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00166(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("USER_INPUT");
    if (user_input == NULL) user_input = "";
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    char _path[512];
    snprintf(_path, sizeof(_path), "/var/app/data/%s", data);
    if (remove(_path) != 0) return;
}
