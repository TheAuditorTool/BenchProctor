// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>

void benchmark_test_00352(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    char data[512];
    size_t _len = strlen(user_input);
    size_t _w = 0;
    while (_w < _len && _w < sizeof(data) - 1) { data[_w] = user_input[_w]; ++_w; }
    data[_w] = '\0';
    char _tmpl[] = "/tmp/app.XXXXXX";
    int _tfd = mkstemp(_tmpl);
    if (_tfd >= 0) {
        ssize_t _wn = write(_tfd, data, strlen(data));
        (void)_wn;
        close(_tfd);
    }
}
