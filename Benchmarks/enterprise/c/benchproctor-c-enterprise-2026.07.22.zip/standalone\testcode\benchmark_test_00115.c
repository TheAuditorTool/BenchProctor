// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct rsa_st RSA;
#define RSA_PKCS1_PADDING 1
#define RSA_PKCS1_OAEP_PADDING 4
extern RSA *RSA_new(void);
extern void RSA_free(RSA *_rsa);
extern int RSA_public_encrypt(int _flen, const unsigned char *_from, unsigned char *_to, RSA *_rsa, int _padding);
static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00115(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/etc/app/config", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    const char *(*_fn)(const char *) = c_passthrough;
    const char *data = _fn(user_input);
    RSA *_rsa = RSA_new();
    unsigned char _enc[512];
    RSA_public_encrypt((int)strlen(data), (const unsigned char *)data, _enc, _rsa, RSA_PKCS1_OAEP_PADDING);
    RSA_free(_rsa);
}
