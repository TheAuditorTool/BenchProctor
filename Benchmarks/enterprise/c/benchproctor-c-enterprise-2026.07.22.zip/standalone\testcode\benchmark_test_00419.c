// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>

struct c_ctx { const char *captured; };
static const char *c_capture(const struct c_ctx *c) { return c->captured; }

void benchmark_test_00419(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/tmp/data", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    struct c_ctx _ctx = { user_input };
    const char *data = c_capture(&_ctx);
    char _path[512];
    snprintf(_path, sizeof(_path), "/var/app/data/%s", data);
    chmod(_path, 0777);
}
