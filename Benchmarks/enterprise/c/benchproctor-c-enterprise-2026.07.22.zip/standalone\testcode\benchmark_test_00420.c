// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00420(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    if (fgets(user_input_buf, sizeof(user_input_buf), stdin) == NULL) user_input_buf[0] = '\0';
    user_input_buf[strcspn(user_input_buf, "\n")] = '\0';
    const char *user_input = user_input_buf;
    c_shared_input = user_input;
    const char *data = c_shared_input;
    char _trunc[65];
    snprintf(_trunc, sizeof(_trunc), "%s", data);
    const char *safe = _trunc;
    long _n = strtol(safe, NULL, 10);
    char *_buf = malloc((size_t)_n);
    if (_buf) free(_buf);
}
