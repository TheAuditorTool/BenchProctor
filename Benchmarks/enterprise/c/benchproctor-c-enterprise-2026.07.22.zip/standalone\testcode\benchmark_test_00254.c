// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00254(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    long _v = strtol(data, NULL, 10);
    if (_v < 0 || _v > 4294967295L) return;
    unsigned int _u = (unsigned int)_v;
    printf("%u\n", _u);
}
