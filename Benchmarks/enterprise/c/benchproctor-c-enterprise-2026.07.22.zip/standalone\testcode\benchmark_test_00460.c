// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef void CURL;
#define CURLOPT_URL 10002
#define CURLOPT_SSL_VERIFYPEER 64
#define CURLOPT_SSL_VERIFYHOST 81
extern CURL *curl_easy_init(void);
extern int curl_easy_setopt(CURL *_handle, int _option, ...);
extern int curl_easy_perform(CURL *_handle);
extern void curl_easy_cleanup(CURL *_handle);
static const char *c_shared_input;

void benchmark_test_00460(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    CURL *_curl = curl_easy_init();
    char _url[512];
    snprintf(_url, sizeof(_url), "http://api.internal.svc/ingest?d=%s", data);
    curl_easy_setopt(_curl, CURLOPT_URL, _url);
    curl_easy_perform(_curl);
    curl_easy_cleanup(_curl);
}
