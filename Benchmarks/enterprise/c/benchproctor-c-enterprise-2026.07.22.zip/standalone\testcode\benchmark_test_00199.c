// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

void benchmark_test_00199(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    const char *data = (strlen(user_input) > 0) ? user_input : "";
    long _n = strtol(data, NULL, 10);
    if (_n < 0 || _n > 1048576) return;
    char *_buf = malloc((size_t)_n);
    if (_buf) free(_buf);
}
