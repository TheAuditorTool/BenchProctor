// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00369(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    const char *safe = data;
    if (strcmp(data, "asc") != 0 && strcmp(data, "desc") != 0) safe = "asc";
    FILE *_cf = fopen("/var/app/data/export.csv", "a");
    if (_cf) { fprintf(_cf, "%s,exported\n", safe); fclose(_cf); }
}
