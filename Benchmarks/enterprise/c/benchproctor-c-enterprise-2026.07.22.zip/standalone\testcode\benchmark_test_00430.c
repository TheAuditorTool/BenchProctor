// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef struct rsa_st RSA;
#define RSA_PKCS1_PADDING 1
#define RSA_PKCS1_OAEP_PADDING 4
extern RSA *RSA_new(void);
extern void RSA_free(RSA *_rsa);
extern int RSA_public_encrypt(int _flen, const unsigned char *_from, unsigned char *_to, RSA *_rsa, int _padding);
struct c_payload { const char *value; };

void benchmark_test_00430(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("DB_ROW_VALUE");
    if (user_input == NULL) user_input = "";
    struct c_payload _pd;
    _pd.value = user_input;
    const char *data = _pd.value;
    RSA *_rsa = RSA_new();
    unsigned char _enc[512];
    RSA_public_encrypt((int)strlen(data), (const unsigned char *)data, _enc, _rsa, RSA_PKCS1_OAEP_PADDING);
    RSA_free(_rsa);
}
