// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/types.h>

static const char *c_shared_input;

void benchmark_test_00013(int argc, char **argv)
{
    const char *user_input = (argc > 1) ? argv[1] : "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    int _uid = atoi(data);
    setuid((uid_t)_uid);
}
