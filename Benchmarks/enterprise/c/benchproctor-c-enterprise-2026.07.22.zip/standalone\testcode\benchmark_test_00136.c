// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

typedef void CURL;
#define CURLOPT_URL 10002
#define CURLOPT_SSL_VERIFYPEER 64
#define CURLOPT_SSL_VERIFYHOST 81
extern CURL *curl_easy_init(void);
extern int curl_easy_setopt(CURL *_handle, int _option, ...);
extern int curl_easy_perform(CURL *_handle);
extern void curl_easy_cleanup(CURL *_handle);
static const char *c_passthrough(const char *s) { return s; }
static const char *c_invoke(const char *(*fn)(const char *), const char *s) { return fn(s); }

void benchmark_test_00136(int argc, char **argv)
{
    (void)argc; (void)argv;
    char user_input_buf[256];
    user_input_buf[0] = '\0';
    FILE *_src_fp = fopen("/tmp/data", "r");
    if (_src_fp != NULL) {
        if (fgets(user_input_buf, sizeof(user_input_buf), _src_fp) == NULL) user_input_buf[0] = '\0';
        fclose(_src_fp);
    }
    const char *user_input = user_input_buf;
    const char *data = c_invoke(c_passthrough, user_input);
    if (getenv("APP_ENV") == NULL || strcmp(getenv("APP_ENV"), "test") != 0) {
        CURL *_curl = curl_easy_init();
        curl_easy_setopt(_curl, CURLOPT_URL, data);
        curl_easy_perform(_curl);
        curl_easy_cleanup(_curl);
    }
}
