// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

extern unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);
static const char *c_passthrough(const char *s) { return s; }

void benchmark_test_00280(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    const char *data = c_passthrough(user_input);
    const char *_cred = getenv("APP_DB_PASSWORD");
    if (_cred == NULL) _cred = "";
    if (strcmp(data, _cred) == 0) { printf("auth ok\n"); }
}
