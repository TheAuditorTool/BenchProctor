// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

static const char *c_shared_input;

void benchmark_test_00274(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *user_input = getenv("QUERY_STRING");
    if (user_input == NULL) user_input = "";
    c_shared_input = user_input;
    const char *data = c_shared_input;
    int _sz = atoi(data);
    const char *_payload = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    char *_dst = malloc((size_t)(_sz + 1));
    if (_dst) { strcpy(_dst, _payload); free(_dst); }
}
