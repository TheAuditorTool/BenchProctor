// SPDX-License-Identifier: Apache-2.0

const BenchmarkTest00007 = async (ctx) => {
  const userInput = (ctx.request.files && ctx.request.files.file && ctx.request.files.file.name) || "";
  const [data] = String(userInput).split(',');
  eval(data);
  ctx.body = { ack: true };
}

module.exports = { BenchmarkTest00007 };
