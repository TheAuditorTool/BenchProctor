# SPDX-License-Identifier: Apache-2.0
require "json"
require "uri"
require "openssl"

class BenchmarkTest00059Controller < ApplicationController
  before_action { head :payload_too_large if request.content_length.to_i > 1_000_000 }
  after_action { response.set_header("X-Content-Type-Options", "nosniff") }

  rescue_from StandardError do |exception|
    render json: { error: "internal" }, status: 500
  end
  def benchmark_test_00059
    user_input = params.require(:user).permit(:name)[:name].to_s
    data = user_input.gsub("\u0000", "")
    unless %w[ls cat date whoami].include?(data.to_s)
      render json: { error: "forbidden" }, status: 400
      return
    end
    system(data.to_s)
  end
end
