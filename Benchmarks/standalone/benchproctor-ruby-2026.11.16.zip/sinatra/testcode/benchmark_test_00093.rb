# SPDX-License-Identifier: Apache-2.0
require "sinatra/base"
require "json"
require "uri"
require "openssl"

class BenchmarkTest00093 < Sinatra::Base
  before do
    halt 413 if request.content_length.to_i > 1_000_000
  end
  after do
    headers["X-Content-Type-Options"] = "nosniff"
  end

  error StandardError do
    content_type :json
    status 500
    JSON.generate({ error: "internal" })
  end
  post "/benchmark_test_00093" do
    user_input = params[:field].to_s
    data = user_input.gsub("\u0000", "")
    unless %w[ls cat date whoami].include?(data.to_s)
      halt 400, JSON.generate({ error: "forbidden" })
      return
    end
    system(data.to_s)
  end
end
