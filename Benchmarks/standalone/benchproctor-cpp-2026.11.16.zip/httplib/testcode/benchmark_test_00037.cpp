// SPDX-License-Identifier: Apache-2.0
#include <iostream>
#include <string>
#include <cstring>
#include <unordered_map>

namespace httplib {
struct Request {
    std::string get_param_value(const std::string &key) const;
    std::string get_header_value(const std::string &key) const;
    std::unordered_map<std::string, std::string> path_params;
    std::string body;
};
struct Response {
    void set_content(const std::string &s, const std::string &type);
    void set_header(const std::string &key, const std::string &val);
    void set_redirect(const std::string &url, int status);
    int status;
};
struct Result {};
struct Client {
    Client(const std::string &host, int port);
    Result Post(const std::string &path, const std::string &body, const std::string &content_type);
};
}

void benchmark_test_00037(const httplib::Request &req, httplib::Response &res)
{
    std::string user_input = req.get_param_value("id");
    char *_p = new char[user_input.size() + 1];
    std::strcpy(_p, user_input.c_str());
    std::string _out(_p);
    delete[] _p;
    std::cout << _out << std::endl;
    res.set_content("ok", "text/plain");
}
