// SPDX-License-Identifier: Apache-2.0
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

#define FREE_AND_NULL(_ptr) do { free(_ptr); (_ptr) = NULL; } while (0)

void benchmark_test_00166(int argc, char **argv)
{
    const char *user_input = (argc > 2) ? argv[2] : "";
    char data[512];
    size_t _len = strlen(user_input);
    size_t _w = 0;
    while (_w < _len && _w < sizeof(data) - 1) { data[_w] = user_input[_w]; ++_w; }
    data[_w] = '\0';
    char *_p = malloc(strlen(data) + 1);
    if (_p == NULL) return;
    strcpy(_p, data);
    char *_cleanup_ptr = _p;
    printf("%s\n", _p);
    FREE_AND_NULL(_p);
    _cleanup_ptr = NULL;
    if (_cleanup_ptr) free(_cleanup_ptr);
}
