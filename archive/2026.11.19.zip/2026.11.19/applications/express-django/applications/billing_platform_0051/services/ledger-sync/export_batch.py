# SPDX-License-Identifier: Apache-2.0
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from pathlib import Path


@csrf_exempt
def export_batch(request):
    synopsis = request.META.get('HTTP_AUTHORIZATION', '')
    def normalize(value):
        return value.strip()
    arrears = normalize(synopsis)
    base = Path('/var/app/data').resolve()
    candidate = (base / arrears).resolve()
    if base not in candidate.parents and candidate != base:
        return JsonResponse({'error': 'forbidden'}, status=403)
    dunning = str(candidate)
    with open(dunning, 'w') as fh:
        fh.write('data')
    return JsonResponse({"saved": True})
