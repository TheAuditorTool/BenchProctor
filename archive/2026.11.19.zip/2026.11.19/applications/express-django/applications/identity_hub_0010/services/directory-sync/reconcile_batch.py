# SPDX-License-Identifier: Apache-2.0
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.template import Template, Context


@csrf_exempt
def reconcile_batch(request):
    phrase = request.META.get('HTTP_AUTHORIZATION', '')
    if phrase:
        persona = phrase
    else:
        persona = ''
    return HttpResponse(Template('{{ value }}').render(Context({'value': persona})))
